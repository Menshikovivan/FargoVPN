from pathlib import Path
import sys, tarfile, tempfile, types
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'app'))


def test_rollback_archive_without_version_is_accepted(monkeypatch):
    import update_manager
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        backup_dir = root / 'backups'; backup_dir.mkdir()
        archive = backup_dir / 'pre_update_20260817_120000.tar.gz'
        tree = root / 'old' / 'vpn-service'
        (tree / 'app').mkdir(parents=True)
        (tree / 'app' / 'main.py').write_text('old')
        (tree / 'install.sh').write_text('#!/bin/sh\n')
        with tarfile.open(archive, 'w:gz') as tar:
            tar.add(tree, arcname='vpn-service')
        monkeypatch.setattr(update_manager, '_preupdate_backup_root', lambda: backup_dir.resolve())
        validated = update_manager.validate_preupdate_backup(str(archive))
        assert validated == archive.resolve()
        assert update_manager._preupdate_version(archive) == ''


def _make_archive(tmp_path, arcname, files):
    source = tmp_path / "source"
    for rel in files:
        path = source / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("x", encoding="utf-8")
    archive = tmp_path / (arcname.replace("/", "_") + ".tar.gz")
    with tarfile.open(archive, "w:gz") as tar:
        tar.add(source, arcname=arcname)
    return archive


def test_real_installer_snapshot_root_is_detected(tmp_path):
    import update_manager
    archive = _make_archive(tmp_path, "vpn_bot", ["main.py", "config.py", "webapp.py"])
    assert update_manager._preupdate_archive_root(archive) == "vpn_bot"


def test_nested_app_snapshot_root_is_detected(tmp_path):
    import update_manager
    archive = _make_archive(tmp_path, "legacy", ["app/main.py", "app/config.py", "app/webapp.py"])
    assert update_manager._preupdate_archive_root(archive) == "legacy/app"
