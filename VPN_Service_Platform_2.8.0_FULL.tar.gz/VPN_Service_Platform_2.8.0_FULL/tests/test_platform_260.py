from __future__ import annotations

import io
import sqlite3
import tarfile
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from test_core import fake_config, reload_module


class Platform260Tests(unittest.TestCase):
    def test_identity_archive_ignores_unrelated_symlinks(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.IDENTITY_IMPORT_DIR = str(temp / "imports")
            init_db = reload_module("init_db", config)
            init_db.migrate()

            legacy_db = temp / "legacy.db"
            connection = sqlite3.connect(legacy_db)
            try:
                connection.execute(
                    "CREATE TABLE users(tg_id INTEGER, username TEXT, email TEXT, uuid TEXT)"
                )
                connection.execute(
                    "INSERT INTO users VALUES(?,?,?,?)",
                    (123456, "legacy_user", "legacy@example", "legacy-uuid"),
                )
                connection.commit()
            finally:
                connection.close()

            archive = temp / "legacy-full.tar.gz"
            with tarfile.open(archive, "w:gz") as handle:
                handle.add(legacy_db, arcname="backup/database/vpn.db")
                symlink = tarfile.TarInfo("backup/venv/bin/python")
                symlink.type = tarfile.SYMTYPE
                symlink.linkname = "/usr/bin/python3"
                handle.addfile(symlink, io.BytesIO())

            migration = reload_module("identity_migration", config)
            selected, rows, reports = migration.select_best_database(archive)
            try:
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0].tg_id, 123456)
                self.assertEqual(sum(item["rows"] for item in reports), 1)
            finally:
                selected.unlink(missing_ok=True)

    def test_persistent_login_rate_limit_and_diagnostic_count(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.WEB_LOGIN_MAX_ATTEMPTS = 3
            config.WEB_LOGIN_WINDOW_SECONDS = 120
            config.WEB_LOGIN_BLOCK_SECONDS = 60
            config.WEB_LOGIN_MAX_BLOCK_SECONDS = 600
            security = reload_module("auth_security", config)

            self.assertTrue(security.check_login("10.0.0.1", "admin", now=1_000).allowed)
            self.assertTrue(security.record_failure("10.0.0.1", "admin", now=1_000).allowed)
            self.assertTrue(security.record_failure("10.0.0.1", "admin", now=1_001).allowed)
            blocked = security.record_failure("10.0.0.1", "admin", now=1_002)
            self.assertFalse(blocked.allowed)
            self.assertEqual(blocked.retry_after, 60)
            self.assertFalse(security.check_login("10.0.0.1", "admin", now=1_010).allowed)

            diagnostics = reload_module("diagnostics", config)
            # Use a current epoch lock so the SQL diagnostic can count it.
            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute("UPDATE login_security SET blocked_until=CAST(strftime('%s','now') AS INTEGER)+60")
                connection.commit()
            finally:
                connection.close()
            self.assertEqual(diagnostics.database_report(config.DB_PATH)["blocked_logins"], 1)

            security.record_success("10.0.0.1", "admin", db_path=config.DB_PATH)
            self.assertTrue(security.check_login("10.0.0.1", "admin", now=1_010).allowed)

            # A rotating username must not bypass the global per-IP bucket.
            self.assertTrue(
                security.record_failure(
                    "10.0.0.2", security.GLOBAL_USERNAME_KEY, now=2_000
                ).allowed
            )
            self.assertTrue(
                security.record_failure(
                    "10.0.0.2", security.GLOBAL_USERNAME_KEY, now=2_001
                ).allowed
            )
            global_block = security.record_failure(
                "10.0.0.2", security.GLOBAL_USERNAME_KEY, now=2_002
            )
            self.assertFalse(global_block.allowed)
            self.assertFalse(
                security.check_login(
                    "10.0.0.2", security.GLOBAL_USERNAME_KEY, now=2_010
                ).allowed
            )

    def test_traffic_deduplication_and_authoritative_inbound_total(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            xui = reload_module("services.xui_api", config)
            clients, duplicate_count = xui.deduplicate_clients(
                [
                    {
                        "email": "Alice@Example",
                        "uuid": "uuid-a",
                        "up": 100,
                        "down": 200,
                        "total": 1000,
                        "inbound_ids": [1],
                        "enable": True,
                    },
                    {
                        "email": "alice@example",
                        "uuid": "uuid-b",
                        "up": 80,
                        "down": 250,
                        "total": 900,
                        "inbound_ids": [2],
                        "enable": False,
                    },
                    {"email": "bob@example", "uuid": "uuid-c", "up": 10, "down": 20, "inbound_ids": [1]},
                ]
            )
            self.assertEqual(duplicate_count, 1)
            self.assertEqual(len(clients), 2)
            alice = next(item for item in clients if item["email"].lower() == "alice@example")
            self.assertEqual((alice["up"], alice["down"]), (100, 250))
            self.assertEqual(alice["inbound_ids"], [1, 2])
            self.assertEqual(set(alice["credential_variants"]), {"uuid-a", "uuid-b"})

            server_summary = xui.summarize_server_traffic(
                {"netTraffic": {"sent": 1234, "recv": 5678}}
            )
            self.assertEqual(server_summary["used"], 6912)
            self.assertEqual(server_summary["source"], "server-status")

            summary = xui.summarize_inbound_traffic(
                [
                    {"id": 1, "up": 1000, "down": 2000, "enable": True},
                    {"id": 2, "up": 3000, "down": 4000, "enable": False},
                ]
            )
            self.assertEqual(summary["used"], 10_000)
            self.assertEqual(summary["enabled_used"], 3_000)
            self.assertEqual(summary["source"], "inbounds")

    def test_xui_sync_repairs_placeholder_and_moves_history(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            init_db = reload_module("init_db", config)
            init_db.migrate()
            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute(
                    "INSERT INTO users(tg_id,username,uuid,email,expiry_time,enable) VALUES(?,?,?,?,?,?)",
                    (-77, "legacy", "same-uuid", "same@example", 0, 1),
                )
                connection.execute(
                    "INSERT INTO user_events(tg_id,direction,event_type,text) VALUES(?,?,?,?)",
                    (-77, "in", "message", "hello"),
                )
                connection.commit()
            finally:
                connection.close()

            xui = reload_module("services.xui_api", config)
            xui.sync_snapshot_to_db(
                {
                    "clients": [
                        {
                            "email": "same@example",
                            "uuid": "same-uuid",
                            "tg_id": 123456789,
                            "expiry_time": 1_900_000_000_000,
                            "enable": True,
                            "up": 1,
                            "down": 2,
                            "total": 100,
                            "sub_id": "sub",
                        }
                    ]
                },
                config.DB_PATH,
            )
            connection = sqlite3.connect(config.DB_PATH)
            try:
                user = connection.execute(
                    "SELECT tg_id,identity_source,identity_updated_at FROM users"
                ).fetchone()
                event_tg = connection.execute("SELECT tg_id FROM user_events").fetchone()[0]
            finally:
                connection.close()
            self.assertEqual(user[0], 123456789)
            self.assertEqual(user[1], "3x-ui")
            self.assertTrue(user[2])
            self.assertEqual(event_tg, 123456789)

    def test_identity_merge_preserves_related_rows_and_marks_source(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            init_db = reload_module("init_db", config)
            init_db.migrate()
            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute(
                    "INSERT INTO users(tg_id,username,uuid,email) VALUES(?,?,?,?)",
                    (-10, "old", "uuid-1", "user@example"),
                )
                connection.execute(
                    "INSERT INTO users(tg_id,username,uuid,email) VALUES(?,?,?,?)",
                    (777, "", "uuid-1", "user@example"),
                )
                connection.execute("INSERT INTO payments(tg_id,status) VALUES(?,?)", (-10, "pending"))
                connection.execute(
                    "INSERT INTO message_log(tg_id,message,success) VALUES(?,?,?)",
                    (-10, "legacy", 1),
                )
                connection.execute(
                    "INSERT INTO user_events(tg_id,direction,event_type,text) VALUES(?,?,?,?)",
                    (-10, "system", "legacy", "legacy"),
                )
                connection.commit()
            finally:
                connection.close()

            migration = reload_module("identity_migration", config)
            result = migration.rebind_local_identity(
                -10,
                777,
                "new_username",
                source="legacy:test.db",
                db_path=config.DB_PATH,
            )
            self.assertEqual(result["tg_id"], 777)
            self.assertEqual(result["username"], "new_username")
            self.assertEqual(result["identity_source"], "legacy:test.db")
            self.assertTrue(result["identity_updated_at"])

            connection = sqlite3.connect(config.DB_PATH)
            try:
                self.assertEqual(connection.execute("SELECT COUNT(*) FROM users").fetchone()[0], 1)
                for table in ("payments", "message_log", "user_events"):
                    self.assertEqual(connection.execute(f"SELECT tg_id FROM {table}").fetchone()[0], 777)
            finally:
                connection.close()

    def test_only_menshikovivan_is_update_publisher(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            config.WEB_USERNAME = "admin"
            config.UPDATE_IS_PUBLISHER = True
            config.UPDATE_PUBLISHER_USERNAME = "admin"
            manager = reload_module("update_manager", config)
            self.assertFalse(manager.publisher_enabled())
            config.WEB_USERNAME = "menshikovivan"
            config.UPDATE_IS_PUBLISHER = False
            config.UPDATE_PUBLISHER_USERNAME = "somebody_else"
            self.assertTrue(manager.publisher_enabled())
            self.assertEqual(manager.PUBLISHER_USERNAME, "menshikovivan")

    def test_remote_update_download_is_pinned_to_master_origin(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            manager = reload_module("update_manager", config)
            payload = {
                "version": "2.6.0",
                "filename": "vpn_service_update_2.6.0.tar.gz",
                "size": 1024,
                "sha256": "a" * 64,
                "download_url": "/api/updates/download/vpn_service_update_2.6.0.tar.gz",
            }
            validated = manager._validated_remote_metadata("https://master.example", payload)
            self.assertEqual(
                validated["download_absolute_url"],
                "https://master.example/api/updates/download/vpn_service_update_2.6.0.tar.gz",
            )

            malicious = dict(payload, download_url="https://attacker.example/update.tar.gz")
            with self.assertRaises(manager.UpdateError):
                manager._validated_remote_metadata("https://master.example", malicious)

            malformed = dict(payload, sha256="not-a-checksum")
            with self.assertRaises(manager.UpdateError):
                manager._validated_remote_metadata("https://master.example", malformed)

    def test_detached_update_worker_completes_and_persists_progress(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            manager = reload_module("update_manager", config)
            worker = reload_module("update_worker", config)
            job_id = "test-success"
            manager.write_status("queued", job_id=job_id, progress=1)

            worker.update_manager.check_available_update = lambda force=False: {
                "available": True,
                "version": "2.6.0",
                "source": "local",
            }
            worker.update_manager.obtain_update_archive = lambda info, progress=None: temp / "release.tar.gz"
            worker.update_manager.stage_update = lambda archive, progress=None: (
                temp,
                {"version": "2.6.0"},
            )
            worker.update_manager.installer_command = lambda package_root: (
                ["/bin/bash", "-c", "exit 0"],
                {},
            )

            with patch.object(worker.subprocess, "run", return_value=SimpleNamespace(returncode=0)):
                self.assertEqual(worker.run(job_id), 0)
            status = manager.read_status()
            self.assertEqual(status["state"], "completed")
            self.assertEqual(status["progress"], 100)
            self.assertEqual(status["version"], "2.6.0")

    def test_detached_worker_preserves_installer_rollback_status(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            manager = reload_module("update_manager", config)
            worker = reload_module("update_worker", config)
            job_id = "test-rollback"
            manager.write_status("queued", job_id=job_id, progress=1)

            worker.update_manager.check_available_update = lambda force=False: {
                "available": True,
                "version": "2.6.0",
                "source": "local",
            }
            worker.update_manager.obtain_update_archive = lambda info, progress=None: temp / "release.tar.gz"
            worker.update_manager.stage_update = lambda archive, progress=None: (
                temp,
                {"version": "2.6.0"},
            )
            worker.update_manager.installer_command = lambda package_root: (["fake-installer"], {})

            def controlled_failure(*args, **kwargs):
                manager.write_status(
                    "failed",
                    job_id=job_id,
                    progress=78,
                    phase="rollback-complete",
                    message="Предыдущая версия восстановлена",
                    error="Проверка новой версии не пройдена",
                )
                return SimpleNamespace(returncode=1)

            with patch.object(worker.subprocess, "run", side_effect=controlled_failure):
                self.assertEqual(worker.run(job_id), 1)
            status = manager.read_status()
            self.assertEqual(status["state"], "failed")
            self.assertEqual(status["phase"], "rollback-complete")
            self.assertEqual(status["message"], "Предыдущая версия восстановлена")

    def test_installer_contains_incremental_update_and_rollback_guards(self):
        source = (Path(__file__).resolve().parents[1] / "install.sh").read_text(encoding="utf-8")
        for marker in (
            'write_update_status "rolling-back"',
            "PREUPDATE_BACKUP",
            "PREUPDATE_SYSTEMD_DIR",
            ".vpn-requirements.sha256",
            "Системные зависимости уже установлены; запуск APT пропущен",
            "Существующее виртуальное окружение Python исправно и будет использовано повторно",
        ):
            self.assertIn(marker, source)

    def test_installer_messages_and_web_states_are_russian(self):
        root = Path(__file__).resolve().parents[1]
        installer = (root / "install.sh").read_text(encoding="utf-8")
        yandex = (root / "app" / "configure_yandex_webdav.sh").read_text(encoding="utf-8")
        worker = (root / "app" / "update_worker.py").read_text(encoding="utf-8")
        webapp = (root / "app" / "webapp.py").read_text(encoding="utf-8")

        for marker in (
            "[Установщик FargoVPN]",
            "Предварительная проверка системы",
            "Установка/обновление завершено",
            "Проверка импортов и синтаксиса Python: успешно",
        ):
            self.assertIn(marker, installer)
        for marker in (
            "Логин Яндекса",
            "Точка монтирования",
            "WebDAV Яндекс.Диска подключён",
        ):
            self.assertIn(marker, yandex)
        self.assertIn("задача {job_id} запущена", worker)
        manager = (root / "app" / "update_manager.py").read_text(encoding="utf-8")
        self.assertIn('("argument ", "параметр ")', manager)
        self.assertIn("checking:'Проверка версии'", webapp)
        self.assertIn("failed:'Ошибка'", webapp)

        for old_message in (
            "Pre-flight checks",
            "Installation/update completed",
            "Choose profile",
            "Mount point:",
            "Installer reported a controlled failure",
        ):
            self.assertNotIn(old_message, installer + yandex + worker)

    def test_installer_import_checks_run_from_target_directory(self):
        source = (Path(__file__).resolve().parents[1] / "install.sh").read_text(encoding="utf-8")
        self.assertIn("target_python() {", source)
        self.assertIn('cd "$TARGET"', source)
        self.assertIn('PYTHONPATH="$TARGET${PYTHONPATH:+:$PYTHONPATH}" exec "$TARGET/.venv/bin/python" "$@"', source)
        self.assertIn("mapfile -t WEB_INFO < <(target_python <<'PY'", source)
        self.assertIn("target_python - <<'PY'\nimport importlib\nimport config", source)
        self.assertIn(
            "target_python - <<'PY'\nfrom pathlib import Path\nimport os, signal, time\nimport service_audit",
            source,
        )
        self.assertNotIn(
            '"$TARGET/.venv/bin/python" - <<\'PY\'\nimport importlib\nimport config',
            source,
        )

    def test_settings_are_sectioned_and_expose_new_controls(self):
        source = (Path(__file__).resolve().parents[1] / "app" / "webapp.py").read_text(encoding="utf-8")
        for marker in (
            'data-tab="bot"',
            'data-tab="payment"',
            'data-tab="xui"',
            'data-tab="security"',
            'data-tab="updates"',
            'name="web_login_max_attempts"',
            'name="bot_welcome_text"',
            'name="update_master_url"',
            'name="user_event_keep_days"',
        ):
            self.assertIn(marker, source)


if __name__ == "__main__":
    unittest.main()
