from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx
from fastapi.testclient import TestClient

from test_core import fake_config, reload_module


class Platform264Tests(unittest.TestCase):
    @staticmethod
    def _metadata(version: str = "2.6.4") -> dict[str, object]:
        filename = f"vpn_service_update_{version}.tar.gz"
        return {
            "version": version,
            "filename": filename,
            "size": 1234,
            "sha256": "a" * 64,
            "published_at": "2026-08-11T10:00:00+00:00",
            "download_url": f"/api/updates/download/{filename}",
        }

    @staticmethod
    def _response(status: int, url: str, payload: dict[str, object]) -> httpx.Response:
        return httpx.Response(
            status,
            json=payload,
            request=httpx.Request("GET", url),
        )

    def test_publisher_exposes_root_and_panel_update_api_aliases(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.WEB_USERNAME = "menshikovivan"
            config.UPDATE_API_TOKEN = "x" * 40
            config.CHAT_MEDIA_CACHE_DIR = str(temp / "media-cache")
            reload_module("init_db", config).migrate()
            reload_module("auth_security", config)
            reload_module("user_events", config)
            reload_module("update_manager", config)
            webapp = reload_module("webapp", config)

            archive = temp / "vpn_service_update_2.6.4.tar.gz"
            archive.write_bytes(b"release-2.6.4")
            metadata = {
                "version": "2.6.4",
                "filename": archive.name,
                "size": archive.stat().st_size,
                "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                "published_at": "2026-08-11T10:00:00+00:00",
                "path": str(archive),
                "source": "local",
            }
            headers = {"Authorization": f"Bearer {config.UPDATE_API_TOKEN}"}

            with patch.object(webapp.update_manager, "latest_local_update", return_value=metadata):
                with TestClient(webapp.app) as client:
                    for prefix in ("", "/panel"):
                        latest = client.get(f"{prefix}/api/updates/latest", headers=headers)
                        self.assertEqual(latest.status_code, 200, latest.text)
                        self.assertEqual(latest.json()["version"], "2.6.4")
                        self.assertEqual(
                            latest.json()["download_url"],
                            f"/api/updates/download/{archive.name}",
                        )
                        download = client.get(
                            f"{prefix}/api/updates/download/{archive.name}", headers=headers
                        )
                        self.assertEqual(download.status_code, 200, download.text)
                        self.assertEqual(download.content, archive.read_bytes())

                    denied = client.get("/panel/api/updates/latest")
                    self.assertEqual(denied.status_code, 401)

    def test_follower_with_panel_url_falls_back_to_root_api(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            config.WEB_USERNAME = "follower"
            manager = reload_module("update_manager", config)
            configured = "http://91.196.34.28:8088/panel"
            panel_endpoint = configured + "/api/updates/latest"
            root_endpoint = "http://91.196.34.28:8088/api/updates/latest"
            calls: list[str] = []

            def fake_get(url: str, **_kwargs):
                calls.append(url)
                if url == panel_endpoint:
                    return self._response(404, url, {"detail": "Not Found"})
                if url == root_endpoint:
                    return self._response(200, url, self._metadata())
                raise AssertionError(f"Неожиданный URL: {url}")

            with patch.object(manager.httpx, "get", side_effect=fake_get):
                remote = manager.fetch_remote_update(configured)

            self.assertEqual(calls, [panel_endpoint, root_endpoint])
            self.assertEqual(remote["configured_master_url"], configured)
            self.assertEqual(remote["master_url"], "http://91.196.34.28:8088")
            self.assertEqual(remote["metadata_url"], root_endpoint)
            self.assertEqual(
                remote["download_absolute_url"],
                "http://91.196.34.28:8088/api/updates/download/vpn_service_update_2.6.4.tar.gz",
            )

    def test_follower_with_root_url_can_fall_back_to_panel_api(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            manager = reload_module("update_manager", config)
            configured = "https://updates.example"
            root_endpoint = configured + "/api/updates/latest"
            panel_endpoint = configured + "/panel/api/updates/latest"

            responses = [
                self._response(404, root_endpoint, {"detail": "Not Found"}),
                self._response(200, panel_endpoint, self._metadata()),
            ]
            with patch.object(manager.httpx, "get", side_effect=responses) as request:
                remote = manager.fetch_remote_update(configured)

            self.assertEqual(request.call_count, 2)
            self.assertEqual(remote["master_url"], "https://updates.example/panel")
            self.assertEqual(remote["metadata_url"], panel_endpoint)
            self.assertEqual(
                remote["download_absolute_url"],
                "https://updates.example/panel/api/updates/download/vpn_service_update_2.6.4.tar.gz",
            )

    def test_full_endpoint_is_normalized_and_unpublished_error_is_clear(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            manager = reload_module("update_manager", config)
            full = "http://91.196.34.28:8088/panel/api/updates/latest"
            self.assertEqual(
                manager.normalize_master_url(full),
                "http://91.196.34.28:8088/panel",
            )
            self.assertEqual(
                manager.normalize_master_url("http://91.196.34.28:8088/updates"),
                "http://91.196.34.28:8088",
            )
            self.assertEqual(
                manager.normalize_master_url("http://91.196.34.28:8088/panel/updates"),
                "http://91.196.34.28:8088/panel",
            )
            endpoint = "http://91.196.34.28:8088/panel/api/updates/latest"
            response = self._response(404, endpoint, {"detail": "Обновление ещё не загружено"})
            with patch.object(manager.httpx, "get", return_value=response):
                with self.assertRaisesRegex(manager.UpdateError, "ещё не опубликовано"):
                    manager.fetch_remote_update(full)


    def test_installer_uses_checksums_for_same_size_release_files(self):
        installer = (Path(__file__).resolve().parents[1] / "install.sh").read_text(
            encoding="utf-8"
        )
        self.assertIn("rsync -a --checksum --delete", installer)

    def test_follower_reports_wrong_token_without_path_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            manager = reload_module("update_manager", config)
            endpoint = "https://updates.example/api/updates/latest"
            response = self._response(401, endpoint, {"detail": "Неверный токен обновлений"})
            with patch.object(manager.httpx, "get", return_value=response) as request:
                with self.assertRaisesRegex(manager.UpdateError, "API-токен"):
                    manager.fetch_remote_update("https://updates.example")
            self.assertEqual(request.call_count, 1)


if __name__ == "__main__":
    unittest.main()
