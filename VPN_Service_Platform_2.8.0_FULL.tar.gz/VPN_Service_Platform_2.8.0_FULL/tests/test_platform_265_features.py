from __future__ import annotations

import hashlib
import io
import sqlite3
import sys
import subprocess
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient

from test_core import fake_config, reload_module


class _FakeProcess:
    pid = 4242
    returncode = None

    def poll(self):
        return None


class _FakeTelegramResponse:
    def __init__(self, payload: dict):
        self.status_code = 200
        self._payload = payload

    def json(self):
        return self._payload


class _FakeTelegramClient:
    def __init__(self, responder):
        self.responder = responder
        self.calls: list[dict] = []

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        return False

    def post(self, endpoint, *, data=None, files=None):
        call = {"endpoint": endpoint, "data": dict(data or {}), "files": files}
        self.calls.append(call)
        return _FakeTelegramResponse(self.responder(call, len(self.calls)))


def _set_test_password(config) -> None:
    salt = b"0123456789abcdef"
    digest = hashlib.pbkdf2_hmac("sha256", b"test", salt, 1000).hex()
    config.WEB_PASSWORD_HASH = f"pbkdf2_sha256$1000${salt.hex()}${digest}"


def _reload_webapp(config):
    # webapp imports configuration-bound helpers at module import time.  Purge
    # them between isolated test configurations so login state and job paths
    # cannot leak from an earlier test database.
    for name in (
        "webapp",
        "auth_security",
        "broadcast_manager",
        "diagnostics",
        "identity_migration",
        "panel_notifications",
        "service_audit",
        "update_manager",
        "user_events",
        "backup",
        "init_db",
        "services.media",
        "services.subscriptions",
        "services.xui_api",
    ):
        sys.modules.pop(name, None)
    return reload_module("webapp", config)


class Platform265FeatureTests(unittest.TestCase):
    def _database_with_users(self, config, *users: tuple[int, str]) -> None:
        init_db = reload_module("init_db", config)
        init_db.migrate()
        with sqlite3.connect(config.DB_PATH) as connection:
            connection.executemany(
                "INSERT INTO users(tg_id,username,email) VALUES(?,?,?)",
                [(tg_id, username, f"{username}@example") for tg_id, username in users],
            )
            connection.commit()

    def test_safe_detached_launcher_uses_nonblocking_systemd_run(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            launcher = reload_module("detached_jobs", config)
            calls: list[list[str]] = []
            original_is_dir = Path.is_dir

            def fake_is_dir(path: Path) -> bool:
                if str(path) == "/run/systemd/system":
                    return True
                return original_is_dir(path)

            def fake_run(command, **_kwargs):
                calls.append([str(item) for item in command])
                return subprocess.CompletedProcess(command, 0, "", "")

            with (
                patch.object(Path, "is_dir", fake_is_dir),
                patch.object(launcher.shutil, "which", return_value="/usr/bin/systemd-run"),
                patch.object(launcher.subprocess, "run", side_effect=fake_run),
            ):
                method = launcher.launch_detached(
                    "vpn-service-test-job",
                    ["/bin/true"],
                    description="Тестовая задача",
                    working_directory=directory,
                )
            self.assertEqual(method, "systemd-run")
            self.assertEqual(len(calls), 1)
            self.assertIn("--no-block", calls[0])
            self.assertIn("--collect", calls[0])

    def test_safe_detached_launcher_refuses_unsafe_process_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            launcher = reload_module("detached_jobs", config)
            original_is_dir = Path.is_dir

            def fake_is_dir(path: Path) -> bool:
                if str(path) == "/run/systemd/system":
                    return False
                return original_is_dir(path)

            with patch.object(Path, "is_dir", fake_is_dir):
                with self.assertRaises(launcher.DetachedJobError) as caught:
                    launcher.launch_detached(
                        "vpn-service-test-job",
                        ["/bin/true"],
                        description="Тестовая задача",
                        working_directory=directory,
                    )
            self.assertIn("безопасный фоновый запуск", str(caught.exception))

    def test_update_job_uses_nonblocking_systemd_template(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            manager = reload_module("update_manager", config)
            original_exists = Path.exists
            original_is_file = Path.is_file
            calls: list[list[str]] = []

            def fake_exists(path: Path) -> bool:
                if str(path) == "/run/systemd/system":
                    return True
                return original_exists(path)

            def fake_is_file(path: Path) -> bool:
                if str(path) == "/etc/systemd/system/vpn-service-update@.service":
                    return True
                return original_is_file(path)

            def fake_run(command, **_kwargs):
                calls.append([str(item) for item in command])
                return subprocess.CompletedProcess(command, 0, "", "")

            with (
                patch.object(Path, "exists", fake_exists),
                patch.object(Path, "is_file", fake_is_file),
                patch.object(manager.shutil, "which", side_effect=lambda name: f"/usr/bin/{name}"),
                patch.object(manager.subprocess, "run", side_effect=fake_run),
            ):
                result = manager.start_update_job(
                    "admin",
                    update_info={"source": "remote", "version": "2.6.5"},
                )

            self.assertEqual(result["launcher"], "systemd-template")
            self.assertEqual(len(calls), 1)
            self.assertEqual(calls[0][:3], ["systemctl", "--no-block", "start"])
            self.assertTrue(calls[0][3].startswith("vpn-service-update@upd-"))
            status = manager.read_status()
            self.assertEqual(status["state"], "queued")
            self.assertEqual(status["progress"], 2)
            self.assertTrue(Path(status["manifest"]).is_file())

    def test_late_launcher_metadata_cannot_roll_update_state_back(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            manager = reload_module("update_manager", config)
            manager.write_status(
                "queued", job_id="race-job", progress=1, phase="queue", message="queued"
            )
            manager.write_status(
                "checking", job_id="race-job", progress=4, phase="check", message="checking"
            )
            manager.write_status(
                "queued",
                job_id="race-job",
                progress=2,
                phase="queue",
                message="late launcher",
                launcher="systemd-template",
            )
            status = manager.read_status()
            self.assertEqual(status["state"], "checking")
            self.assertEqual(status["phase"], "check")
            self.assertEqual(status["progress"], 4)
            self.assertEqual(status["launcher"], "systemd-template")

            manager.write_status(
                "completed", job_id="race-job", progress=100, phase="complete", message="done"
            )
            manager.write_status(
                "queued", job_id="race-job", progress=2, phase="queue", message="too late", pid=42
            )
            status = manager.read_status()
            self.assertEqual(status["state"], "completed")
            self.assertEqual(status["phase"], "complete")
            self.assertEqual(status["progress"], 100)
            self.assertEqual(status["pid"], 42)

    def test_update_worker_reports_monotonic_task_progress(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            manager = reload_module("update_manager", config)
            worker = reload_module("update_worker", config)
            job_id = "progress-test"
            manager.write_status("queued", job_id=job_id, progress=1, phase="queue")
            snapshots: list[tuple[str, str, int]] = []
            original_write = manager.write_status

            def tracked_write(state: str, **details):
                original_write(state, **details)
                current = manager.read_status()
                snapshots.append(
                    (
                        str(current.get("state") or ""),
                        str(current.get("phase") or ""),
                        int(current.get("progress") or 0),
                    )
                )

            manager.write_status = tracked_write
            worker.update_manager.write_status = tracked_write
            worker.update_manager.check_available_update = lambda force=False: {
                "available": True,
                "version": "2.6.5",
                "source": "remote",
                "master_url": "http://master:8088",
                "download_url": "/api/updates/download/release.tar.gz",
                "filename": "release.tar.gz",
                "size": 100,
                "sha256": "0" * 64,
            }

            def fake_obtain(info, progress=None):
                for value in (10, 45, 80, 100):
                    progress(value, f"Загрузка {value}%")
                return temp / "release.tar.gz"

            def fake_stage(archive, progress=None):
                for value in (20, 60, 100):
                    progress(value, f"Распаковка {value}%")
                return temp, {"version": "2.6.5"}

            worker.update_manager.obtain_update_archive = fake_obtain
            worker.update_manager.stage_update = fake_stage
            worker.update_manager.installer_command = lambda package_root: (["fake-installer"], {})

            def fake_installer(*_args, **_kwargs):
                for state, progress, phase in (
                    ("installing", 52, "dependencies"),
                    ("installing", 58, "dependencies"),
                    ("installing", 62, "stop-services"),
                    ("installing", 68, "backup"),
                    ("installing", 73, "files"),
                    ("installing", 83, "python"),
                    ("migrating", 89, "database"),
                    ("installing", 94, "services"),
                    ("restarting", 96, "restart"),
                    ("health-check", 98, "health"),
                    ("completed", 100, "complete"),
                ):
                    tracked_write(
                        state,
                        job_id=job_id,
                        progress=progress,
                        phase=phase,
                        message=phase,
                    )
                return subprocess.CompletedProcess(["fake-installer"], 0)

            with patch.object(worker.subprocess, "run", side_effect=fake_installer):
                self.assertEqual(worker.run(job_id, startup_delay=0), 0)
            progress_values = [item[2] for item in snapshots]
            self.assertEqual(progress_values, sorted(progress_values))
            self.assertEqual(progress_values[-1], 100)
            phases = {item[1] for item in snapshots}
            for phase in (
                "acknowledged",
                "check",
                "download",
                "verify",
                "extract",
                "install",
                "dependencies",
                "backup",
                "files",
                "python",
                "database",
                "services",
                "restart",
                "health",
                "complete",
            ):
                self.assertIn(phase, phases)

    def test_update_page_has_smooth_progress_disconnect_recovery_and_auto_reload(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            _set_test_password(config)
            self._database_with_users(config, (101, "alice"))
            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            webapp.update_manager.check_available_update = lambda force=False: {
                "available": True,
                "version": "2.8.0",
                "source": "remote",
                "configured_master_url": "http://master:8088/panel",
                "metadata_url": "http://master:8088/api/updates/latest",
            }
            webapp.update_manager.read_status = lambda: {
                "job_id": "upd-test",
                "state": "installing",
                "phase": "files",
                "progress": 70,
                "message": "Копируются файлы",
            }
            webapp.update_manager.update_job_busy = lambda status=None: True

            with TestClient(webapp.app) as client:
                login = client.post(
                    "/login",
                    data={"username": "admin", "password": "test"},
                    follow_redirects=False,
                )
                self.assertEqual(login.status_code, 303)
                page = client.get("/updates")
                self.assertEqual(page.status_code, 200)
                self.assertIn("requestAnimationFrame(animateProgress)", page.text)
                self.assertIn("Это не считается ошибкой установки", page.text)
                self.assertIn("window.location.replace", page.text)
                self.assertIn("keepalive:true", page.text)
                self.assertIn("phaseCaps", page.text)
                self.assertIn("scheduleStatusCheck", page.text)
                self.assertIn("fetchStatus().catch", page.text)
                status = client.get("/api/updates/status")
                self.assertEqual(status.status_code, 200)
                self.assertEqual(status.json()["installed_version"], "2.8.0")

    def test_web_broadcast_button_and_start_route(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            _set_test_password(config)
            self._database_with_users(config, (101, "alice"), (102, "bob"))
            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            webapp.live_users = lambda: (
                [
                    {
                        "tg_id": 101,
                        "username": "alice",
                        "email": "alice@example",
                        "expiry_time": 1_900_000_000_000,
                        "remaining_days": 10,
                        "enable": True,
                        "active": True,
                        "online": False,
                        "last_online_ts": 0,
                        "up": 0,
                        "down": 0,
                        "traffic_used": 0,
                        "total": 0,
                        "quota_remaining": None,
                    }
                ],
                {"stale": False},
            )
            captured: dict = {}

            def fake_start(**kwargs):
                captured.update(kwargs)
                return {
                    "job_id": "mail-test",
                    "status": {
                        "job_id": "mail-test",
                        "state": "queued",
                        "progress": 1,
                        "total": 2,
                    },
                }

            webapp.broadcast_manager.start_broadcast = fake_start
            with TestClient(webapp.app) as client:
                login = client.post(
                    "/login",
                    data={"username": "admin", "password": "test"},
                    follow_redirects=False,
                )
                self.assertEqual(login.status_code, 303)
                users_page = client.get("/users")
                self.assertEqual(users_page.status_code, 200)
                self.assertIn("Массовая рассылка", users_page.text)
                page = client.get("/broadcast")
                self.assertEqual(page.status_code, 200)
                self.assertIn("Текст", page.text)
                self.assertIn("Фотография", page.text)
                self.assertIn("Видео", page.text)
                self.assertIn("Документ", page.text)
                response = client.post(
                    "/broadcast/start",
                    data={"kind": "text", "message": "Тестовая рассылка", "confirm": "1"},
                    headers={"Accept": "application/json"},
                )
                self.assertEqual(response.status_code, 202)
                self.assertEqual(response.json()["job_id"], "mail-test")
                self.assertEqual(captured["actor"], "admin")
                self.assertEqual(captured["kind"], "text")
                self.assertEqual(captured["message"], "Тестовая рассылка")

    def test_background_text_broadcast_snapshots_recipients_and_records_results(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.BROADCAST_SEND_DELAY_SECONDS = 0.02
            self._database_with_users(config, (101, "alice"), (102, "bob"), (-5, "legacy"))
            manager = reload_module("broadcast_manager", config)
            with patch.object(manager, "launch_detached", return_value="runtime-unit"):
                started = manager.start_broadcast(actor="admin", message="Всем привет", kind="text")
            job_id = started["job_id"]
            manifest = manager.read_manifest(job_id)
            self.assertEqual([item["tg_id"] for item in manifest["recipients"]], [101, 102])
            self.assertEqual(started["status"]["launcher"], "runtime-unit")

            worker = reload_module("broadcast_worker", config)
            client = _FakeTelegramClient(
                lambda call, _number: {"ok": True, "result": {"message_id": 1}}
            )
            with (
                patch.object(worker.httpx, "Client", return_value=client),
                patch.object(worker.time, "sleep", return_value=None),
            ):
                code = worker.run(job_id, startup_delay=0)
            self.assertEqual(code, 0)
            self.assertEqual([call["data"]["chat_id"] for call in client.calls], [101, 102])
            self.assertTrue(all(call["endpoint"].endswith("/sendMessage") for call in client.calls))
            status = manager.read_status(job_id)
            self.assertEqual(status["state"], "completed")
            self.assertEqual(status["progress"], 100)
            self.assertEqual(status["delivered"], 2)
            self.assertEqual(status["failed"], 0)
            with sqlite3.connect(config.DB_PATH) as connection:
                events = connection.execute(
                    "SELECT COUNT(*) FROM user_events WHERE event_type='broadcast_message'"
                ).fetchone()[0]
                audits = connection.execute(
                    "SELECT COUNT(*) FROM audit_log WHERE action='web_broadcast_completed'"
                ).fetchone()[0]
            self.assertEqual(events, 2)
            self.assertEqual(audits, 1)


    def test_empty_chat_does_not_acknowledge_message_arriving_after_snapshot(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            _set_test_password(config)
            self._database_with_users(config, (101, "alice"))
            events = reload_module("user_events", config)
            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            original_recent = webapp.user_events.recent_events
            inserted: list[int] = []

            def recent_with_race(*args, **kwargs):
                rows = original_recent(*args, **kwargs)
                if not inserted:
                    inserted.append(
                        events.record_event(
                            101,
                            username="alice",
                            direction="in",
                            event_type="telegram_message",
                            text="Сообщение после пустого снимка",
                            db_path=config.DB_PATH,
                        )
                    )
                return rows

            with TestClient(webapp.app) as client:
                login = client.post(
                    "/login",
                    data={"username": "admin", "password": "test"},
                    follow_redirects=False,
                )
                self.assertEqual(login.status_code, 303)
                with patch.object(webapp.user_events, "recent_events", side_effect=recent_with_race):
                    detail = client.get("/users/id/101")
                self.assertEqual(detail.status_code, 200)
                self.assertNotIn("Сообщение после пустого снимка", detail.text)
                summary = client.get("/api/users/unread").json()
                self.assertEqual(summary["total"], 1)
                self.assertEqual(summary["items"][0]["preview"], "Сообщение после пустого снимка")

    def test_opening_empty_chat_reconciles_counter_after_history_pruning(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            _set_test_password(config)
            self._database_with_users(config, (101, "alice"))
            events = reload_module("user_events", config)
            events.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_message",
                text="Будет удалено политикой хранения",
                db_path=config.DB_PATH,
            )
            with sqlite3.connect(config.DB_PATH) as connection:
                connection.execute("DELETE FROM user_events WHERE tg_id=101")
                connection.commit()
            self.assertEqual(events.unread_messages_summary(db_path=config.DB_PATH)["total"], 1)

            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            with TestClient(webapp.app) as client:
                login = client.post(
                    "/login",
                    data={"username": "admin", "password": "test"},
                    follow_redirects=False,
                )
                self.assertEqual(login.status_code, 303)
                detail = client.get("/users/id/101")
                self.assertEqual(detail.status_code, 200)
                summary = client.get("/api/users/unread").json()
                self.assertEqual(summary["total"], 0)

    @staticmethod
    def _release_archive(version: str = "2.8.0") -> bytes:
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
            files = {
                f"VPN_Service_Platform_{version}_FULL/app/VERSION": version.encode(),
                f"VPN_Service_Platform_{version}_FULL/install.sh": b"#!/usr/bin/env bash\nexit 0\n",
            }
            for name, payload in files.items():
                info = tarfile.TarInfo(name)
                info.size = len(payload)
                info.mode = 0o755 if name.endswith("install.sh") else 0o644
                archive.addfile(info, io.BytesIO(payload))
        return buffer.getvalue()

    def test_follower_manual_update_accepts_valid_archive_and_rejects_corrupt_file(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.WEB_USERNAME = "follower"
            _set_test_password(config)
            self._database_with_users(config, (101, "alice"))
            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            captured: dict = {}

            def fake_start(actor="web", update_info=None):
                captured["actor"] = actor
                captured["update_info"] = dict(update_info or {})
                webapp.update_manager.write_status(
                    "queued", job_id="manual-test", progress=2, phase="queue", message="queued"
                )
                return {"job_id": "manual-test", "state": "queued", "launcher": "test"}

            with TestClient(webapp.app) as client:
                login = client.post(
                    "/login",
                    data={"username": "follower", "password": "test"},
                    follow_redirects=False,
                )
                self.assertEqual(login.status_code, 303)
                with patch.object(webapp.update_manager, "start_update_job", side_effect=fake_start):
                    valid = client.post(
                        "/updates/upload-and-apply",
                        data={"allow_reinstall": "1"},
                        files={
                            "archive": (
                                "VPN_Service_Platform_2.7.1_FULL.tar.gz",
                                self._release_archive(),
                                "application/gzip",
                            )
                        },
                        headers={"Accept": "application/json"},
                    )
                self.assertEqual(valid.status_code, 202, valid.text)
                self.assertEqual(valid.json()["version"], "2.8.0")
                self.assertEqual(captured["update_info"]["source"], "manual")
                self.assertTrue(Path(captured["update_info"]["path"]).is_file())

                # Reset the synthetic queued state so validation reaches the archive parser.
                webapp.update_manager.write_status("completed", job_id="manual-test", progress=100)
                broken = client.post(
                    "/updates/upload-and-apply",
                    files={"archive": ("broken.tar.gz", b"not-a-gzip", "application/gzip")},
                    headers={"Accept": "application/json"},
                )
                self.assertEqual(broken.status_code, 409, broken.text)
                self.assertIn("Архив повреждён", broken.json()["detail"])

    def test_busy_update_and_broadcast_reject_before_processing_upload(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.WEB_USERNAME = "follower"
            _set_test_password(config)
            self._database_with_users(config, (101, "alice"))
            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            with TestClient(webapp.app) as client:
                login = client.post(
                    "/login",
                    data={"username": "follower", "password": "test"},
                    follow_redirects=False,
                )
                self.assertEqual(login.status_code, 303)
                with patch.object(webapp.update_manager, "update_job_busy", return_value=True):
                    update = client.post(
                        "/updates/upload-and-apply",
                        files={"archive": ("ignored.tar.gz", b"ignored", "application/gzip")},
                        headers={"Accept": "application/json"},
                    )
                self.assertEqual(update.status_code, 409)
                self.assertIn("уже выполняется", update.json()["detail"])

                with patch.object(webapp.broadcast_manager, "broadcast_busy", return_value=True):
                    broadcast = client.post(
                        "/broadcast/start",
                        data={"kind": "photo", "message": "", "confirm": "1"},
                        files={"media": ("ignored.jpg", b"ignored", "image/jpeg")},
                        headers={"Accept": "application/json"},
                    )
                self.assertEqual(broadcast.status_code, 409)
                self.assertIn("уже выполняется", broadcast.json()["detail"])

    def test_media_broadcast_uploads_once_and_reuses_telegram_file_id(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            self._database_with_users(config, (101, "alice"), (102, "bob"))
            source = temp / "picture.jpg"
            source.write_bytes(b"\xff\xd8\xff\xe0" + b"test-image")
            manager = reload_module("broadcast_manager", config)
            with patch.object(manager, "launch_detached", return_value="runtime-unit"):
                started = manager.start_broadcast(
                    actor="admin",
                    message="Подпись",
                    kind="photo",
                    source=source,
                    original_name="picture.jpg",
                    content_type="image/jpeg",
                )
            job_id = started["job_id"]

            def responder(call, number):
                if number == 1:
                    self.assertIsNotNone(call["files"])
                    return {"ok": True, "result": {"photo": [{"file_id": "reuse-photo-id"}]}}
                self.assertIsNone(call["files"])
                self.assertEqual(call["data"]["photo"], "reuse-photo-id")
                return {"ok": True, "result": {"photo": [{"file_id": "reuse-photo-id"}]}}

            worker = reload_module("broadcast_worker", config)
            client = _FakeTelegramClient(responder)
            with (
                patch.object(worker.httpx, "Client", return_value=client),
                patch.object(worker.time, "sleep", return_value=None),
            ):
                code = worker.run(job_id, startup_delay=0)
            self.assertEqual(code, 0)
            self.assertEqual(len(client.calls), 2)
            self.assertTrue(all(call["endpoint"].endswith("/sendPhoto") for call in client.calls))
            manifest = manager.read_manifest(job_id)
            self.assertFalse(Path(manifest["payload_path"]).exists())


if __name__ == "__main__":
    unittest.main()
