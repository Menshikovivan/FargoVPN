from __future__ import annotations

import hashlib
import sqlite3
import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from test_core import fake_config, reload_module


class UnreadNotificationTests(unittest.TestCase):
    def test_incoming_messages_increment_and_read_receipts_are_race_safe(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.PANEL_NOTIFY_ADMIN_MESSAGES = False
            init_db = reload_module("init_db", config)
            init_db.migrate()
            with sqlite3.connect(config.DB_PATH) as connection:
                connection.execute(
                    "INSERT INTO users(tg_id,username,email) VALUES(?,?,?)",
                    (101, "alice", "alice@example"),
                )
                connection.commit()

            events = reload_module("user_events", config)
            events.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_callback",
                text="Нажата кнопка",
                db_path=config.DB_PATH,
            )
            # Administrator commands and button presses are journaled but must
            # not produce user-message notifications.
            events.record_event(
                config.ADMIN_IDS[0],
                username="admin",
                direction="in",
                event_type="telegram_message",
                text="Команда администратора",
                db_path=config.DB_PATH,
            )
            self.assertEqual(events.unread_messages_summary(db_path=config.DB_PATH)["total"], 0)

            first_id = events.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_message",
                text="Первое сообщение",
                db_path=config.DB_PATH,
            )
            second_id = events.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_message",
                text="Второе сообщение",
                db_path=config.DB_PATH,
            )
            events.record_event(
                101,
                username="alice",
                direction="out",
                event_type="admin_message",
                text="Ответ администратора",
                db_path=config.DB_PATH,
            )

            summary = events.unread_messages_summary(db_path=config.DB_PATH)
            self.assertEqual(summary["total"], 2)
            self.assertEqual(summary["users"], 1)
            self.assertEqual(summary["items"][0]["tg_id"], 101)
            self.assertEqual(summary["items"][0]["count"], 2)
            self.assertEqual(summary["items"][0]["preview"], "Второе сообщение")

            partial = events.mark_messages_read(
                101, through_event_id=first_id, db_path=config.DB_PATH
            )
            self.assertEqual(partial["remaining"], 1)
            self.assertEqual(events.unread_messages_summary(db_path=config.DB_PATH)["total"], 1)

            complete = events.mark_messages_read(
                101, through_event_id=second_id, db_path=config.DB_PATH
            )
            self.assertEqual(complete["remaining"], 0)
            self.assertEqual(events.unread_messages_summary(db_path=config.DB_PATH)["total"], 0)

    def test_upgrade_baselines_old_history_and_only_new_messages_notify(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            with sqlite3.connect(config.DB_PATH) as connection:
                connection.execute(
                    """
                    CREATE TABLE user_events(
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        tg_id INTEGER NOT NULL,
                        username TEXT,
                        direction TEXT NOT NULL DEFAULT 'system',
                        event_type TEXT NOT NULL DEFAULT 'event',
                        text TEXT,
                        actor TEXT,
                        success INTEGER DEFAULT 1,
                        metadata TEXT
                    )
                    """
                )
                connection.execute(
                    "INSERT INTO user_events(tg_id,direction,event_type,text) VALUES(?,?,?,?)",
                    (202, "in", "telegram_message", "Старое сообщение"),
                )
                connection.commit()

            init_db = reload_module("init_db", config)
            init_db.migrate()
            with sqlite3.connect(config.DB_PATH) as connection:
                connection.execute(
                    "INSERT INTO users(tg_id,username,email) VALUES(?,?,?)",
                    (202, "bob", "bob@example"),
                )
                connection.commit()

            events = reload_module("user_events", config)
            self.assertEqual(events.unread_messages_summary(db_path=config.DB_PATH)["total"], 0)
            events.record_event(
                202,
                username="bob",
                direction="in",
                event_type="telegram_message",
                text="Новое сообщение",
                db_path=config.DB_PATH,
            )
            summary = events.unread_messages_summary(db_path=config.DB_PATH)
            self.assertEqual(summary["total"], 1)
            self.assertEqual(summary["items"][0]["preview"], "Новое сообщение")

    def test_identity_rebind_moves_unread_state_with_conversation(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            init_db = reload_module("init_db", config)
            init_db.migrate()
            with sqlite3.connect(config.DB_PATH) as connection:
                connection.execute(
                    "INSERT INTO users(tg_id,username,uuid,email) VALUES(?,?,?,?)",
                    (-10, "legacy", "same-uuid", "same@example"),
                )
                connection.execute(
                    "INSERT INTO users(tg_id,username,uuid,email) VALUES(?,?,?,?)",
                    (777, "", "same-uuid", "same@example"),
                )
                connection.commit()

            events = reload_module("user_events", config)
            events.record_event(
                -10,
                username="legacy",
                direction="in",
                event_type="telegram_message",
                text="Непрочитанное обращение",
                db_path=config.DB_PATH,
            )
            migration = reload_module("identity_migration", config)
            result = migration.rebind_local_identity(
                -10,
                777,
                "restored",
                source="test",
                db_path=config.DB_PATH,
            )
            self.assertEqual(result["tg_id"], 777)
            summary = events.unread_messages_summary(db_path=config.DB_PATH)
            self.assertEqual(summary["total"], 1)
            self.assertEqual(summary["items"][0]["tg_id"], 777)
            self.assertEqual(summary["items"][0]["preview"], "Непрочитанное обращение")


    def test_authenticated_http_flow_renders_and_clears_notification(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            salt = b"0123456789abcdef"
            digest = hashlib.pbkdf2_hmac("sha256", b"test", salt, 1000).hex()
            config.WEB_PASSWORD_HASH = f"pbkdf2_sha256$1000${salt.hex()}${digest}"
            init_db = reload_module("init_db", config)
            init_db.migrate()
            with sqlite3.connect(config.DB_PATH) as connection:
                connection.execute(
                    """
                    INSERT INTO users(tg_id,username,email,expiry_time,enable,up,down,total)
                    VALUES(?,?,?,?,?,?,?,?)
                    """,
                    (101, "alice", "alice@example", 1_900_000_000_000, 1, 100, 200, 1000),
                )
                connection.commit()

            events = reload_module("user_events", config)
            event_id = events.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_message",
                text="Здравствуйте, нужна помощь",
                db_path=config.DB_PATH,
            )
            webapp = reload_module("webapp", config)
            webapp.update_banner = lambda: ""
            webapp.live_users = lambda: (
                [
                    {
                        "tg_id": 101,
                        "username": "alice",
                        "email": "alice@example",
                        "expiry_time": 1_900_000_000_000,
                        "remaining_days": 10,
                        "enable": True,
                        "active": True,
                        "online": False,
                        "last_online_ts": 0,
                        "up": 100,
                        "down": 200,
                        "traffic_used": 300,
                        "total": 1000,
                        "quota_remaining": 700,
                    }
                ],
                {"stale": False},
            )

            with TestClient(webapp.app) as client:
                login = client.post(
                    "/login",
                    data={"username": "admin", "password": "test"},
                    follow_redirects=False,
                )
                self.assertEqual(login.status_code, 303)
                page = client.get("/users")
                self.assertEqual(page.status_code, 200)
                self.assertIn("data-unread-indicator", page.text)
                self.assertIn("Здравствуйте, нужна помощь", page.text)
                self.assertIn("Непрочитанных сообщений: 1", page.text)
                self.assertEqual(client.get("/api/users/unread").json()["total"], 1)

                chat = client.get("/users/id/101")
                self.assertEqual(chat.status_code, 200)
                self.assertIn("Здравствуйте, нужна помощь", chat.text)
                self.assertEqual(client.get("/api/users/unread").json()["total"], 0)

    def test_opening_chat_keeps_message_arriving_during_render_unread(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            salt = b"0123456789abcdef"
            digest = hashlib.pbkdf2_hmac("sha256", b"test", salt, 1000).hex()
            config.WEB_PASSWORD_HASH = f"pbkdf2_sha256$1000${salt.hex()}${digest}"
            init_db = reload_module("init_db", config)
            init_db.migrate()
            with sqlite3.connect(config.DB_PATH) as connection:
                connection.execute(
                    "INSERT INTO users(tg_id,username,email) VALUES(?,?,?)",
                    (101, "alice", "alice@example"),
                )
                connection.commit()

            events = reload_module("user_events", config)
            events.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_message",
                text="Первое сообщение",
                db_path=config.DB_PATH,
            )
            webapp = reload_module("webapp", config)
            webapp.update_banner = lambda: ""
            original_recent = webapp.user_events.recent_events
            injected = False

            def recent_with_race(*args, **kwargs):
                nonlocal injected
                rendered = original_recent(*args, **kwargs)
                if not injected:
                    injected = True
                    webapp.user_events.record_event(
                        101,
                        username="alice",
                        direction="in",
                        event_type="telegram_message",
                        text="Сообщение во время открытия",
                        db_path=config.DB_PATH,
                    )
                return rendered

            webapp.user_events.recent_events = recent_with_race
            with TestClient(webapp.app) as client:
                login = client.post(
                    "/login",
                    data={"username": "admin", "password": "test"},
                    follow_redirects=False,
                )
                self.assertEqual(login.status_code, 303)
                chat = client.get("/users/id/101")
                self.assertEqual(chat.status_code, 200)
                self.assertIn("Первое сообщение", chat.text)
                self.assertNotIn("Сообщение во время открытия", chat.text)
                summary = client.get("/api/users/unread").json()
                self.assertEqual(summary["total"], 1)
                self.assertEqual(summary["items"][0]["preview"], "Сообщение во время открытия")

    def test_web_panel_contains_live_unread_routes_and_visual_marker(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            webapp = reload_module("webapp", config)
            paths = {getattr(route, "path", "") for route in webapp.app.routes}
            self.assertIn("/api/users/unread", paths)
            self.assertIn("/api/users/{tg_id}/read", paths)
            source = (Path(__file__).resolve().parents[1] / "app" / "webapp.py").read_text(
                encoding="utf-8"
            )
            css = (Path(__file__).resolve().parents[1] / "app" / "static" / "panel.css").read_text(
                encoding="utf-8"
            )
            javascript = (
                Path(__file__).resolve().parents[1] / "app" / "static" / "panel.js"
            ).read_text(encoding="utf-8")
            self.assertIn("data-unread-indicator", source)
            self.assertIn("unread-indicator", css)
            self.assertIn("pollUnreadMessages", javascript)
            self.assertIn("setInterval(pollPanelNotifications, 3000)", javascript)


if __name__ == "__main__":
    unittest.main()
