from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx
from fastapi.testclient import TestClient

from test_core import APP, ROOT, fake_config, reload_module


class Platform265UpdateRoutingTests(unittest.TestCase):
    @staticmethod
    def _payload(version: str = "9.9.9") -> dict[str, object]:
        filename = f"VPN_Service_Platform_{version}_FULL.tar.gz"
        return {
            "version": version,
            "filename": filename,
            "size": 1024,
            "sha256": "a" * 64,
            "download_url": f"/api/updates/download/{filename}",
        }

    def test_master_url_normalization_and_candidates(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = reload_module("update_manager", fake_config(Path(directory)))
            self.assertEqual(
                manager.normalize_master_url("HTTP://example.test:8088/api/updates/latest"),
                "http://example.test:8088",
            )
            self.assertEqual(
                manager.normalize_master_url("http://example.test:8088/updates/"),
                "http://example.test:8088",
            )
            self.assertEqual(
                manager.master_url_candidates("http://example.test:8088/panel"),
                ["http://example.test:8088/panel", "http://example.test:8088"],
            )

    def test_follower_recovers_from_obsolete_panel_suffix(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            config.WEB_USERNAME = "follower"
            config.UPDATE_MASTER_URL = "http://91.196.34.28:8088/panel"
            config.UPDATE_API_TOKEN = "x" * 32
            manager = reload_module("update_manager", config)
            called: list[str] = []

            def fake_get(url: str, **_kwargs):
                called.append(url)
                request = httpx.Request("GET", url)
                if url.endswith("/panel/api/updates/latest"):
                    return httpx.Response(404, request=request, json={"detail": "Not Found"})
                return httpx.Response(200, request=request, json=self._payload())

            with patch.object(manager.httpx, "get", side_effect=fake_get):
                info = manager.check_available_update(force=True)

            self.assertEqual(
                called,
                [
                    "http://91.196.34.28:8088/panel/api/updates/latest",
                    "http://91.196.34.28:8088/api/updates/latest",
                ],
            )
            self.assertEqual(info["error"], "")
            self.assertTrue(info["available"])
            self.assertTrue(info["fallback_used"])
            self.assertEqual(info["master_url"], "http://91.196.34.28:8088")
            self.assertEqual(
                info["download_absolute_url"],
                "http://91.196.34.28:8088/api/updates/download/VPN_Service_Platform_9.9.9_FULL.tar.gz",
            )

    def test_unpublished_archive_is_not_misreported_as_missing_route(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            config.WEB_USERNAME = "follower"
            config.UPDATE_API_TOKEN = "x" * 32
            manager = reload_module("update_manager", config)
            called: list[str] = []

            def fake_get(url: str, **_kwargs):
                called.append(url)
                return httpx.Response(
                    404,
                    request=httpx.Request("GET", url),
                    json={"detail": "Обновление ещё не загружено"},
                )

            with patch.object(manager.httpx, "get", side_effect=fake_get):
                with self.assertRaises(manager.UpdateError) as context:
                    manager.fetch_remote_metadata("https://vpn.example/panel")
            self.assertEqual(called, ["https://vpn.example/panel/api/updates/latest"])
            self.assertIn("пока не опубликован архив", str(context.exception))

    def test_real_reverse_proxy_panel_prefix_is_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            config.WEB_USERNAME = "follower"
            config.UPDATE_API_TOKEN = "x" * 32
            manager = reload_module("update_manager", config)
            called: list[str] = []

            def fake_get(url: str, **_kwargs):
                called.append(url)
                return httpx.Response(
                    200,
                    request=httpx.Request("GET", url),
                    json=self._payload(),
                )

            with patch.object(manager.httpx, "get", side_effect=fake_get):
                remote = manager.fetch_remote_metadata("https://vpn.example/panel")

            self.assertEqual(called, ["https://vpn.example/panel/api/updates/latest"])
            self.assertFalse(remote["fallback_used"])
            self.assertEqual(
                remote["download_absolute_url"],
                "https://vpn.example/panel/api/updates/download/VPN_Service_Platform_9.9.9_FULL.tar.gz",
            )

    def test_diagnostics_lists_both_compatible_endpoints(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            config.WEB_USERNAME = "follower"
            config.UPDATE_MASTER_URL = "http://91.196.34.28:8088/panel"
            config.UPDATE_API_TOKEN = "x" * 32
            reload_module("update_manager", config)
            diagnostics = reload_module("diagnostics", config)
            report = diagnostics.update_topology_report(
                {
                    "error": "",
                    "master_url": "http://91.196.34.28:8088",
                    "metadata_url": "http://91.196.34.28:8088/api/updates/latest",
                    "fallback_used": True,
                    "version": "2.6.4",
                }
            )
            self.assertTrue(report["healthy"])
            self.assertEqual(len(report["candidate_endpoints"]), 2)
            self.assertTrue(report["fallback_used"])
            self.assertIn("/panel/api/updates/latest", report["candidate_endpoints"][0])
            self.assertEqual(
                report["metadata_url"],
                "http://91.196.34.28:8088/api/updates/latest",
            )

    def test_update_errors_are_human_readable(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            config.WEB_USERNAME = "follower"
            config.UPDATE_API_TOKEN = "x" * 32
            manager = reload_module("update_manager", config)

            def fake_get(url: str, **_kwargs):
                return httpx.Response(
                    401,
                    request=httpx.Request("GET", url),
                    json={"detail": "Неверный токен обновлений"},
                )

            with patch.object(manager.httpx, "get", side_effect=fake_get):
                with self.assertRaises(manager.UpdateError) as context:
                    manager.fetch_remote_metadata("http://example.test:8088")
            self.assertIn("API-токен не совпадает", str(context.exception))
            self.assertNotIn("developer.mozilla.org", str(context.exception))

    def test_publisher_keeps_backward_compatible_panel_api_aliases(self):
        source = (APP / "webapp.py").read_text(encoding="utf-8")
        self.assertIn('@app.get("/panel/api/updates/latest", include_in_schema=False)', source)
        self.assertIn(
            '@app.get("/panel/api/updates/download/{filename}", include_in_schema=False)',
            source,
        )
        self.assertIn("Старое значение с /panel версия 2.6.4 исправляет автоматически", source)

        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.WEB_USERNAME = "menshikovivan"
            config.UPDATE_API_TOKEN = "x" * 32
            update_root = Path(config.UPDATE_DIR)
            update_root.mkdir(parents=True, exist_ok=True)
            archive = update_root / "vpn_service_update_2.6.4.tar.gz"
            archive.write_bytes(b"test-archive")
            manager = reload_module("update_manager", config)
            metadata = {
                "version": "2.6.4",
                "filename": archive.name,
                "size": archive.stat().st_size,
                "sha256": manager.sha256_file(archive),
                "published_at": "2026-08-11T00:00:00+00:00",
                "path": str(archive),
            }
            (update_root / "latest.json").write_text(
                json.dumps(metadata), encoding="utf-8"
            )
            webapp = reload_module("webapp", config)
            paths = {getattr(route, "path", "") for route in webapp.app.routes}
            self.assertIn("/panel/api/updates/latest", paths)
            self.assertIn("/panel/api/updates/download/{filename}", paths)
            headers = {"Authorization": "Bearer " + config.UPDATE_API_TOKEN}
            with TestClient(webapp.app) as client:
                self.assertEqual(client.get("/panel/api/updates/latest").status_code, 401)
                latest = client.get("/panel/api/updates/latest", headers=headers)
                self.assertEqual(latest.status_code, 200)
                payload = latest.json()
                self.assertEqual(payload["version"], "2.6.4")
                download = client.get(
                    "/panel/api/updates/download/" + archive.name, headers=headers
                )
                self.assertEqual(download.status_code, 200)
                self.assertEqual(download.content, b"test-archive")

    def test_release_keeps_264_routing_and_advances_to_269(self):
        self.assertEqual((APP / "VERSION").read_text(encoding="utf-8").strip(), "2.8.0")
        self.assertIn("2.8.0", (ROOT / "BUILD_PROFILE.txt").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
