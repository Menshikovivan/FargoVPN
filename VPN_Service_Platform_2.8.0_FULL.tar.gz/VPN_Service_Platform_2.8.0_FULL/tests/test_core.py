from __future__ import annotations

import asyncio
import importlib
import io
import os
import subprocess
import sqlite3
import sys
import tarfile
import tempfile
import types
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"


def fake_config(temp: Path) -> types.ModuleType:
    module = types.ModuleType("config")
    module.INSTALL_PROFILE = "full"
    module.SERVICE_NAME = "TestVPN"
    module.BOT_TOKEN = "test-token"
    module.ADMIN_IDS = [999]
    module.PANEL_NOTIFY_ADMIN_MESSAGES = True
    module.DB_PATH = str(temp / "vpn.db")
    module.BASE_URL = "https://127.0.0.1/"
    module.SUB_BASE_URL = "https://127.0.0.1/sub/"
    module.MASTER_API_TOKEN = "api-token"
    module.PAYMENT_PRICE = 150
    module.PAYMENT_PHONE = "+79990000000"
    module.PAYMENT_BANK = "Test Bank"
    module.PAYMENT_RECEIVER = "Test Receiver"
    module.RECEIPT_OCR_ENABLED = True
    module.RECEIPT_AUTO_APPROVE = True
    module.RECEIPT_MIN_AMOUNT = 150.0
    module.RECEIPT_MAX_AGE_HOURS = 24
    module.RECEIPT_RECEIVER_ALIASES = ""
    module.RECEIPT_ALLOW_MASKED_PHONE = True
    module.RECEIPT_TIMEZONE = "Europe/Moscow"
    module.RECEIPT_OCR_LANGUAGES = "rus+eng"
    module.RECEIPT_OCR_TIMEOUT = 20
    module.XUI_CACHE_SECONDS = 1
    module.XUI_VERIFY_TLS = False
    module.XUI_DB_PATH = str(temp / "x-ui.db")
    module.REMINDER_DAYS = [7, 3, 1, 0]
    module.REMINDER_LOCK_PATH = str(temp / "reminders.lock")
    module.BACKUP_DIR = str(temp / "backups")
    module.BACKUP_KEEP_DAYS = 14
    module.BACKUP_INTERVAL_DAYS = 3
    module.BACKUP_TELEGRAM = False
    module.BACKUP_TELEGRAM_PART_MB = 45
    module.BACKUP_INCLUDE_VENV = False
    module.BACKUP_LOCK_PATH = str(temp / "backup.lock")
    module.BACKUP_STATE_PATH = str(temp / "backup-state.json")
    module.YANDEX_DISK_ENABLED = False
    module.YANDEX_DISK_MODE = "oauth"
    module.YANDEX_DISK_TOKEN = ""
    module.YANDEX_DISK_PATH = "VPN-Service-Backups"
    module.YANDEX_LOCAL_PATH = str(temp / "yandex")
    module.YANDEX_LOCAL_REQUIRE_MOUNT = False
    module.YANDEX_WEBDAV_URL = "https://webdav.yandex.ru"
    module.YANDEX_DAVFS_SECRETS_PATH = str(temp / "davfs2-secrets")
    module.YANDEX_UPLOAD_RETRIES = 1
    module.YANDEX_UPLOAD_VERIFY_ATTEMPTS = 2
    module.YANDEX_UPLOAD_VERIFY_DELAY = 0
    module.GOOGLE_DRIVE_ENABLED = False
    module.GOOGLE_DRIVE_CLIENT_ID = ""
    module.GOOGLE_DRIVE_CLIENT_SECRET = ""
    module.GOOGLE_DRIVE_REFRESH_TOKEN = ""
    module.GOOGLE_DRIVE_FOLDER_ID = ""
    module.GOOGLE_DRIVE_OAUTH_REDIRECT_URL = ""
    module.RCLONE_REMOTE = ""
    module.RCLONE_PATH = "VPN-Service-Backups"
    module.WEB_HOST = "127.0.0.1"
    module.WEB_PORT = 8088
    module.WEB_USERNAME = "admin"
    module.WEB_PASSWORD_HASH = "test"
    module.WEB_SECRET_KEY = "test-secret-key"
    module.WEB_COOKIE_HTTPS_ONLY = False
    module.UPDATE_DIR = str(temp / "updates")
    module.UPDATE_MAX_ARCHIVE_MB = 20
    module.UPDATE_PUBLISHER_USERNAME = "menshikovivan"
    module.UPDATE_IS_PUBLISHER = True
    module.UPDATE_MASTER_URL = ""
    module.UPDATE_API_TOKEN = "update-token"
    module.UPDATE_CHECK_INTERVAL = 10
    module.UPDATE_VERIFY_TLS = True
    module.BROADCAST_DIR = str(temp / "broadcasts")
    module.BROADCAST_MEDIA_MAX_MB = 45
    module.BROADCAST_SEND_DELAY_SECONDS = 0.04
    module.BROADCAST_STALE_SECONDS = 7200
    module.CHAT_MEDIA_MAX_MB = 100
    module.CHAT_MEDIA_CACHE_DIR = str(temp / "chat-media")
    module.CHAT_MEDIA_CACHE_DAYS = 30
    module.CHAT_MEDIA_CACHE_MAX_MB = 512
    return module


def reload_module(name: str, config_module: types.ModuleType):
    sys.modules["config"] = config_module
    sys.path.insert(0, str(APP))
    try:
        for loaded in list(sys.modules):
            if loaded == name or loaded.startswith(name + "."):
                del sys.modules[loaded]
        return importlib.import_module(name)
    finally:
        if sys.path and sys.path[0] == str(APP):
            sys.path.pop(0)


class CoreTests(unittest.TestCase):
    def test_xui_normalization_and_db_sync(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            xui = reload_module("services.xui_api", config)
            flat = xui.normalize_client(
                {
                    "email": "flat@example",
                    "id": "uuid-flat",
                    "expiryTime": 1_900_000_000_000,
                    "up": 10,
                    "down": 20,
                    "totalGB": 100,
                    "enable": True,
                }
            )
            nested = xui.normalize_client(
                {
                    "client": {"email": "nested@example", "id": "uuid-nested", "expiryTime": 1_900_000_000_000},
                    "traffic": {"up": 30, "down": 40, "total": 200, "lastOnline": 1_700_000_000},
                }
            )
            self.assertEqual(flat["up"] + flat["down"], 30)
            self.assertEqual(flat["total"], 100)
            self.assertEqual(nested["last_online_ts"], 1_700_000_000_000)
            self.assertEqual(nested["up"] + nested["down"], 70)

            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute(
                    "CREATE TABLE users(tg_id INTEGER PRIMARY KEY, username TEXT, uuid TEXT, email TEXT, expiry_time INTEGER, enable INTEGER, up INTEGER, down INTEGER, total INTEGER, sub_id TEXT, last_online TEXT, last_reminder_days INTEGER DEFAULT -1)"
                )
                connection.execute(
                    "INSERT INTO users(tg_id,username,uuid,email,expiry_time,enable,last_reminder_days) VALUES(?,?,?,?,?,?,?)",
                    (123, "alice", "uuid-flat", "flat@example", 1_800_000_000_000, 1, 7),
                )
                connection.execute(
                    "INSERT INTO users(tg_id,username,uuid,email,expiry_time,enable,last_reminder_days) VALUES(?,?,?,?,?,?,?)",
                    (456, "removed", "uuid-removed", "removed@example", 1_900_000_000_000, 1, 3),
                )
                connection.commit()
            finally:
                connection.close()
            changed = xui.sync_snapshot_to_db({"clients": [flat, nested]})
            self.assertEqual(changed, 3)
            connection = sqlite3.connect(config.DB_PATH)
            try:
                row = connection.execute(
                    "SELECT up,down,last_sync_at,last_reminder_days FROM users WHERE tg_id=123"
                ).fetchone()
                removed = connection.execute(
                    "SELECT enable FROM users WHERE tg_id=456"
                ).fetchone()
                columns = {item[1] for item in connection.execute("PRAGMA table_info(users)")}
            finally:
                connection.close()
            self.assertEqual(row[:2], (10, 20))
            self.assertTrue(row[2])
            self.assertEqual(row[3], -1)
            self.assertEqual(removed[0], 0)
            self.assertIn("last_online_ts", columns)


    def test_xui_update_maps_record_uuid_and_preserves_typed_fields(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            xui = reload_module("services.xui_api", config)
            email = "existinguser_123456789"
            raw_client = {
                "id": 41,
                "uuid": "11111111-2222-3333-4444-555555555555",
                "email": email,
                "subId": "sub-existing",
                "password": "keep-password",
                "auth": "keep-auth",
                "flow": "xtls-rprx-vision",
                "security": "auto",
                "reverse": '{"tag":"reverse-tag"}',
                "privateKey": "keep-private",
                "publicKey": "keep-public",
                "allowedIPs": "10.0.0.2/32, 10.0.0.3/32",
                "preSharedKey": "keep-psk",
                "keepAlive": "25",
                "expiryTime": 1_900_000_000_000,
                "totalGB": 0,
                "limitIp": 0,
                "tgId": "123456789",
                "enable": True,
                "comment": "keep-comment",
                "reset": 0,
                "createdAt": 1_700_000_000_000,
                "updatedAt": 1_800_000_000_000,
                "traffic": {"up": 12, "down": 34},
                "inboundIds": [1, 2],
            }
            record = {"client": dict(raw_client), "inboundIds": [1, 2], "externalConfigIds": [7]}

            normalized = xui.normalize_client(record["client"])
            self.assertEqual(normalized["uuid"], raw_client["uuid"])
            self.assertEqual(xui.normalize_client({"id": 41, "email": "db-row"})["uuid"], "")

            sync_calls: list[tuple[str, str, dict | None]] = []

            def fake_request(method, api_path, payload=None, timeout=12.0):
                sync_calls.append((method, api_path, payload))
                if method == "GET":
                    return {"success": True, "obj": record}
                return {"success": True, "obj": None}

            xui.request_json_sync = fake_request
            xui.update_client_sync(email, {"expiryTime": 2_000_000_000_000, "tgId": "123456789"})
            update_payload = next(payload for method, _path, payload in sync_calls if method == "POST")
            self.assertIsInstance(update_payload["id"], str)
            self.assertEqual(update_payload["id"], raw_client["uuid"])
            self.assertEqual(update_payload["tgId"], 123456789)
            self.assertEqual(update_payload["keepAlive"], 25)
            self.assertEqual(update_payload["allowedIPs"], ["10.0.0.2/32", "10.0.0.3/32"])
            self.assertEqual(update_payload["reverse"], {"tag": "reverse-tag"})
            self.assertEqual(update_payload["created_at"], raw_client["createdAt"])
            self.assertEqual(update_payload["updated_at"], raw_client["updatedAt"])
            self.assertEqual(update_payload["password"], "keep-password")
            self.assertEqual(update_payload["auth"], "keep-auth")
            self.assertEqual(update_payload["privateKey"], "keep-private")
            for key in ("uuid", "traffic", "inboundIds", "externalConfigIds", "createdAt", "updatedAt"):
                self.assertNotIn(key, update_payload)

            async_calls: list[tuple[str, str, dict | None]] = []
            server = xui.ServerClient()

            async def fake_async_request(method, api_path, data=None):
                async_calls.append((method, api_path, data))
                if method == "GET":
                    return {"success": True, "obj": record}
                return {"success": True, "obj": None}

            server._request = fake_async_request
            ok = asyncio.run(
                server.add_or_update_client(
                    "fallback-uuid",
                    email,
                    "fallback-sub",
                    expiry_ts=2_100_000_000_000,
                    enable=True,
                )
            )
            self.assertTrue(ok)
            async_payload = next(data for method, _path, data in async_calls if method == "POST")
            self.assertEqual(async_payload["id"], raw_client["uuid"])
            self.assertIsInstance(async_payload["id"], str)
            self.assertEqual(async_payload["allowedIPs"], ["10.0.0.2/32", "10.0.0.3/32"])
            self.assertEqual(async_payload["reverse"], {"tag": "reverse-tag"})
            self.assertEqual(async_payload["password"], "keep-password")
            self.assertNotIn("uuid", async_payload)

            legacy_client = xui._editable_client_payload(
                {"id": "legacy-string-uuid", "email": "legacy-user", "tgId": 43}
            )
            self.assertEqual(legacy_client["id"], "legacy-string-uuid")

            password_client = xui._editable_client_payload(
                {"id": 99, "email": "trojan-user", "password": "secret", "tgId": "42"}
            )
            self.assertNotIn("id", password_client)
            self.assertEqual(password_client["password"], "secret")
            self.assertEqual(password_client["tgId"], 42)


    def test_extend_client_sync_posts_string_uuid_without_second_prefetch(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            xui = reload_module("services.xui_api", config)
            email = "paiduser_424242424"
            current = {
                "id": 14825,
                "uuid": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
                "email": email,
                "subId": "sub-paid",
                "expiryTime": 1_900_000_000_000,
                "totalGB": 0,
                "limitIp": 0,
                "tgId": 424242424,
                "enable": True,
                "security": "auto",
                "flow": "xtls-rprx-vision",
                "allowedIPs": "",
            }
            calls: list[tuple[str, str, dict | None]] = []

            def fake_request(method, api_path, payload=None, timeout=12.0):
                calls.append((method, api_path, payload))
                if method == "POST":
                    current.update(payload or {})
                    current["uuid"] = current.pop("id")
                    current["id"] = 14825
                    return {"success": True, "msg": "Client updated"}
                return {
                    "success": True,
                    "obj": {"client": dict(current), "inboundIds": [1]},
                }

            xui.request_json_sync = fake_request
            xui.time.time = lambda: 1_800_000_000.0
            result = xui.extend_client_sync(email, 30, tg_id=424242424)

            self.assertEqual([method for method, _path, _payload in calls], ["GET", "POST", "GET"])
            posted = calls[1][2]
            self.assertEqual(posted["id"], "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
            self.assertIsInstance(posted["id"], str)
            self.assertEqual(posted["expiryTime"], 1_902_592_000_000)
            self.assertEqual(posted["tgId"], 424242424)
            self.assertEqual(posted["allowedIPs"], [])
            self.assertEqual(result["expiry_time"], 1_902_592_000_000)

    def test_renewal_stays_successful_when_post_succeeds_but_verify_get_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            xui = reload_module("services.xui_api", config)
            email = "paiduser_555"
            client = {
                "id": 77,
                "uuid": "aaaaaaaa-bbbb-cccc-dddd-ffffffffffff",
                "email": email,
                "subId": "sub-paid",
                "expiryTime": 1_900_000_000_000,
                "tgId": 555,
                "enable": True,
            }
            get_count = 0

            def fake_request(method, api_path, payload=None, timeout=12.0):
                nonlocal get_count
                if method == "GET":
                    get_count += 1
                    if get_count > 1:
                        raise RuntimeError("temporary verification failure")
                    return {"success": True, "obj": {"client": dict(client), "inboundIds": [1]}}
                self.assertEqual(method, "POST")
                return {"success": True, "msg": "Client updated"}

            xui.request_json_sync = fake_request
            xui.time.time = lambda: 1_800_000_000.0
            result = xui.extend_client_sync(email, 30, tg_id=555)
            self.assertEqual(result["expiry_time"], 1_902_592_000_000)
            self.assertTrue(result["enable"])
            self.assertEqual(result["tg_id"], 555)
            self.assertEqual(get_count, 2)

    def test_statistics_conversion_and_telegram_identity_rules(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            xui = reload_module("services.xui_api", config)
            self.assertEqual(xui.bytes_to_gb(1024**3), 1.0)
            self.assertEqual(xui.bytes_to_gb(None), 0.0)
            self.assertEqual(xui.bytes_to_gb("bad"), 0.0)

            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute(
                    "CREATE TABLE users(tg_id INTEGER PRIMARY KEY, username TEXT, uuid TEXT, email TEXT, expiry_time INTEGER, enable INTEGER, up INTEGER, down INTEGER, total INTEGER, sub_id TEXT, last_online TEXT, last_reminder_days INTEGER DEFAULT -1)"
                )
                connection.commit()
            finally:
                connection.close()

            legacy = xui.normalize_client(
                {
                    "email": "manual_1700000000",
                    "id": "legacy-uuid",
                    "expiryTime": 1_900_000_000_000,
                    "enable": True,
                }
            )
            xui.sync_snapshot_to_db({"clients": [legacy]})
            connection = sqlite3.connect(config.DB_PATH)
            try:
                legacy_id = connection.execute(
                    "SELECT tg_id FROM users WHERE email='manual_1700000000'"
                ).fetchone()[0]
            finally:
                connection.close()
            self.assertLess(legacy_id, 0, "numeric legacy suffix must not become a Telegram ID during bulk sync")

            explicit = dict(legacy)
            explicit["tg_id"] = 777001
            xui.sync_snapshot_to_db({"clients": [explicit]})
            connection = sqlite3.connect(config.DB_PATH)
            try:
                row = connection.execute(
                    "SELECT tg_id,email FROM users WHERE email='manual_1700000000'"
                ).fetchone()
            finally:
                connection.close()
            self.assertEqual(row, (777001, "manual_1700000000"))

    def test_existing_subscription_is_extended_instead_of_added(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            reload_module("init_db", config).migrate()
            subscriptions = reload_module("services.subscriptions", config)
            existing = {
                "email": "alice_123456",
                "uuid": "uuid-alice",
                "sub_id": "sub-alice",
                "expiry_time": 1_900_000_000_000,
                "enable": True,
                "tg_id": 123456,
            }
            updated = {**existing, "expiry_time": 1_902_592_000_000}
            calls: list[tuple[str, int, int | None]] = []
            subscriptions._candidate_for_subscription = lambda *_args: dict(existing)

            def extend(email, days, tg_id=None):
                calls.append((email, days, tg_id))
                return dict(updated)

            subscriptions.extend_client_sync = extend

            def should_not_add(*_args, **_kwargs):
                raise AssertionError("existing client must not be added again")

            subscriptions.add_client_sync = should_not_add
            result = subscriptions.ensure_subscription_sync(123456, "@alice", 30, config.DB_PATH)
            self.assertFalse(result.created)
            self.assertEqual(result.tg_id, 123456)
            self.assertEqual(calls, [("alice_123456", 30, 123456)])
            connection = sqlite3.connect(config.DB_PATH)
            try:
                row = connection.execute(
                    "SELECT tg_id,username,email,expiry_time FROM users WHERE tg_id=123456"
                ).fetchone()
            finally:
                connection.close()
            self.assertEqual(row, (123456, "alice", "alice_123456", updated["expiry_time"]))

    def test_duplicate_add_is_recovered_and_extended(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            reload_module("init_db", config).migrate()
            subscriptions = reload_module("services.subscriptions", config)
            subscriptions._candidate_for_subscription = lambda *_args: None
            subscriptions.inbound_ids_sync = lambda: [1]
            add_calls: list[str] = []
            extend_calls: list[tuple[str, int, int | None]] = []

            def duplicate(client, _inbounds):
                add_calls.append(str(client["email"]))
                raise RuntimeError(f"email already in use: {client['email']}")

            subscriptions.add_client_sync = duplicate
            subscriptions._client_from_snapshot_by_email = lambda email, force=True: {
                "email": email,
                "uuid": "existing-uuid",
                "sub_id": "existing-sub",
                "expiry_time": 1_800_000_000_000,
                "enable": True,
                "tg_id": 0,
            }

            def extend(email, days, tg_id=None):
                extend_calls.append((email, days, tg_id))
                return {
                    "email": email,
                    "uuid": "existing-uuid",
                    "sub_id": "existing-sub",
                    "expiry_time": 1_902_592_000_000,
                    "enable": True,
                    "tg_id": tg_id,
                }

            subscriptions.extend_client_sync = extend
            result = subscriptions.ensure_subscription_sync(987654321, "existinguser", 30, config.DB_PATH)
            self.assertFalse(result.created)
            self.assertTrue(result.recovered)
            self.assertEqual(add_calls, ["existinguser_987654321"])
            self.assertEqual(extend_calls, [("existinguser_987654321", 30, 987654321)])

    def test_manual_subscription_without_telegram_uses_nickname(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            reload_module("init_db", config).migrate()
            subscriptions = reload_module("services.subscriptions", config)
            subscriptions._candidate_for_subscription = lambda *_args: None
            subscriptions.inbound_ids_sync = lambda: [1]
            added = []

            def add_client(client, _inbounds):
                added.append(dict(client))

            subscriptions.add_client_sync = add_client
            subscriptions._client_from_snapshot_by_email = lambda *_args, **_kwargs: None

            result = subscriptions.ensure_subscription_sync(
                0, "ivan", 30, config.DB_PATH
            )

            self.assertLess(result.tg_id, 0)
            self.assertEqual(result.username, "ivan")
            self.assertEqual(added[0]["email"], "ivan")
            self.assertEqual(added[0]["tgId"], 0)

            connection = sqlite3.connect(config.DB_PATH)
            try:
                row = connection.execute(
                    "SELECT tg_id,username,email FROM users WHERE email='ivan'"
                ).fetchone()
            finally:
                connection.close()
            self.assertEqual(row, (result.tg_id, "ivan", "ivan"))

    def test_payment_approval_is_idempotent_and_rolls_back_on_panel_error(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            reload_module("init_db", config).migrate()
            subscriptions = reload_module("services.subscriptions", config)
            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute(
                    "INSERT INTO payments(tg_id,username,telegram_file_id,amount) VALUES(?,?,?,?)",
                    (123456, "alice", "file-1", 150),
                )
                first_payment = connection.execute("SELECT last_insert_rowid()").fetchone()[0]
                connection.execute(
                    "INSERT INTO payments(tg_id,username,telegram_file_id,amount) VALUES(?,?,?,?)",
                    (654321, "bob", "file-2", 150),
                )
                second_payment = connection.execute("SELECT last_insert_rowid()").fetchone()[0]
                connection.commit()
            finally:
                connection.close()

            activations: list[int] = []

            def activate(tg_id, username, days=30, db_path=None):
                activations.append(int(tg_id))
                return subscriptions.SubscriptionResult(
                    tg_id=int(tg_id),
                    username=str(username),
                    email=f"{username}_{tg_id}",
                    uuid="uuid",
                    sub_id="sub",
                    expiry_time=1_900_000_000_000,
                    created=False,
                )

            subscriptions.ensure_subscription_sync = activate
            approved = subscriptions.approve_payment_sync(first_payment, "999", 30, config.DB_PATH)
            repeated = subscriptions.approve_payment_sync(first_payment, "999", 30, config.DB_PATH)
            self.assertTrue(approved.success)
            self.assertTrue(repeated.success)
            self.assertTrue(repeated.already_processed)
            self.assertEqual(activations, [123456])

            def fail(*_args, **_kwargs):
                raise RuntimeError("3x-ui unavailable")

            subscriptions.ensure_subscription_sync = fail
            failed = subscriptions.approve_payment_sync(second_payment, "999", 30, config.DB_PATH)
            self.assertFalse(failed.success)
            connection = sqlite3.connect(config.DB_PATH)
            try:
                rows = dict(
                    connection.execute(
                        "SELECT id,status FROM payments WHERE id IN (?,?)", (first_payment, second_payment)
                    ).fetchall()
                )
                last_error = connection.execute(
                    "SELECT last_error FROM payments WHERE id=?", (second_payment,)
                ).fetchone()[0]
            finally:
                connection.close()
            self.assertEqual(rows[first_payment], "approved")
            self.assertEqual(rows[second_payment], "pending")
            self.assertIn("3x-ui unavailable", last_error)

    def test_receipt_ocr_rules_and_duplicate_protection(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.PAYMENT_RECEIVER = "Иван Иванов"
            config.PAYMENT_PHONE = "+79991234567"
            ocr = reload_module("services.receipt_ocr", config)
            now = datetime(2026, 8, 8, 15, 0, tzinfo=ZoneInfo("Europe/Moscow"))
            valid_text = """Перевод выполнен
Получатель: Иван И.
Телефон получателя: +7 *** ***-45-67
Сумма: 500 ₽
08.08.2026 14:30
"""
            valid = ocr.analyze_receipt(
                b"valid-receipt",
                receiver=config.PAYMENT_RECEIVER,
                phone=config.PAYMENT_PHONE,
                minimum_amount=150,
                max_age_hours=24,
                allow_masked_phone=True,
                timezone_name="Europe/Moscow",
                now=now,
                ocr_text=valid_text,
            )
            self.assertTrue(valid.passed, valid.reasons)
            self.assertEqual(valid.amount, 500)
            self.assertTrue(valid.name_match)
            self.assertTrue(valid.phone_match)
            self.assertTrue(valid.date_match)

            exact_limit = ocr.analyze_receipt(
                b"limit",
                receiver=config.PAYMENT_RECEIVER,
                phone=config.PAYMENT_PHONE,
                minimum_amount=150,
                max_age_hours=24,
                timezone_name="Europe/Moscow",
                now=now,
                ocr_text=valid_text.replace("500 ₽", "150 ₽"),
            )
            self.assertTrue(exact_limit.passed, exact_limit.reasons)
            self.assertEqual(exact_limit.amount, 150)
            self.assertTrue(exact_limit.amount_match)

            above_limit = ocr.analyze_receipt(
                b"above-limit",
                receiver=config.PAYMENT_RECEIVER,
                phone=config.PAYMENT_PHONE,
                minimum_amount=150,
                max_age_hours=24,
                timezone_name="Europe/Moscow",
                now=now,
                ocr_text=valid_text.replace("500 ₽", "150,01 ₽"),
            )
            self.assertTrue(above_limit.passed, above_limit.reasons)
            self.assertAlmostEqual(above_limit.amount or 0, 150.01, places=2)

            stale = ocr.analyze_receipt(
                b"stale",
                receiver=config.PAYMENT_RECEIVER,
                phone=config.PAYMENT_PHONE,
                minimum_amount=150,
                max_age_hours=24,
                timezone_name="Europe/Moscow",
                check_date=True,
                now=now,
                ocr_text=valid_text.replace("08.08.2026 14:30", "07.08.2026 10:00"),
            )
            self.assertFalse(stale.passed)
            self.assertFalse(stale.date_match)

            no_amount_text = """Перевод по номеру телефона +7 999 123-45-67
Получатель Иван Меншиков
08.08.2026 14:30
"""
            no_amount = ocr.analyze_receipt(
                b"no-amount",
                receiver=config.PAYMENT_RECEIVER,
                phone=config.PAYMENT_PHONE,
                minimum_amount=150,
                timezone_name="Europe/Moscow",
                now=now,
                ocr_text=no_amount_text,
            )
            self.assertIsNone(no_amount.amount)
            self.assertFalse(no_amount.passed)

            balance_only = ocr.analyze_receipt(
                b"balance-only",
                receiver=config.PAYMENT_RECEIVER,
                phone=config.PAYMENT_PHONE,
                minimum_amount=150,
                timezone_name="Europe/Moscow",
                now=now,
                ocr_text=no_amount_text + "Баланс: 10 000 ₽\n",
            )
            self.assertIsNone(balance_only.amount)
            self.assertFalse(balance_only.passed)

            failed_text = valid_text + "\nОперация отменена"
            failed = ocr.analyze_receipt(
                b"failed",
                receiver=config.PAYMENT_RECEIVER,
                phone=config.PAYMENT_PHONE,
                minimum_amount=150,
                timezone_name="Europe/Moscow",
                now=now,
                ocr_text=failed_text,
            )
            self.assertFalse(failed.passed)
            self.assertTrue(failed.explicit_failure)

            reload_module("init_db", config).migrate()
            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute(
                    "INSERT INTO payments(tg_id,username,telegram_file_id,amount) VALUES(?,?,?,?)",
                    (111, "first", "file-a", 150),
                )
                first_id = int(connection.execute("SELECT last_insert_rowid()").fetchone()[0])
                connection.execute(
                    "INSERT INTO payments(tg_id,username,telegram_file_id,amount) VALUES(?,?,?,?)",
                    (222, "second", "file-b", 150),
                )
                second_id = int(connection.execute("SELECT last_insert_rowid()").fetchone()[0])
                connection.commit()
            finally:
                connection.close()
            first = ocr.analyze_payment_receipt(
                config.DB_PATH,
                first_id,
                b"same-file-bytes",
                receiver=config.PAYMENT_RECEIVER,
                phone=config.PAYMENT_PHONE,
                minimum_amount=150,
                timezone_name="Europe/Moscow",
                now=now,
                ocr_text=valid_text,
            )
            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute("UPDATE payments SET status='approved' WHERE id=?", (first_id,))
                connection.commit()
            finally:
                connection.close()
            second = ocr.analyze_payment_receipt(
                config.DB_PATH,
                second_id,
                b"same-file-bytes",
                receiver=config.PAYMENT_RECEIVER,
                phone=config.PAYMENT_PHONE,
                minimum_amount=150,
                timezone_name="Europe/Moscow",
                now=now,
                ocr_text=valid_text,
            )
            self.assertTrue(first.passed)
            self.assertFalse(second.passed)
            self.assertEqual(second.status, "duplicate")
            self.assertEqual(second.duplicate_payment_id, first_id)
            connection = sqlite3.connect(config.DB_PATH)
            try:
                stored = connection.execute(
                    "SELECT ocr_status,receipt_amount,receipt_date FROM payments WHERE id=?",
                    (second_id,),
                ).fetchone()
                columns = {row[1] for row in connection.execute("PRAGMA table_info(payments)")}
            finally:
                connection.close()
            self.assertEqual(stored[0], "duplicate")
            self.assertEqual(stored[1], 500)
            self.assertTrue(stored[2])
            self.assertIn("auto_approved", columns)


    def test_receipt_mobile_screenshots_and_optional_filters(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            ocr = reload_module("services.receipt_ocr", config)
            examples = [
                ("""Перевод отправлен
300 P
В Альфа-Банк через СБП
Иван Иванович И
Статус перевода
""", 300.0),
                ("""Иван И.
+7 999 123-45-67
-150 P
Квитанция
Готово
""", 150.0),
                ("""Перевод выполнен
Текущий счёт --7656
3 255,36 P -> 3 105,36 P
-150 P
Без комиссии
Иван Иванович И.
В Альфа-Банк по номеру +7 999 123-45-67
""", 150.0),
            ]
            for index, (text, expected_amount) in enumerate(examples):
                result = ocr.analyze_receipt(
                    f"mobile-{index}".encode(),
                    receiver="Иван Иванович И",
                    phone="+7 999 123-45-67",
                    minimum_amount=150,
                    check_name=True,
                    check_phone=False,
                    check_amount=True,
                    check_date=False,
                    check_status=True,
                    ocr_text=text,
                )
                self.assertTrue(result.passed, (index, result.reasons, result.text))
                self.assertEqual(result.amount, expected_amount)

            first_strict = ocr.analyze_receipt(
                b"strict-phone-date",
                receiver="Иван Иванович И",
                phone="+7 999 123-45-67",
                minimum_amount=150,
                check_name=True,
                check_phone=True,
                check_amount=True,
                check_date=True,
                check_status=True,
                ocr_text=examples[0][0],
            )
            self.assertFalse(first_strict.passed)
            self.assertIn("не найден номер получателя", first_strict.reasons)
            self.assertIn("дата должна быть не старше 24 ч", first_strict.reasons)

    def test_pending_receipt_does_not_block_retry_as_duplicate(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            reload_module("init_db", config).migrate()
            ocr = reload_module("services.receipt_ocr", config)
            connection = sqlite3.connect(config.DB_PATH)
            try:
                for tg_id in (201, 202):
                    connection.execute(
                        "INSERT INTO payments(tg_id,username,telegram_file_id,amount,status) VALUES(?,?,?,?, 'pending')",
                        (tg_id, "friend", f"file-{tg_id}", 150),
                    )
                connection.commit()
                ids = [row[0] for row in connection.execute("SELECT id FROM payments ORDER BY id")]
            finally:
                connection.close()
            text = "Иван И.\n-150 P\nПеревод выполнен"
            first = ocr.analyze_payment_receipt(
                config.DB_PATH, ids[0], b"retry-same", receiver="Иван И", phone="", minimum_amount=150,
                check_duplicate=True, ocr_text=text,
            )
            second = ocr.analyze_payment_receipt(
                config.DB_PATH, ids[1], b"retry-same", receiver="Иван И", phone="", minimum_amount=150,
                check_duplicate=True, ocr_text=text,
            )
            self.assertTrue(first.passed)
            self.assertTrue(second.passed)
            self.assertIsNone(second.duplicate_payment_id)

    def test_receipt_duplicate_filter_can_be_disabled(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            reload_module("init_db", config).migrate()
            ocr = reload_module("services.receipt_ocr", config)
            connection = sqlite3.connect(config.DB_PATH)
            try:
                for tg_id in (101, 102):
                    connection.execute(
                        "INSERT INTO payments(tg_id,username,telegram_file_id,amount) VALUES(?,?,?,?)",
                        (tg_id, "friend", f"file-{tg_id}", 150),
                    )
                connection.commit()
                ids = [row[0] for row in connection.execute("SELECT id FROM payments ORDER BY id")]
            finally:
                connection.close()
            text = "Иван И.\n-150 P\nПеревод выполнен"
            first = ocr.analyze_payment_receipt(
                config.DB_PATH, ids[0], b"same", receiver="Иван М", phone="", minimum_amount=150,
                check_duplicate=True, ocr_text=text,
            )
            second = ocr.analyze_payment_receipt(
                config.DB_PATH, ids[1], b"same", receiver="Иван М", phone="", minimum_amount=150,
                check_duplicate=False, ocr_text=text,
            )
            self.assertTrue(first.passed)
            self.assertTrue(second.passed)
            self.assertIsNone(second.duplicate_payment_id)

    def test_change_client_days_supports_subtraction_without_unlimited(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            xui = reload_module("services.xui_api", config)
            now_ms = 1_800_000_000_000
            current_ms = now_ms + 20 * 86_400_000
            state = {
                "client": {
                    "id": "11111111-2222-3333-4444-555555555555",
                    "email": "friend_123",
                    "expiryTime": current_ms,
                    "enable": True,
                },
                "normalized": {
                    "email": "friend_123",
                    "uuid": "11111111-2222-3333-4444-555555555555",
                    "expiry_time": current_ms,
                    "enable": True,
                },
            }
            updates: list[dict] = []
            xui.time.time = lambda: now_ms / 1000
            xui.get_client_record_sync = lambda _email: state
            xui.update_client_sync = lambda _email, changes, record=None: updates.append(dict(changes))

            reduced = xui.change_client_days_sync("friend_123", -5, tg_id=123)
            self.assertEqual(updates[-1]["expiryTime"], now_ms + 15 * 86_400_000)
            self.assertTrue(updates[-1]["enable"])
            self.assertEqual(updates[-1]["tgId"], 123)
            self.assertEqual(reduced["expiry_time"], now_ms + 15 * 86_400_000)

            updates.clear()
            xui.change_client_days_sync("friend_123", -30, tg_id=123)
            self.assertGreater(updates[-1]["expiryTime"], 0)
            self.assertFalse(updates[-1]["enable"])

            state["client"]["expiryTime"] = 0
            state["normalized"]["expiry_time"] = 0
            with self.assertRaises(ValueError):
                xui.change_client_days_sync("friend_123", -1, tg_id=123)

    def test_web_user_days_route_accepts_negative_values(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            reload_module("init_db", config).migrate()
            webapp = reload_module("webapp", config)
            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute(
                    "INSERT INTO users(tg_id,username,email,expiry_time,enable) VALUES(?,?,?,?,?)",
                    (123456, "friend", "friend_123456", 1_900_000_000_000, 1),
                )
                connection.commit()
            finally:
                connection.close()

            captured: list[tuple[str, int, int | None]] = []

            def change(email, days_delta, tg_id=None):
                captured.append((email, days_delta, tg_id))
                return {"expiry_time": 1_899_395_200_000, "enable": True}

            webapp.change_client_days_sync = change
            webapp.fetch_and_sync = lambda *args, **kwargs: {"stale": False, "clients": []}

            class DummyRequest:
                session = {"auth": True, "user": "tester"}

            response = webapp.adjust_days(DummyRequest(), 123456, -7)
            self.assertEqual(response.status_code, 303)
            self.assertEqual(captured, [("friend_123456", -7, 123456)])
            connection = sqlite3.connect(config.DB_PATH)
            try:
                expiry, enabled = connection.execute(
                    "SELECT expiry_time,enable FROM users WHERE tg_id=123456"
                ).fetchone()
            finally:
                connection.close()
            self.assertEqual(expiry, 1_899_395_200_000)
            self.assertEqual(enabled, 1)
            with self.assertRaises(Exception):
                webapp.adjust_days(DummyRequest(), 123456, 0)

    def test_ocr_approval_uses_selected_term_not_overpayment(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            reload_module("init_db", config).migrate()
            subscriptions = reload_module("services.subscriptions", config)
            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute(
                    """INSERT INTO payments(
                        tg_id,username,telegram_file_id,amount,receipt_amount,ocr_status
                    ) VALUES(?,?,?,?,?,?)""",
                    (777777, "friend", "receipt-file", 150, 500.0, "passed"),
                )
                payment_id = int(connection.execute("SELECT last_insert_rowid()").fetchone()[0])
                connection.commit()
            finally:
                connection.close()

            calls: list[tuple[int, str, int]] = []

            def activate(tg_id, username, days=30, db_path=None):
                calls.append((int(tg_id), str(username), int(days)))
                return subscriptions.SubscriptionResult(
                    tg_id=int(tg_id),
                    username=str(username),
                    email=f"{username}_{tg_id}",
                    uuid="uuid",
                    sub_id="sub",
                    expiry_time=1_900_000_000_000,
                    created=False,
                )

            subscriptions.ensure_subscription_sync = activate
            result = subscriptions.approve_payment_sync(
                payment_id, "ocr:auto", days=30, db_path=config.DB_PATH
            )
            self.assertTrue(result.success)
            self.assertEqual(calls, [(777777, "friend", 30)])
            connection = sqlite3.connect(config.DB_PATH)
            try:
                status, auto_approved, receipt_amount = connection.execute(
                    "SELECT status,auto_approved,receipt_amount FROM payments WHERE id=?",
                    (payment_id,),
                ).fetchone()
            finally:
                connection.close()
            self.assertEqual(status, "approved")
            self.assertEqual(auto_approved, 1)
            self.assertEqual(receipt_amount, 500.0)

    def test_receipt_image_magic_detection(self):
        media = reload_module("services.media", types.ModuleType("config"))
        self.assertEqual(media.detect_image_media_type(b"\xff\xd8\xffdata", "receipt.bin", "application/octet-stream"), "image/jpeg")
        self.assertEqual(media.detect_image_media_type(b"\x89PNG\r\n\x1a\ndata", "receipt", "application/octet-stream"), "image/png")
        self.assertEqual(media.detect_image_media_type(b"not-an-image", "receipt.webp", "application/octet-stream"), "image/webp")
        self.assertIsNone(media.detect_image_media_type(b"not-an-image", "receipt.bin", "application/octet-stream"))

    def test_yandex_local_backup_and_update_profile_preservation(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.YANDEX_DISK_ENABLED = True
            config.YANDEX_DISK_MODE = "local"
            Path(config.YANDEX_LOCAL_PATH).mkdir(parents=True)
            backup = reload_module("backup", config)
            source = temp / "backup.tar.gz"
            source.write_bytes(b"backup-data")
            ok, detail = backup.upload_to_yandex(source)
            self.assertTrue(ok, detail)
            copied = Path(config.YANDEX_LOCAL_PATH) / config.YANDEX_DISK_PATH / source.name
            self.assertEqual(copied.read_bytes(), source.read_bytes())
            self.assertFalse(any(copied.parent.glob(".*.uploading-*")))

            config.INSTALL_PROFILE = "lite"
            manager = reload_module("update_manager", config)
            package = temp / "package"
            package.mkdir()
            installer = package / "install.sh"
            installer.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
            installer.chmod(0o755)
            from unittest.mock import patch

            with patch.object(manager, "launch_detached", return_value="runtime-unit") as launch:
                manager.launch_update(package, "2.5.0")
            self.assertEqual(launch.call_count, 1)
            wrappers = sorted(Path(config.UPDATE_DIR).glob("apply-*.sh"))
            self.assertEqual(len(wrappers), 1)
            command = wrappers[0].read_text(encoding="utf-8")
            self.assertIn("--profile lite", command)
            self.assertIn("--update-existing", command)

    def test_yandex_direct_webdav_upload_uses_final_path_and_verifies_size(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.YANDEX_DISK_ENABLED = True
            config.YANDEX_DISK_MODE = "local"
            local_root = Path(config.YANDEX_LOCAL_PATH)
            local_root.mkdir(parents=True)
            Path(config.YANDEX_DAVFS_SECRETS_PATH).write_text(
                f"{local_root} test-login test-app-password\n",
                encoding="utf-8",
            )
            backup = reload_module("backup", config)
            source = temp / "vpn-backup.tar.gz"
            payload = b"verified-webdav-payload"
            source.write_bytes(payload)
            recorded: dict[str, object] = {"directories": [], "uploads": []}

            class FakeResponse:
                def __init__(self, status_code=200, content=b"", data=None):
                    self.status_code = status_code
                    self.content = content
                    self._data = data or {}

                def raise_for_status(self):
                    if self.status_code >= 400:
                        raise RuntimeError(f"HTTP {self.status_code}")

                def json(self):
                    return self._data

            class FakeClient:
                def __init__(self, *args, **kwargs):
                    recorded["auth"] = kwargs.get("auth")

                def __enter__(self):
                    return self

                def __exit__(self, exc_type, exc, tb):
                    return False

                def request(self, method, url, headers=None, content=None, **kwargs):
                    if method == "MKCOL":
                        recorded["directories"].append(url)
                        return FakeResponse(201)
                    if method == "PROPFIND":
                        if str(url).rstrip("/").endswith("VPN-Service-Backups"):
                            body = (
                                b'<?xml version="1.0"?><d:multistatus xmlns:d="DAV:">'
                                b'<d:response><d:propstat><d:prop><d:resourcetype>'
                                b'<d:collection/></d:resourcetype></d:prop></d:propstat>'
                                b'</d:response></d:multistatus>'
                            )
                        else:
                            body = (
                                b'<?xml version="1.0"?><d:multistatus xmlns:d="DAV:">'
                                b'<d:response><d:propstat><d:prop><d:getcontentlength>'
                                + str(len(payload)).encode()
                                + b'</d:getcontentlength></d:prop></d:propstat></d:response>'
                                b'</d:multistatus>'
                            )
                        return FakeResponse(207, body)
                    raise AssertionError((method, url))

                def put(self, url, headers=None, content=None, **kwargs):
                    body = b"".join(content) if not isinstance(content, (bytes, bytearray)) else bytes(content)
                    recorded["uploads"].append((url, headers or {}, body))
                    return FakeResponse(201)

                def delete(self, url, **kwargs):
                    return FakeResponse(204)

            backup.httpx.Client = FakeClient
            ok, detail = backup.upload_to_yandex(source)
            self.assertTrue(ok, detail)
            self.assertIn("проверено", detail)
            self.assertFalse(recorded["directories"])
            self.assertEqual(len(recorded["uploads"]), 1)
            upload_url, headers, body = recorded["uploads"][0]
            self.assertTrue(str(upload_url).endswith("/VPN-Service-Backups/vpn-backup.tar.gz"))
            self.assertEqual(headers["Content-Length"], str(len(payload)))
            self.assertEqual(body, payload)
            self.assertFalse((local_root / config.YANDEX_DISK_PATH / source.name).exists())

    def test_yandex_oauth_upload_sets_content_length_and_checks_remote_file(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.YANDEX_DISK_ENABLED = True
            config.YANDEX_DISK_MODE = "oauth"
            config.YANDEX_DISK_TOKEN = "oauth-token"
            backup = reload_module("backup", config)
            source = temp / "oauth-backup.tar.gz"
            payload = b"oauth-payload"
            source.write_bytes(payload)
            recorded: dict[str, object] = {"uploaded": b"", "headers": {}}

            class FakeResponse:
                def __init__(self, status_code=200, data=None, content=b""):
                    self.status_code = status_code
                    self._data = data or {}
                    self.content = content

                def raise_for_status(self):
                    if self.status_code >= 400:
                        raise RuntimeError(f"HTTP {self.status_code}")

                def json(self):
                    return self._data

            class FakeClient:
                def __init__(self, *args, **kwargs):
                    self.api = bool((kwargs.get("headers") or {}).get("Authorization"))

                def __enter__(self):
                    return self

                def __exit__(self, exc_type, exc, tb):
                    return False

                def put(self, url, params=None, headers=None, content=None, **kwargs):
                    if self.api:
                        return FakeResponse(201)
                    recorded["headers"] = headers or {}
                    recorded["uploaded"] = b"".join(content)
                    return FakeResponse(201)

                def get(self, url, params=None, **kwargs):
                    if url.endswith("/resources/upload"):
                        return FakeResponse(200, {"href": "https://upload.example/file", "method": "PUT"})
                    if url.endswith("/resources"):
                        return FakeResponse(
                            200,
                            {
                                "name": source.name,
                                "path": f"disk:/{config.YANDEX_DISK_PATH}/{source.name}",
                                "type": "file",
                                "size": len(payload),
                            },
                        )
                    raise AssertionError(url)

            backup.httpx.Client = FakeClient
            ok, detail = backup.upload_to_yandex(source)
            self.assertTrue(ok, detail)
            self.assertIn("проверено", detail)
            self.assertEqual(recorded["headers"]["Content-Length"], str(len(payload)))
            self.assertEqual(recorded["uploaded"], payload)

    def test_install_scripts_and_lite_dependencies(self):
        for script in (ROOT / "install.sh", ROOT / "install_with_web.sh", ROOT / "install_bot_only.sh", APP / "configure_yandex_webdav.sh"):
            result = subprocess.run(["bash", "-n", str(script)], capture_output=True, text=True, check=False)
            self.assertEqual(result.returncode, 0, f"{script.name}: {result.stderr}")
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        self.assertIn("--update-existing", installer)
        self.assertIn("PROFILE == full", installer)
        self.assertIn("PROFILE == lite", installer)
        self.assertIn("tesseract-ocr-rus", installer)
        self.assertIn("tesseract-ocr-eng", installer)
        lite_requirements = (APP / "requirements-lite.txt").read_text(encoding="utf-8").lower()
        self.assertIn("pytesseract", lite_requirements)
        self.assertIn("pillow", lite_requirements)
        self.assertNotIn("fastapi", lite_requirements)
        self.assertNotIn("uvicorn", lite_requirements)
        self.assertNotIn("python-multipart", lite_requirements)

    def test_webapp_import_health_and_new_routes(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            webapp = reload_module("webapp", config)
            self.assertIn("2.8.0", webapp.health())
            paths = {getattr(route, "path", "") for route in webapp.app.routes}
            self.assertIn("/payments/{payment_id}/receipt/image", paths)
            self.assertIn("/users/{tg_id}/days", paths)
            self.assertIn("/users/{tg_id}/bind-telegram", paths)
            source = (APP / "webapp.py").read_text(encoding="utf-8")
            self.assertIn('min="-3650"', source)
            self.assertIn("Изменить дни", source)
            self.assertIn("/updates/token", paths)

    def test_update_archive_validation_blocks_traversal(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            manager = reload_module("update_manager", config)
            valid = temp / "valid.tar.gz"
            with tarfile.open(valid, "w:gz") as archive:
                version = b"9.9.9\n"
                version_info = tarfile.TarInfo("VPN_Service/app/VERSION")
                version_info.size = len(version)
                archive.addfile(version_info, io.BytesIO(version))
                installer = b"#!/bin/bash\n"
                installer_info = tarfile.TarInfo("VPN_Service/install.sh")
                installer_info.size = len(installer)
                archive.addfile(installer_info, io.BytesIO(installer))
            info = manager.inspect_archive(valid)
            self.assertEqual(info["version"], "9.9.9")
            root = manager.safe_extract(valid, temp / "extract")
            self.assertTrue((root / "install.sh").is_file())

            bad = temp / "bad.tar.gz"
            with tarfile.open(bad, "w:gz") as archive:
                payload = b"bad"
                item = tarfile.TarInfo("../../outside")
                item.size = len(payload)
                archive.addfile(item, io.BytesIO(payload))
            with self.assertRaises(manager.UpdateError):
                manager.inspect_archive(bad)

    def test_expired_subscription_never_matches_reminder(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            aiogram = types.ModuleType("aiogram")

            sent: list[tuple[int, str]] = []
            created: list[int] = []

            class DummySession:
                async def close(self):
                    return None

            class DummyBot:
                def __init__(self, *_args, **_kwargs):
                    created.append(1)
                    self.session = DummySession()

                async def send_message(self, tg_id, text, **_kwargs):
                    sent.append((int(tg_id), str(text)))

            aiogram.Bot = DummyBot
            sys.modules["aiogram"] = aiogram
            reminders = reload_module("trigger_reminders", config)
            now_ms = int(datetime(2026, 1, 15, 12, 0, 0).timestamp() * 1000)
            self.assertIsNone(reminders.reminder_day(now_ms - 1, now_ms))
            self.assertEqual(reminders.reminder_day(now_ms + 60_000, now_ms), 0)

            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute(
                    "CREATE TABLE users(tg_id INTEGER PRIMARY KEY,username TEXT,expiry_time INTEGER,enable INTEGER,last_reminder_days INTEGER DEFAULT -1)"
                )
                connection.execute(
                    "INSERT INTO users VALUES(?,?,?,?,?)",
                    (123, "expired", now_ms - 1, 1, -1),
                )
                connection.commit()
            finally:
                connection.close()

            reminders.fetch_and_sync = lambda *_args, **_kwargs: {"stale": False, "clients": []}
            self.assertEqual(asyncio.run(reminders.run()), 0)
            self.assertEqual(sent, [])

            # Even a future local row is not processed when the live API cannot be verified.
            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute(
                    "INSERT INTO users VALUES(?,?,?,?,?)",
                    (456, "future", now_ms + 60_000, 1, -1),
                )
                connection.commit()
            finally:
                connection.close()
            before = len(created)
            reminders.fetch_and_sync = lambda *_args, **_kwargs: {"stale": True, "error": "offline"}
            self.assertEqual(asyncio.run(reminders.run()), 0)
            self.assertEqual(len(created), before)
            self.assertEqual(sent, [])

    def test_backup_interval_and_full_layout(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            connection = sqlite3.connect(config.DB_PATH)
            try:
                connection.execute("CREATE TABLE sample(value TEXT)")
                connection.execute("INSERT INTO sample VALUES('ok')")
                connection.commit()
            finally:
                connection.close()
            connection = sqlite3.connect(config.XUI_DB_PATH)
            try:
                connection.execute("CREATE TABLE sample(value TEXT)")
                connection.commit()
            finally:
                connection.close()
            backup = reload_module("backup", config)
            self.assertTrue(backup.scheduled_backup_due(now=1000))
            backup._write_state({"last_backup_ts": 1000})
            self.assertFalse(backup.scheduled_backup_due(now=1000 + 2 * 86400))
            self.assertTrue(backup.scheduled_backup_due(now=1000 + 3 * 86400))
            archive = backup.create_backup()
            with tarfile.open(archive, "r:gz") as handle:
                names = set(handle.getnames())
            self.assertIn("vpn_service_backup/manifest.json", names)
            self.assertTrue(any(name.endswith("/bot/VERSION") for name in names))
            self.assertTrue(any(name.endswith("/databases/x-ui.db") for name in names))

            payload = temp / "large.bin"
            payload.write_bytes(b"abcdefghij")
            parts = backup.split_for_telegram(payload, temp / "parts", 4)
            self.assertEqual([part.stat().st_size for part in parts], [4, 4, 2])
            self.assertEqual(b"".join(part.read_bytes() for part in parts), payload.read_bytes())

            calls: list[int] = []
            original_create = backup.create_backup

            def counted_create():
                calls.append(1)
                return original_create()

            backup.create_backup = counted_create
            backup._write_state({"last_backup_ts": 0})
            self.assertEqual(backup.main(["--scheduled", "--local-only"]), 0)
            self.assertEqual(backup.main(["--scheduled", "--local-only"]), 0)
            self.assertEqual(len(calls), 1)


if __name__ == "__main__":
    unittest.main()
