from __future__ import annotations

import hashlib
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient

from test_core import fake_config, reload_module


def _set_test_password(config) -> None:
    salt = b"0123456789abcdef"
    digest = hashlib.pbkdf2_hmac("sha256", b"test", salt, 1000).hex()
    config.WEB_PASSWORD_HASH = f"pbkdf2_sha256$1000${salt.hex()}${digest}"


def _reload_webapp(config):
    for name in (
        "webapp",
        "auth_security",
        "broadcast_manager",
        "diagnostics",
        "identity_migration",
        "panel_notifications",
        "service_audit",
        "update_manager",
        "user_events",
        "backup",
        "init_db",
        "services.media",
        "services.telegram_events",
        "services.subscriptions",
        "services.xui_api",
    ):
        sys.modules.pop(name, None)
    return reload_module("webapp", config)


def _login(client: TestClient) -> None:
    response = client.post(
        "/login",
        data={"username": "admin", "password": "test"},
        follow_redirects=False,
    )
    assert response.status_code == 303


class Platform267PanelTests(unittest.TestCase):
    @staticmethod
    def _database_with_user(config, tg_id: int = 101, username: str = "alice") -> None:
        init_db = reload_module("init_db", config)
        init_db.migrate()
        with sqlite3.connect(config.DB_PATH) as connection:
            connection.execute(
                "INSERT INTO users(tg_id,username,email) VALUES(?,?,?)",
                (tg_id, username, f"{username}@example"),
            )
            connection.commit()

    def test_opening_conversation_repairs_stale_cursor_and_clears_counter(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            _set_test_password(config)
            self._database_with_user(config)
            events = reload_module("user_events", config)
            event_id = events.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_message",
                text="Новое сообщение",
                db_path=config.DB_PATH,
            )
            # Reproduce a stale/imported compact state seen in older databases:
            # the count and incoming cursor no longer agree with the journal.
            with sqlite3.connect(config.DB_PATH) as connection:
                connection.execute(
                    """
                    UPDATE user_message_state
                    SET unread_count=17,last_read_event_id=0,last_incoming_event_id=999999
                    WHERE tg_id=101
                    """
                )
                connection.commit()

            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            with TestClient(webapp.app) as client:
                _login(client)
                before = client.get("/api/panel/notifications").json()
                self.assertEqual(before["messages"]["total"], 17)
                detail = client.get("/users/id/101")
                self.assertEqual(detail.status_code, 200)
                self.assertIn("Новое сообщение", detail.text)
                after = client.get("/api/panel/notifications").json()
                self.assertEqual(after["messages"]["total"], 0)

            with sqlite3.connect(config.DB_PATH) as connection:
                state = connection.execute(
                    """
                    SELECT last_read_event_id,last_incoming_event_id,unread_count
                    FROM user_message_state WHERE tg_id=101
                    """
                ).fetchone()
            self.assertEqual(state, (event_id, event_id, 0))

    def test_new_payment_sets_badge_and_opening_payments_clears_it(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            _set_test_password(config)
            self._database_with_user(config)
            # The notification cursor was created by the migration above. A row
            # inserted after that point is a genuinely new receipt, regardless
            # of whether OCR immediately approves it.
            with sqlite3.connect(config.DB_PATH) as connection:
                cursor = connection.execute(
                    """
                    INSERT INTO payments(
                        tg_id,username,telegram_file_id,status,amount,
                        receipt_amount,ocr_status,auto_approved
                    ) VALUES(?,?,?,?,?,?,?,?)
                    """,
                    (101, "alice", "receipt-file-id", "approved", 150, 150.0, "passed", 1),
                )
                payment_id = int(cursor.lastrowid)
                connection.commit()

            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            with TestClient(webapp.app) as client:
                _login(client)
                snapshot = client.get("/api/panel/notifications")
                self.assertEqual(snapshot.status_code, 200)
                payload = snapshot.json()
                self.assertEqual(payload["payments"]["total"], 1)
                self.assertEqual(payload["payments"]["last_payment_id"], payment_id)
                self.assertEqual(payload["payments"]["latest"]["status"], "approved")
                self.assertEqual(payload["payments"]["latest"]["amount"], 150.0)

                users_page = client.get("/users")
                self.assertIn('id="payments-nav-badge"', users_page.text)
                self.assertIn('aria-label="Новых оплат: 1"', users_page.text)

                # No explicit filter: a new auto-approved receipt must still be
                # visible, and opening the section acknowledges current rows.
                payments_page = client.get("/payments")
                self.assertEqual(payments_page.status_code, 200)
                self.assertIn("@alice", payments_page.text)
                self.assertIn("Автоматически", payments_page.text)
                after = client.get("/api/panel/notifications").json()
                self.assertEqual(after["payments"]["total"], 0)

    def test_existing_payments_are_baselined_when_feature_is_first_installed(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            path = Path(config.DB_PATH)
            with sqlite3.connect(path) as connection:
                connection.executescript(
                    """
                    CREATE TABLE payments(
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        tg_id INTEGER NOT NULL,
                        username TEXT,
                        amount INTEGER,
                        receipt_amount REAL,
                        status TEXT,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP
                    );
                    INSERT INTO payments(tg_id,username,amount,receipt_amount,status)
                    VALUES(101,'alice',150,150,'pending');
                    """
                )
                connection.commit()
            notifications = reload_module("panel_notifications", config)
            summary = notifications.payment_notifications_summary(db_path=config.DB_PATH)
            self.assertEqual(summary["total"], 0)
            with sqlite3.connect(config.DB_PATH) as connection:
                connection.execute(
                    "INSERT INTO payments(tg_id,username,amount,receipt_amount,status) VALUES(?,?,?,?,?)",
                    (102, "bob", 150, 150.0, "pending"),
                )
                connection.commit()
            summary = notifications.payment_notifications_summary(db_path=config.DB_PATH)
            self.assertEqual(summary["total"], 1)
            self.assertEqual(summary["latest"]["username"], "bob")

    def test_web_broadcast_sends_caption_and_attachment_as_one_payload(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            _set_test_password(config)
            self._database_with_user(config)
            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            captured: dict = {}

            def fake_start(**kwargs):
                captured.update(kwargs)
                source = kwargs.get("source")
                captured["source_bytes"] = source.read_bytes() if source else b""
                return {
                    "job_id": "mail-combined",
                    "status": {"job_id": "mail-combined", "state": "queued", "progress": 0},
                }

            webapp.broadcast_manager.start_broadcast = fake_start
            jpeg = b"\xff\xd8\xff\xe0" + b"combined-photo"
            with TestClient(webapp.app) as client:
                _login(client)
                page = client.get("/broadcast")
                self.assertEqual(page.status_code, 200)
                self.assertIn("одним сообщением", page.text)
                response = client.post(
                    "/broadcast/start",
                    data={"message": "Подпись вместе с фотографией", "confirm": "1"},
                    files={"media": ("offer.jpg", jpeg, "image/jpeg")},
                    headers={"Accept": "application/json"},
                )
                self.assertEqual(response.status_code, 202)
                self.assertEqual(response.json()["job_id"], "mail-combined")

            self.assertEqual(captured["actor"], "admin")
            self.assertEqual(captured["kind"], "auto")
            self.assertEqual(captured["message"], "Подпись вместе с фотографией")
            self.assertEqual(captured["original_name"], "offer.jpg")
            self.assertEqual(captured["content_type"], "image/jpeg")
            self.assertEqual(captured["source_bytes"], jpeg)

    def test_broadcast_manager_auto_detects_photo_and_document_with_caption(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            self._database_with_user(config)
            manager = reload_module("broadcast_manager", config)
            photo = temp / "photo.jpg"
            photo.write_bytes(b"\xff\xd8\xff\xe0" + b"photo")
            document = temp / "manual.pdf"
            document.write_bytes(b"%PDF-1.7\nexample")

            # Avoid launching systemd; the manifest itself is the contract used
            # by the worker to send one media message with the text as caption.
            from unittest.mock import patch
            with patch.object(manager, "launch_detached", return_value="runtime-unit"):
                photo_job = manager.start_broadcast(
                    actor="admin",
                    message="Подпись фото",
                    kind="auto",
                    source=photo,
                    original_name=photo.name,
                    content_type="image/jpeg",
                )
            photo_manifest = manager.read_manifest(photo_job["job_id"])
            self.assertEqual(photo_manifest["kind"], "photo")
            self.assertEqual(photo_manifest["message"], "Подпись фото")

            # Mark the first mock job complete so a second job may be created.
            manager.write_status(photo_job["job_id"], "completed", progress=100)
            with patch.object(manager, "launch_detached", return_value="runtime-unit"):
                document_job = manager.start_broadcast(
                    actor="admin",
                    message="Инструкция во вложении",
                    kind="auto",
                    source=document,
                    original_name=document.name,
                    content_type="application/pdf",
                )
            document_manifest = manager.read_manifest(document_job["job_id"])
            self.assertEqual(document_manifest["kind"], "document")
            self.assertEqual(document_manifest["message"], "Инструкция во вложении")


if __name__ == "__main__":
    unittest.main()
