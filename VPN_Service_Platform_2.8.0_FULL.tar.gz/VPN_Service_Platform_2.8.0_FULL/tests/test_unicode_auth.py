import hashlib
import hmac
import importlib
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
if str(APP) not in sys.path:
    sys.path.insert(0, str(APP))

from tests.test_core import fake_config, reload_module

with __import__("tempfile").TemporaryDirectory() as _tmp:
    _config = fake_config(Path(_tmp))
    module = reload_module("webapp", _config)
    config = _config


def test_secure_text_compare_supports_unicode():
    assert module._secure_text_compare("иван", "иван") is True
    assert module._secure_text_compare("иван", "Иван") is False
    assert module._secure_text_compare("menshikovivan", "menshikovivan") is True


def test_verify_password_supports_unicode_plaintext():
    config.WEB_PASSWORD_HASH = "пароль-сервера"
    assert module.verify_password("пароль-сервера") is True
    assert module.verify_password("другой-пароль") is False


def test_verify_password_pbkdf2_still_works():
    password = "пароль-сервера"
    salt = bytes.fromhex("00112233445566778899aabbccddeeff")
    iterations = 120000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations).hex()
    config.WEB_PASSWORD_HASH = f"pbkdf2_sha256${iterations}${salt.hex()}${digest}"
    assert module.verify_password(password) is True
    assert module.verify_password("неверно") is False
