from pathlib import Path
import sys
import tarfile
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))


def test_rollback_worker_restores_real_installer_snapshot(monkeypatch):
    import rollback_worker
    import update_manager

    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        target = base / "vpn-service-app"
        target.mkdir(parents=True)
        (target / "main.py").write_text("current", encoding="utf-8")
        (target / "config.py").write_text("x=0", encoding="utf-8")

        source = base / "previous"
        source.mkdir(parents=True)
        (source / "main.py").write_text("previous", encoding="utf-8")
        (source / "config.py").write_text("x=1", encoding="utf-8")
        (source / "webapp.py").write_text("old web", encoding="utf-8")

        archive = base / "pre_update_20260817_120000.tar.gz"
        with tarfile.open(archive, "w:gz") as tar:
            tar.add(source, arcname="vpn_bot")

        monkeypatch.setattr(update_manager, "APP_DIR", target)
        monkeypatch.setattr(rollback_worker.update_manager, "APP_DIR", target)
        monkeypatch.setattr(update_manager, "_preupdate_version", lambda _p: "")
        monkeypatch.setattr(rollback_worker.update_manager, "_preupdate_version", lambda _p: "")
        monkeypatch.setattr(rollback_worker, "restart_services", lambda: None)
        monkeypatch.setattr(rollback_worker.subprocess, "run", lambda *a, **k: type("R", (), {"returncode": 0})())
        monkeypatch.setattr(rollback_worker.update_manager, "write_status", lambda *a, **k: None)
        monkeypatch.setattr(rollback_worker.update_manager, "read_status", lambda: {"progress": 90})

        result = rollback_worker.run("job-test", archive)

        assert result == 0
        assert (target / "main.py").read_text(encoding="utf-8") == "previous"
        assert (target / "config.py").read_text(encoding="utf-8") == "x=1"
        assert (target / "webapp.py").read_text(encoding="utf-8") == "old web"
