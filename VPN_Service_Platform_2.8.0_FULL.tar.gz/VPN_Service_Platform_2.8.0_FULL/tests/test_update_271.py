from pathlib import Path
import tarfile,sys,types,importlib,tempfile
root=Path(__file__).resolve().parents[1]
config=types.ModuleType("config")
config.UPDATE_DIR=str(root/".test-updates")
config.UPDATE_MAX_ARCHIVE_MB=50
config.UPDATE_VERIFY_TLS=True
config.BACKUP_DIR=str(root/".test-backups")
config.WEB_USERNAME="menshikovivan"
sys.modules["config"]=config
sys.path.insert(0,str(root/"app"))
sys.modules.pop("update_manager",None)
import update_manager

def test_read_embedded_release_notes(tmp_path):
    pkg=tmp_path/"r.tar.gz"; d=tmp_path/"root"/"app"; d.mkdir(parents=True)
    (d/"VERSION").write_text("9.9.9\n"); (tmp_path/"root"/"install.sh").write_text("#!/bin/bash\n"); (tmp_path/"root"/"RELEASE_NOTES_9.9.9.md").write_text("# Release\n\n- Change A\n")
    with tarfile.open(pkg,"w:gz") as t:
        t.add(tmp_path/"root"/"app",arcname="root/app"); t.add(tmp_path/"root"/"install.sh",arcname="root/install.sh"); t.add(tmp_path/"root"/"RELEASE_NOTES_9.9.9.md",arcname="root/RELEASE_NOTES_9.9.9.md")
    assert "Change A" in update_manager._read_changelog_from_archive(pkg,"9.9.9")


def test_rollback_manifest_does_not_require_update_dir(tmp_path, monkeypatch):
    import update_manager
    archive = tmp_path / "pre_update_20260816_040000.tar.gz"
    # The validation layer is tested separately; this confirms the rollback
    # job can write a manifest without treating the backup archive as a release.
    monkeypatch.setattr(update_manager, "validate_preupdate_backup", lambda value: archive)
    monkeypatch.setattr(update_manager, "_preupdate_version", lambda value: "2.7.0")
    monkeypatch.setattr(update_manager, "update_job_busy", lambda: False)
    manifest_path = tmp_path / "manifest.json"
    monkeypatch.setattr(update_manager, "write_job_manifest", lambda job, actor, info: manifest_path)
    monkeypatch.setattr(update_manager, "APP_DIR", tmp_path)
    class FakeLauncher:
        pass
    # Avoid starting systemd in the test; only exercise the data passed into the manifest.
    import detached_jobs
    monkeypatch.setattr(detached_jobs, "launch_detached", lambda *args, **kwargs: "test")
    result = update_manager.start_rollback_job("tester", str(archive))
    assert result["state"] == "queued"
