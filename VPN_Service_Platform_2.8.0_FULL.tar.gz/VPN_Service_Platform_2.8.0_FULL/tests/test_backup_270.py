from __future__ import annotations

import importlib
import json
import sys
import tempfile
import time
from pathlib import Path
from types import ModuleType


def load_backup(tmp: Path):
    config = ModuleType("config")
    config.BACKUP_STATE_PATH = str(tmp / "state.json")
    config.BACKUP_DIR = str(tmp / "backups")
    config.BACKUP_INTERVAL_DAYS = 3
    config.BACKUP_RETRY_INTERVAL_SECONDS = 60
    config.BACKUP_PENDING_KEEP_DAYS = 30
    config.YANDEX_DISK_ENABLED = True
    config.BACKUP_TELEGRAM = False
    config.YANDEX_DISK_MODE = "oauth"
    config.YANDEX_DISK_TOKEN = "token"
    config.YANDEX_DISK_PATH = "VPN-Service-Backups"
    config.DB_PATH = str(tmp / "bot.db")
    config.XUI_DB_PATH = str(tmp / "xui.db")
    config.SERVICE_NAME = "test"
    config.BOT_TOKEN = ""
    config.ADMIN_IDS = []
    config.BACKUP_LOCK_PATH = str(tmp / "lock")
    config.BACKUP_INCLUDE_VENV = False
    config.BACKUP_TELEGRAM_PART_MB = 45
    config.RCLONE_REMOTE = ""
    config.RCLONE_PATH = "VPN-Service-Backups"
    sys.modules["config"] = config
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app"))
    sys.modules.pop("backup", None)
    return importlib.import_module("backup")


def test_failed_delivery_is_persisted_and_retried():
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        backup = load_backup(tmp)
        archive = tmp / "backup.tar.gz"
        archive.write_bytes(b"backup")
        state = {
            "pending_deliveries": [{
                "archive": str(archive),
                "created_ts": time.time(),
                "last_attempt_ts": 0,
                "remaining": ["yandex"],
                "attempts": 1,
            }]
        }
        Path(backup.STATE_PATH).write_text(json.dumps(state), encoding="utf-8")
        calls = []
        backup._deliver_archive = lambda p, names: calls.append((p, names)) or {"yandex": (True, "ok")}
        assert backup.retry_pending_deliveries() == 1
        assert calls == [(archive, {"yandex"})]
        saved = json.loads(Path(backup.STATE_PATH).read_text(encoding="utf-8"))
        assert saved["pending_deliveries"] == []


def test_failed_new_delivery_is_queued():
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        backup = load_backup(tmp)
        archive = tmp / "backup.tar.gz"
        archive.write_bytes(b"backup")
        backup._update_pending_after_delivery(
            archive,
            {
                "telegram": (True, "disabled"),
                "yandex": (False, "network error"),
            },
        )
        saved = json.loads(Path(backup.STATE_PATH).read_text(encoding="utf-8"))
        assert saved["pending_deliveries"][0]["remaining"] == ["yandex"]


