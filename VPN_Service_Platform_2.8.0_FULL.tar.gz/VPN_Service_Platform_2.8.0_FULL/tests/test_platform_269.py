from __future__ import annotations

import ast
import asyncio
import logging
import types
import unittest
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
MAIN = APP / "main.py"


class FakeMessage:
    def __init__(self, chat_id: int):
        self.chat = types.SimpleNamespace(id=chat_id)


class FakeReplyKeyboardRemove:
    def __init__(self, *, remove_keyboard: bool):
        self.remove_keyboard = remove_keyboard


class FakeBot:
    def __init__(self, *, fail_first: bool = False):
        self.fail_first = fail_first
        self.send_calls: list[dict[str, Any]] = []
        self.delete_calls: list[dict[str, Any]] = []

    async def send_message(self, **kwargs: Any):
        self.send_calls.append(dict(kwargs))
        if self.fail_first and len(self.send_calls) == 1:
            raise RuntimeError("temporary Telegram error")
        return types.SimpleNamespace(message_id=700 + len(self.send_calls))

    async def delete_message(self, **kwargs: Any):
        self.delete_calls.append(dict(kwargs))
        return True


def load_keyboard_helpers() -> dict[str, Any]:
    """Execute the exact cleaner functions from main.py with lightweight fakes."""
    tree = ast.parse(MAIN.read_text(encoding="utf-8"), filename=str(MAIN))
    wanted = {
        "_event_chat_id",
        "_delete_legacy_keyboard_notice_later",
        "ensure_legacy_reply_keyboard_removed",
    }
    functions = [
        node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in wanted
    ]
    if {node.name for node in functions} != wanted:
        raise AssertionError("Не найдены все функции очистки старой клавиатуры")

    namespace: dict[str, Any] = {
        "Any": Any,
        "asyncio": asyncio,
        "Bot": FakeBot,
        "Message": FakeMessage,
        "ReplyKeyboardRemove": FakeReplyKeyboardRemove,
        "logger": logging.getLogger("test-platform-269"),
        "_LEGACY_REPLY_KEYBOARD_CLEARED": set(),
        "_LEGACY_REPLY_KEYBOARD_IN_FLIGHT": set(),
        "_LEGACY_REPLY_KEYBOARD_DELETE_TASKS": set(),
    }
    module = ast.Module(body=functions, type_ignores=[])
    ast.fix_missing_locations(module)
    exec(compile(module, str(MAIN), "exec"), namespace)
    return namespace


class Platform269Tests(unittest.TestCase):
    def test_application_builds_only_inline_keyboards(self):
        source = MAIN.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(MAIN))
        referenced_names = {
            node.id for node in ast.walk(tree) if isinstance(node, ast.Name)
        }
        imported_names = {
            alias.name
            for node in ast.walk(tree)
            if isinstance(node, (ast.Import, ast.ImportFrom))
            for alias in node.names
        }
        self.assertIn("InlineKeyboardBuilder", referenced_names)
        self.assertIn("ReplyKeyboardRemove", referenced_names)
        self.assertIn("ReplyKeyboardMarkup", referenced_names | imported_names)
        self.assertIn("KeyboardButtonRequestUsers", referenced_names | imported_names)

    def test_incoming_messages_and_callbacks_trigger_legacy_cleanup(self):
        source = MAIN.read_text(encoding="utf-8")
        middleware_start = source.index("class EventJournalMiddleware")
        middleware_end = source.index("bot = JournalBot", middleware_start)
        middleware = source[middleware_start:middleware_end]
        self.assertIn("_event_chat_id(event)", middleware)
        self.assertIn("await ensure_legacy_reply_keyboard_removed", middleware)
        self.assertIn("dp.message.outer_middleware(EventJournalMiddleware())", source)
        self.assertIn("dp.callback_query.outer_middleware(EventJournalMiddleware())", source)

    def test_unsolicited_text_and_media_also_remove_old_keyboard(self):
        source = MAIN.read_text(encoding="utf-8")
        class_start = source.index("class JournalBot")
        class_end = source.index("def refresh_telegram_identity", class_start)
        journal_bot = source[class_start:class_end]
        for method in ("send_message", "send_photo", "send_document", "send_video"):
            method_start = journal_bot.index(f"async def {method}")
            next_method_candidates = [
                pos
                for name in ("send_message", "send_photo", "send_document", "send_video")
                if (pos := journal_bot.find(f"async def {name}", method_start + 1)) >= 0
            ]
            method_end = min(next_method_candidates) if next_method_candidates else len(journal_bot)
            block = journal_bot[method_start:method_end]
            self.assertIn("await ensure_legacy_reply_keyboard_removed", block, method)

    def test_cleaner_sends_reply_keyboard_remove_only_once(self):
        namespace = load_keyboard_helpers()
        cleaner = namespace["ensure_legacy_reply_keyboard_removed"]

        async def scenario():
            bot = FakeBot()
            deleted: list[tuple[int, int]] = []

            async def delete_immediately(_bot: FakeBot, chat_id: int, message_id: int):
                deleted.append((chat_id, message_id))

            namespace["_delete_legacy_keyboard_notice_later"] = delete_immediately
            first = await cleaner(bot, 123456)
            await asyncio.sleep(0)
            second = await cleaner(bot, 123456)
            return bot, deleted, first, second

        bot, deleted, first, second = asyncio.run(scenario())
        self.assertTrue(first)
        self.assertFalse(second)
        self.assertEqual(len(bot.send_calls), 1)
        call = bot.send_calls[0]
        self.assertEqual(call["chat_id"], 123456)
        self.assertTrue(call["disable_notification"])
        self.assertIsInstance(call["reply_markup"], FakeReplyKeyboardRemove)
        self.assertTrue(call["reply_markup"].remove_keyboard)
        self.assertEqual(deleted, [(123456, 701)])

    def test_cleaner_retries_after_temporary_telegram_error(self):
        namespace = load_keyboard_helpers()
        cleaner = namespace["ensure_legacy_reply_keyboard_removed"]

        async def scenario():
            bot = FakeBot(fail_first=True)

            async def delete_immediately(_bot: FakeBot, chat_id: int, message_id: int):
                return None

            namespace["_delete_legacy_keyboard_notice_later"] = delete_immediately
            first = await cleaner(bot, 999)
            second = await cleaner(bot, 999)
            await asyncio.sleep(0)
            return bot, first, second

        bot, first, second = asyncio.run(scenario())
        self.assertFalse(first)
        self.assertTrue(second)
        self.assertEqual(len(bot.send_calls), 2)

    def test_chat_id_is_taken_from_message_or_callback_message(self):
        namespace = load_keyboard_helpers()
        resolver = namespace["_event_chat_id"]
        self.assertEqual(resolver(FakeMessage(321)), 321)
        callback = types.SimpleNamespace(
            message=types.SimpleNamespace(chat=types.SimpleNamespace(id=654)),
            from_user=types.SimpleNamespace(id=999),
        )
        self.assertEqual(resolver(callback), 654)
        callback_without_message = types.SimpleNamespace(
            message=None,
            from_user=types.SimpleNamespace(id=777),
        )
        self.assertEqual(resolver(callback_without_message), 777)

    def test_release_version_is_269(self):
        self.assertEqual((APP / "VERSION").read_text(encoding="utf-8").strip(), "2.8.0")
        self.assertIn("2.8.0", (ROOT / "BUILD_PROFILE.txt").read_text(encoding="utf-8"))
        self.assertIn('echo 2.8.0', (ROOT / "install.sh").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
