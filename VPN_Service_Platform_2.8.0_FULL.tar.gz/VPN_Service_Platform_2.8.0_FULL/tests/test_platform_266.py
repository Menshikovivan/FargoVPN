from __future__ import annotations

import hashlib
import json
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from fastapi.testclient import TestClient

from test_core import fake_config, reload_module


def _set_test_password(config) -> None:
    salt = b"0123456789abcdef"
    digest = hashlib.pbkdf2_hmac("sha256", b"test", salt, 1000).hex()
    config.WEB_PASSWORD_HASH = f"pbkdf2_sha256$1000${salt.hex()}${digest}"


def _reload_webapp(config):
    for name in (
        "webapp",
        "auth_security",
        "broadcast_manager",
        "diagnostics",
        "identity_migration",
        "panel_notifications",
        "service_audit",
        "update_manager",
        "user_events",
        "backup",
        "init_db",
        "services.media",
        "services.telegram_events",
        "services.subscriptions",
        "services.xui_api",
    ):
        sys.modules.pop(name, None)
    return reload_module("webapp", config)


class _EnumLikePhoto:
    value = "photo"

    def __str__(self) -> str:
        return "ContentType.PHOTO"


class Platform266MediaChatTests(unittest.TestCase):
    @staticmethod
    def _message_with_photo(*, caption: str = ""):
        photo = SimpleNamespace(
            file_id="secret-photo-file-id",
            file_unique_id="unique-photo-id",
            file_size=12345,
            width=1280,
            height=720,
        )
        return SimpleNamespace(
            message_id=77,
            text=None,
            caption=caption,
            content_type=_EnumLikePhoto(),
            photo=[photo],
            video=None,
            animation=None,
            video_note=None,
            document=None,
            sticker=None,
            voice=None,
            audio=None,
        )

    @staticmethod
    def _database_with_user(config, tg_id: int = 101, username: str = "alice") -> None:
        init_db = reload_module("init_db", config)
        init_db.migrate()
        with sqlite3.connect(config.DB_PATH) as connection:
            connection.execute(
                "INSERT INTO users(tg_id,username,email) VALUES(?,?,?)",
                (tg_id, username, f"{username}@example"),
            )
            connection.commit()

    def test_content_type_enum_is_normalized_and_photo_metadata_is_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            events_helper = reload_module("services.telegram_events", config)
            event_type, text, metadata = events_helper.incoming_message_event_payload(
                self._message_with_photo()
            )
            self.assertEqual(event_type, "telegram_photo")
            self.assertEqual(text, "[Фото]")
            self.assertNotIn("ContentType.PHOTO", text)
            self.assertEqual(metadata["telegram_message_id"], 77)
            self.assertEqual(metadata["media"]["kind"], "photo")
            self.assertEqual(metadata["media"]["file_id"], "secret-photo-file-id")
            self.assertEqual(metadata["media"]["mime_type"], "image/jpeg")
            self.assertEqual(metadata["media"]["file_name"], "photo.jpg")

    def test_photo_event_updates_unread_state_and_keeps_caption(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            self._database_with_user(config)
            helper = reload_module("services.telegram_events", config)
            journal = reload_module("user_events", config)
            event_type, text, metadata = helper.incoming_message_event_payload(
                self._message_with_photo(caption="Подпись к фотографии")
            )
            event_id = journal.record_event(
                101,
                username="alice",
                direction="in",
                event_type=event_type,
                text=text,
                actor="telegram:101",
                metadata=metadata,
                db_path=config.DB_PATH,
            )
            self.assertGreater(event_id, 0)
            summary = journal.unread_messages_summary(db_path=config.DB_PATH)
            self.assertEqual(summary["total"], 1)
            self.assertEqual(summary["items"][0]["preview"], "Подпись к фотографии")
            stored = journal.get_event(101, event_id, db_path=config.DB_PATH)
            self.assertEqual(stored["metadata"]["media"]["file_id"], "secret-photo-file-id")

    def test_media_signature_detection_accepts_photo_video_and_rejects_active_text(self):
        with tempfile.TemporaryDirectory() as directory:
            media = reload_module("services.media", fake_config(Path(directory)))
            self.assertEqual(media.detect_media_type(b"\xff\xd8\xff\xe0", "x.bin", ""), "image/jpeg")
            self.assertEqual(
                media.detect_media_type(
                    b"\x00\x00\x00\x18ftypisom",
                    "x.bin",
                    "application/octet-stream",
                ),
                "video/mp4",
            )
            self.assertEqual(media.detect_media_type(b"RIFFxxxxWEBP", "x.bin", ""), "image/webp")
            self.assertIsNone(
                media.detect_media_type(
                    b"<svg xmlns='http://www.w3.org/2000/svg'><script/></svg>",
                    "renamed.jpg",
                    "image/jpeg",
                )
            )
            self.assertIsNone(
                media.detect_media_type(
                    b"<html><script>alert(1)</script></html>",
                    "renamed.png",
                    "image/png",
                )
            )

    def test_web_chat_renders_photo_and_serves_it_through_authenticated_route(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.CHAT_MEDIA_CACHE_DIR = str(temp / "chat-media")
            _set_test_password(config)
            self._database_with_user(config)
            journal = reload_module("user_events", config)
            event_id = journal.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_photo",
                text="[Фото]",
                actor="telegram:101",
                metadata={
                    "telegram_message_id": 77,
                    "media": {
                        "kind": "photo",
                        "file_id": "secret-photo-file-id",
                        "file_unique_id": "unique-photo-id",
                        "mime_type": "image/jpeg",
                        "file_name": "photo.jpg",
                        "file_size": 12,
                    },
                },
                db_path=config.DB_PATH,
            )
            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            image_bytes = b"\xff\xd8\xff\xe0test-photo"

            def fake_download(_token, file_id, destination, **_kwargs):
                self.assertEqual(file_id, "secret-photo-file-id")
                path = Path(destination)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(image_bytes)
                return path, "image/jpeg", "photo.jpg"

            with TestClient(webapp.app) as client:
                unauthenticated = client.get(
                    f"/api/users/101/events/{event_id}/media",
                    follow_redirects=False,
                )
                self.assertNotEqual(unauthenticated.status_code, 200)
                login = client.post(
                    "/login",
                    data={"username": "admin", "password": "test"},
                    follow_redirects=False,
                )
                self.assertEqual(login.status_code, 303)
                detail = client.get("/users/id/101")
                self.assertEqual(detail.status_code, 200)
                self.assertIn('class="chat-media-image"', detail.text)
                self.assertIn(f"/api/users/101/events/{event_id}/media", detail.text)
                self.assertNotIn("secret-photo-file-id", detail.text)
                api_event = client.get("/api/users/101/events").json()["events"][0]
                self.assertEqual(api_event["metadata"]["media"]["kind"], "photo")
                self.assertNotIn(
                    "secret-photo-file-id",
                    json.dumps(api_event, ensure_ascii=False),
                )
                with patch.object(
                    webapp,
                    "download_telegram_media_to_path",
                    side_effect=fake_download,
                ):
                    media = client.get(f"/api/users/101/events/{event_id}/media")
                self.assertEqual(media.status_code, 200)
                self.assertEqual(media.content, image_bytes)
                self.assertTrue(media.headers["content-type"].startswith("image/jpeg"))
                self.assertIn("inline", media.headers.get("content-disposition", "").lower())
                self.assertIn("private", media.headers.get("cache-control", "").lower())

    def test_video_markup_and_legacy_content_type_explanation(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            _set_test_password(config)
            self._database_with_user(config)
            journal = reload_module("user_events", config)
            video_id = journal.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_video",
                text="Видео с подписью",
                actor="telegram:101",
                metadata={
                    "media": {
                        "kind": "video",
                        "file_id": "secret-video-id",
                        "mime_type": "video/mp4",
                        "file_name": "clip.mp4",
                    }
                },
                db_path=config.DB_PATH,
            )
            journal.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_message",
                text="Отправлено: ContentType.PHOTO",
                actor="telegram:101",
                db_path=config.DB_PATH,
            )
            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            with TestClient(webapp.app) as client:
                login = client.post(
                    "/login",
                    data={"username": "admin", "password": "test"},
                    follow_redirects=False,
                )
                self.assertEqual(login.status_code, 303)
                detail = client.get("/users/id/101")
                self.assertIn('class="chat-media-video"', detail.text)
                self.assertIn(f"/api/users/101/events/{video_id}/media", detail.text)
                self.assertNotIn("Отправлено: ContentType.PHOTO", detail.text)
                self.assertIn("Файл был получен старой версией", detail.text)

    def test_media_cache_limits_are_exposed_in_settings(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            _set_test_password(config)
            self._database_with_user(config)
            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            with TestClient(webapp.app) as client:
                client.post(
                    "/login",
                    data={"username": "admin", "password": "test"},
                    follow_redirects=False,
                )
                page = client.get("/settings")
                self.assertEqual(page.status_code, 200)
                self.assertIn('name="chat_media_max_mb"', page.text)
                self.assertIn('name="chat_media_cache_days"', page.text)
                self.assertIn('name="chat_media_cache_max_mb"', page.text)


if __name__ == "__main__":
    unittest.main()
