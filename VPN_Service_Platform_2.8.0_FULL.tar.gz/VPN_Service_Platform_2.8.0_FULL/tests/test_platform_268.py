from __future__ import annotations

import hashlib
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx
from fastapi.testclient import TestClient

from test_core import fake_config, reload_module

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"


def _set_test_password(config) -> None:
    salt = b"0123456789abcdef"
    digest = hashlib.pbkdf2_hmac("sha256", b"test", salt, 1000).hex()
    config.WEB_PASSWORD_HASH = f"pbkdf2_sha256$1000${salt.hex()}${digest}"


def _reload_webapp(config):
    import sys

    for name in (
        "webapp",
        "auth_security",
        "broadcast_manager",
        "diagnostics",
        "identity_migration",
        "panel_notifications",
        "service_audit",
        "update_manager",
        "user_events",
        "backup",
        "init_db",
        "services.media",
        "services.telegram_events",
        "services.subscriptions",
        "services.xui_api",
    ):
        sys.modules.pop(name, None)
    return reload_module("webapp", config)


def _login(client: TestClient, username: str = "admin") -> None:
    response = client.post(
        "/login",
        data={"username": username, "password": "test"},
        follow_redirects=False,
    )
    assert response.status_code == 303, response.text


class FakeResponse:
    def __init__(self, status_code: int = 200, content: bytes = b"", headers=None):
        self.status_code = status_code
        self.content = content
        self.headers = headers or {}

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


def collection_xml() -> bytes:
    return (
        b'<?xml version="1.0"?><d:multistatus xmlns:d="DAV:">'
        b"<d:response><d:propstat><d:prop><d:resourcetype>"
        b"<d:collection/></d:resourcetype></d:prop></d:propstat>"
        b"</d:response></d:multistatus>"
    )


def file_xml(size: int) -> bytes:
    return (
        b'<?xml version="1.0"?><d:multistatus xmlns:d="DAV:">'
        b"<d:response><d:propstat><d:prop><d:getcontentlength>"
        + str(size).encode()
        + b"</d:getcontentlength></d:prop></d:propstat></d:response>"
        b"</d:multistatus>"
    )


class Platform268Tests(unittest.TestCase):
    @staticmethod
    def _database_with_user(config, tg_id: int = 101, username: str = "alice") -> None:
        init_db = reload_module("init_db", config)
        init_db.migrate()
        with sqlite3.connect(config.DB_PATH) as connection:
            connection.execute(
                "INSERT INTO users(tg_id,username,email) VALUES(?,?,?)",
                (tg_id, username, f"{username}@example"),
            )
            connection.commit()

    def test_incoming_message_reaches_live_api_clears_on_open_and_reappears(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            _set_test_password(config)
            self._database_with_user(config)
            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""

            with TestClient(webapp.app) as client:
                _login(client)
                self.assertEqual(client.get("/api/panel/notifications").json()["messages"]["total"], 0)

                first_id = webapp.user_events.record_event(
                    101,
                    username="alice",
                    direction="in",
                    event_type="telegram_message",
                    text="Первое новое сообщение",
                    db_path=config.DB_PATH,
                )
                payload = client.get("/api/panel/notifications").json()
                self.assertEqual(payload["messages"]["total"], 1)
                self.assertEqual(payload["messages"]["last_event_id"], first_id)
                self.assertEqual(payload["messages"]["items"][0]["username"], "alice")

                detail = client.get("/users/id/101")
                self.assertEqual(detail.status_code, 200)
                self.assertIn("Первое новое сообщение", detail.text)
                self.assertEqual(client.get("/api/panel/notifications").json()["messages"]["total"], 0)

                second_id = webapp.user_events.record_event(
                    101,
                    username="alice",
                    direction="in",
                    event_type="telegram_photo",
                    text="[Фото]",
                    db_path=config.DB_PATH,
                )
                after = client.get("/api/panel/notifications").json()["messages"]
                self.assertEqual(after["total"], 1)
                self.assertEqual(after["last_event_id"], second_id)

    def test_database_trigger_and_python_fallback_keep_badge_atomic(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            self._database_with_user(config)
            events = reload_module("user_events", config)
            events.ensure_schema(config.DB_PATH)

            with sqlite3.connect(config.DB_PATH) as connection:
                cursor = connection.execute(
                    """
                    INSERT INTO user_events(tg_id,username,direction,event_type,text)
                    VALUES(?,?,?,?,?)
                    """,
                    (101, "alice", "in", "telegram_message", "Прямой INSERT"),
                )
                direct_id = int(cursor.lastrowid)
                connection.commit()
                state = connection.execute(
                    "SELECT last_incoming_event_id,unread_count FROM user_message_state WHERE tg_id=101"
                ).fetchone()
            self.assertEqual(state, (direct_id, 1))

            # Simulate an external restore which removed the trigger while the
            # long-running Python module still considers its schema initialized.
            with sqlite3.connect(config.DB_PATH) as connection:
                connection.execute("DROP TRIGGER IF EXISTS trg_user_events_unread_insert_v268")
                connection.commit()
            second_id = events.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_message",
                text="Fallback",
                db_path=config.DB_PATH,
            )
            with sqlite3.connect(config.DB_PATH) as connection:
                state = connection.execute(
                    "SELECT last_incoming_event_id,unread_count FROM user_message_state WHERE tg_id=101"
                ).fetchone()
            self.assertEqual(state, (second_id, 2))

    def test_admin_messages_notify_by_default_and_can_be_disabled(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            config.ADMIN_IDS = [101]
            config.PANEL_NOTIFY_ADMIN_MESSAGES = True
            events = reload_module("user_events", config)
            events.record_event(
                101,
                direction="in",
                event_type="telegram_message",
                text="Сообщение администратора",
                db_path=config.DB_PATH,
            )
            self.assertEqual(events.unread_messages_summary(db_path=config.DB_PATH)["total"], 1)

            # The Python repair path must follow the same admin-notification
            # setting when an external restore removes the SQLite trigger.
            with sqlite3.connect(config.DB_PATH) as connection:
                connection.execute("DROP TRIGGER IF EXISTS trg_user_events_unread_insert_v268")
                connection.commit()
            events.record_event(
                101,
                direction="in",
                event_type="telegram_message",
                text="Сообщение администратора без триггера",
                db_path=config.DB_PATH,
            )
            self.assertEqual(events.unread_messages_summary(db_path=config.DB_PATH)["total"], 2)

        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            config.ADMIN_IDS = [101]
            config.PANEL_NOTIFY_ADMIN_MESSAGES = False
            events = reload_module("user_events", config)
            events.record_event(
                101,
                direction="in",
                event_type="telegram_message",
                text="Скрытое сообщение администратора",
                db_path=config.DB_PATH,
            )
            self.assertEqual(events.unread_messages_summary(db_path=config.DB_PATH)["total"], 0)

    def test_notification_channels_fail_independently(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            _set_test_password(config)
            self._database_with_user(config)
            webapp = _reload_webapp(config)
            webapp.update_banner = lambda: ""
            webapp.user_events.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_message",
                text="Сообщение при ошибке оплат",
                db_path=config.DB_PATH,
            )
            with TestClient(webapp.app) as client:
                _login(client)
                with patch.object(
                    webapp.panel_notifications,
                    "payment_notifications_summary",
                    side_effect=RuntimeError("legacy payments schema"),
                ):
                    response = client.get("/api/panel/notifications")
                self.assertEqual(response.status_code, 200)
                payload = response.json()
                self.assertEqual(payload["messages"]["total"], 1)
                self.assertEqual(payload["payments"]["total"], 0)
                self.assertIn("payments", payload["errors"])

    def test_frontend_polls_early_often_and_has_optional_audio(self):
        javascript = (APP / "static" / "panel.js").read_text(encoding="utf-8")
        css = (APP / "static" / "panel.css").read_text(encoding="utf-8")
        self.assertIn("document.readyState === 'loading'", javascript)
        self.assertIn("setTimeout(pollPanelNotifications, 250)", javascript)
        self.assertIn("setInterval(pollPanelNotifications, 3000)", javascript)
        self.assertIn("credentials: 'same-origin'", javascript)
        self.assertIn("window.AudioContext || window.webkitAudioContext", javascript)
        self.assertIn("notification-sound-toggle", javascript)
        self.assertIn("message-live-alert", javascript)
        self.assertIn("payment-live-alert", javascript)
        self.assertIn(".panel-live-alerts", css)
        self.assertIn(".notification-sound-toggle", css)

    def test_diagnostics_reports_notification_trigger_and_tracking_health(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            self._database_with_user(config)
            events = reload_module("user_events", config)
            events.record_event(
                101,
                username="alice",
                direction="in",
                event_type="telegram_message",
                text="Диагностируемое сообщение",
                db_path=config.DB_PATH,
            )
            diagnostics = reload_module("diagnostics", config)
            report = diagnostics.database_report(config.DB_PATH)
            self.assertTrue(report["unread_trigger"])
            self.assertEqual(report["untracked_incoming_messages"], 0)
            self.assertEqual(report["unread_messages"], 1)
            self.assertTrue(report["healthy"])

    def test_webdav_existing_directory_uses_propfind_without_noisy_mkcol(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            backup = reload_module("backup", config)
            calls: list[str] = []

            class Client:
                def request(self, method, url, **kwargs):
                    calls.append(method)
                    if method == "PROPFIND":
                        return FakeResponse(207, collection_xml())
                    raise AssertionError((method, url))

            backup.ensure_yandex_webdav_directory(
                Client(), "https://webdav.yandex.ru", "VPN-Service-Backups"
            )
            self.assertEqual(calls, ["PROPFIND"])

    def test_webdav_405_is_only_accepted_after_collection_verification(self):
        with tempfile.TemporaryDirectory() as directory:
            config = fake_config(Path(directory))
            backup = reload_module("backup", config)
            responses = [FakeResponse(404), FakeResponse(405), FakeResponse(207, collection_xml())]
            calls: list[str] = []

            class Client:
                def request(self, method, url, **kwargs):
                    calls.append(method)
                    return responses.pop(0)

            backup.ensure_yandex_webdav_directory(
                Client(), "https://webdav.yandex.ru", "VPN-Service-Backups"
            )
            self.assertEqual(calls, ["PROPFIND", "MKCOL", "PROPFIND"])

    def test_webdav_disconnect_after_put_is_remote_verified_as_success(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.YANDEX_DISK_ENABLED = True
            config.YANDEX_DISK_MODE = "local"
            config.YANDEX_UPLOAD_RETRIES = 1
            config.YANDEX_UPLOAD_VERIFY_ATTEMPTS = 1
            config.YANDEX_UPLOAD_VERIFY_DELAY = 0
            local_root = Path(config.YANDEX_LOCAL_PATH)
            local_root.mkdir(parents=True)
            Path(config.YANDEX_DAVFS_SECRETS_PATH).write_text(
                f"{local_root} test-login test-app-password\n",
                encoding="utf-8",
            )
            source = temp / "backup.tar.gz"
            payload = b"backup-confirmed-after-disconnect"
            source.write_bytes(payload)
            backup = reload_module("backup", config)
            put_calls = 0

            class Client:
                def __enter__(self):
                    return self

                def __exit__(self, exc_type, exc, tb):
                    return False

                def request(self, method, url, **kwargs):
                    if method != "PROPFIND":
                        raise AssertionError((method, url))
                    if str(url).rstrip("/").endswith("VPN-Service-Backups"):
                        return FakeResponse(207, collection_xml())
                    return FakeResponse(207, file_xml(len(payload)))

                def put(self, url, **kwargs):
                    nonlocal put_calls
                    put_calls += 1
                    # Reproduce the production log: the server can accept the
                    # body and close before httpx receives a response.
                    raise httpx.RemoteProtocolError(
                        "Server disconnected without sending a response"
                    )

                def head(self, url, **kwargs):
                    return FakeResponse(200, headers={"Content-Length": str(len(payload))})

                def delete(self, url, **kwargs):
                    return FakeResponse(204)

            backup._webdav_client = lambda *args, **kwargs: Client()
            ok, detail = backup.upload_to_yandex(source)
            self.assertTrue(ok, detail)
            self.assertEqual(put_calls, 1)
            self.assertIn("ответ PUT был потерян", detail)
            self.assertIn("проверено", detail)
            self.assertFalse((local_root / config.YANDEX_DISK_PATH / source.name).exists())

    def test_local_mode_falls_back_to_mount_then_requires_remote_confirmation(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            config = fake_config(temp)
            config.YANDEX_DISK_ENABLED = True
            config.YANDEX_DISK_MODE = "local"
            local_root = Path(config.YANDEX_LOCAL_PATH)
            local_root.mkdir(parents=True)
            source = temp / "backup.tar.gz"
            source.write_bytes(b"payload")
            backup = reload_module("backup", config)

            with patch.object(backup, "_upload_to_yandex_webdav", return_value=(False, "disconnect")), patch.object(
                backup, "_test_yandex_local_path", return_value=(True, "mounted")
            ), patch.object(
                backup, "_copy_to_yandex_mount", return_value=(True, "written")
            ), patch.object(
                backup, "_davfs_credentials", return_value=("login", "password")
            ), patch.object(
                backup,
                "_verify_yandex_webdav_upload",
                return_value=(True, "7 байт, проверено"),
            ):
                ok, detail = backup.upload_to_yandex(source)
            self.assertTrue(ok, detail)
            self.assertIn("удалённо подтверждено", detail)

    def test_release_defaults_are_269(self):
        self.assertEqual((APP / "VERSION").read_text(encoding="utf-8").strip(), "2.8.0")
        self.assertIn("2.8.0", (ROOT / "BUILD_PROFILE.txt").read_text(encoding="utf-8"))
        config_example = (APP / "config.example.py").read_text(encoding="utf-8")
        installer = (ROOT / "install.sh").read_text(encoding="utf-8")
        self.assertIn("PANEL_NOTIFY_ADMIN_MESSAGES = True", config_example)
        self.assertIn("YANDEX_UPLOAD_RETRIES = 5", config_example)
        self.assertIn('ensure("YANDEX_UPLOAD_VERIFY_ATTEMPTS", 8)', installer)


if __name__ == "__main__":
    unittest.main()
