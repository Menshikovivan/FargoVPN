from pathlib import Path
import json
import time
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"app"))

def test_backup_interval_uses_live_config(tmp_path, monkeypatch):
    import backup
    state=tmp_path/"state.json"; state.write_text(json.dumps({"last_backup_ts":time.time()-1.5*86400}))
    monkeypatch.setattr(backup,"STATE_PATH",state)
    monkeypatch.setattr(backup,"reload_runtime_config",lambda:None)
    monkeypatch.setattr(backup.config,"BACKUP_INTERVAL_DAYS",2,raising=False)
    assert backup.scheduled_backup_due() is False
    monkeypatch.setattr(backup.config,"BACKUP_INTERVAL_DAYS",1,raising=False)
    assert backup.scheduled_backup_due() is True

def test_google_upload_removed():
    import backup
    assert not hasattr(backup,"upload_to_google")
    assert not hasattr(backup,"google_access_token")
