# VPN Service Platform 2.8.0 — быстрый старт

## Новая установка

Распакуйте архив и запустите полный установщик:

```bash
cd /root
rm -rf /root/VPN_Service_Platform_2.8.0_FULL
tar -xzf VPN_Service_Platform_2.8.0_FULL.tar.gz
cd /root/VPN_Service_Platform_2.8.0_FULL
sudo bash install_with_web.sh
```

Установщик запросит необходимые параметры (бот, панель и настройки сервиса), создаст `/root/vpn_bot`, виртуальное окружение и systemd-сервисы.

## Обновление существующей установки

```bash
cd /root
rm -rf /root/VPN_Service_Platform_2.8.0_FULL
tar -xzf VPN_Service_Platform_2.8.0_FULL.tar.gz
cd /root/VPN_Service_Platform_2.8.0_FULL
sudo bash install_with_web.sh --update-existing /root/vpn_bot
```

Не удаляйте `/root/vpn_bot`: установщик сохраняет `config.py`, SQLite-базу, пользователей, платежи, настройки обновлений и существующее виртуальное окружение.

## Проверка после установки

```bash
curl -fsS http://127.0.0.1:8088/health
sudo systemctl status vpn-service-bot vpn-service-web --no-pager
sudo journalctl -u vpn-service-web -n 100 --no-pager
sudo journalctl -u vpn-service-bot -n 100 --no-pager
```

Ожидаемая версия `/health`: `2.8.0`.

## Первый вход в веб-панель

Используйте логин и пароль, указанные при настройке. Логин и пароль могут содержать кириллицу и другие Unicode-символы.

После входа проверьте, что открывается главная страница панели и что раздел диагностики доступен без ошибок 500.

## Дополнительная диагностика

```bash
sudo /root/vpn_bot/.venv/bin/python /root/vpn_bot/diagnostics.py --live --json
sudo /root/vpn_bot/.venv/bin/python /root/vpn_bot/backup.py --test-yandex
```
