(function () {
  'use strict';
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  async function pollPlatformUpdate() {
    const slot = document.getElementById('global-update-slot');
    if (!slot || document.getElementById('global-update-banner')) return;
    try {
      const response = await fetch('/api/panel/update-status', {cache: 'no-store'});
      if (!response.ok) return;
      const data = await response.json();
      if (!data.available) return;
      const box = document.createElement('div');
      box.className = 'update-banner';
      box.id = 'global-update-banner';
      const strong = document.createElement('strong');
      strong.textContent = 'Доступно обновление ' + (data.version || '');
      const span = document.createElement('span');
      span.textContent = 'Новая версия готова к установке.';
      const link = document.createElement('a');
      link.className = 'button small';
      link.href = '/updates';
      link.textContent = 'Обновить';
      box.append(strong, span, link);
      slot.replaceWith(box);
    } catch (_) {}
  }

  function initTabs() {
    document.querySelectorAll('[data-tabs]').forEach((root) => {
      const buttons = root.querySelectorAll('[data-tab]');
      const sections = document.querySelectorAll('[data-tab-section]');
      const activate = (name) => {
        buttons.forEach((button) => button.classList.toggle('active', button.dataset.tab === name));
        sections.forEach((section) => section.classList.toggle('active', section.dataset.tabSection === name));
        if (history.replaceState) history.replaceState(null, '', '#' + name);
      };
      buttons.forEach((button) => button.addEventListener('click', (event) => {
        event.preventDefault();
        activate(button.dataset.tab);
      }));
      const requested = location.hash.slice(1);
      const initial = Array.from(buttons).some((button) => button.dataset.tab === requested)
        ? requested : (buttons[0] && buttons[0].dataset.tab);
      if (initial) activate(initial);
    });
  }

  function initConfirmations() {
    document.querySelectorAll('[data-confirm]').forEach((element) => {
      element.addEventListener('click', (event) => {
        if (!window.confirm(element.dataset.confirm || 'Продолжить?')) event.preventDefault();
      });
    });
  }

  const originalTitle = document.title;
  let messageNotificationTotal = 0;
  let paymentNotificationTotal = 0;
  let notificationLoopStarted = false;
  let audioContext = null;
  const SOUND_KEY = 'vpn-panel-notification-sound';
  const MESSAGE_SEEN_KEY = 'vpn-panel-last-message-event';
  const PAYMENT_SEEN_KEY = 'vpn-panel-last-payment-event';

  function storageGet(key) {
    try { return window.localStorage.getItem(key); } catch (_) { return null; }
  }

  function storageSet(key, value) {
    try { window.localStorage.setItem(key, String(value)); } catch (_) {}
  }

  function soundEnabled() {
    return storageGet(SOUND_KEY) !== '0';
  }

  function compactCount(value) {
    const count = Math.max(0, Number(value || 0));
    return count > 99 ? '99+' : String(count);
  }

  function refreshDocumentTitle() {
    const combined = messageNotificationTotal + paymentNotificationTotal;
    document.title = combined > 0 ? '(' + compactCount(combined) + ') ' + originalTitle : originalTitle;
  }

  function updateSoundButton() {
    const button = document.getElementById('notification-sound-toggle');
    if (!button) return;
    const enabled = soundEnabled();
    button.classList.toggle('enabled', enabled);
    button.setAttribute('aria-pressed', enabled ? 'true' : 'false');
    button.title = enabled
      ? 'Звук уведомлений включён. Браузеру нужен хотя бы один клик по странице.'
      : 'Звук уведомлений выключен';
    button.innerHTML = enabled ? '<span>🔔</span><b>Звук включён</b>' : '<span>🔕</span><b>Звук выключен</b>';
  }

  async function unlockAudio() {
    if (!soundEnabled()) return false;
    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return false;
      if (!audioContext) audioContext = new AudioContextClass();
      if (audioContext.state === 'suspended') await audioContext.resume();
      return audioContext.state === 'running';
    } catch (_) {
      return false;
    }
  }

  async function playNotificationSound(kind) {
    if (!soundEnabled() || !(await unlockAudio())) return;
    try {
      const now = audioContext.currentTime;
      const gain = audioContext.createGain();
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.16, now + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.55);
      gain.connect(audioContext.destination);
      const frequencies = kind === 'payment' ? [740, 988] : [523, 659];
      frequencies.forEach((frequency, index) => {
        const oscillator = audioContext.createOscillator();
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(frequency, now + index * 0.16);
        oscillator.connect(gain);
        oscillator.start(now + index * 0.16);
        oscillator.stop(now + index * 0.16 + 0.28);
      });
    } catch (_) {}
  }

  function ensureSoundToggle() {
    if (!document.getElementById('unread-nav-badge') && !document.getElementById('payments-nav-badge')) return;
    if (document.getElementById('notification-sound-toggle')) return;
    const button = document.createElement('button');
    button.type = 'button';
    button.id = 'notification-sound-toggle';
    button.className = 'notification-sound-toggle';
    button.addEventListener('click', async (event) => {
      event.preventDefault();
      event.stopPropagation();
      const enable = !soundEnabled();
      storageSet(SOUND_KEY, enable ? '1' : '0');
      updateSoundButton();
      if (enable) {
        await unlockAudio();
        await playNotificationSound('message');
      }
    });
    document.body.append(button);
    updateSoundButton();
    const unlock = () => { unlockAudio(); };
    document.addEventListener('pointerdown', unlock, {once: true, passive: true});
    document.addEventListener('keydown', unlock, {once: true});
  }

  function liveAlertHost() {
    let host = document.getElementById('panel-live-alerts');
    if (!host) {
      host = document.createElement('div');
      host.id = 'panel-live-alerts';
      host.className = 'panel-live-alerts';
      document.body.append(host);
    }
    return host;
  }

  function messageAlertText(data) {
    const total = Math.max(0, Number(data && data.total || 0));
    const items = Array.isArray(data && data.items) ? data.items : [];
    const latest = items[0] || null;
    if (!latest) return total === 1 ? 'Получено новое сообщение' : 'Новых сообщений: ' + total;
    const username = String(latest.username || '').trim();
    const who = username ? '@' + username : 'Telegram ID ' + String(latest.tg_id || '—');
    const preview = String(latest.preview || '').replace(/\s+/g, ' ').trim();
    const prefix = total > 1 ? 'Новых сообщений: ' + total + '. Последнее от ' : 'Новое сообщение от ';
    return prefix + who + (preview ? ': ' + preview.slice(0, 140) : '');
  }

  function applyUnreadMessages(data) {
    const total = Math.max(0, Number(data && data.total || 0));
    const userCount = Math.max(0, Number(data && data.users || 0));
    const items = Array.isArray(data && data.items) ? data.items : [];
    const byUser = new Map(items.map((item) => [String(item.tg_id), item]));
    messageNotificationTotal = total;
    const navBadge = document.getElementById('unread-nav-badge');
    if (navBadge) {
      navBadge.textContent = compactCount(total);
      navBadge.hidden = total <= 0;
      navBadge.setAttribute('aria-label', 'Непрочитанных сообщений: ' + total);
    }

    document.querySelectorAll('[data-user-tg-id]').forEach((card) => {
      const item = byUser.get(String(card.dataset.userTgId));
      const count = Math.max(0, Number(item && item.count || 0));
      const indicator = card.querySelector('[data-unread-indicator]');
      const preview = card.querySelector('[data-unread-preview]');
      const chatButton = card.querySelector('[data-chat-button]');
      card.classList.toggle('has-unread', count > 0);
      if (indicator) {
        indicator.textContent = compactCount(count);
        indicator.hidden = count <= 0;
        const title = 'Непрочитанных сообщений: ' + count;
        indicator.title = title;
        indicator.setAttribute('aria-label', title);
      }
      if (preview) {
        const message = String(item && item.preview || '').replace(/\s+/g, ' ').trim();
        const textSlot = preview.querySelector('span');
        if (textSlot) textSlot.textContent = message || 'Получено новое сообщение';
        preview.hidden = count <= 0;
      }
      if (chatButton) {
        const base = chatButton.dataset.baseLabel || 'Открыть чат';
        chatButton.textContent = count > 0 ? base + ' · ' + compactCount(count) : base;
      }
    });

    const summary = document.getElementById('users-unread-summary');
    if (summary) {
      summary.textContent = total > 0
        ? 'Непрочитано сообщений: ' + total + ' от ' + userCount + ' пользователей'
        : 'Новых сообщений нет';
      summary.classList.toggle('active', total > 0);
    }

    let alertBox = document.getElementById('message-live-alert');
    if (total <= 0) {
      if (alertBox) alertBox.remove();
      refreshDocumentTitle();
      return;
    }
    const latest = items[0] || {};
    if (!alertBox) {
      alertBox = document.createElement('div');
      alertBox.id = 'message-live-alert';
      alertBox.className = 'panel-live-alert message-live-alert';
      alertBox.setAttribute('role', 'status');
      alertBox.setAttribute('aria-live', 'polite');
      const dot = document.createElement('span');
      dot.className = 'panel-live-dot message-live-dot';
      const textSlot = document.createElement('strong');
      textSlot.dataset.messageAlertText = '1';
      const link = document.createElement('a');
      link.className = 'button small';
      link.dataset.messageAlertLink = '1';
      link.textContent = 'Открыть переписку';
      alertBox.append(dot, textSlot, link);
      liveAlertHost().append(alertBox);
    }
    const textSlot = alertBox.querySelector('[data-message-alert-text]');
    if (textSlot) textSlot.textContent = messageAlertText(data);
    const link = alertBox.querySelector('[data-message-alert-link]');
    if (link) {
      const id = Number(latest.tg_id || 0);
      link.href = latest.known_user && id > 0 ? '/users/id/' + id : '/users?status=unread';
    }
    refreshDocumentTitle();
  }

  function paymentAlertText(data) {
    const total = Math.max(0, Number(data && data.total || 0));
    const latest = data && data.latest && typeof data.latest === 'object' ? data.latest : null;
    if (!latest) return total === 1 ? 'Получена новая оплата' : 'Получено новых оплат: ' + total;
    const username = String(latest.username || '').trim();
    const who = username ? '@' + username : 'Telegram ID ' + String(latest.tg_id || '—');
    const amount = Number(latest.amount);
    const amountText = Number.isFinite(amount) ? ' · ' + amount.toLocaleString('ru-RU') + ' ₽' : '';
    return (total > 1 ? 'Новых оплат: ' + total + '. Последняя от ' : 'Новая оплата от ') + who + amountText;
  }

  function applyPaymentNotifications(data) {
    const total = Math.max(0, Number(data && data.total || 0));
    paymentNotificationTotal = total;
    const badge = document.getElementById('payments-nav-badge');
    if (badge) {
      badge.textContent = compactCount(total);
      badge.hidden = total <= 0;
      badge.setAttribute('aria-label', 'Новых оплат: ' + total);
      badge.title = 'Новых оплат: ' + total;
    }
    const summary = document.getElementById('payments-notification-summary');
    if (summary) {
      summary.textContent = total > 0 ? paymentAlertText(data) : 'Новых оплат нет';
      summary.classList.toggle('active', total > 0);
    }

    let alertBox = document.getElementById('payment-live-alert');
    if (total <= 0) {
      if (alertBox) alertBox.remove();
      refreshDocumentTitle();
      return;
    }
    if (!alertBox) {
      alertBox = document.createElement('div');
      alertBox.id = 'payment-live-alert';
      alertBox.className = 'panel-live-alert payment-live-alert';
      alertBox.setAttribute('role', 'status');
      alertBox.setAttribute('aria-live', 'polite');
      const dot = document.createElement('span');
      dot.className = 'panel-live-dot payment-live-dot';
      const textSlot = document.createElement('strong');
      textSlot.dataset.paymentAlertText = '1';
      const link = document.createElement('a');
      link.className = 'button small';
      link.href = '/payments?status=all';
      link.textContent = 'Открыть оплаты';
      alertBox.append(dot, textSlot, link);
      liveAlertHost().append(alertBox);
    }
    const textSlot = alertBox.querySelector('[data-payment-alert-text]');
    if (textSlot) textSlot.textContent = paymentAlertText(data);
    refreshDocumentTitle();
  }

  function numericStorage(key) {
    const raw = storageGet(key);
    if (raw === null || raw === '') return null;
    const value = Number(raw);
    return Number.isFinite(value) && value >= 0 ? value : null;
  }

  function detectNewNotifications(data) {
    const messages = data && data.messages || {};
    const payments = data && data.payments || {};
    const messageItems = Array.isArray(messages.items) ? messages.items : [];
    const messageId = Math.max(
      Number(messages.last_event_id || 0),
      ...messageItems.map((item) => Number(item.last_event_id || 0))
    );
    const paymentId = Number(payments.last_payment_id || 0);
    const seenMessage = numericStorage(MESSAGE_SEEN_KEY);
    const seenPayment = numericStorage(PAYMENT_SEEN_KEY);
    let newMessage = false;
    let newPayment = false;
    if (seenMessage === null) storageSet(MESSAGE_SEEN_KEY, messageId);
    else if (messageId > seenMessage && Number(messages.total || 0) > 0) {
      newMessage = true;
      storageSet(MESSAGE_SEEN_KEY, messageId);
    }
    if (seenPayment === null) storageSet(PAYMENT_SEEN_KEY, paymentId);
    else if (paymentId > seenPayment && Number(payments.total || 0) > 0) {
      newPayment = true;
      storageSet(PAYMENT_SEEN_KEY, paymentId);
    }
    if (newPayment) playNotificationSound('payment');
    else if (newMessage) playNotificationSound('message');
  }

  async function pollPanelNotifications() {
    if (document.hidden || (!document.getElementById('unread-nav-badge') && !document.getElementById('payments-nav-badge'))) return;
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetch('/api/panel/notifications', {
        cache: 'no-store',
        credentials: 'same-origin',
        headers: {Accept: 'application/json'},
        signal: controller.signal
      });
      if (!response.ok) {
        console.warn('Не удалось получить уведомления панели: HTTP ' + response.status);
        return;
      }
      const data = await response.json();
      if (data && data.errors && Object.keys(data.errors).length) {
        console.warn('Часть каналов уведомлений недоступна', data.errors);
      }
      detectNewNotifications(data || {});
      applyUnreadMessages(data && data.messages || {});
      applyPaymentNotifications(data && data.payments || {});
    } catch (error) {
      if (error && error.name !== 'AbortError') console.warn('Ошибка опроса уведомлений панели', error);
    } finally {
      window.clearTimeout(timeout);
    }
  }

  // Compatibility alias retained for pages and installations that still call
  // the previous unread-only poller name. The implementation now fetches both
  // message and payment notifications in one lightweight request.
  const pollUnreadMessages = pollPanelNotifications;
  window.VPNPanel = {sleep, pollUnreadMessages, pollPanelNotifications, playNotificationSound};

  function startPanelScripts() {
    if (notificationLoopStarted) return;
    notificationLoopStarted = true;
    initTabs();
    initConfirmations();
    ensureSoundToggle();
    setTimeout(pollPlatformUpdate, 3000);
    setInterval(pollPlatformUpdate, 60000);
    setTimeout(pollPanelNotifications, 250);
    setInterval(pollPanelNotifications, 3000);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) pollPanelNotifications();
    });
    window.addEventListener('focus', pollPanelNotifications);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startPanelScripts, {once: true});
  } else {
    startPanelScripts();
  }
})();
