"""3x-ui API access, normalization and live snapshot synchronization.

Traffic, expiry and last-online values from 3x-ui are authoritative. The local
SQLite database is only a metadata store and an offline cache for the bot.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import re
import sqlite3
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

import aiohttp
import httpx

import config
import user_events

logger = logging.getLogger(__name__)

_CACHE_LOCK = threading.Lock()
_CACHE: dict[str, Any] = {
    "ts": 0.0,
    "clients": [],
    "by_email": {},
    "by_tg_id": {},
    "online": set(),
    "traffic_summary": {},
    "server_traffic_summary": {},
    "duplicate_records": 0,
    "error": "Снимок 3x-ui ещё не загружен",
    "stale": True,
}
_LAST_SYNCED_LOCK = threading.Lock()
_LAST_SYNCED: dict[str, float] = {}


def _base_url() -> str:
    return str(config.BASE_URL).rstrip("/")


def _headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {config.MASTER_API_TOKEN}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


def _verify_tls() -> bool:
    return bool(getattr(config, "XUI_VERIFY_TLS", False))


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return default


def _bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off", ""}:
            return False
    return default


def _client_credential_id(client: dict[str, Any] | None) -> str:
    """Return the Xray credential ID, never the numeric database row ID."""
    if not isinstance(client, dict):
        return ""
    uuid_value = client.get("uuid")
    if isinstance(uuid_value, str) and uuid_value.strip():
        return uuid_value.strip()
    id_value = client.get("id")
    if isinstance(id_value, str) and id_value.strip():
        return id_value.strip()
    return ""


def _string_list(value: Any) -> list[str]:
    """Convert ClientRecord CSV/JSON storage into Client.allowedIPs []."""
    if isinstance(value, (list, tuple, set)):
        return [str(item).strip() for item in value if str(item).strip()]
    if not isinstance(value, str):
        return []
    text = value.strip()
    if not text:
        return []
    if text.startswith("["):
        try:
            parsed = json.loads(text)
        except (TypeError, ValueError, json.JSONDecodeError):
            parsed = None
        if isinstance(parsed, list):
            return [str(item).strip() for item in parsed if str(item).strip()]
    return [item.strip() for item in text.split(",") if item.strip()]


def _reverse_object(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict):
        tag = str(value.get("tag") or "").strip()
        return {"tag": tag} if tag else None
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text or text.lower() == "null":
        return None
    try:
        parsed = json.loads(text)
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    if not isinstance(parsed, dict):
        return None
    tag = str(parsed.get("tag") or "").strip()
    return {"tag": tag} if tag else None


def _editable_client_payload(
    client: dict[str, Any] | None,
    fallback_id: str = "",
) -> dict[str, Any]:
    """Convert clients/get ClientRecord JSON to the Client update model.

    3x-ui's ClientRecord uses an integer ``id`` database primary key and a
    string ``uuid`` credential. The update endpoint decodes ``Client.id`` as a
    string and performs a full-row replacement, so credentials and every
    protocol-specific field must be preserved with the correct JSON types.
    """
    source = dict(client) if isinstance(client, dict) else {}
    payload: dict[str, Any] = {}

    credential_id = _client_credential_id(source) or str(fallback_id or "").strip()
    if credential_id:
        payload["id"] = credential_id

    string_fields = (
        "email",
        "subId",
        "security",
        "password",
        "flow",
        "auth",
        "group",
        "comment",
        "privateKey",
        "publicKey",
        "preSharedKey",
        "secret",
        "adTag",
    )
    for key in string_fields:
        if key in source and source[key] is not None:
            payload[key] = str(source[key])

    for key in ("totalGB", "expiryTime", "limitIp", "tgId", "reset", "keepAlive"):
        if key in source:
            payload[key] = _int(source.get(key))

    if "enable" in source:
        payload["enable"] = _bool(source.get("enable"), True)

    if "allowedIPs" in source:
        payload["allowedIPs"] = _string_list(source.get("allowedIPs"))

    reverse = _reverse_object(source.get("reverse"))
    if reverse is not None:
        payload["reverse"] = reverse

    created = source.get("created_at") or source.get("createdAt")
    updated = source.get("updated_at") or source.get("updatedAt")
    if _int(created) > 0:
        payload["created_at"] = _int(created)
    if _int(updated) > 0:
        payload["updated_at"] = _int(updated)

    return payload


def bytes_to_gb(value: Any, digits: int = 2) -> float:
    """Convert a byte counter to GiB without failing on empty API values."""
    try:
        number = max(0.0, float(value or 0))
    except (TypeError, ValueError):
        number = 0.0
    return round(number / (1024 ** 3), max(0, int(digits)))


def telegram_id_from_email(email: str) -> int:
    """Recover the legacy Telegram ID stored as the final ``_<digits>`` suffix."""
    match = re.search(r"_([1-9][0-9]{4,19})$", str(email or "").strip())
    if not match:
        return 0
    try:
        return int(match.group(1))
    except (TypeError, ValueError):
        return 0


def normalize_timestamp_ms(value: Any) -> int:
    """Normalize Unix seconds/milliseconds to milliseconds."""
    timestamp = _int(value)
    if timestamp <= 0:
        return 0
    if timestamp < 10_000_000_000:
        return timestamp * 1000
    return timestamp


def normalize_client(raw: dict[str, Any]) -> dict[str, Any]:
    """Normalize current and legacy 3x-ui client list response shapes."""
    if not isinstance(raw, dict):
        return {}
    nested = raw.get("client") if isinstance(raw.get("client"), dict) else {}
    traffic = raw.get("traffic") if isinstance(raw.get("traffic"), dict) else {}
    # Some versions put traffic under client. Keep the explicit traffic object authoritative.
    nested_traffic = nested.get("traffic") if isinstance(nested.get("traffic"), dict) else {}
    traffic = {**nested_traffic, **traffic}
    client = {**nested, **raw}

    email = str(client.get("email") or traffic.get("email") or "").strip()
    up = _int(traffic.get("up", client.get("up", 0)))
    down = _int(traffic.get("down", client.get("down", 0)))
    total = _int(
        traffic.get(
            "total",
            traffic.get("totalGB", client.get("total", client.get("totalGB", 0))),
        )
    )
    expiry = normalize_timestamp_ms(
        traffic.get("expiryTime", client.get("expiryTime", nested.get("expiryTime", 0)))
    )
    last_online = normalize_timestamp_ms(
        traffic.get("lastOnline", client.get("lastOnline", nested.get("lastOnline", 0)))
    )
    traffic_enable = traffic.get("enable")
    enable_value = client.get("enable", nested.get("enable", True))
    enable = bool(enable_value if traffic_enable is None else traffic_enable)
    uuid_value = _client_credential_id(raw) or _client_credential_id(nested) or _client_credential_id(client)

    return {
        "email": email,
        "uuid": str(uuid_value or ""),
        "sub_id": str(client.get("subId") or traffic.get("subId") or ""),
        "expiry_time": expiry,
        "enable": enable,
        "up": max(0, up),
        "down": max(0, down),
        "total": max(0, total),
        "last_online_ts": max(0, last_online),
        "online": False,
        "inbound_ids": client.get("inboundIds") if isinstance(client.get("inboundIds"), list) else [],
        "tg_id": _int(client.get("tgId", nested.get("tgId", 0))),
        "raw": raw,
    }


def request_json_sync(
    method: str,
    path: str,
    payload: dict[str, Any] | None = None,
    timeout: float = 12.0,
) -> dict[str, Any]:
    """Perform an authenticated 3x-ui request and validate the JSON envelope."""
    response = httpx.request(
        method.upper(),
        f"{_base_url()}/{path.lstrip('/')}",
        headers=_headers(),
        json=payload,
        verify=_verify_tls(),
        timeout=httpx.Timeout(timeout, connect=min(5.0, timeout)),
    )
    response.raise_for_status()
    data = response.json()
    if not isinstance(data, dict):
        raise RuntimeError("3x-ui вернула некорректный JSON")
    if not data.get("success"):
        raise RuntimeError(str(data.get("msg") or "3x-ui отклонила запрос"))
    return data


def _last_online_map(value: Any) -> dict[str, int]:
    result: dict[str, int] = {}
    if isinstance(value, dict):
        for key, timestamp in value.items():
            if isinstance(timestamp, dict):
                email = str(timestamp.get("email") or key).strip().lower()
                ts = timestamp.get("lastOnline", timestamp.get("time", 0))
            else:
                email = str(key).strip().lower()
                ts = timestamp
            if email:
                result[email] = normalize_timestamp_ms(ts)
    elif isinstance(value, list):
        for item in value:
            if not isinstance(item, dict):
                continue
            email = str(item.get("email") or item.get("clientEmail") or "").strip().lower()
            if email:
                result[email] = normalize_timestamp_ms(item.get("lastOnline", item.get("time", 0)))
    return result


def _copy_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    return {
        "ts": float(snapshot.get("ts", 0)),
        "clients": [dict(item) for item in snapshot.get("clients", [])],
        "by_email": {key: dict(value) for key, value in snapshot.get("by_email", {}).items()},
        "by_tg_id": {int(key): dict(value) for key, value in snapshot.get("by_tg_id", {}).items()},
        "online": set(snapshot.get("online", set())),
        "traffic_summary": dict(snapshot.get("traffic_summary", {})),
        "server_traffic_summary": dict(snapshot.get("server_traffic_summary", {})),
        "duplicate_records": _int(snapshot.get("duplicate_records")),
        "error": str(snapshot.get("error", "")),
        "stale": bool(snapshot.get("stale", False)),
    }


def _client_identity_key(item: dict[str, Any]) -> str:
    # 3x-ui uses email as the stable client identity across several inbound
    # protocols. A UUID may be blank or protocol-specific, so keying on it
    # would still duplicate the same user in the dashboard.
    return str(item.get("email") or "").strip().lower()


def deduplicate_clients(clients: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], int]:
    """Collapse the same 3x-ui client returned from several inbounds.

    Some 3x-ui builds expose one traffic row per inbound. Those counters are
    often mirrors of the same client total, therefore summing them can inflate
    dashboard traffic many times over. We keep the maximum counter for each
    direction and retain all inbound IDs for diagnostics.
    """
    merged: dict[str, dict[str, Any]] = {}
    duplicate_records = 0
    for source in clients:
        if not isinstance(source, dict) or not source.get("email"):
            continue
        key = _client_identity_key(source)
        if key not in merged:
            merged[key] = dict(source)
            merged[key]["inbound_ids"] = list(source.get("inbound_ids") or [])
            continue
        duplicate_records += 1
        target = merged[key]
        for field in ("up", "down", "total", "last_online_ts", "expiry_time"):
            target[field] = max(_int(target.get(field)), _int(source.get(field)))
        target["enable"] = bool(target.get("enable")) or bool(source.get("enable"))
        target["online"] = bool(target.get("online")) or bool(source.get("online"))
        target_uuid = str(target.get("uuid") or "").strip()
        source_uuid = str(source.get("uuid") or "").strip()
        variants = set(str(value) for value in target.get("credential_variants", []) if value)
        if target_uuid:
            variants.add(target_uuid)
        if source_uuid:
            variants.add(source_uuid)
        if not target_uuid and source_uuid:
            target["uuid"] = source_uuid
        if variants:
            target["credential_variants"] = sorted(variants)
        if not target.get("sub_id") and source.get("sub_id"):
            target["sub_id"] = str(source["sub_id"])
        if _int(target.get("tg_id")) <= 0 and _int(source.get("tg_id")) > 0:
            target["tg_id"] = _int(source.get("tg_id"))
        inbound_ids = {
            _int(value)
            for value in list(target.get("inbound_ids") or []) + list(source.get("inbound_ids") or [])
            if _int(value) > 0
        }
        target["inbound_ids"] = sorted(inbound_ids)
    return list(merged.values()), duplicate_records


def summarize_server_traffic(value: Any) -> dict[str, Any]:
    """Normalize the same cumulative counters shown on the 3x-ui dashboard."""
    status = value if isinstance(value, dict) else {}
    counters = status.get("netTraffic") if isinstance(status.get("netTraffic"), dict) else {}
    sent = max(0, _int(counters.get("sent")))
    received = max(0, _int(counters.get("recv")))
    if not counters:
        return {}
    return {
        "up": sent,
        "down": received,
        "used": sent + received,
        "source": "server-status",
    }


def summarize_inbound_traffic(value: Any) -> dict[str, Any]:
    inbounds = [item for item in (value if isinstance(value, list) else []) if isinstance(item, dict)]
    enabled = [item for item in inbounds if _bool(item.get("enable"), True)]

    def totals(rows: list[dict[str, Any]]) -> tuple[int, int]:
        return (
            sum(max(0, _int(item.get("up"))) for item in rows),
            sum(max(0, _int(item.get("down"))) for item in rows),
        )

    up, down = totals(inbounds)
    enabled_up, enabled_down = totals(enabled)
    return {
        # The 3x-ui aggregate is based on inbound counters, including disabled
        # inbounds that still contain historical usage.
        "up": up,
        "down": down,
        "used": up + down,
        "enabled_up": enabled_up,
        "enabled_down": enabled_down,
        "enabled_used": enabled_up + enabled_down,
        "inbounds": len(inbounds),
        "enabled_inbounds": len(enabled),
        "source": "inbounds",
    }


def fetch_snapshot_sync(force: bool = False) -> dict[str, Any]:
    """Fetch and cache current clients, traffic, online status and last-seen data."""
    ttl = max(1, _int(getattr(config, "XUI_CACHE_SECONDS", 15), 15))
    now = time.time()
    with _CACHE_LOCK:
        if not force and now - float(_CACHE.get("ts", 0)) < ttl:
            return _copy_snapshot(_CACHE)

    try:
        list_data = request_json_sync("GET", "panel/api/clients/list")
        raw_clients = list_data.get("obj") if isinstance(list_data.get("obj"), list) else []
        clients = [normalize_client(item) for item in raw_clients if isinstance(item, dict)]
        clients = [item for item in clients if item.get("email")]
        clients, duplicate_records = deduplicate_clients(clients)

        traffic_summary: dict[str, Any] = {}
        try:
            inbound_data = request_json_sync("GET", "panel/api/inbounds/list")
            traffic_summary = summarize_inbound_traffic(inbound_data.get("obj"))
        except Exception as error:
            logger.debug("3x-ui inbound traffic unavailable: %s", error)

        server_traffic_summary: dict[str, Any] = {}
        try:
            server_data = request_json_sync("GET", "panel/api/server/status")
            server_traffic_summary = summarize_server_traffic(server_data.get("obj"))
        except Exception as error:
            # Older 3x-ui versions may not expose this endpoint through the API
            # token. The dashboard then falls back to inbound/client counters.
            logger.debug("3x-ui server traffic unavailable: %s", error)

        last_online: dict[str, int] = {}
        online: set[str] = set()
        try:
            last_data = request_json_sync("POST", "panel/api/clients/lastOnline")
            last_online = _last_online_map(last_data.get("obj"))
        except Exception as error:
            logger.debug("3x-ui lastOnline unavailable: %s", error)
        try:
            online_data = request_json_sync("POST", "panel/api/clients/onlines")
            if isinstance(online_data.get("obj"), list):
                online = {
                    str(item.get("email") if isinstance(item, dict) else item).strip().lower()
                    for item in online_data["obj"]
                    if item
                }
        except Exception as error:
            logger.debug("3x-ui onlines unavailable: %s", error)

        for item in clients:
            email_key = str(item["email"]).lower()
            if last_online.get(email_key, 0) > 0:
                item["last_online_ts"] = last_online[email_key]
            item["online"] = email_key in online

        snapshot = {
            "ts": time.time(),
            "clients": clients,
            "by_email": {str(item["email"]).lower(): item for item in clients},
            # Keep this index strictly authoritative. Legacy email suffixes are
            # considered only by find_client_by_telegram_id_sync() for the one
            # concrete Telegram user currently being recovered.
            "by_tg_id": {
                int(item.get("tg_id") or 0): item
                for item in clients
                if int(item.get("tg_id") or 0) > 0
            },
            "online": online,
            "traffic_summary": traffic_summary,
            "server_traffic_summary": server_traffic_summary,
            "duplicate_records": duplicate_records,
            "error": "",
            "stale": False,
        }
        with _CACHE_LOCK:
            _CACHE.clear()
            _CACHE.update(snapshot)
        return _copy_snapshot(snapshot)
    except Exception as error:
        logger.warning("Не удалось получить свежие данные 3x-ui: %s", error)
        with _CACHE_LOCK:
            cached = _copy_snapshot(_CACHE)
        cached["error"] = str(error)
        cached["stale"] = True
        return cached


def invalidate_snapshot_cache() -> None:
    with _CACHE_LOCK:
        _CACHE["ts"] = 0.0


def _stable_negative_id(email: str) -> int:
    digest = hashlib.sha256(email.lower().encode("utf-8")).digest()
    return -(int.from_bytes(digest[:7], "big") % 9_000_000_000 + 1)


def _ensure_user_columns(connection: sqlite3.Connection) -> None:
    columns = {str(row[1]) for row in connection.execute("PRAGMA table_info(users)")}
    additions = {
        "last_online_ts": "INTEGER DEFAULT 0",
        "last_sync_at": "TEXT",
        "identity_source": "TEXT",
        "identity_updated_at": "TEXT",
        "notes": "TEXT",
    }
    for name, ddl in additions.items():
        if name not in columns:
            connection.execute(f"ALTER TABLE users ADD COLUMN {name} {ddl}")


def _rekey_related_rows(connection: sqlite3.Connection, old_tg_id: int, new_tg_id: int) -> None:
    """Move payments and conversation history when a placeholder ID is repaired."""
    if int(old_tg_id) == int(new_tg_id):
        return
    for table in ("payments", "message_log", "user_events"):
        exists = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
        ).fetchone()
        if not exists:
            continue
        table_columns = {str(row[1]) for row in connection.execute(f"PRAGMA table_info({table})")}
        if "tg_id" in table_columns:
            connection.execute(
                f"UPDATE {table} SET tg_id=? WHERE tg_id=?",
                (int(new_tg_id), int(old_tg_id)),
            )
    user_events.rekey_message_state(connection, int(old_tg_id), int(new_tg_id))


def sync_snapshot_to_db(snapshot: dict[str, Any], db_path: str | Path | None = None) -> int:
    """Persist a live snapshot and repair legacy rows whose TG ID was lost.

    A positive ``tgId`` from 3x-ui is authoritative. Numeric email suffixes are
    deliberately *not* promoted here: old manual clients used Unix timestamps in
    the same position. The suffix is considered only when a concrete Telegram ID
    is being recovered by the bot/payment flow. Username alone is never identity.
    """
    clients = snapshot.get("clients") if isinstance(snapshot, dict) else []
    if not isinstance(clients, list):
        return 0
    target = str(db_path or config.DB_PATH)
    Path(target).parent.mkdir(parents=True, exist_ok=True)
    now_text = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    changed = 0

    connection = sqlite3.connect(target, timeout=20)
    try:
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout=20000")
        _ensure_user_columns(connection)
        rows = connection.execute(
            "SELECT tg_id,username,uuid,email,expiry_time,last_reminder_days FROM users"
        ).fetchall()
        by_email = {str(row["email"] or "").strip().lower(): row for row in rows if row["email"]}
        by_uuid = {str(row["uuid"] or "").strip().lower(): row for row in rows if row["uuid"]}
        matched_ids: set[int] = set()

        for item in clients:
            if not isinstance(item, dict) or not item.get("email"):
                continue
            email = str(item["email"]).strip()
            email_key = email.lower()
            uuid_key = str(item.get("uuid") or "").strip().lower()
            source_row = by_email.get(email_key) or (by_uuid.get(uuid_key) if uuid_key else None)
            row = dict(source_row) if source_row else None
            panel_tg_id = _int(item.get("tg_id"))
            inferred_tg_id = panel_tg_id if panel_tg_id > 0 else 0

            if row:
                current_tg_id = int(row["tg_id"])
                if current_tg_id <= 0 and inferred_tg_id > 0:
                    existing = connection.execute(
                        "SELECT tg_id,username,uuid,email,expiry_time,last_reminder_days FROM users WHERE tg_id=?",
                        (inferred_tg_id,),
                    ).fetchone()
                    if existing:
                        existing_dict = dict(existing)
                        if not existing_dict.get("username") and row.get("username"):
                            connection.execute(
                                "UPDATE users SET username=? WHERE tg_id=?",
                                (row.get("username"), inferred_tg_id),
                            )
                            existing_dict["username"] = row.get("username")
                        _rekey_related_rows(connection, current_tg_id, inferred_tg_id)
                        connection.execute("DELETE FROM users WHERE tg_id=?", (current_tg_id,))
                        row = existing_dict
                    else:
                        _rekey_related_rows(connection, current_tg_id, inferred_tg_id)
                        connection.execute(
                            "UPDATE users SET tg_id=? WHERE tg_id=?",
                            (inferred_tg_id, current_tg_id),
                        )
                        row["tg_id"] = inferred_tg_id
                    tg_id = inferred_tg_id
                    changed += 1
                else:
                    tg_id = current_tg_id
                    if panel_tg_id > 0 and current_tg_id > 0 and panel_tg_id != current_tg_id:
                        logger.warning(
                            "Конфликт TG ID для %s: локально %s, в 3x-ui %s; сохранён локальный ID",
                            email, current_tg_id, panel_tg_id,
                        )
            else:
                tg_id = inferred_tg_id or _stable_negative_id(email)

            if tg_id in matched_ids:
                logger.warning("Повторяющийся TG ID %s у клиента %s; запись оставлена без Telegram-привязки", tg_id, email)
                tg_id = _stable_negative_id(email)
            matched_ids.add(tg_id)

            username = str((row or {}).get("username") or "") or (email.rsplit("_", 1)[0] or "Веб-клиент")
            last_online_ts = _int(item.get("last_online_ts"))
            last_online = (
                datetime.fromtimestamp(last_online_ts / 1000).strftime("%Y-%m-%d %H:%M:%S")
                if last_online_ts > 0
                else None
            )
            connection.execute(
                """
                INSERT INTO users(
                    tg_id,username,uuid,email,expiry_time,enable,up,down,total,sub_id,
                    last_online,last_online_ts,last_sync_at,last_reminder_days
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,-1)
                ON CONFLICT(tg_id) DO UPDATE SET
                    username=COALESCE(NULLIF(users.username,''),excluded.username),
                    uuid=excluded.uuid,email=excluded.email,
                    last_reminder_days=CASE
                        WHEN COALESCE(users.expiry_time,0) <> COALESCE(excluded.expiry_time,0) THEN -1
                        ELSE users.last_reminder_days
                    END,
                    expiry_time=excluded.expiry_time,
                    enable=excluded.enable,up=excluded.up,down=excluded.down,total=excluded.total,
                    sub_id=excluded.sub_id,
                    last_online=COALESCE(excluded.last_online,users.last_online),
                    last_online_ts=MAX(COALESCE(excluded.last_online_ts,0),COALESCE(users.last_online_ts,0)),
                    last_sync_at=excluded.last_sync_at
                """,
                (
                    tg_id,
                    username,
                    str(item.get("uuid") or ""),
                    email,
                    _int(item.get("expiry_time")),
                    int(bool(item.get("enable"))),
                    _int(item.get("up")),
                    _int(item.get("down")),
                    _int(item.get("total")),
                    str(item.get("sub_id") or ""),
                    last_online,
                    last_online_ts,
                    now_text,
                ),
            )
            if panel_tg_id > 0:
                connection.execute(
                    "UPDATE users SET identity_source='3x-ui',identity_updated_at=? WHERE tg_id=?",
                    (now_text, tg_id),
                )
            changed += 1

        # A successful full list is authoritative. Keep metadata, but disable local
        # rows that no longer exist in 3x-ui so reminders cannot target them.
        for source_row in rows:
            tg_id = int(source_row["tg_id"])
            if source_row["email"] and tg_id not in matched_ids:
                connection.execute(
                    "UPDATE users SET enable=0,last_sync_at=? WHERE tg_id=?",
                    (now_text, tg_id),
                )
                changed += 1
        connection.commit()
    finally:
        connection.close()
    return changed


def fetch_and_sync(force: bool = False, db_path: str | Path | None = None) -> dict[str, Any]:
    """Return a live snapshot and persist each fresh snapshot at most once.

    Dashboard routes share the same in-memory 3x-ui cache. Without this guard,
    every page view rewrote all users to SQLite even when the cached snapshot
    had not changed.
    """
    snapshot = fetch_snapshot_sync(force=force)
    if snapshot.get("stale"):
        return snapshot
    target = str(Path(db_path or config.DB_PATH).resolve())
    snapshot_ts = float(snapshot.get("ts") or 0)
    should_sync = False
    with _LAST_SYNCED_LOCK:
        if snapshot_ts > 0 and _LAST_SYNCED.get(target) != snapshot_ts:
            _LAST_SYNCED[target] = snapshot_ts
            should_sync = True
    if should_sync:
        try:
            sync_snapshot_to_db(snapshot, db_path=target)
        except Exception:
            with _LAST_SYNCED_LOCK:
                if _LAST_SYNCED.get(target) == snapshot_ts:
                    _LAST_SYNCED.pop(target, None)
            raise
    return snapshot


def inbound_ids_sync() -> list[int]:
    data = request_json_sync("GET", "panel/api/inbounds/list")
    return [int(item["id"]) for item in data.get("obj", []) if isinstance(item, dict) and item.get("id") is not None]


def add_client_sync(client: dict[str, Any], inbound_ids: list[int] | None = None) -> dict[str, Any]:
    result = request_json_sync(
        "POST",
        "panel/api/clients/add",
        {"client": client, "inboundIds": inbound_ids if inbound_ids is not None else inbound_ids_sync()},
    )
    invalidate_snapshot_cache()
    return result


def get_client_record_sync(email: str) -> dict[str, Any]:
    """Return the raw ClientRecord, typed update payload and attachments."""
    clean_email = str(email or "").strip()
    if not clean_email:
        raise ValueError("Email клиента не указан")
    data = request_json_sync("GET", f"panel/api/clients/get/{quote(clean_email, safe='')}")
    obj = data.get("obj")
    if not isinstance(obj, dict):
        raise RuntimeError(f"Клиент {clean_email} не найден в 3x-ui")

    nested = obj.get("client") if isinstance(obj.get("client"), dict) else obj
    raw_client = dict(nested)
    if not raw_client.get("email"):
        raw_client["email"] = clean_email

    inbound_ids = obj.get("inboundIds")
    if not isinstance(inbound_ids, list):
        inbound_ids = raw_client.get("inboundIds") if isinstance(raw_client.get("inboundIds"), list) else []

    normalized = normalize_client({"client": raw_client, "inboundIds": inbound_ids})
    editable = _editable_client_payload(raw_client, fallback_id=str(normalized.get("uuid") or ""))
    return {
        "client": raw_client,
        "editable_client": editable,
        "inbound_ids": [_int(value) for value in inbound_ids],
        "normalized": normalized,
        "raw": obj,
    }


def update_client_sync(
    email: str,
    changes: dict[str, Any],
    record: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Replace a 3x-ui client row while preserving every editable field."""
    record = record or get_client_record_sync(email)
    fallback_id = str(record.get("normalized", {}).get("uuid") or "")
    base = record.get("editable_client")
    client = dict(base) if isinstance(base, dict) else _editable_client_payload(record.get("client"), fallback_id)
    client.update(changes)
    client = _editable_client_payload(client, fallback_id=fallback_id)
    client["email"] = str(client.get("email") or email).strip()

    defaults = {
        "comment": "VPN Service Platform",
        "enable": True,
        "expiryTime": 0,
        "limitIp": 0,
        "reset": 0,
        "security": "auto",
        "subId": "",
        "tgId": 0,
        "totalGB": 0,
    }
    for key, value in defaults.items():
        client.setdefault(key, value)

    result = request_json_sync(
        "POST",
        f"panel/api/clients/update/{quote(str(email), safe='')}",
        client,
    )
    invalidate_snapshot_cache()
    return result


def extend_client_sync(email: str, days: int, tg_id: int | None = None) -> dict[str, Any]:
    """Extend from the later of now/current expiry and re-enable the client.

    Unlike ``bulkAdjust``, this also converts legacy unlimited/zero expiry into a
    real paid period and can repair the client's Telegram ID in the same update.
    """
    days = int(days)
    if days <= 0:
        raise ValueError("Количество дней для продления должно быть положительным")
    record = get_client_record_sync(email)
    client = record["client"]
    current = normalize_timestamp_ms(client.get("expiryTime", record["normalized"].get("expiry_time", 0)))
    now_ms = int(time.time() * 1000)
    expiry = max(now_ms, current if current > 0 else now_ms) + days * 86_400_000
    changes: dict[str, Any] = {"expiryTime": expiry, "enable": True}
    if tg_id is not None and int(tg_id) > 0:
        changes["tgId"] = int(tg_id)
    update_client_sync(email, changes, record=record)
    try:
        updated = get_client_record_sync(str(changes.get("email") or email))
        normalized = dict(updated["normalized"])
    except Exception as error:
        # The POST has already been accepted.  A temporary verification GET
        # must not report the renewal as failed, otherwise a retry can add the
        # same days a second time.
        logger.warning("Клиент %s обновлён, но контрольный GET не выполнен: %s", email, error)
        normalized = dict(record.get("normalized") or {})
    normalized["expiry_time"] = expiry
    normalized["enable"] = True
    if tg_id is not None and int(tg_id) > 0:
        normalized["tg_id"] = int(tg_id)
    return normalized


def change_client_days_sync(
    email: str,
    days_delta: int,
    tg_id: int | None = None,
) -> dict[str, Any]:
    """Add or subtract days without converting an expired term to unlimited.

    Positive values behave like a renewal and start from the later of now or
    the current expiry. Negative values subtract from the exact current expiry.
    If subtraction moves the date into the past, the client is disabled and a
    small positive timestamp is retained because expiryTime=0 means unlimited
    in 3x-ui.
    """
    days_delta = int(days_delta)
    if days_delta == 0:
        raise ValueError("Изменение количества дней не может быть равно нулю")
    record = get_client_record_sync(email)
    normalized = dict(record.get("normalized") or {})
    current = normalize_timestamp_ms(
        record.get("client", {}).get("expiryTime", normalized.get("expiry_time", 0))
    )
    now_ms = int(time.time() * 1000)
    if days_delta > 0:
        base = max(now_ms, current if current > 0 else now_ms)
        expiry = base + days_delta * 86_400_000
        enable = True
    else:
        if current <= 0:
            raise ValueError("Нельзя убавить дни у бессрочной подписки: сначала задайте дату окончания")
        expiry = max(1, current + days_delta * 86_400_000)
        enable = bool(normalized.get("enable", True)) and expiry > now_ms
    changes: dict[str, Any] = {"expiryTime": expiry, "enable": enable}
    if tg_id is not None and int(tg_id) > 0:
        changes["tgId"] = int(tg_id)
    update_client_sync(email, changes, record=record)
    try:
        updated = get_client_record_sync(email)
        result = dict(updated["normalized"])
    except Exception as error:
        logger.warning("Срок клиента %s изменён, но контрольный GET не выполнен: %s", email, error)
        result = dict(normalized)
    result["expiry_time"] = expiry
    result["enable"] = enable
    if tg_id is not None and int(tg_id) > 0:
        result["tg_id"] = int(tg_id)
    return result


def bind_client_tg_id_sync(email: str, tg_id: int) -> dict[str, Any]:
    tg_id = int(tg_id)
    if tg_id <= 0:
        raise ValueError("Telegram ID должен быть положительным")
    update_client_sync(email, {"tgId": tg_id})
    record = get_client_record_sync(email)
    normalized = dict(record["normalized"])
    normalized["tg_id"] = tg_id
    return normalized


def find_client_by_telegram_id_sync(tg_id: int, force: bool = True) -> dict[str, Any] | None:
    """Find a panel client by explicit tgId, then by the legacy email suffix."""
    tg_id = int(tg_id)
    if tg_id <= 0:
        return None
    try:
        data = request_json_sync("GET", f"panel/api/clients/get/tgId/{tg_id}")
        obj = data.get("obj")
        candidates = obj if isinstance(obj, list) else [obj]
        for candidate in candidates:
            if isinstance(candidate, dict):
                normalized = normalize_client(candidate)
                if normalized.get("email"):
                    return normalized
    except Exception as error:
        logger.debug("Поиск клиента по tgId через прямой endpoint недоступен: %s", error)

    snapshot = fetch_snapshot_sync(force=force)
    explicit = snapshot.get("by_tg_id", {}).get(tg_id)
    if explicit:
        return dict(explicit)
    for item in snapshot.get("clients", []):
        if telegram_id_from_email(str(item.get("email") or "")) == tg_id:
            return dict(item)
    return None


def adjust_client_sync(email: str, days: int = 0, bytes_delta: int = 0) -> dict[str, Any]:
    result = request_json_sync(
        "POST",
        "panel/api/clients/bulkAdjust",
        {"emails": [email], "addDays": int(days), "addBytes": int(bytes_delta)},
    )
    invalidate_snapshot_cache()
    return result


def set_client_status_sync(email: str, enable: bool) -> dict[str, Any]:
    endpoint = "panel/api/clients/bulkEnable" if enable else "panel/api/clients/bulkDisable"
    result = request_json_sync("POST", endpoint, {"emails": [email]})
    invalidate_snapshot_cache()
    return result


def delete_client_sync(email: str, keep_traffic: bool = False) -> dict[str, Any]:
    result = request_json_sync(
        "POST",
        "panel/api/clients/bulkDel",
        {"emails": [email], "keepTraffic": bool(keep_traffic)},
    )
    invalidate_snapshot_cache()
    return result


class ServerClient:
    """Async compatibility wrapper used by the Telegram bot."""

    def __init__(self, *_args: Any, **_kwargs: Any):
        self.base_url = _base_url()
        self.headers = _headers()

    async def _request(self, method: str, path: str, data: dict | None = None) -> dict[str, Any]:
        timeout = getattr(config, "API_TIMEOUT", aiohttp.ClientTimeout(total=12.0))
        async with aiohttp.ClientSession(
            connector=aiohttp.TCPConnector(ssl=_verify_tls()), timeout=timeout
        ) as session:
            try:
                url = f"{self.base_url}/{path.lstrip('/')}"
                async with session.request(method, url, headers=_headers(), json=data) as response:
                    payload = await response.json(content_type=None)
                    if response.status == 200 and isinstance(payload, dict):
                        return payload
                    return {"success": False, "msg": f"HTTP {response.status}"}
            except Exception as error:
                logger.warning("3x-ui request failed: %s", error)
                return {"success": False, "msg": str(error)}

    async def add_or_update_client(
        self,
        uuid: str,
        email: str,
        sub_id: str,
        expiry_ts: int = 0,
        enable: bool = True,
    ) -> bool:
        check = await self._request("GET", f"panel/api/clients/get/{quote(email, safe='')}")
        current = check.get("obj") if isinstance(check.get("obj"), dict) else {}
        raw_client = current.get("client") if isinstance(current.get("client"), dict) else current
        inbound_ids = current.get("inboundIds") if isinstance(current.get("inboundIds"), list) else []
        if not inbound_ids and isinstance(raw_client, dict) and isinstance(raw_client.get("inboundIds"), list):
            inbound_ids = list(raw_client.get("inboundIds") or [])

        base = _editable_client_payload(raw_client, fallback_id=uuid)
        payload = {
            **base,
            "email": email,
            "subId": base.get("subId") or sub_id,
            "totalGB": _int(base.get("totalGB")),
            "expiryTime": int(expiry_ts),
            "enable": bool(enable),
            "limitIp": _int(base.get("limitIp")),
            "flow": base.get("flow") or "xtls-rprx-vision",
        }
        payload = _editable_client_payload(payload, fallback_id=base.get("id") or uuid)

        if check.get("success") and current:
            result = await self._request("POST", f"panel/api/clients/update/{quote(email, safe='')}", payload)
        else:
            if not inbound_ids:
                try:
                    inbound_ids = await asyncio.to_thread(inbound_ids_sync)
                except Exception:
                    inbound_ids = []
            result = await self._request(
                "POST",
                "panel/api/clients/add",
                {"client": payload, "inboundIds": inbound_ids},
            )
        invalidate_snapshot_cache()
        return bool(result.get("success"))

    async def delete_client(self, email: str) -> bool:
        result = await self._request("POST", "panel/api/clients/bulkDel", {"emails": [email], "keepTraffic": False})
        invalidate_snapshot_cache()
        return bool(result.get("success"))

    async def set_client_status(self, email: str, enable: bool) -> bool:
        path = "panel/api/clients/bulkEnable" if enable else "panel/api/clients/bulkDisable"
        result = await self._request("POST", path, {"emails": [email]})
        invalidate_snapshot_cache()
        return bool(result.get("success"))

    async def get_client_stats(self, email: str) -> dict[str, Any]:
        result = await self._request("GET", f"panel/api/clients/traffic/{quote(email, safe='')}")
        if result.get("success") and isinstance(result.get("obj"), dict):
            item = normalize_client({**result["obj"], "traffic": result["obj"]})
            item["exists"] = True
            return item
        snapshot = await asyncio.to_thread(fetch_snapshot_sync, False)
        item = snapshot.get("by_email", {}).get(email.lower())
        return {**item, "exists": True} if item else {"exists": False, "up": 0, "down": 0}

    async def get_system_status(self) -> dict[str, str]:
        try:
            import psutil

            return {
                "cpu": f"{psutil.cpu_percent():.0f}%",
                "ram": f"{psutil.virtual_memory().percent:.0f}%",
                "disk": f"{psutil.disk_usage('/').percent:.0f}%",
            }
        except Exception:
            return {"cpu": "Н/Д", "ram": "Н/Д", "disk": "Н/Д"}

    async def run_speedtest(self) -> str:
        try:
            process = await asyncio.create_subprocess_exec(
                "speedtest-cli",
                "--simple",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await process.communicate()
            text = stdout.decode(errors="replace").strip()
            return text or "⚠️ Скорость временно недоступна."
        except Exception as error:
            return f"❌ Ошибка: {error}"

    async def get_online_users_list(self) -> list[str]:
        result = await self._request("POST", "panel/api/clients/onlines")
        if result.get("success") and isinstance(result.get("obj"), list):
            return [
                str(item.get("email") if isinstance(item, dict) else item).strip()
                for item in result["obj"]
                if item
            ]
        return []
