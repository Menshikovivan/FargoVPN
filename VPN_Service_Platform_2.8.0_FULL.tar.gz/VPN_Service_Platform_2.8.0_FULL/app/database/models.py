import aiosqlite
import os
import time
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../vpn_bot.db")

async def init_db():
    async with aiosqlite.connect(DB_PATH) as conn:
        # Создаем таблицу, идентичную структуре client_traffics в 3X-UI
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                tg_id INTEGER PRIMARY KEY,
                username TEXT,
                uuid TEXT UNIQUE,
                email TEXT UNIQUE,
                expiry_time INTEGER DEFAULT 0,
                enable INTEGER DEFAULT 0,
                up INTEGER DEFAULT 0,
                down INTEGER DEFAULT 0,
                total INTEGER DEFAULT 0,
                sub_id TEXT
            )
        """)
        await conn.commit()

async def create_user(tg_id, username, uuid, email, sub_id):
    async with aiosqlite.connect(DB_PATH) as conn:
        async with conn.execute("SELECT tg_id FROM users WHERE tg_id = ?", (tg_id,)) as c:
            if await c.fetchone():
                return
        await conn.execute(
            "INSERT INTO users (tg_id, username, uuid, email, sub_id, expiry_time, enable) VALUES (?, ?, ?, ?, ?, 0, 0)",
            (tg_id, username, uuid, email, sub_id)
        )
        await conn.commit()

async def get_user(tg_id):
    async with aiosqlite.connect(DB_PATH) as conn:
        # Строгий упорядоченный выбор полей во избежание кракозябр
        conn.row_factory = aiosqlite.Row
        async with conn.execute("SELECT uuid, email, sub_id, expiry_time, enable FROM users WHERE tg_id = ?", (tg_id,)) as c:
            row = await c.fetchone()
            if not row:
                return None
            
            ts_ms = row["expiry_time"]
            if ts_ms and ts_ms > 0:
                expiry_date_str = datetime.fromtimestamp(ts_ms / 1000).strftime("%Y-%m-%d %H:%M:%S")
            else:
                expiry_date_str = "Нет подписки"
                
            return {
                "uuid": row["uuid"],
                "email": row["email"],
                "sub_id": row["sub_id"],
                "expiry_date": expiry_date_str,
                "enable": row["enable"]
            }

async def activate_or_prolong_user(tg_id) -> int:
    """Продлевает подписку на 30 дней вперед в чистых миллисекундах"""
    async with aiosqlite.connect(DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        async with conn.execute("SELECT expiry_time FROM users WHERE tg_id = ?", (tg_id,)) as c:
            row = await c.fetchone()
            now_ms = int(time.time() * 1000)
            
            if row and row["expiry_time"] > now_ms:
                new_expiry_ms = row["expiry_time"] + (30 * 24 * 60 * 60 * 1000)
            else:
                new_expiry_ms = now_ms + (30 * 24 * 60 * 60 * 1000)
                
            await conn.execute("UPDATE users SET expiry_time = ?, enable = 1 WHERE tg_id = ?", (new_expiry_ms, tg_id))
            await conn.commit()
            return new_expiry_ms
