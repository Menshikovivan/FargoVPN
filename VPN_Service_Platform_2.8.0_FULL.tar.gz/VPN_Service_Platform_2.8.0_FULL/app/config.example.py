"""Пример конфигурации. Установщик создаёт app/config.py автоматически."""
import aiohttp

INSTALL_PROFILE = "full"
SERVICE_NAME = "MyVPN"
BOT_TOKEN = "123456:telegram-bot-token"
ADMIN_IDS = [123456789]
PANEL_NOTIFY_ADMIN_MESSAGES = True
SUBSCRIPTION_DAYS = 30
BOT_WELCOME_TEXT = ""  # optional; {service} is replaced with SERVICE_NAME
BOT_SUPPORT_PROMPT = ""
FAQ_INCY_URL = "https://apps.apple.com/ru/app/incy/id6756943388"
BOT_IDENTITY_REFRESH_SECONDS = 600
BOT_SYNC_INTERVAL_SECONDS = 3600
DB_PATH = "/root/vpn_bot/data/vpn_bot.db"
BASE_URL = "https://panel.example.com/"
MASTER_API_URL = BASE_URL
MASTER_API_TOKEN = "3x-ui-api-token"
SUB_BASE_URL = "https://panel.example.com/sub/"
PAYMENT_PRICE = 150
PAYMENT_PHONE = "+79990000000"
PAYMENT_BANK = "Банк"
PAYMENT_RECEIVER = "Получатель"

# Local receipt OCR. PAYMENT_PHONE and PAYMENT_RECEIVER are the expected
# recipient details. Automatic approval requires all checks to pass.
RECEIPT_OCR_ENABLED = True
RECEIPT_AUTO_APPROVE = True
RECEIPT_MIN_AMOUNT = 150.0  # accepted when recognized amount is >= this value
RECEIPT_MAX_AGE_HOURS = 24
RECEIPT_RECEIVER_ALIASES = ""  # e.g. "Иван И.; И. Иванов"
RECEIPT_ALLOW_MASKED_PHONE = True
RECEIPT_TIMEZONE = "Europe/Moscow"
RECEIPT_OCR_LANGUAGES = "rus+eng"
RECEIPT_OCR_TIMEOUT = 20
# Individual filters. Defaults are intentionally tolerant of mobile-bank
# screenshots: phone and date are optional because some banks do not show them.
RECEIPT_FILTER_NAME = True
RECEIPT_FILTER_PHONE = False
RECEIPT_FILTER_AMOUNT = True
RECEIPT_FILTER_DATE = False
RECEIPT_FILTER_STATUS = True
RECEIPT_FILTER_DUPLICATE = True

API_TIMEOUT = aiohttp.ClientTimeout(total=12.0)

WEB_HOST = "0.0.0.0"
WEB_PORT = 8088
WEB_USERNAME = "admin"
WEB_PASSWORD_HASH = "pbkdf2_sha256$260000$...$..."
WEB_SECRET_KEY = "replace-with-a-random-secret"
WEB_COOKIE_HTTPS_ONLY = False
WEB_SESSION_MAX_AGE_SECONDS = 28800
WEB_TRUST_PROXY_HEADERS = False
WEB_LOGIN_MAX_ATTEMPTS = 5
WEB_LOGIN_WINDOW_SECONDS = 900
WEB_LOGIN_BLOCK_SECONDS = 900
WEB_LOGIN_MAX_BLOCK_SECONDS = 86400
WEB_LOGIN_SECURITY_RETENTION_DAYS = 30

XUI_DB_PATH = "/etc/x-ui/x-ui.db"
XUI_CACHE_SECONDS = 15
XUI_VERIFY_TLS = False
REMINDER_DAYS = [7, 3, 1, 0]
REMINDER_LOCK_PATH = "/run/vpn-service-reminders.lock"
METRICS_STORE_INTERVAL_SECONDS = 60
IDENTITY_IMPORT_MAX_MB = 512
USER_EVENT_KEEP_DAYS = 365
USER_EVENT_MAX_ROWS = 250000
CHAT_MEDIA_MAX_MB = 100
CHAT_MEDIA_CACHE_DIR = "/var/cache/vpn-service/chat-media"
CHAT_MEDIA_CACHE_DAYS = 30
CHAT_MEDIA_CACHE_MAX_MB = 512
BROADCAST_DIR = "/var/lib/vpn-service/broadcasts"
BROADCAST_MEDIA_MAX_MB = 45
BROADCAST_SEND_DELAY_SECONDS = 0.04
BROADCAST_STALE_SECONDS = 7200

BACKUP_DIR = "/var/backups/vpn-service"
BACKUP_KEEP_DAYS = 14
BACKUP_INTERVAL_DAYS = 3
BACKUP_TELEGRAM = True
BACKUP_TELEGRAM_PART_MB = 45
BACKUP_INCLUDE_VENV = True
BACKUP_LOCK_PATH = "/run/vpn-service-backup.lock"
BACKUP_STATE_PATH = "/var/lib/vpn-service/backup-state.json"
BACKUP_RETRY_INTERVAL_SECONDS = 900
BACKUP_PENDING_KEEP_DAYS = 30

# Yandex.Disk: official OAuth REST API or a locally mounted WebDAV disk.
YANDEX_DISK_ENABLED = False
YANDEX_DISK_MODE = "oauth"  # oauth | local
YANDEX_DISK_TOKEN = ""
YANDEX_DISK_PATH = "VPN-Service-Backups"
YANDEX_LOCAL_PATH = "/mnt/yandex-disk"
YANDEX_LOCAL_REQUIRE_MOUNT = True
YANDEX_WEBDAV_URL = "https://webdav.yandex.ru"
YANDEX_DAVFS_SECRETS_PATH = "/etc/davfs2/secrets"
YANDEX_UPLOAD_RETRIES = 5
YANDEX_UPLOAD_VERIFY_ATTEMPTS = 12
YANDEX_UPLOAD_VERIFY_DELAY = 1.0


# Legacy rclone settings remain supported as a fallback.
RCLONE_REMOTE = ""
RCLONE_PATH = "VPN-Service-Backups"

# Update distribution. The role is derived only from WEB_USERNAME:
# menshikovivan is the publisher; every other panel must point to it.
# Use the base origin, for example http://91.196.34.28:8088 (normally without /panel).
# Version 2.6.5 accepts old /panel URLs and falls back safely on the same origin.
UPDATE_DIR = "/var/lib/vpn-service/updates"
UPDATE_PUBLISHER_USERNAME = "menshikovivan"
UPDATE_IS_PUBLISHER = False
UPDATE_MASTER_URL = ""
UPDATE_API_TOKEN = "replace-with-the-same-random-token-on-all-panels"
UPDATE_CHECK_INTERVAL = 60
UPDATE_VERIFY_TLS = True
UPDATE_MAX_ARCHIVE_MB = 1024
UPDATE_STALE_JOB_SECONDS = 7200
