#!/usr/bin/env python3
"""VPN Service Platform web control panel."""
from __future__ import annotations

import hashlib
import hmac
import html
import json
import logging
import math
import os
import re
import secrets
import shutil
import sqlite3
import subprocess
import sys
import tarfile
import tempfile
import time
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlencode, urlsplit

import httpx
import psutil
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

import config
import auth_security
import broadcast_manager
import diagnostics as platform_diagnostics
import identity_migration
import panel_notifications
import service_audit
import update_manager
import user_events
from backup import test_yandex_connection
from init_db import migrate as migrate_database
from services.media import (
    detect_media_type,
    download_telegram_file,
    download_telegram_media_to_path,
    media_kind,
    safe_media_filename,
)
from services.subscriptions import (
    approve_payment_sync,
    decline_payment_sync,
    ensure_subscription_sync,
)
from services.xui_api import (
    bind_client_tg_id_sync,
    change_client_days_sync,
    delete_client_sync,
    fetch_and_sync,
    invalidate_snapshot_cache,
    request_json_sync,
    set_client_status_sync,
)

APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = Path(getattr(config, "__file__", APP_DIR / "config.py")).resolve()
PYTHON = APP_DIR / ".venv" / "bin" / "python"
if not PYTHON.is_file():
    PYTHON = Path(sys.executable)

migrate_database()

app = FastAPI(title=f"{config.SERVICE_NAME} Control Panel", docs_url=None, redoc_url=None)
app.add_middleware(
    SessionMiddleware,
    secret_key=config.WEB_SECRET_KEY,
    https_only=bool(getattr(config, "WEB_COOKIE_HTTPS_ONLY", False)),
    same_site="lax",
    max_age=max(900, int(getattr(config, "WEB_SESSION_MAX_AGE_SECONDS", 28_800))),
)
app.mount("/static", StaticFiles(directory=str(APP_DIR / "static")), name="static")
NET_CACHE = {
    "ts": time.time(),
    "in": psutil.net_io_counters().bytes_recv,
    "out": psutil.net_io_counters().bytes_sent,
}
METRICS_LAST_WRITE = 0.0
CHAT_MEDIA_CACHE_DIR = Path(
    getattr(config, "CHAT_MEDIA_CACHE_DIR", "/var/cache/vpn-service/chat-media")
).expanduser()
CHAT_MEDIA_CACHE_LAST_PRUNE = 0.0
LOGGER = logging.getLogger(__name__)


@app.middleware("http")
async def response_security_headers(request: Request, call_next):
    if request.method.upper() in {"POST", "PUT", "PATCH", "DELETE"}:
        fetch_site = request.headers.get("sec-fetch-site", "").strip().lower()
        origin = request.headers.get("origin", "").strip()
        host = request.headers.get("host", "").strip().lower()
        origin_host = urlsplit(origin).netloc.lower() if origin else ""
        if fetch_site == "cross-site" or (origin_host and host and origin_host != host):
            if request.url.path.startswith(("/api/", "/panel/api/")) or "application/json" in request.headers.get("accept", ""):
                return JSONResponse({"detail": "Межсайтовый запрос отклонён"}, status_code=403)
            return PlainTextResponse("Межсайтовый запрос отклонён", status_code=403)

    response = await call_next(request)
    if request.url.path.startswith("/static/"):
        response.headers["Cache-Control"] = "public, max-age=86400, immutable"
    elif request.url.path.startswith("/api/users/") and request.url.path.endswith("/media"):
        response.headers["Cache-Control"] = "private, max-age=3600"
    else:
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    response.headers["X-VPN-Platform-Version"] = update_manager.current_version()
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
        "script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'self'"
    )
    secure_request = request.url.scheme == "https" or (
        bool(getattr(config, "WEB_TRUST_PROXY_HEADERS", False))
        and request.headers.get("x-forwarded-proto", "").split(",", 1)[0].strip().lower() == "https"
    )
    if secure_request:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response


def _secure_text_compare(left: str, right: str) -> bool:
    """Constant-time text comparison that also supports Unicode strings."""
    try:
        return hmac.compare_digest(str(left).encode("utf-8"), str(right).encode("utf-8"))
    except (TypeError, UnicodeEncodeError):
        return False


def verify_password(password: str) -> bool:
    stored = str(config.WEB_PASSWORD_HASH)
    if stored.startswith("pbkdf2_sha256$"):
        try:
            _, iterations, salt, digest = stored.split("$", 3)
            value = hashlib.pbkdf2_hmac(
                "sha256", password.encode("utf-8"), bytes.fromhex(salt), int(iterations)
            ).hex()
            return _secure_text_compare(value, digest)
        except (ValueError, TypeError):
            return False
    return _secure_text_compare(password, stored)


def request_ip(request: Request) -> str:
    if bool(getattr(config, "WEB_TRUST_PROXY_HEADERS", False)):
        forwarded = request.headers.get("x-forwarded-for", "").split(",", 1)[0].strip()
        if forwarded:
            return forwarded[:128]
    return str(request.client.host if request.client else "unknown")[:128]


def require_auth(request: Request) -> None:
    if not request.session.get("auth"):
        raise HTTPException(401)
    login_at = int(request.session.get("login_at") or 0)
    max_age = max(900, int(getattr(config, "WEB_SESSION_MAX_AGE_SECONDS", 28_800)))
    if login_at > 0 and int(time.time()) - login_at > max_age:
        request.session.clear()
        raise HTTPException(401, "Сессия истекла")


@contextmanager
def database():
    connection = sqlite3.connect(config.DB_PATH, timeout=20)
    try:
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout=20000")
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def audit(actor: str, action: str, details: str = "") -> None:
    try:
        with database() as connection:
            connection.execute(
                "INSERT INTO audit_log(actor,action,details) VALUES(?,?,?)",
                (actor, action, details[:4000]),
            )
    except Exception:
        pass


def set_flash(request: Request, message: str, kind: str = "good") -> None:
    request.session["flash"] = {"message": message[:1000], "kind": kind}


def pop_flash(request: Request) -> str:
    data = request.session.pop("flash", None)
    if not isinstance(data, dict) or not data.get("message"):
        return ""
    kind = str(data.get("kind") or "good")
    cls = "toast bad-toast" if kind == "bad" else "toast"
    return f'<div class="{cls}">{html.escape(str(data["message"]))}</div>'


def shell(args: list[str], timeout: int = 20) -> str:
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout, check=False)
        return ((result.stdout or "") + (result.stderr or ""))[-40000:]
    except Exception as error:
        return str(error)


def service_state(unit: str) -> str:
    return shell(["systemctl", "is-active", unit], timeout=8).strip() or "unknown"


def fmt_bytes(value: float | int) -> str:
    number = float(value or 0)
    for unit in ("Б", "КБ", "МБ", "ГБ", "ТБ", "ПБ"):
        if abs(number) < 1024 or unit == "ПБ":
            return f"{number:.1f} {unit}"
        number /= 1024
    return "0 Б"


def fmt_date(milliseconds: int | None) -> str:
    if not milliseconds:
        return "Бессрочно"
    try:
        return datetime.fromtimestamp(int(milliseconds) / 1000).strftime("%d.%m.%Y %H:%M")
    except Exception:
        return "—"


def fmt_last_online(milliseconds: int | None, online: bool = False) -> str:
    if online:
        return "Сейчас онлайн"
    if not milliseconds:
        return "Нет данных"
    try:
        return datetime.fromtimestamp(int(milliseconds) / 1000).strftime("%d.%m.%Y %H:%M")
    except Exception:
        return "—"


def remaining_days(expiry_ms: int, now_ms: int | None = None) -> float:
    if not expiry_ms:
        return math.inf
    now_ms = now_ms or int(time.time() * 1000)
    delta = (int(expiry_ms) - now_ms) / 86_400_000
    return math.ceil(delta) if delta >= 0 else math.floor(delta)


def remaining_label(expiry_ms: int, now_ms: int | None = None) -> str:
    if not expiry_ms:
        return "∞"
    now_ms = now_ms or int(time.time() * 1000)
    if int(expiry_ms) < now_ms:
        expired_date = datetime.fromtimestamp(int(expiry_ms) / 1000).date()
        days_ago = max(0, (datetime.fromtimestamp(now_ms / 1000).date() - expired_date).days)
        return "Истекла сегодня" if days_ago == 0 else f"Истекла {days_ago} дн. назад"
    days = remaining_days(expiry_ms, now_ms)
    if days == 0:
        return "Сегодня"
    return f"{int(days)} дн."


def status_badge(active: bool, text_on: str = "Активен", text_off: str = "Отключён") -> str:
    css = "good" if active else "bad"
    return f'<span class="badge {css}">{html.escape(text_on if active else text_off)}</span>'


def api_source_badge(stale: bool) -> str:
    return (
        '<span class="badge warn">Локальный кэш</span>'
        if stale
        else '<span class="badge good">3x-ui LIVE</span>'
    )


def telegram_send(tg_id: int, message: str) -> tuple[bool, str]:
    try:
        response = httpx.post(
            f"https://api.telegram.org/bot{config.BOT_TOKEN}/sendMessage",
            data={"chat_id": int(tg_id), "text": message},
            timeout=20,
        )
        data = response.json()
        if response.status_code == 200 and data.get("ok"):
            return True, "Сообщение отправлено"
        return False, str(data.get("description") or f"HTTP {response.status_code}")
    except Exception as error:
        return False, str(error)


def telegram_send_media(
    tg_id: int,
    upload: UploadFile,
    caption: str = "",
) -> tuple[bool, str, dict[str, Any], str, str]:
    """Send one photo/video from the web chat and return journal metadata."""
    filename = safe_media_filename(str(upload.filename or "media"), str(upload.content_type or ""))
    file_object = upload.file
    try:
        original_position = file_object.tell()
    except Exception:
        original_position = 0
    try:
        file_object.seek(0, os.SEEK_END)
        size = int(file_object.tell())
        file_object.seek(0)
        head = file_object.read(128)
        file_object.seek(0)
    except Exception as error:
        return False, f"Не удалось прочитать файл: {error}", {}, "admin_media", caption

    max_bytes = max(1, int(getattr(config, "CHAT_MEDIA_MAX_MB", 100))) * 1024 * 1024
    if size <= 0:
        return False, "Файл пуст", {}, "admin_media", caption
    if size > max_bytes:
        return (
            False,
            f"Файл больше разрешённого лимита {int(getattr(config, 'CHAT_MEDIA_MAX_MB', 100))} МБ",
            {},
            "admin_media",
            caption,
        )
    media_type = detect_media_type(head, filename, str(upload.content_type or ""))
    kind = media_kind(media_type)
    if kind not in {"photo", "video"} or not media_type:
        return False, "Поддерживаются только фотографии и видео", {}, "admin_media", caption

    endpoint = "sendPhoto" if kind == "photo" else "sendVideo"
    field = "photo" if kind == "photo" else "video"
    event_type = "admin_photo" if kind == "photo" else "admin_video"
    label = "Фото" if kind == "photo" else "Видео"
    event_text = caption.strip() or f"[{label}]"
    try:
        response = httpx.post(
            f"https://api.telegram.org/bot{config.BOT_TOKEN}/{endpoint}",
            data={"chat_id": int(tg_id), "caption": caption[:1024]},
            files={field: (filename, file_object, media_type)},
            timeout=httpx.Timeout(300.0, connect=30.0),
        )
        try:
            payload = response.json()
        except ValueError:
            payload = {}
        if response.status_code != 200 or not payload.get("ok"):
            return (
                False,
                str(payload.get("description") or f"Telegram HTTP {response.status_code}"),
                {},
                event_type,
                event_text,
            )
        result = payload.get("result") if isinstance(payload.get("result"), dict) else {}
        telegram_file: dict[str, Any] = {}
        photos = result.get("photo") if isinstance(result.get("photo"), list) else []
        if photos and isinstance(photos[-1], dict):
            telegram_file = photos[-1]
        else:
            candidate = result.get("video") or result.get("animation") or result.get("document")
            if isinstance(candidate, dict):
                telegram_file = candidate
        file_id = str(telegram_file.get("file_id") or "")
        if not file_id:
            return False, "Telegram не вернул file_id отправленного файла", {}, event_type, event_text
        media = {
            "kind": kind,
            "file_id": file_id,
            "file_unique_id": str(telegram_file.get("file_unique_id") or ""),
            "mime_type": str(telegram_file.get("mime_type") or media_type),
            "file_name": str(telegram_file.get("file_name") or filename),
            "file_size": int(telegram_file.get("file_size") or size),
            "width": int(telegram_file.get("width") or 0),
            "height": int(telegram_file.get("height") or 0),
            "duration": int(telegram_file.get("duration") or 0),
        }
        media = {key: value for key, value in media.items() if value not in ("", 0, None)}
        return True, "Файл отправлен", {"media": media, "source": "web_panel"}, event_type, event_text
    except Exception as error:
        return False, str(error), {}, event_type, event_text
    finally:
        try:
            file_object.seek(original_position)
        except Exception:
            pass


def telegram_receipt_file(payment_id: int) -> tuple[bytes, str, str]:
    with database() as connection:
        row = connection.execute(
            "SELECT telegram_file_id FROM payments WHERE id=?", (int(payment_id),)
        ).fetchone()
    if not row or not row[0]:
        raise HTTPException(404, "Чек не найден")
    try:
        content, media_type, filename = download_telegram_file(
            config.BOT_TOKEN, str(row[0]), timeout=30.0
        )
    except Exception as error:
        raise HTTPException(502, str(error)) from error
    extension = Path(filename).suffix or ".jpg"
    return content, media_type, f"receipt_{int(payment_id)}{extension}"


def _local_users() -> list[dict[str, Any]]:
    with database() as connection:
        rows = connection.execute("SELECT * FROM users").fetchall()
    return [dict(row) for row in rows]


def live_users(force: bool = False) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Merge live 3x-ui values with local Telegram metadata."""
    snapshot = fetch_and_sync(force=force, db_path=config.DB_PATH)
    local = _local_users()
    by_email = {str(row.get("email") or "").strip().lower(): row for row in local if row.get("email")}
    by_uuid = {str(row.get("uuid") or "").strip().lower(): row for row in local if row.get("uuid")}
    now_ms = int(time.time() * 1000)

    source_clients: list[dict[str, Any]]
    if not snapshot.get("stale"):
        source_clients = [dict(item) for item in snapshot.get("clients", [])]
    else:
        source_clients = [
            {
                "email": row.get("email") or "",
                "uuid": row.get("uuid") or "",
                "sub_id": row.get("sub_id") or "",
                "expiry_time": int(row.get("expiry_time") or 0),
                "enable": bool(row.get("enable")),
                "up": int(row.get("up") or 0),
                "down": int(row.get("down") or 0),
                "total": int(row.get("total") or 0),
                "last_online_ts": int(row.get("last_online_ts") or 0),
                "online": False,
                "tg_id": int(row.get("tg_id") or 0),
            }
            for row in local
        ]

    merged: list[dict[str, Any]] = []
    for client in source_clients:
        email_key = str(client.get("email") or "").strip().lower()
        uuid_key = str(client.get("uuid") or "").strip().lower()
        row = by_email.get(email_key) or (by_uuid.get(uuid_key) if uuid_key else None) or {}
        expiry = int(client.get("expiry_time") or 0)
        up = int(client.get("up") or 0)
        down = int(client.get("down") or 0)
        total = int(client.get("total") or 0)
        used = up + down
        quota_remaining = max(0, total - used) if total > 0 else None
        tg_id = int(row.get("tg_id") or client.get("tg_id") or 0)
        item = {
            **client,
            "tg_id": tg_id,
            "username": str(row.get("username") or "") or email_key.rsplit("_", 1)[0] or "Без имени",
            "expiry_time": expiry,
            "up": up,
            "down": down,
            "traffic_used": used,
            "total": total,
            "quota_remaining": quota_remaining,
            "last_online_ts": int(client.get("last_online_ts") or row.get("last_online_ts") or 0),
            "online": bool(client.get("online")),
            "enable": bool(client.get("enable")),
            "active": bool(client.get("enable")) and (expiry <= 0 or expiry > now_ms),
            "remaining_days": remaining_days(expiry, now_ms),
            "source_stale": bool(snapshot.get("stale")),
        }
        merged.append(item)
    return merged, snapshot


def get_user(tg_id: int) -> dict[str, Any] | None:
    with database() as connection:
        row = connection.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()
    return dict(row) if row else None


def event_for_web(event: dict[str, Any], tg_id: int) -> dict[str, Any]:
    """Remove Telegram secrets and prepare one safe browser event."""
    result = dict(event)
    legacy_text = str(result.get("text") or "").strip()
    legacy_match = re.fullmatch(
        r"Отправлено:\s*(?:ContentType\.)?([A-Za-z_]+)",
        legacy_text,
        flags=re.IGNORECASE,
    )
    if legacy_match:
        legacy_kind = legacy_match.group(1).lower()
        legacy_label = {
            "photo": "Фото",
            "video": "Видео",
            "animation": "Анимация",
            "video_note": "Видеосообщение",
            "document": "Документ",
            "voice": "Голосовое сообщение",
            "audio": "Аудио",
            "sticker": "Стикер",
        }.get(legacy_kind, legacy_kind.replace("_", " ").capitalize())
        result["text"] = (
            f"[{legacy_label}] Файл был получен старой версией и не содержит Telegram file_id; "
            "показать его повторно невозможно."
        )
        result["legacy_media_missing"] = True
    metadata = dict(result.get("metadata") or {})
    media = metadata.get("media")
    if isinstance(media, dict) and media.get("file_id") and media.get("kind") in {"photo", "video"}:
        public_media = {
            key: media.get(key)
            for key in ("kind", "mime_type", "file_name", "file_size", "width", "height", "duration")
            if media.get(key) not in (None, "", 0)
        }
        public_media["url"] = f"/api/users/{int(tg_id)}/events/{int(result.get('id') or 0)}/media"
        metadata["media"] = public_media
    else:
        metadata.pop("media", None)
    metadata.pop("telegram_file_id", None)
    result["metadata"] = metadata
    return result


def _event_media_html(event: dict[str, Any]) -> str:
    metadata = event.get("metadata") if isinstance(event.get("metadata"), dict) else {}
    media = metadata.get("media") if isinstance(metadata, dict) else None
    if not isinstance(media, dict):
        return ""
    url = html.escape(str(media.get("url") or ""), quote=True)
    if not url:
        return ""
    kind = str(media.get("kind") or "")
    filename = html.escape(str(media.get("file_name") or ("Фотография" if kind == "photo" else "Видео")))
    if kind == "photo":
        return (
            f'<a class="chat-media-link" href="{url}" target="_blank" rel="noopener">'
            f'<img class="chat-media-image" src="{url}" alt="{filename}" loading="lazy"></a>'
        )
    if kind == "video":
        return (
            f'<video class="chat-media-video" controls preload="metadata" playsinline src="{url}">'
            'Ваш браузер не поддерживает воспроизведение видео.</video>'
        )
    return ""


def render_user_events(events: list[dict[str, Any]], tg_id: int) -> str:
    result: list[str] = []
    for raw_event in events:
        event = event_for_web(raw_event, tg_id)
        direction = str(event.get("direction") or "system")
        if direction not in {"in", "out", "system"}:
            direction = "system"
        text = str(event.get("text") or event.get("event_type") or "Событие")
        actor = str(event.get("actor") or event.get("username") or "system")
        text_html = html.escape(text).replace("\n", "<br>")
        failed = " failed" if not bool(event.get("success", True)) else ""
        result.append(
            f'<div class="chat-message {direction}{failed}" data-event-id="{int(event.get("id") or 0)}">'
            f'{_event_media_html(event)}<div class="chat-message-text">{text_html}</div>'
            f'<small>{html.escape(str(event.get("created_at") or ""))} · {html.escape(actor)}</small></div>'
        )
    return "".join(result)


def _chat_media_cache_path(tg_id: int, event_id: int, file_id: str) -> Path:
    digest = hashlib.sha256(str(file_id).encode("utf-8")).hexdigest()[:20]
    return CHAT_MEDIA_CACHE_DIR / str(int(tg_id)) / f"{int(event_id)}-{digest}.media"


def _prune_chat_media_cache(protected: Path | None = None) -> None:
    global CHAT_MEDIA_CACHE_LAST_PRUNE
    now = time.time()
    if now - CHAT_MEDIA_CACHE_LAST_PRUNE < 3600:
        return
    CHAT_MEDIA_CACHE_LAST_PRUNE = now
    try:
        CHAT_MEDIA_CACHE_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
        max_age = max(1, int(getattr(config, "CHAT_MEDIA_CACHE_DAYS", 30))) * 86400
        max_bytes = max(16, int(getattr(config, "CHAT_MEDIA_CACHE_MAX_MB", 512))) * 1024 * 1024
        files: list[tuple[float, int, Path]] = []
        total = 0
        for path in CHAT_MEDIA_CACHE_DIR.rglob("*.media"):
            try:
                if not path.is_file() or path.is_symlink():
                    continue
                stat = path.stat()
                if now - stat.st_mtime > max_age and path != protected:
                    path.unlink(missing_ok=True)
                    continue
                files.append((stat.st_mtime, stat.st_size, path))
                total += stat.st_size
            except OSError:
                continue
        if total > max_bytes:
            for _mtime, size, path in sorted(files):
                if path == protected:
                    continue
                path.unlink(missing_ok=True)
                total -= size
                if total <= max_bytes:
                    break
    except OSError:
        pass


def cached_event_media(tg_id: int, event_id: int) -> tuple[Path, str, str]:
    event = user_events.get_event(tg_id, event_id, db_path=config.DB_PATH)
    if not event:
        raise HTTPException(404, "Событие не найдено")
    metadata = event.get("metadata") if isinstance(event.get("metadata"), dict) else {}
    media = metadata.get("media") if isinstance(metadata, dict) else None
    if not isinstance(media, dict) or media.get("kind") not in {"photo", "video"}:
        raise HTTPException(404, "В событии нет поддерживаемого медиа")
    file_id = str(media.get("file_id") or "")
    if not file_id:
        raise HTTPException(404, "Telegram file_id отсутствует")
    cache_path = _chat_media_cache_path(tg_id, event_id, file_id)
    cache_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    media_type = str(media.get("mime_type") or "")
    filename = safe_media_filename(str(media.get("file_name") or "media"), media_type)
    if not cache_path.is_file() or cache_path.stat().st_size <= 0:
        try:
            cache_path, media_type, downloaded_name = download_telegram_media_to_path(
                config.BOT_TOKEN,
                file_id,
                cache_path,
                timeout=300.0,
                max_bytes=max(1, int(getattr(config, "CHAT_MEDIA_MAX_MB", 100))) * 1024 * 1024,
                allowed_kinds=(str(media.get("kind")),),
            )
            filename = safe_media_filename(downloaded_name or filename, media_type)
        except Exception as error:
            raise HTTPException(502, f"Не удалось получить медиа из Telegram: {error}") from error
    elif not media_type:
        with cache_path.open("rb") as handle:
            media_type = detect_media_type(handle.read(128), filename, "") or "application/octet-stream"
    _prune_chat_media_cache(cache_path)
    return cache_path, media_type or "application/octet-stream", filename


def navigation(active: str) -> str:
    items = [
        ("dashboard", "/", "⌂", "Обзор"),
        ("users", "/users", "♙", "Пользователи"),
        ("broadcast", "/broadcast", "✉", "Рассылка"),
        ("payments", "/payments", "₽", "Платежи"),
        ("monitoring", "/monitoring", "⌁", "Мониторинг"),
        ("backups", "/backups", "↻", "Бэкапы"),
        ("yandex", "/settings/yandex", "☁", "Яндекс.Диск"),
        ("updates", "/updates", "⬆", "Обновления"),
        ("logs", "/logs", "≡", "Журналы"),
        ("settings", "/settings", "⚙", "Настройки"),
        ("diagnostics", "/diagnostics", "✓", "Диагностика"),
    ]
    try:
        unread_total = int(
            user_events.unread_messages_summary(limit=1, db_path=config.DB_PATH).get("total") or 0
        )
    except Exception:
        unread_total = 0
    try:
        payment_total = int(
            panel_notifications.payment_notifications_summary(db_path=config.DB_PATH).get("total") or 0
        )
    except Exception:
        payment_total = 0
    links: list[str] = []
    for key, url, icon, label in items:
        notification = ""
        if key == "users":
            unread_text = "99+" if unread_total > 99 else str(unread_total)
            notification = (
                f'<span id="unread-nav-badge" class="nav-unread-badge" '
                f'aria-label="Непрочитанных сообщений: {unread_total}" '
                f'{"" if unread_total else "hidden"}>{unread_text}</span>'
            )
        elif key == "payments":
            payment_text = "99+" if payment_total > 99 else str(payment_total)
            notification = (
                f'<span id="payments-nav-badge" class="nav-unread-badge payment-notification-badge" '
                f'aria-label="Новых оплат: {payment_total}" '
                f'{"" if payment_total else "hidden"}>{payment_text}</span>'
            )
        links.append(
            f'<a class="{"active" if key == active else ""}" href="{url}">'
            f'<i>{icon}</i><span class="nav-label">{label}</span>{notification}</a>'
        )
    return (
        '<aside><div class="brand"><div class="logo">V</div><div>'
        f'<strong>{html.escape(str(config.SERVICE_NAME))}</strong><small>Control Panel</small></div></div>'
        f'<nav>{"".join(links)}</nav><div class="aside-foot"><a href="/logout">⇥ Выйти</a></div></aside>'
    )

def update_banner() -> str:
    try:
        info = update_manager.cached_update_info()
        if info.get("available"):
            version = html.escape(str(info.get("version") or ""))
            return (
                '<div class="update-banner" id="global-update-banner"><strong>Доступно обновление '
                f'{version}</strong><span>Новая версия готова к установке.</span>'
                '<a class="button small" href="/updates">Обновить</a></div>'
            )
    except Exception:
        pass
    return ""


def page(request: Request, title: str, body: str, active: str = "", scripts: str = "") -> str:
    banner = update_banner() if active else ""
    banner_slot = banner if banner else ('<div id="global-update-slot"></div>' if active else "")
    flash = pop_flash(request) if active else ""
    navigation_html = navigation(active) if active else ""
    body_class = "panel-page" if active else "login-page"
    return f'''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)} · {html.escape(str(config.SERVICE_NAME))}</title>
<link rel="stylesheet" href="/static/panel.css?v={html.escape(update_manager.current_version())}">
</head><body class="{body_class}">{navigation_html}<main>{banner_slot}{flash}{body}</main>
<script src="/static/panel.js?v={html.escape(update_manager.current_version())}" defer></script>{scripts}</body></html>'''


@app.exception_handler(401)
async def unauthorized(request: Request, error: Exception):
    if request.url.path.startswith(("/api/", "/panel/api/")):
        detail = getattr(error, "detail", "Требуется авторизация")
        return JSONResponse({"detail": str(detail)}, status_code=401)
    return RedirectResponse("/login", 303)


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    body = f'''<div class="login-wrap"><div class="card login-card"><div class="logo">V</div><h1 style="text-align:center">{html.escape(str(config.SERVICE_NAME))}</h1><p class="subtitle" style="text-align:center">Веб-панель управления VPN-сервисом</p><form method="post"><input name="username" placeholder="Логин" required autofocus><input name="password" type="password" placeholder="Пароль" required><button style="width:100%;margin-top:10px">Войти</button></form></div></div>'''
    return page(request, "Вход", body)


@app.post("/login")
def login_post(request: Request, username: str = Form(), password: str = Form()):
    ip_address = request_ip(request)
    clean_username = str(username or "").strip()[:200]
    username_state = auth_security.check_login(ip_address, clean_username, db_path=config.DB_PATH)
    ip_state = auth_security.check_login(ip_address, auth_security.GLOBAL_USERNAME_KEY, db_path=config.DB_PATH)
    blocked_states = [item for item in (username_state, ip_state) if not item.allowed]
    if blocked_states:
        state = max(blocked_states, key=lambda item: item.retry_after)
        audit("security", "login_blocked", f"ip={ip_address}; retry={state.retry_after}")
        body = (
            '<div class="login-wrap"><div class="card login-card">'
            '<h2>Вход временно ограничен</h2><p>Слишком много неудачных попыток. '
            f'Повторите через {max(1, state.retry_after)} сек.</p>'
            '<a class="button secondary" href="/login">Вернуться</a></div></div>'
        )
        return HTMLResponse(
            page(request, "Вход", body),
            429,
            headers={"Retry-After": str(max(1, state.retry_after))},
        )

    valid_username = _secure_text_compare(clean_username, str(config.WEB_USERNAME))
    # Always perform the password hash, even for a wrong username, so response
    # timing does not reveal the configured panel login.
    valid_password = verify_password(password)
    if valid_username and valid_password:
        auth_security.record_success(ip_address, clean_username, db_path=config.DB_PATH)
        auth_security.record_success(ip_address, auth_security.GLOBAL_USERNAME_KEY, db_path=config.DB_PATH)
        auth_security.prune(db_path=config.DB_PATH)
        if not str(config.WEB_PASSWORD_HASH).startswith("pbkdf2_sha256$"):
            save_config_values({"WEB_PASSWORD_HASH": _password_hash(password)})
        request.session.clear()
        request.session["auth"] = True
        request.session["user"] = clean_username
        request.session["login_at"] = int(time.time())
        audit(clean_username, "login_success", f"ip={ip_address}")
        return RedirectResponse("/", 303)

    failed_username = auth_security.record_failure(ip_address, clean_username, db_path=config.DB_PATH)
    failed_ip = auth_security.record_failure(ip_address, auth_security.GLOBAL_USERNAME_KEY, db_path=config.DB_PATH)
    failed_states = [item for item in (failed_username, failed_ip) if not item.allowed]
    failed = max(failed_states, key=lambda item: item.retry_after) if failed_states else failed_ip
    audit("security", "login_failure", f"ip={ip_address}; blocked={not failed.allowed}")
    retry = max(1, failed.retry_after)
    detail = (
        f"Слишком много неудачных попыток. Повторите через {retry} сек."
        if not failed.allowed
        else "Неверный логин или пароль."
    )
    body = (
        '<div class="login-wrap"><div class="card login-card"><h2>Войти не удалось</h2>'
        f'<p>{html.escape(detail)}</p><a class="button secondary" href="/login">Повторить</a></div></div>'
    )
    status_code = 429 if not failed.allowed else 403
    headers = {"Retry-After": str(retry)} if status_code == 429 else None
    return HTMLResponse(page(request, "Вход", body), status_code, headers=headers)


@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", 303)


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    require_auth(request)
    users, snapshot = live_users()
    now_ms = int(time.time() * 1000)
    total = len(users)
    active = sum(1 for item in users if item["active"])
    expiring = sum(
        1
        for item in users
        if item["active"] and item["expiry_time"] > 0 and now_ms < item["expiry_time"] <= now_ms + 7 * 86_400_000
    )
    online = sum(1 for item in users if item.get("online"))
    client_traffic_up = sum(int(item.get("up") or 0) for item in users)
    client_traffic_down = sum(int(item.get("down") or 0) for item in users)
    server_traffic = snapshot.get("server_traffic_summary") if isinstance(snapshot.get("server_traffic_summary"), dict) else {}
    inbound_traffic = snapshot.get("traffic_summary") if isinstance(snapshot.get("traffic_summary"), dict) else {}
    traffic_summary = server_traffic or inbound_traffic
    traffic_up = int(traffic_summary.get("up") if "up" in traffic_summary else client_traffic_up)
    traffic_down = int(traffic_summary.get("down") if "down" in traffic_summary else client_traffic_down)
    if traffic_summary.get("source") == "server-status":
        traffic_source = "тот же счётчик, что на главной 3x-ui"
    elif traffic_summary.get("source") == "inbounds":
        traffic_source = "сумма inbound 3x-ui (резервный источник)"
    else:
        traffic_source = "дедуплицированная сумма клиентов"
    with database() as connection:
        pending = connection.execute("SELECT count(*) FROM payments WHERE status='pending'").fetchone()[0]
    cpu = psutil.cpu_percent()
    ram = psutil.virtual_memory().percent
    disk = psutil.disk_usage("/").percent
    bot_status = service_state("vpn-service-bot") == "active"
    recent = sorted(users, key=lambda item: int(item.get("last_online_ts") or 0), reverse=True)[:8]
    recent_rows = "".join(
        f'<tr><td>{html.escape(item["username"])}</td><td>{html.escape(str(item.get("email") or "—"))}</td><td>{remaining_label(item["expiry_time"], now_ms)}</td><td>{fmt_last_online(item.get("last_online_ts"), item.get("online", False))}</td><td>{fmt_bytes(item["traffic_used"])}</td><td>{status_badge(item["active"])}</td></tr>'
        for item in recent
    )
    source_notice = ""
    if snapshot.get("stale"):
        source_notice = f'<div class="notice"><strong>3x-ui API недоступна.</strong> Показан локальный кэш. Причина: {html.escape(str(snapshot.get("error") or "неизвестно"))}</div>'
    body = f'''<header><div><h1>Панель управления</h1><div class="subtitle">Состояние {html.escape(str(config.SERVICE_NAME))} · {api_source_badge(bool(snapshot.get("stale")))}</div></div><div class="actions"><form method="post" action="/sync"><button class="secondary">↻ Обновить из 3x-ui</button></form><form method="post" action="/service/bot/restart"><button>Перезапустить бот</button></form></div></header>{source_notice}
<div class="grid">
<div class="card metric"><div class="label">Пользователи 3x-ui</div><div class="value">{total}</div><div class="hint">Активных: {active}</div></div>
<div class="card metric"><div class="label">Сейчас онлайн</div><div class="value">{online}</div><div class="hint">По API onlines</div></div>
<div class="card metric"><div class="label">Истекают за 7 дней</div><div class="value">{expiring}</div><div class="hint">Требуют внимания</div></div>
<div class="card metric"><div class="label">Ожидают оплаты</div><div class="value">{pending}</div><div class="hint"><a href="/payments">Открыть очередь</a></div></div>
<div class="card metric"><div class="label">Telegram-бот</div><div class="value" style="font-size:22px">{status_badge(bot_status, "Работает", "Остановлен")}</div><div class="hint">systemd: vpn-service-bot</div></div>
<div class="card metric"><div class="label">CPU</div><div class="value">{cpu:.0f}%</div><div class="progress"><span style="width:{cpu}%"></span></div></div>
<div class="card metric"><div class="label">Оперативная память</div><div class="value">{ram:.0f}%</div><div class="progress"><span style="width:{ram}%"></span></div></div>
<div class="card metric"><div class="label">Общий трафик как в 3x-ui</div><div class="value" style="font-size:21px">{fmt_bytes(traffic_up + traffic_down)}</div><div class="hint">↑ {fmt_bytes(traffic_up)} · ↓ {fmt_bytes(traffic_down)} · {traffic_source}</div></div>
<div class="card wide chart-card"><div class="section-title"><h2>Нагрузка сервера</h2><span class="badge good">LIVE</span></div><div id="server-chart" class="chart"></div></div>
<div class="card side"><div class="section-title"><h2>Сеть сейчас</h2></div><div style="font-size:28px;font-weight:750;margin:24px 0">↓ <span id="net-down">0</span></div><div style="font-size:28px;font-weight:750">↑ <span id="net-up">0</span></div><p class="subtitle">Текущая скорость сервера</p></div>
<div class="card full"><div class="section-title"><h2>Последняя активность</h2><a href="/users?sort=last_online&order=desc">Все пользователи →</a></div><div class="table-wrap"><table><thead><tr><th>Пользователь</th><th>3x-ui email</th><th>Осталось</th><th>Последний онлайн</th><th>Трафик</th><th>Статус</th></tr></thead><tbody>{recent_rows or '<tr><td colspan="6">Пользователей нет.</td></tr>'}</tbody></table></div></div>
</div>'''
    script = '''<script>
const vals=[];function draw(){const el=document.getElementById('server-chart');if(!vals.length)return;const w=800,h=210,max=100;let pts=vals.map((v,i)=>`${i*(w/(Math.max(vals.length-1,1)))},${h-v/max*h}`).join(' ');el.innerHTML=`<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><defs><linearGradient id="grad" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4d8dff"/><stop offset="1" stop-color="#4d8dff" stop-opacity="0"/></linearGradient></defs><polygon class="area" points="0,${h} ${pts} ${w},${h}"/><polyline points="${pts}"/></svg>`}async function tick(){try{const r=await fetch('/api/metrics');const d=await r.json();vals.push(d.cpu);if(vals.length>40)vals.shift();draw();document.getElementById('net-down').textContent=d.net_down;document.getElementById('net-up').textContent=d.net_up}catch(e){}}tick();setInterval(tick,3000);</script>'''
    return page(request, "Обзор", body, "dashboard", script)


@app.get("/api/panel/update-status")
def panel_update_status(request: Request):
    require_auth(request)
    info = update_manager.check_available_update()
    return {
        "available": bool(info.get("available")),
        "version": str(info.get("version") or ""),
        "installed_version": str(info.get("installed_version") or update_manager.current_version()),
        "error": str(info.get("error") or ""),
    }


@app.get("/api/metrics")
def metrics_api(request: Request):
    require_auth(request)
    global NET_CACHE
    counters = psutil.net_io_counters()
    now = time.time()
    elapsed = max(now - NET_CACHE["ts"], 0.1)
    down = max(0, (counters.bytes_recv - NET_CACHE["in"]) / elapsed)
    up = max(0, (counters.bytes_sent - NET_CACHE["out"]) / elapsed)
    NET_CACHE = {"ts": now, "in": counters.bytes_recv, "out": counters.bytes_sent}
    cpu = psutil.cpu_percent()
    ram = psutil.virtual_memory().percent
    disk = psutil.disk_usage("/").percent
    global METRICS_LAST_WRITE
    store_interval = max(10, int(getattr(config, "METRICS_STORE_INTERVAL_SECONDS", 60)))
    if now - METRICS_LAST_WRITE >= store_interval:
        try:
            with database() as connection:
                connection.execute(
                    "INSERT INTO metrics(cpu,ram,disk,net_in,net_out) VALUES(?,?,?,?,?)",
                    (cpu, ram, disk, int(down), int(up)),
                )
                connection.execute(
                    "DELETE FROM metrics WHERE id NOT IN (SELECT id FROM metrics ORDER BY id DESC LIMIT 5000)"
                )
            METRICS_LAST_WRITE = now
        except Exception:
            pass
    return {
        "cpu": cpu,
        "ram": ram,
        "disk": disk,
        "net_down": f"{fmt_bytes(down)}/с",
        "net_up": f"{fmt_bytes(up)}/с",
    }


def _telegram_bot_username() -> str:
    token = str(getattr(config, "BOT_TOKEN", "") or "").strip()
    if not token:
        return ""
    try:
        response = httpx.get(f"https://api.telegram.org/bot{token}/getMe", timeout=6.0)
        payload = response.json()
        username = str((payload.get("result") or {}).get("username") or "").strip().lstrip("@")
        return username
    except Exception:
        return ""


def create_telegram_link_request(local_tg_id: int) -> dict[str, Any]:
    local_tg_id = int(local_tg_id)
    if local_tg_id >= 0:
        raise ValueError("Ссылка привязки доступна только для локального пользователя без Telegram")
    token = secrets.token_urlsafe(18).replace("-", "").replace("_", "")[:32]
    now = datetime.now(timezone.utc)
    expires = now + timedelta(minutes=30)
    with database() as connection:
        connection.execute(
            "DELETE FROM telegram_link_requests WHERE expires_at < ?",
            (now.isoformat(timespec="seconds"),),
        )
        connection.execute(
            "INSERT INTO telegram_link_requests(token,local_tg_id,created_at,expires_at) VALUES(?,?,?,?)",
            (token, local_tg_id, now.isoformat(timespec="seconds"), expires.isoformat(timespec="seconds")),
        )
    bot_username = _telegram_bot_username()
    if not bot_username:
        raise RuntimeError("Не удалось определить username Telegram-бота")
    return {"token": token, "expires_at": expires.isoformat(timespec="seconds"), "deep_link": f"https://t.me/{bot_username}?start=bind_{token}"}


def telegram_link_request_status(token: str) -> dict[str, Any]:
    with database() as connection:
        row = connection.execute(
            "SELECT token,local_tg_id,expires_at,consumed_at,resolved_tg_id FROM telegram_link_requests WHERE token=?",
            (str(token),),
        ).fetchone()
    if not row:
        return {"status": "missing"}
    if row[3] and int(row[4] or 0) > 0:
        return {"status": "resolved", "tg_id": int(row[4]), "local_tg_id": int(row[1])}
    if str(row[2]) < datetime.now(timezone.utc).isoformat(timespec="seconds"):
        return {"status": "expired", "local_tg_id": int(row[1])}
    return {"status": "pending", "local_tg_id": int(row[1]), "expires_at": str(row[2])}


def telegram_username_lookup(username: str) -> list[dict[str, Any]]:
    """Find a known Telegram identity by username across all local identity logs.

    Telegram's Bot API cannot resolve an arbitrary private user from @username alone,
    so this function deliberately searches only identities that this installation has
    already received from Telegram or stored in its own database.
    """
    clean = str(username or "").strip().lstrip("@").casefold()
    if not clean:
        return []

    with database() as connection:
        found: dict[int, dict[str, Any]] = {}

        def add_match(tg_id: Any, value_username: Any = "", email: Any = "", enable: Any = 1, source: str = "local") -> None:
            try:
                normalized_id = int(tg_id or 0)
            except (TypeError, ValueError):
                normalized_id = 0
            if normalized_id <= 0:
                return
            candidate = {
                "tg_id": normalized_id,
                "username": str(value_username or clean).strip().lstrip("@"),
                "email": str(email or ""),
                "enable": int(enable or 0),
                "source": source,
            }
            previous = found.get(normalized_id)
            if previous is None or (not previous.get("username") and candidate["username"]):
                found[normalized_id] = candidate

        tables = [
            str(row[0]) for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        ]

        for table in tables:
            try:
                quoted = '"' + table.replace('"', '""') + '"'
                columns = {
                    str(r[1]) for r in connection.execute(f"PRAGMA table_info({quoted})").fetchall()
                }
            except Exception:
                continue
            if "username" not in columns or "tg_id" not in columns:
                continue

            select_columns = ["tg_id", "username"]
            if "email" in columns:
                select_columns.append("email")
            if "enable" in columns:
                select_columns.append("enable")
            select_sql = ", ".join(select_columns)
            try:
                rows = connection.execute(
                    f"SELECT {select_sql} FROM {quoted} "
                    "WHERE tg_id>0 AND LOWER(REPLACE(COALESCE(username,''),'@',''))=? "
                    "ORDER BY tg_id DESC",
                    (clean,),
                ).fetchall()
            except Exception:
                continue
            for row in rows:
                add_match(
                    row["tg_id"],
                    row["username"],
                    row["email"] if "email" in columns else "",
                    row["enable"] if "enable" in columns else 1,
                    source=table,
                )

        # Some older event records stored the username only in actor=telegram:@name.
        for table in tables:
            try:
                quoted = '"' + table.replace('"', '""') + '"'
                columns = {str(r[1]) for r in connection.execute(f"PRAGMA table_info({quoted})").fetchall()}
            except Exception:
                continue
            if "tg_id" not in columns or "actor" not in columns:
                continue
            try:
                rows = connection.execute(
                    f"SELECT tg_id, actor FROM {quoted} WHERE tg_id>0 "
                    "AND LOWER(actor)=? ORDER BY tg_id DESC",
                    (f"telegram:@{clean}",),
                ).fetchall()
            except Exception:
                continue
            for row in rows:
                add_match(row["tg_id"], clean, source=table + ":actor")

        try:
            snapshot = fetch_snapshot_sync(False)
            for client in (snapshot.get("clients") or snapshot.get("all_clients") or []):
                try:
                    candidate_id = int(client.get("tg_id") or client.get("tgId") or 0)
                except Exception:
                    candidate_id = 0
                email_value = str(client.get("email") or "").strip().lstrip("@").casefold()
                if candidate_id > 0 and (email_value == clean or email_value.startswith(clean + "_")):
                    add_match(candidate_id, clean, enable=client.get("enable", 1), source="3x-ui")
        except Exception:
            pass
        return sorted(found.values(), key=lambda item: int(item["tg_id"]))


def update_topology_public(report: dict[str, Any], publisher: bool) -> dict[str, Any]:
    if publisher:
        return report
    redacted = dict(report)
    for key in ("master_url", "resolved_master_url", "metadata_url", "publisher_username", "configured_master_url"):
        redacted[key] = ""
    redacted["candidate_endpoints"] = []
    return redacted


@app.get("/api/telegram/lookup")
def telegram_lookup_api(request: Request, username: str = ""):
    require_auth(request)
    clean = str(username or "").strip().lstrip("@")[:100]
    if not clean:
        raise HTTPException(400, "Укажите Telegram @username")
    matches = telegram_username_lookup(clean)
    return {
        "username": clean,
        "matches": [{"tg_id": int(row.get("tg_id") or 0), "username": str(row.get("username") or ""), "email": str(row.get("email") or ""), "telegram_connected": int(row.get("tg_id") or 0) > 0, "enabled": bool(row.get("enable"))} for row in matches],
        "note": "Найденные ID берутся из локальной истории Telegram-взаимодействий. Telegram Bot API не позволяет надёжно получить ID произвольного личного пользователя только по @username.",
    }


@app.post("/api/telegram/link-request")
def telegram_link_request_api(request: Request, tg_id: int = Form(...)):
    require_auth(request)
    row = get_user(int(tg_id))
    if not row:
        raise HTTPException(404, "Пользователь не найден")
    try:
        return create_telegram_link_request(int(tg_id))
    except ValueError as error:
        raise HTTPException(400, str(error)) from error
    except RuntimeError as error:
        raise HTTPException(502, str(error)) from error


@app.get("/api/telegram/link-request/{token}")
def telegram_link_request_status_api(request: Request, token: str):
    require_auth(request)
    return telegram_link_request_status(token)


@app.get("/users", response_class=HTMLResponse)
def users_page(
    request: Request,
    q: str = "",
    status: str = "all",
    sort: str = "remaining",
    order: str = "asc",
):
    require_auth(request)
    users, snapshot = live_users()
    unread_snapshot = user_events.unread_messages_summary(db_path=config.DB_PATH)
    unread_map = {int(item["tg_id"]): item for item in unread_snapshot.get("items", [])}
    q_clean = q.strip().lower()
    if q_clean:
        users = [
            item
            for item in users
            if q_clean in str(item.get("username") or "").lower()
            or q_clean in str(item.get("email") or "").lower()
            or q_clean in str(item.get("tg_id") or "")
        ]
    if status == "active":
        users = [item for item in users if item["active"]]
    elif status == "expired":
        users = [item for item in users if item["expiry_time"] > 0 and item["remaining_days"] < 0]
    elif status == "blocked":
        users = [item for item in users if not item["enable"]]
    elif status == "online":
        users = [item for item in users if item["online"]]
    elif status == "unread":
        users = [item for item in users if int(item.get("tg_id") or 0) in unread_map]

    sorters = {
        "remaining": lambda item: item["remaining_days"],
        "last_online": lambda item: int(item.get("last_online_ts") or 0),
        "traffic": lambda item: int(item.get("traffic_used") or 0),
        "quota": lambda item: math.inf if item.get("quota_remaining") is None else int(item["quota_remaining"]),
        "name": lambda item: str(item.get("username") or "").lower(),
    }
    sort = sort if sort in sorters else "remaining"
    order = order if order in ("asc", "desc") else "asc"
    users.sort(key=sorters[sort], reverse=order == "desc")
    # Unread conversations always stay at the top; the selected sort order is
    # preserved inside unread and ordinary groups.
    users.sort(
        key=lambda item: int(unread_map.get(int(item.get("tg_id") or 0), {}).get("count") or 0) > 0,
        reverse=True,
    )

    now_ms = int(time.time() * 1000)
    cards: list[str] = []
    for item in users[:2000]:
        tg_id = int(item.get("tg_id") or 0)
        unread = unread_map.get(tg_id, {})
        unread_count = max(0, int(unread.get("count") or 0))
        unread_text = "99+" if unread_count > 99 else str(unread_count)
        unread_hidden = "" if unread_count else "hidden"
        unread_title = f"Непрочитанных сообщений: {unread_count}"
        unread_preview = " ".join(str(unread.get("preview") or "").split())[:180]
        preview_hidden = "" if unread_count and unread_preview else "hidden"
        quota = "∞" if item["quota_remaining"] is None else fmt_bytes(item["quota_remaining"])
        display_name = str(item.get("username") or item.get("email") or "Без Telegram-привязки")
        base_button_label = "Открыть чат" if tg_id > 0 else "Открыть карточку"
        button_label = (
            f"{base_button_label} · {unread_text}" if unread_count else base_button_label
        )
        message_button = (
            f'<a class="button small secondary" href="/users/id/{tg_id}" '
            f'data-chat-button data-base-label="{base_button_label}">{button_label}</a>'
        )
        cards.append(
            f'''<div class="card user-card {'has-unread' if unread_count else ''}" data-user-tg-id="{tg_id}"><div class="section-title"><div><div class="user-name-line"><h3>{html.escape(display_name)}</h3><span class="unread-indicator" data-unread-indicator aria-label="{html.escape(unread_title)}" title="{html.escape(unread_title)}" {unread_hidden}>{unread_text}</span></div><div class="meta">Telegram: {tg_id if tg_id > 0 else "не привязан"} · {html.escape(str(item.get("email") or "—"))}</div></div>{status_badge(item["active"])}</div>
<div class="unread-preview" data-unread-preview {preview_hidden}><strong>Новое сообщение</strong><span>{html.escape(unread_preview)}</span></div>
<div class="numbers"><div><small>Осталось срока</small><strong>{remaining_label(item["expiry_time"], now_ms)}</strong></div><div><small>Трафик</small><strong>{fmt_bytes(item["traffic_used"])}</strong></div><div><small>Остаток лимита</small><strong>{quota}</strong></div></div>
<div class="meta" style="margin-bottom:13px">До: {fmt_date(item["expiry_time"])}<br>Последний онлайн: {html.escape(fmt_last_online(item.get("last_online_ts"), item.get("online", False)))}<br>↑ {fmt_bytes(item["up"])} · ↓ {fmt_bytes(item["down"])}</div>
<div class="actions">{message_button}<form class="inline" method="post" action="/users/{tg_id}/days"><input name="days" type="number" value="30" min="-3650" max="3650" step="1" aria-label="Изменение срока в днях" title="Положительное число добавляет дни, отрицательное — убавляет"><button class="small" title="Введите, например, 30 или -5">Изменить дни</button></form><form method="post" action="/users/{tg_id}/toggle"><button class="small secondary">{"Блокировать" if item["enable"] else "Включить"}</button></form><form method="post" action="/users/{tg_id}/delete" onsubmit="return confirm('Удалить пользователя из базы и 3x-ui?')"><button class="small danger">Удалить</button></form></div></div>'''
        )
    source_notice = ""
    if snapshot.get("stale"):
        source_notice = f'<div class="notice">Показан локальный кэш: {html.escape(str(snapshot.get("error") or "3x-ui API недоступна"))}</div>'
    unread_total = max(0, int(unread_snapshot.get("total") or 0))
    unread_users = max(0, int(unread_snapshot.get("users") or 0))
    unread_summary_text = (
        f"Непрочитано сообщений: {unread_total} от {unread_users} пользователей"
        if unread_total
        else "Новых сообщений нет"
    )
    body = f'''<header><div><h1>Пользователи</h1><div class="subtitle">Актуальные сроки, трафик, Telegram-привязки и история общения · {api_source_badge(bool(snapshot.get("stale")))}</div><div id="users-unread-summary" class="users-unread-summary {'active' if unread_total else ''}">{html.escape(unread_summary_text)}</div></div><div class="actions"><a class="button secondary" href="/broadcast">✉ Массовая рассылка</a><a class="button secondary" href="/users/import-identities">Импорт привязок</a><a class="button" href="/users/new">＋ Создать пользователя</a></div></header>{source_notice}
<div class="toolbar"><form><input name="q" value="{html.escape(q)}" placeholder="Имя, TG ID, @username или email"><select name="status"><option value="all">Все</option><option value="unread" {'selected' if status=='unread' else ''}>С новыми сообщениями</option><option value="active" {'selected' if status=='active' else ''}>Активные</option><option value="expired" {'selected' if status=='expired' else ''}>Истёкшие</option><option value="blocked" {'selected' if status=='blocked' else ''}>Заблокированные</option><option value="online" {'selected' if status=='online' else ''}>Сейчас онлайн</option></select><select name="sort"><option value="remaining" {'selected' if sort=='remaining' else ''}>По остатку срока</option><option value="last_online" {'selected' if sort=='last_online' else ''}>По последнему онлайн</option><option value="traffic" {'selected' if sort=='traffic' else ''}>По объёму трафика</option><option value="quota" {'selected' if sort=='quota' else ''}>По остатку лимита</option><option value="name" {'selected' if sort=='name' else ''}>По имени</option></select><select name="order"><option value="asc" {'selected' if order=='asc' else ''}>По возрастанию</option><option value="desc" {'selected' if order=='desc' else ''}>По убыванию</option></select></form><form method="post" action="/sync"><button class="secondary">↻ Обновить из 3x-ui</button></form></div><div class="user-cards">{''.join(cards) or '<div class="card">Пользователи не найдены.</div>'}</div>'''
    scripts = """<script>(function(){const f=document.querySelector('div.toolbar form');if(!f)return;let timer=0;f.querySelectorAll('select').forEach(x=>x.addEventListener('change',()=>{window.location.search=new URLSearchParams(new FormData(f)).toString()}));const q=f.querySelector('[name=q]');if(q)q.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>{window.location.search=new URLSearchParams(new FormData(f)).toString()},350)});})();</script>"""
    return page(request, "Пользователи", body, "users", scripts)


@app.get("/users/import-identities", response_class=HTMLResponse)
def import_identities_page(request: Request, token: str = ""):
    require_auth(request)
    preview: list[identity_migration.IdentityMatch] = []
    metadata: dict[str, Any] = {}
    error = ""
    if token:
        try:
            metadata, preview = identity_migration.preview_staged(token, config.DB_PATH)
        except Exception as exc:
            error = str(exc)
    summary = identity_migration.preview_summary(preview) if preview else {}
    rows = "".join(
        f'''<tr><td>{item.source.tg_id}</td><td>@{html.escape(item.source.username or "—")}</td><td>{html.escape(item.source.email or "—")}</td><td>{item.target_tg_id if item.target_tg_id is not None else "—"}</td><td><span class="badge {"good" if item.status in {"ready", "already"} else ("bad" if item.status == "conflict" else "warn")}">{html.escape(item.status)}</span></td><td>{html.escape(item.reason)}<br><span class="muted">{html.escape(item.detail)}</span></td></tr>'''
        for item in preview
    )
    preview_block = ""
    if preview:
        preview_block = f'''<div class="card full"><div class="section-title"><h2>Предварительная проверка</h2><span class="badge good">{summary.get('ready', 0)} готовы</span></div>
<div class="grid"><div class="card metric"><div class="label">Найдено</div><div class="value">{summary.get('total', 0)}</div></div><div class="card metric"><div class="label">Готово</div><div class="value">{summary.get('ready', 0)}</div></div><div class="card metric"><div class="label">Уже актуально</div><div class="value">{summary.get('already', 0)}</div></div><div class="card metric"><div class="label">Конфликты / без пары</div><div class="value">{summary.get('conflict', 0) + summary.get('unmatched', 0)}</div></div></div>
<div class="table-wrap"><table><thead><tr><th>Старый TG ID</th><th>Ник</th><th>Email 3x-ui</th><th>Текущий TG ID</th><th>Статус</th><th>Основание</th></tr></thead><tbody>{rows}</tbody></table></div>
<form method="post" action="/users/import-identities/apply" style="margin-top:18px"><input type="hidden" name="token" value="{html.escape(token)}"><label class="check-row"><input type="checkbox" name="sync_panel" value="1" checked> Записать восстановленные tgId также в 3x-ui</label><label class="check-row"><input type="checkbox" name="overwrite_conflicts" value="1"> Разрешить замену уже положительных TG ID (только после просмотра конфликтов)</label><button data-confirm="Применить проверенные Telegram-привязки?">Применить восстановление</button></form></div>'''
    error_html = f'<div class="notice">{html.escape(error)}</div>' if error else ""
    body = f'''<header><div><h1>Восстановление Telegram-привязок</h1><div class="subtitle">Безопасное сопоставление по UUID и email — без догадок по числам в имени</div></div><a class="button secondary" href="/users">Назад к пользователям</a></header>{error_html}
<div class="grid"><div class="card full"><h2>Загрузить старую базу или архив</h2><p class="muted">Поддерживаются SQLite и tar.gz. Импорт сначала создаёт отчёт; изменения не применяются до отдельного подтверждения. Загруженная копия удаляется после применения.</p><form method="post" action="/users/import-identities" enctype="multipart/form-data"><div class="setting"><label>Старая база/архив</label><input type="file" name="source" accept=".db,.sqlite,.sqlite3,.tar,.gz,.tgz,application/gzip" required></div><button>Проверить привязки</button></form></div>{preview_block}</div>'''
    return page(request, "Импорт Telegram-привязок", body, "users")


@app.post("/users/import-identities")
async def import_identities_upload(request: Request, source: UploadFile = File(...)):
    require_auth(request)
    max_size = max(10, int(getattr(config, "IDENTITY_IMPORT_MAX_MB", 512))) * 1024 * 1024
    temp_path: Path | None = None
    try:
        suffix = "".join(Path(source.filename or "legacy.db").suffixes[-2:]) or ".db"
        with tempfile.NamedTemporaryFile(prefix="vpn_identity_upload_", suffix=suffix, delete=False) as handle:
            temp_path = Path(handle.name)
            total = 0
            while True:
                chunk = await source.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_size:
                    raise identity_migration.IdentityImportError("Файл импорта превышает допустимый размер")
                handle.write(chunk)
        metadata = identity_migration.stage_import(temp_path, source.filename or "legacy.db")
        audit(str(request.session.get("user", "web")), "identity_import_preview", str(metadata.get("selected_rows")))
        return RedirectResponse(f"/users/import-identities?token={quote(str(metadata['token']))}", 303)
    except Exception as exc:
        set_flash(request, f"Не удалось прочитать старую базу: {exc}", "bad")
        return RedirectResponse("/users/import-identities", 303)
    finally:
        if temp_path:
            temp_path.unlink(missing_ok=True)
        await source.close()


@app.post("/users/import-identities/apply")
def import_identities_apply(
    request: Request,
    token: str = Form(),
    sync_panel: str | None = Form(None),
    overwrite_conflicts: str | None = Form(None),
):
    require_auth(request)
    try:
        result = identity_migration.apply_staged(
            token,
            db_path=config.DB_PATH,
            sync_panel=sync_panel == "1",
            overwrite_conflicts=overwrite_conflicts == "1",
        )
        audit(str(request.session.get("user", "web")), "identity_import_apply", json.dumps(result, ensure_ascii=False)[:3000])
        message = (
            f"Привязки обработаны: обновлено {result['updated']}, уже актуально {result['already']}, "
            f"конфликтов {result['conflicts']}, без совпадения {result['unmatched']}, в 3x-ui записано {result['panel_updated']}."
        )
        if result.get("panel_errors"):
            message += " Ошибки 3x-ui: " + "; ".join(result["panel_errors"][:3])
        set_flash(request, message, "bad" if result.get("panel_errors") else "good")
    except Exception as exc:
        set_flash(request, f"Импорт не применён: {exc}", "bad")
        return RedirectResponse(f"/users/import-identities?token={quote(token)}", 303)
    return RedirectResponse("/users", 303)


@app.get("/users/id/{tg_id}", response_class=HTMLResponse)
def user_detail_page(request: Request, tg_id: int):
    require_auth(request)
    row = get_user(tg_id)
    if not row:
        raise HTTPException(404)
    # Opening the conversation is the read action. Clear the compact counter
    # before rendering even if an imported/older database contains a stale
    # cursor. A message committed after this transaction is counted normally.
    try:
        user_events.mark_conversation_opened(tg_id, db_path=config.DB_PATH)
    except Exception as error:
        LOGGER.warning("Не удалось сбросить непрочитанные сообщения TG ID %s: %s", tg_id, error)
    events = user_events.recent_events(tg_id, limit=250, db_path=config.DB_PATH)
    event_html = render_user_events(events, tg_id)
    initial_last_id = int(events[-1]["id"]) if events else 0
    # A second exact acknowledgement covers a message that was committed after
    # the first reset but was included in the rendered snapshot. Anything newer
    # than the snapshot boundary remains unread.
    if initial_last_id > 0:
        try:
            user_events.mark_messages_read(
                tg_id,
                through_event_id=initial_last_id,
                db_path=config.DB_PATH,
            )
        except Exception as error:
            LOGGER.warning("Не удалось подтвердить видимую историю TG ID %s: %s", tg_id, error)
    disabled = tg_id <= 0
    identity_source = str(row.get("identity_source") or "не указано")
    media_limit = max(1, int(getattr(config, "CHAT_MEDIA_MAX_MB", 100)))
    body = f'''<header><div><h1>{html.escape(str(row.get('username') or 'Пользователь'))}</h1><div class="subtitle">Карточка, Telegram-привязка, переписка и журнал действий</div></div><a class="button secondary" href="/users">Назад</a></header>
<div class="chat-layout"><div class="card"><div class="section-title"><h2>Чат с пользователем</h2><span class="badge {'warn' if disabled else 'good'}">{'Нет TG ID' if disabled else 'Telegram подключён'}</span></div>
{('<div class="notice">Сначала восстановите или укажите положительный Telegram ID. Ник сам по себе не позволяет боту написать пользователю.</div>' if disabled else '')}
<div id="chat-window" class="chat-window">{event_html or '<div class="empty-state">История пока пуста. Новые сообщения и действия появятся здесь.</div>'}</div>
<form id="chat-form" class="chat-compose" method="post" action="/users/{tg_id}/message" enctype="multipart/form-data"><div class="chat-compose-main"><textarea name="message" maxlength="4096" {'disabled' if disabled else ''} placeholder="Сообщение или подпись к фото/видео"></textarea><label class="chat-attachment"><span>＋ Фото или видео</span><input name="media" type="file" accept="image/*,video/*" {'disabled' if disabled else ''}><small>До {media_limit} МБ; для медиа подпись — до 1024 символов.</small></label></div><button {'disabled' if disabled else ''}>Отправить</button></form></div>
<div class="card"><h2>Идентификация</h2><div class="setting"><label>Проверка Telegram по нику</label><div class="actions"><button type="button" class="secondary" id="telegram-lookup-button">🔎 Найти Telegram ID по @username</button>{('<button type="button" class="secondary" id="telegram-link-button">🔗 Запросить привязку через Telegram</button>' if tg_id <= 0 else '')}</div><div id="telegram-lookup-result" class="muted" style="margin-top:10px;white-space:pre-wrap"></div><div id="telegram-link-result" class="notice" style="display:none;margin-top:10px;word-break:break-all"></div></div><form method="post" action="/users/id/{tg_id}/identity"><div class="setting"><label>Telegram ID</label><input name="new_tg_id" type="number" min="1" value="{tg_id if tg_id > 0 else ''}" required></div><div class="setting"><label>Telegram @username</label><input name="username" value="{html.escape(str(row.get('username') or ''))}" maxlength="100"></div><label class="check-row"><input type="checkbox" name="overwrite_positive" value="1"> Подтверждаю замену существующего положительного ID</label><button>Сохранить и синхронизировать 3x-ui</button></form>
<hr style="border:0;border-top:1px solid var(--line);margin:20px 0"><div class="setting"><label>Email 3x-ui</label><div class="code">{html.escape(str(row.get('email') or '—'))}</div></div><div class="setting"><label>UUID</label><div class="code">{html.escape(str(row.get('uuid') or '—'))}</div></div><div class="setting"><label>Источник привязки</label><div>{html.escape(identity_source)}</div></div><div class="setting"><label>Последнее обновление</label><div>{html.escape(str(row.get('identity_updated_at') or '—'))}</div></div></div></div>'''
    script = f'''<script>
(function(){{
const b=document.getElementById('telegram-lookup-button'),r=document.getElementById('telegram-lookup-result');
if(b)b.addEventListener('click',async()=>{{const i=document.querySelector('input[name=\"username\"]'),u=String((i&&i.value)||'').trim().replace(/^@/,'');if(!u){{r.textContent='Укажите @username';return;}}b.disabled=true;r.textContent='Поиск…';try{{const x=await fetch('/api/telegram/lookup?username='+encodeURIComponent(u));const d=await x.json();if(!x.ok)throw new Error(d.detail||'Ошибка');r.textContent=d.matches&&d.matches.length?d.matches.map(z=>'@'+(z.username||u)+' — Telegram ID '+z.tg_id+(z.telegram_connected?' · подключён':' · без привязки')).join('\n'):'Совпадений нет. Для произвольного @username Telegram Bot API не даёт универсального способа получить ID.';}}catch(e){{r.textContent=e.message||'Ошибка';}}finally{{b.disabled=false;}}}});

const linkButton=document.getElementById('telegram-link-button'),linkResult=document.getElementById('telegram-link-result');
if(linkButton)linkButton.addEventListener('click',async()=>{{linkButton.disabled=true;linkResult.style.display='block';linkResult.textContent='Создание одноразовой ссылки…';try{{const body=new URLSearchParams();body.set('tg_id',String({tg_id}));const response=await fetch('/api/telegram/link-request',{{method:'POST',headers:{{'Content-Type':'application/x-www-form-urlencoded'}},body,credentials:'same-origin'}});const data=await response.json();if(!response.ok)throw new Error(data.detail||'Ошибка');linkResult.innerHTML='Передайте пользователю ссылку: <a href="'+data.deep_link+'" target="_blank" rel="noopener">'+data.deep_link+'</a>';const token=data.token;const poll=async()=>{{try{{const r=await fetch('/api/telegram/link-request/'+encodeURIComponent(token),{{credentials:'same-origin',cache:'no-store'}});const status=await r.json();if(status.status==='resolved'){{linkResult.textContent='✅ Telegram ID получен: '+status.tg_id;setTimeout(()=>location.reload(),600);return;}}if(status.status==='expired'){{linkResult.textContent='Ссылка истекла. Создайте новую.';return;}}setTimeout(poll,2000);}}catch(_e){{setTimeout(poll,3000);}}}};poll();}}catch(error){{linkResult.textContent=error.message||'Ошибка';}}finally{{linkButton.disabled=false;}}}});

}})();
(function(){{
let afterId={initial_last_id};const chat=document.getElementById('chat-window');const form=document.getElementById('chat-form');
function appendEvent(item){{
  const empty=chat.querySelector('.empty-state');if(empty)empty.remove();
  if(item.id && chat.querySelector('[data-event-id="'+Number(item.id)+'"]')){{afterId=Math.max(afterId,Number(item.id||0));return;}}
  const box=document.createElement('div');box.className='chat-message '+(item.direction||'system')+(item.success===false?' failed':'');box.dataset.eventId=item.id;
  const media=item.metadata&&item.metadata.media;
  if(media&&media.url){{
    if(media.kind==='photo'){{const link=document.createElement('a');link.className='chat-media-link';link.href=media.url;link.target='_blank';link.rel='noopener';const image=document.createElement('img');image.className='chat-media-image';image.src=media.url;image.alt=media.file_name||'Фотография';image.loading='lazy';link.append(image);box.append(link);}}
    if(media.kind==='video'){{const video=document.createElement('video');video.className='chat-media-video';video.src=media.url;video.controls=true;video.preload='metadata';video.playsInline=true;box.append(video);}}
  }}
  const text=document.createElement('div');text.className='chat-message-text';text.textContent=item.text||item.event_type||'Событие';
  const meta=document.createElement('small');meta.textContent=(item.created_at||'')+' · '+(item.actor||item.username||'system');box.append(text,meta);chat.append(box);afterId=Math.max(afterId,Number(item.id||0));chat.scrollTop=chat.scrollHeight;
}}
async function markVisibleRead(){{if(document.hidden)return;try{{const response=await fetch('/api/users/{tg_id}/read?through_event_id='+afterId,{{method:'POST',headers:{{Accept:'application/json'}},cache:'no-store',keepalive:true}});if(response.ok&&window.VPNPanel&&typeof window.VPNPanel.pollUnreadMessages==='function')await window.VPNPanel.pollUnreadMessages();}}catch(_e){{}}}}
async function poll(){{try{{const r=await fetch('/api/users/{tg_id}/events?after_id='+afterId,{{cache:'no-store'}});if(r.ok){{const d=await r.json();const items=d.events||[];items.forEach(appendEvent);if(items.length)await markVisibleRead();}}}}catch(_e){{}}finally{{setTimeout(poll,3000);}}}}
if(form)form.addEventListener('submit',async(e)=>{{e.preventDefault();const button=form.querySelector('button');const text=form.querySelector('textarea');const file=form.querySelector('input[type=file]');if(!(text.value||'').trim()&&!(file.files&&file.files.length)){{alert('Введите сообщение или выберите фото/видео');return;}}button.disabled=true;try{{const r=await fetch(form.action,{{method:'POST',body:new FormData(form),headers:{{Accept:'application/json'}}}});const d=await r.json();if(!r.ok)throw new Error(d.detail||'Ошибка отправки');if(d.event)appendEvent(d.event);form.reset();}}catch(err){{alert(err.message);}}finally{{button.disabled=false;}}}});
document.addEventListener('visibilitychange',()=>{{if(!document.hidden)markVisibleRead();}});
chat.scrollTop=chat.scrollHeight;markVisibleRead();setTimeout(poll,1200);
}})();</script>'''
    return page(request, "Пользователь", body, "users", script)


@app.post("/users/id/{tg_id}/identity")
def user_identity_update(
    request: Request,
    tg_id: int,
    new_tg_id: int = Form(),
    username: str = Form(""),
    overwrite_positive: str | None = Form(None),
):
    require_auth(request)
    row = get_user(tg_id)
    if not row:
        raise HTTPException(404)
    try:
        result = identity_migration.rebind_local_identity(
            tg_id,
            new_tg_id,
            username,
            source=f"manual:{request.session.get('user', 'web')}",
            overwrite_positive=overwrite_positive == "1",
            db_path=config.DB_PATH,
        )
        panel_error = ""
        if result.get("email"):
            try:
                bind_client_tg_id_sync(str(result["email"]), int(result["tg_id"]))
            except Exception as exc:
                panel_error = str(exc)
        user_events.safe_record_event(
            int(result["tg_id"]), username=str(result.get("username") or ""), direction="system",
            event_type="identity_updated", text=f"Telegram ID обновлён: {tg_id} → {result['tg_id']}",
            actor=str(request.session.get("user", "web")), metadata={"panel_error": panel_error}, db_path=config.DB_PATH,
        )
        audit(str(request.session.get("user", "web")), "identity_manual_update", f"{tg_id}->{result['tg_id']}")
        set_flash(request, "Привязка сохранена" + (f"; 3x-ui: {panel_error}" if panel_error else " и записана в 3x-ui"), "bad" if panel_error else "good")
        return RedirectResponse(f"/users/id/{int(result['tg_id'])}", 303)
    except Exception as exc:
        set_flash(request, f"Не удалось изменить привязку: {exc}", "bad")
        return RedirectResponse(f"/users/id/{tg_id}", 303)


@app.get("/api/users/{tg_id}/events")
def user_events_api(request: Request, tg_id: int, after_id: int = 0):
    require_auth(request)
    if not get_user(tg_id):
        raise HTTPException(404)
    events = user_events.recent_events(
        tg_id, limit=250, after_id=after_id, db_path=config.DB_PATH
    )
    return {"events": [event_for_web(event, tg_id) for event in events]}


@app.get("/api/users/unread")
def unread_user_messages_api(request: Request):
    require_auth(request)
    return JSONResponse(
        user_events.unread_messages_summary(db_path=config.DB_PATH),
        headers={"Cache-Control": "no-store, no-cache, must-revalidate"},
    )


@app.get("/api/panel/notifications")
def panel_notifications_api(request: Request):
    require_auth(request)
    # Keep channels independent. A legacy payment schema or a temporarily busy
    # table must never suppress message badges (and vice versa).
    payload: dict[str, Any] = {
        "messages": {"total": 0, "users": 0, "items": [], "last_event_id": 0},
        "payments": {"total": 0, "last_payment_id": 0, "latest": None},
        "errors": {},
        "server_time_ms": int(time.time() * 1000),
    }
    try:
        payload["messages"] = user_events.unread_messages_summary(db_path=config.DB_PATH)
    except Exception as error:
        LOGGER.exception("Ошибка получения уведомлений о сообщениях: %s", error)
        payload["errors"]["messages"] = str(error)[:500]
    try:
        payload["payments"] = panel_notifications.payment_notifications_summary(
            db_path=config.DB_PATH
        )
    except Exception as error:
        LOGGER.exception("Ошибка получения уведомлений об оплатах: %s", error)
        payload["errors"]["payments"] = str(error)[:500]
    return JSONResponse(
        payload,
        headers={"Cache-Control": "no-store, no-cache, must-revalidate"},
    )


@app.post("/api/users/{tg_id}/read")
def mark_user_messages_read_api(
    request: Request,
    tg_id: int,
    through_event_id: int = 0,
):
    require_auth(request)
    if not get_user(tg_id):
        raise HTTPException(404)
    return user_events.mark_messages_read(
        tg_id,
        through_event_id=through_event_id if through_event_id > 0 else None,
        db_path=config.DB_PATH,
    )


@app.get("/api/users/{tg_id}/events/{event_id}/media")
def user_event_media(request: Request, tg_id: int, event_id: int):
    require_auth(request)
    if not get_user(tg_id):
        raise HTTPException(404)
    path, media_type, filename = cached_event_media(tg_id, event_id)
    return FileResponse(
        path,
        media_type=media_type,
        filename=filename,
        content_disposition_type="inline",
        headers={
            "Cache-Control": "private, max-age=3600",
            "X-Content-Type-Options": "nosniff",
        },
    )


@app.get("/users/new", response_class=HTMLResponse)
def new_user_page(request: Request):
    require_auth(request)
    body = '''<header><div><h1>Новый пользователь</h1><div class="subtitle">Создание доступа одновременно в 3x-ui и базе бота</div></div></header><div class="card" style="max-width:650px"><form method="post"><div class="setting"><label>Telegram ID <span class="muted">(необязательно)</span></label><input name="tg_id" type="number" min="1" placeholder="Можно оставить пустым"><div class="muted" style="margin-top:5px">Если Telegram ID пока неизвестен, пользователь создаётся без Telegram-привязки. Позже ID можно привязать в карточке.</div></div><div class="setting"><label>Имя пользователя</label><input name="username" required maxlength="80" placeholder="Например: Иван"></div><div class="setting"><label>Количество дней</label><input name="days" type="number" value="30" min="1" max="3650" required></div><button>Создать доступ</button></form></div>'''
    return page(request, "Новый пользователь", body, "users")


@app.post("/users/new")
def create_user(request: Request, tg_id: str = Form(""), username: str = Form(), days: int = Form(30)):
    require_auth(request)
    username = username.strip().replace("@", "")[:80]
    text_id = str(tg_id or "").strip()
    try:
        parsed = int(text_id) if text_id else 0
    except ValueError as exc:
        raise HTTPException(400, "Telegram ID должен быть числом или пустым") from exc
    if parsed < 0 or not username or not 1 <= days <= 3650:
        raise HTTPException(400, "Некорректные параметры")
    if parsed == 0:
        with database() as connection:
            row = connection.execute("SELECT MIN(tg_id) FROM users WHERE tg_id<0").fetchone()
            parsed = min(-1, int(row[0] or 0) - 1)
    try:
        result = ensure_subscription_sync(parsed, username, days=days, db_path=config.DB_PATH)
        email = result.email
        fetch_and_sync(force=True, db_path=config.DB_PATH)
    except Exception as error:
        raise HTTPException(502, f"3x-ui не приняла создание пользователя: {error}") from error
    audit(str(request.session.get("user", "web")), "create_user", email)
    user_events.safe_record_event(parsed, username=username, direction="system", event_type="subscription_created" if result.created else "subscription_extended", text=f"Доступ {'создан' if result.created else 'продлён'} на {days} дн.", actor=str(request.session.get("user", "web")), metadata={"email": email, "days": days, "telegram_linked": parsed > 0}, db_path=config.DB_PATH)
    set_flash(request, f"Пользователь {username} {'создан' if result.created else 'найден и продлён'}" + (" без Telegram-привязки" if parsed < 0 else ""))
    return RedirectResponse("/users", 303)


@app.post("/users/{tg_id}/days")
def adjust_days(request: Request, tg_id: int, days: int = Form()):
    require_auth(request)
    if days == 0 or not -3650 <= days <= 3650:
        raise HTTPException(400, "Укажите число дней от -3650 до 3650, кроме нуля")
    row = get_user(tg_id)
    if not row:
        raise HTTPException(404)
    try:
        result = change_client_days_sync(
            str(row["email"]), days_delta=days, tg_id=tg_id if tg_id > 0 else None
        )
        with database() as connection:
            connection.execute(
                "UPDATE users SET expiry_time=?,enable=?,last_reminder_days=-1 WHERE tg_id=?",
                (int(result.get("expiry_time") or 0), int(bool(result.get("enable"))), tg_id),
            )
        fetch_and_sync(force=True, db_path=config.DB_PATH)
    except Exception as error:
        raise HTTPException(502, f"3x-ui отклонила изменение срока: {error}") from error
    audit(str(request.session.get("user", "web")), "adjust_user_days", f"{tg_id}: {days:+d}")
    user_events.safe_record_event(
        tg_id,
        username=str(row.get("username") or ""),
        direction="system",
        event_type="subscription_days_changed",
        text=f"Срок изменён на {days:+d} дн.; новый срок {fmt_date(int(result.get('expiry_time') or 0))}",
        actor=str(request.session.get("user", "web")),
        metadata={"days_delta": days, "expiry_time": int(result.get("expiry_time") or 0)},
        db_path=config.DB_PATH,
    )
    verb = "Добавлено" if days > 0 else "Убавлено"
    set_flash(request, f"{verb} {abs(days)} дн. Новый срок: {fmt_date(int(result.get('expiry_time') or 0))}")
    return RedirectResponse("/users", 303)


@app.get("/users/{tg_id}/bind-telegram", response_class=HTMLResponse)
def bind_telegram_page(request: Request, tg_id: int):
    require_auth(request)
    if not get_user(tg_id):
        raise HTTPException(404)
    return RedirectResponse(f"/users/id/{tg_id}", 303)


@app.post("/users/{tg_id}/bind-telegram")
def bind_telegram_user(
    request: Request,
    tg_id: int,
    new_tg_id: int = Form(),
    username: str = Form(""),
):
    require_auth(request)
    try:
        result = identity_migration.rebind_local_identity(
            tg_id,
            new_tg_id,
            username.strip().lstrip("@"),
            source=f"manual:{request.session.get('user', 'web')}",
            db_path=config.DB_PATH,
        )
        if result.get("email"):
            bind_client_tg_id_sync(str(result["email"]), int(result["tg_id"]))
    except Exception as error:
        set_flash(request, f"Не удалось привязать Telegram ID: {error}", "bad")
        return RedirectResponse(f"/users/id/{tg_id}", 303)
    audit(str(request.session.get("user", "web")), "bind_telegram_id", f"{tg_id} -> {new_tg_id}")
    user_events.safe_record_event(
        int(result["tg_id"]),
        username=str(result.get("username") or username),
        direction="system",
        event_type="identity_updated",
        text=f"Telegram ID привязан: {tg_id} → {result['tg_id']}",
        actor=str(request.session.get("user", "web")),
        db_path=config.DB_PATH,
    )
    set_flash(request, f"Пользователь привязан к Telegram ID {result['tg_id']}")
    return RedirectResponse(f"/users/id/{int(result['tg_id'])}", 303)


@app.post("/users/{tg_id}/toggle")
def toggle_user(request: Request, tg_id: int):
    require_auth(request)
    row = get_user(tg_id)
    if not row:
        raise HTTPException(404)
    new_state = not bool(row["enable"])
    try:
        set_client_status_sync(str(row["email"]), new_state)
        fetch_and_sync(force=True, db_path=config.DB_PATH)
    except Exception as error:
        raise HTTPException(502, f"3x-ui отклонила изменение статуса: {error}") from error
    audit(str(request.session.get("user", "web")), "toggle_user", f"{tg_id}: {new_state}")
    user_events.safe_record_event(
        tg_id,
        username=str(row.get("username") or ""),
        direction="system",
        event_type="access_enabled" if new_state else "access_blocked",
        text="Доступ включён" if new_state else "Доступ заблокирован",
        actor=str(request.session.get("user", "web")),
        db_path=config.DB_PATH,
    )
    set_flash(request, "Пользователь включён" if new_state else "Пользователь заблокирован")
    return RedirectResponse("/users", 303)


@app.post("/users/{tg_id}/delete")
def delete_user(request: Request, tg_id: int):
    require_auth(request)
    row = get_user(tg_id)
    if not row:
        raise HTTPException(404)
    user_events.safe_record_event(
        tg_id,
        username=str(row.get("username") or ""),
        direction="system",
        event_type="user_deleted",
        text="Пользователь удалён из платформы и 3x-ui",
        actor=str(request.session.get("user", "web")),
        metadata={"email": str(row.get("email") or "")},
        db_path=config.DB_PATH,
    )
    try:
        delete_client_sync(str(row["email"]), keep_traffic=False)
        with database() as connection:
            connection.execute("DELETE FROM users WHERE tg_id=?", (tg_id,))
    except Exception as error:
        raise HTTPException(502, f"3x-ui отклонила удаление: {error}") from error
    audit(str(request.session.get("user", "web")), "delete_user", str(tg_id))
    set_flash(request, "Пользователь удалён")
    return RedirectResponse("/users", 303)


@app.get("/users/{tg_id}/message", response_class=HTMLResponse)
def message_user_page(request: Request, tg_id: int):
    require_auth(request)
    if not get_user(tg_id):
        raise HTTPException(404)
    return RedirectResponse(f"/users/id/{tg_id}", 303)


@app.post("/users/{tg_id}/message")
def message_user(
    request: Request,
    tg_id: int,
    message: str = Form(""),
    media: UploadFile | None = File(None),
):
    require_auth(request)
    row = get_user(tg_id)
    if not row:
        raise HTTPException(404)
    message = message.strip()
    has_media = bool(media and str(media.filename or "").strip())
    if tg_id <= 0 or (not message and not has_media) or len(message) > 4096:
        raise HTTPException(400, "Введите сообщение или выберите фото/видео")
    if has_media and len(message) > 1024:
        raise HTTPException(400, "Подпись к фото или видео не должна превышать 1024 символа")

    metadata: dict[str, Any] = {}
    if has_media and media is not None:
        ok, detail, metadata, event_type, event_text = telegram_send_media(tg_id, media, message)
    else:
        ok, detail = telegram_send(tg_id, message)
        event_type, event_text = "admin_message", message
    actor = str(request.session.get("user", "web"))
    with database() as connection:
        connection.execute(
            "INSERT INTO message_log(actor,tg_id,username,message,success,detail) VALUES(?,?,?,?,?,?)",
            (actor, tg_id, row.get("username"), event_text, int(ok), detail),
        )
    event_metadata = dict(metadata)
    event_metadata["telegram_result"] = detail
    event_id = user_events.safe_record_event(
        tg_id,
        username=str(row.get("username") or ""),
        direction="out",
        event_type=event_type,
        text=event_text,
        actor=actor,
        success=ok,
        metadata=event_metadata,
        db_path=config.DB_PATH,
    )
    event = None
    if event_id:
        recorded = user_events.recent_events(
            tg_id, limit=1, after_id=max(0, int(event_id) - 1), db_path=config.DB_PATH
        )
        event = event_for_web(recorded[0], tg_id) if recorded else None
    try:
        if media is not None:
            media.file.close()
    except Exception:
        pass
    audit(actor, "message_user", f"{tg_id}: {detail}")
    wants_json = "application/json" in request.headers.get("accept", "")
    if not ok:
        if wants_json:
            return JSONResponse(
                {"ok": False, "detail": f"Telegram не принял сообщение: {detail}", "event": event},
                status_code=502,
            )
        set_flash(request, f"Telegram не принял сообщение: {detail}", "bad")
        return RedirectResponse(f"/users/id/{tg_id}", 303)
    if wants_json:
        return {"ok": True, "detail": detail, "event": event}
    set_flash(request, "Сообщение отправлено пользователю")
    return RedirectResponse(f"/users/id/{tg_id}", 303)

@app.get("/broadcast", response_class=HTMLResponse)
def broadcast_page(request: Request):
    require_auth(request)
    status = broadcast_manager.read_status()
    busy = broadcast_manager.broadcast_busy(status)
    state = str(status.get("state") or "idle")
    labels = {
        "idle": "Ожидание",
        "queued": "В очереди",
        "running": "Отправка",
        "completed": "Завершено",
        "failed": "Ошибка",
    }
    progress = max(0, min(100, int(status.get("progress") or 0)))
    state_class = "bad" if state == "failed" else ("warn" if busy else "good")
    failures = status.get("failure_examples") if isinstance(status.get("failure_examples"), list) else []
    failure_html = "".join(f"<li>{html.escape(str(item))}</li>" for item in failures[:10])
    detail_html = (
        f'<details class="broadcast-errors"><summary>Показать примеры ошибок</summary><ul>{failure_html}</ul></details>'
        if failure_html else ""
    )
    media_limit = max(1, int(getattr(config, "BROADCAST_MEDIA_MAX_MB", 45)))
    body = f'''<header><div><h1>Массовая рассылка</h1><div class="subtitle">Единый редактор: текст можно отправить отдельно или вместе с фотографией, видео либо файлом</div></div><a class="button secondary" href="/users">К пользователям</a></header>
<div class="grid"><div class="card half"><h2>Новое сообщение</h2><p class="muted">Поддерживаются: Текст, Фотография, Видео и Документ. Добавьте текст и при необходимости одно вложение: Telegram отправит их одним сообщением, а текст станет подписью к файлу.</p>
<form id="broadcast-form" method="post" action="/broadcast/start" enctype="multipart/form-data">
<div class="setting"><label id="broadcast-message-label">Текст сообщения</label><textarea id="broadcast-message" name="message" maxlength="4096" rows="7" placeholder="Введите текст сообщения"></textarea><div id="broadcast-limit" class="muted">До 4096 символов без вложения; до 1024 символов с вложением.</div></div>
<div class="setting broadcast-composer-file"><label>Фотография, видео или файл (необязательно)</label><input id="broadcast-file" type="file" name="media"><div id="broadcast-file-hint" class="muted">Можно прикрепить изображение, видео, PDF, архив или другой документ. Максимальный размер: {media_limit} МБ.</div></div>
<label class="check-row"><input type="checkbox" name="confirm" value="1" required> Подтверждаю отправку всем пользователям с положительным Telegram ID</label>
<button id="broadcast-start" {'disabled' if busy else ''}>Запустить рассылку</button>
<div id="broadcast-upload" class="file-progress"><div class="progress large"><span id="broadcast-upload-bar" style="width:0%"></span></div><div id="broadcast-upload-text" class="muted">Передача сообщения…</div></div>
</form></div>
<div class="card half"><div class="section-title"><h2>Текущий результат</h2><span id="broadcast-state" class="badge {state_class}">{html.escape(labels.get(state, state))}</span></div>
<div class="status-panel"><div class="progress large"><span id="broadcast-progress-bar" style="width:{progress}%"></span></div><div class="progress-meta"><span id="broadcast-message-status">{html.escape(str(status.get('message') or 'Рассылка ещё не запускалась'))}</span><strong id="broadcast-progress-value">{progress}%</strong></div>
<div class="broadcast-counters"><span>Всего: <strong id="broadcast-total">{int(status.get('total') or 0)}</strong></span><span>Обработано: <strong id="broadcast-processed">{int(status.get('processed') or 0)}</strong></span><span>Доставлено: <strong id="broadcast-delivered">{int(status.get('delivered') or 0)}</strong></span><span>Ошибок: <strong id="broadcast-failed">{int(status.get('failed') or 0)}</strong></span></div>
<div id="broadcast-error" class="notice" style="{'display:block' if status.get('error') else 'display:none'};margin-top:14px">{html.escape(str(status.get('error') or ''))}</div>{detail_html}</div>
<p><a class="button secondary small" href="/api/broadcast/log" target="_blank">Открыть журнал рассылки</a></p></div></div>'''
    initial = json.dumps(status, ensure_ascii=False, default=str).replace("<", "\\u003c")
    script = r'''<script>
(function(){
const initial=__INITIAL__;const busyStates=new Set(['queued','running']);
const labels={idle:'Ожидание',queued:'В очереди',running:'Отправка',completed:'Завершено',failed:'Ошибка'};
const file=document.getElementById('broadcast-file');const message=document.getElementById('broadcast-message');const messageLabel=document.getElementById('broadcast-message-label');const limit=document.getElementById('broadcast-limit');const fileHint=document.getElementById('broadcast-file-hint');
function updateFields(){const attached=Boolean(file.files&&file.files.length);message.required=!attached;message.maxLength=attached?1024:4096;messageLabel.textContent=attached?'Текст сообщения / подпись к вложению':'Текст сообщения';limit.textContent=attached?'Текст и вложение будут отправлены одним сообщением. Подпись — до 1024 символов.':'До 4096 символов. Можно добавить фотографию, видео или файл.';if(attached){const selected=file.files[0];const type=String(selected.type||'');const kind=type.startsWith('image/')?'фотография':(type.startsWith('video/')?'видео':'файл');fileHint.textContent='Выбрано: '+selected.name+' ('+kind+'). Тип отправки будет определён автоматически.';}else{fileHint.textContent='Можно прикрепить изображение, видео, PDF, архив или другой документ.';}}
file.addEventListener('change',updateFields);updateFields();
function render(data){data=data||{};const state=data.state||'idle';const progress=Math.max(0,Math.min(100,Number(data.progress||0)));document.getElementById('broadcast-progress-bar').style.width=progress+'%';document.getElementById('broadcast-progress-value').textContent=Math.round(progress)+'%';document.getElementById('broadcast-message-status').textContent=data.message||'Ожидание запуска';const badge=document.getElementById('broadcast-state');badge.textContent=labels[state]||state;badge.className='badge '+(state==='failed'?'bad':(busyStates.has(state)?'warn':'good'));document.getElementById('broadcast-error').textContent=data.error||'';document.getElementById('broadcast-error').style.display=data.error?'block':'none';['total','processed','delivered','failed'].forEach((name)=>{document.getElementById('broadcast-'+name).textContent=Number(data[name]||0);});document.getElementById('broadcast-start').disabled=busyStates.has(state);return state;}
let lastState=render(initial);
async function poll(){try{const response=await fetch('/api/broadcast/status',{cache:'no-store'});if(response.ok)lastState=render(await response.json());}catch(_e){}finally{setTimeout(poll,busyStates.has(lastState)?1200:5000);}}
document.getElementById('broadcast-form').addEventListener('submit',(event)=>{event.preventDefault();const hasFile=Boolean(file.files&&file.files.length);const textValue=(message.value||'').trim();if(!hasFile&&!textValue){alert('Введите текст сообщения или прикрепите файл');return;}if(hasFile&&textValue.length>1024){alert('При наличии вложения текст должен быть не длиннее 1024 символов');return;}if(!window.confirm('Запустить массовую рассылку всем пользователям?'))return;const form=event.currentTarget;const xhr=new XMLHttpRequest();const upload=document.getElementById('broadcast-upload');const bar=document.getElementById('broadcast-upload-bar');const statusText=document.getElementById('broadcast-upload-text');const button=document.getElementById('broadcast-start');upload.classList.add('visible');button.disabled=true;statusText.textContent='Передача данных на сервер…';xhr.open('POST',form.action);xhr.setRequestHeader('Accept','application/json');xhr.upload.onprogress=(e)=>{if(e.lengthComputable){const p=Math.round(e.loaded/e.total*100);bar.style.width=p+'%';statusText.textContent='Загружено '+p+'%';}};xhr.onload=()=>{let data={};try{data=JSON.parse(xhr.responseText)}catch(_e){}if(xhr.status>=200&&xhr.status<300){bar.style.width='100%';statusText.textContent='Сообщение принято, рассылка запущена';lastState=render(data.status||data);}else{button.disabled=false;statusText.textContent='Ошибка: '+(data.detail||data.error||'HTTP '+xhr.status);}};xhr.onerror=()=>{button.disabled=false;statusText.textContent='Соединение прервано. Статус будет проверен автоматически.';};xhr.send(new FormData(form));});
setTimeout(poll,600);
})();
</script>'''.replace('__INITIAL__', initial)
    return page(request, "Массовая рассылка", body, "broadcast", script)


@app.get("/api/broadcast/status")
def broadcast_status_api(request: Request):
    require_auth(request)
    status = broadcast_manager.read_status()
    return {**status, "state": str(status.get("state") or "idle")}


@app.get("/api/broadcast/log")
def broadcast_log_api(request: Request):
    require_auth(request)
    status = broadcast_manager.read_status()
    job_id = str(status.get("job_id") or "")
    path = broadcast_manager.log_path(job_id) if job_id else Path("")
    if not job_id or not path.is_file():
        return PlainTextResponse("Журнал рассылки пока пуст.")
    return FileResponse(path, media_type="text/plain; charset=utf-8", filename="vpn-service-broadcast.log")


@app.post("/broadcast/start")
async def broadcast_start(
    request: Request,
    kind: str = Form("auto"),
    message: str = Form(""),
    confirm: str = Form(""),
    media: UploadFile | None = File(None),
):
    require_auth(request)
    if confirm != "1":
        raise HTTPException(400, "Необходимо подтвердить массовую рассылку")
    if broadcast_manager.broadcast_busy():
        return JSONResponse(
            {"ok": False, "detail": "Другая массовая рассылка уже выполняется"},
            status_code=409,
        )
    max_size = max(1, int(getattr(config, "BROADCAST_MEDIA_MAX_MB", 45))) * 1024 * 1024
    temp_path: Path | None = None
    try:
        if media is not None and str(media.filename or "").strip():
            suffix = "".join(Path(media.filename or "broadcast.bin").suffixes[-2:])[:20] or ".bin"
            with tempfile.NamedTemporaryFile(prefix="vpn_broadcast_", suffix=suffix, delete=False) as handle:
                temp_path = Path(handle.name)
                total = 0
                while True:
                    chunk = await media.read(1024 * 1024)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > max_size:
                        raise broadcast_manager.BroadcastError(
                            f"Файл рассылки превышает допустимый размер {max_size // (1024 * 1024)} МБ"
                        )
                    handle.write(chunk)
        actor = str(request.session.get("user", "web"))
        result = broadcast_manager.start_broadcast(
            actor=actor,
            message=message,
            kind="auto" if temp_path is not None else "text",
            source=temp_path,
            original_name=str(media.filename or "") if media is not None else "",
            content_type=str(media.content_type or "") if media is not None else "",
        )
        audit(actor, "web_broadcast_started", result["job_id"])
        return JSONResponse({"ok": True, **result}, status_code=202)
    except broadcast_manager.BroadcastError as error:
        return JSONResponse({"ok": False, "detail": str(error)}, status_code=409)
    finally:
        if temp_path:
            temp_path.unlink(missing_ok=True)
        if media is not None:
            await media.close()


@app.get("/payments", response_class=HTMLResponse)
def payments(request: Request, status: str = "pending"):
    require_auth(request)
    # When the administrator follows the notification without choosing a
    # filter, show all new receipts (including ones auto-approved by OCR).
    try:
        before_read = panel_notifications.payment_notifications_summary(db_path=config.DB_PATH)
    except Exception:
        before_read = {"total": 0}
    if "status" not in request.query_params and int(before_read.get("total") or 0) > 0:
        status = "all"
    # Opening the section acknowledges every payment committed at this moment.
    # A receipt arriving after this transaction remains a new notification.
    try:
        panel_notifications.mark_payments_page_opened(db_path=config.DB_PATH)
    except Exception as error:
        LOGGER.warning("Не удалось сбросить уведомления об оплатах: %s", error)
    with database() as connection:
        rows = connection.execute(
            "SELECT * FROM payments WHERE (?='all' OR status=?) ORDER BY id DESC LIMIT 500",
            (status, status),
        ).fetchall()
    table_rows: list[str] = []
    for row in rows:
        actions = f'<a class="button small secondary" href="/payments/{row["id"]}/receipt" target="_blank">Чек</a>'
        if row["status"] == "pending":
            actions += f' <form class="inline" method="post" action="/payments/{row["id"]}/approve"><button class="small">Подтвердить</button></form> <form class="inline" method="post" action="/payments/{row["id"]}/decline"><button class="small danger">Отклонить</button></form>'
        if row["status"] == "declined":
            badge = '<span class="badge bad">Отклонён</span>'
        elif row["status"] == "approved":
            badge = '<span class="badge good">Подтверждён</span>'
        elif row["status"] == "processing":
            badge = '<span class="badge warn">Обрабатывается</span>'
        else:
            badge = '<span class="badge warn">Ожидает</span>'
        if int(row["auto_approved"] or 0):
            badge += '<br><span class="badge good" style="margin-top:5px">Автоматически</span>'
        ocr_status = str(row["ocr_status"] or "not_checked")
        ocr_badges = {
            "passed": '<span class="badge good">Все совпало</span>',
            "duplicate": '<span class="badge bad">Дубликат</span>',
            "error": '<span class="badge bad">Ошибка OCR</span>',
            "manual": '<span class="badge warn">Нужна проверка</span>',
            "not_checked": '<span class="badge warn">Не проверен</span>',
        }
        ocr_badge = ocr_badges.get(ocr_status, '<span class="badge warn">Нужна проверка</span>')
        recognized = []
        if row["receipt_receiver"]:
            recognized.append(f'имя: {html.escape(str(row["receipt_receiver"]))}')
        if row["receipt_phone"]:
            recognized.append(f'номер: {html.escape(str(row["receipt_phone"]))}')
        if row["receipt_date"]:
            recognized.append(f'дата: {html.escape(str(row["receipt_date"]))}')
        ocr_note = '<br><small>' + '<br>'.join(recognized) + '</small>' if recognized else ''
        error_note = ""
        if row["last_error"]:
            error_note = f'<br><small style="color:var(--red)">{html.escape(str(row["last_error"]))}</small>'
        actual_amount = row["receipt_amount"] if row["receipt_amount"] is not None else row["amount"]
        amount_text = f"{float(actual_amount):g} ₽" if actual_amount is not None else "—"
        table_rows.append(
            f'<tr><td>#{row["id"]}</td><td>@{html.escape(row["username"] or "нет")}<br><small>ID {row["tg_id"]}</small></td><td>{amount_text}</td><td>{html.escape(row["created_at"] or "")}</td><td>{ocr_badge}{ocr_note}</td><td>{badge}{error_note}</td><td>{actions}</td></tr>'
        )
    body = f'''<header><div><h1>Платежи</h1><div class="subtitle">Автоматическая OCR-проверка и ручная модерация чеков · открытие раздела отмечает текущие оплаты просмотренными</div></div></header><div class="toolbar"><a class="button {'secondary' if status!='pending' else ''}" href="/payments?status=pending">Ожидают</a><a class="button {'secondary' if status!='approved' else ''}" href="/payments?status=approved">Подтверждённые</a><a class="button {'secondary' if status!='all' else ''}" href="/payments?status=all">Все</a></div><div class="card table-wrap"><table><thead><tr><th>ID</th><th>Пользователь</th><th>Сумма чека</th><th>Получен</th><th>OCR</th><th>Статус</th><th>Действия</th></tr></thead><tbody>{''.join(table_rows) or '<tr><td colspan="7">Платежей нет.</td></tr>'}</tbody></table></div>'''
    return page(request, "Платежи", body, "payments")


@app.get("/payments/{payment_id}/receipt", response_class=HTMLResponse)
def receipt(request: Request, payment_id: int):
    require_auth(request)
    with database() as connection:
        row = connection.execute("SELECT * FROM payments WHERE id=?", (payment_id,)).fetchone()
    if not row:
        raise HTTPException(404)
    try:
        panel_notifications.mark_payments_read(
            through_payment_id=payment_id,
            db_path=config.DB_PATH,
        )
    except Exception as error:
        LOGGER.warning("Не удалось отметить оплату #%s просмотренной: %s", payment_id, error)
    if not row["telegram_file_id"]:
        raise HTTPException(404)
    amount = "—" if row["receipt_amount"] is None else f"{float(row['receipt_amount']):g} ₽"
    status = html.escape(str(row["ocr_status"] or "not_checked"))
    try:
        details = json.loads(str(row["ocr_details"] or "{}"))
    except (ValueError, TypeError):
        details = {}
    filters = details.get("filters") or {}
    checks = [
        ("Имя получателя", bool(details.get("name_match")), bool(filters.get("name", True))),
        ("Номер получателя", bool(details.get("phone_match")), bool(filters.get("phone", True))),
        ("Сумма не ниже порога", bool(details.get("amount_match")), bool(filters.get("amount", True))),
        ("Свежая дата", bool(details.get("date_match")), bool(filters.get("date", True))),
    ]
    checks_html = "".join(
        f'<div class="check-row"><span class="badge {"good" if (not enabled or ok) else "bad"}">{"○" if not enabled else ("✓" if ok else "✗")}</span><span>{html.escape(label)}{" (фильтр выключен)" if not enabled else ""}</span></div>'
        for label, ok, enabled in checks
    )
    duplicate = details.get("duplicate_payment_id")
    duplicate_html = f'<div class="notice">Этот чек уже использовался или совпал с платежом #{int(duplicate)}.</div>' if duplicate else ""
    reasons = details.get("reasons") or []
    reasons_html = "" if not reasons else '<p class="muted">Причины ручной проверки: ' + html.escape("; ".join(map(str, reasons))) + '</p>'
    ocr_text = html.escape(str(row["ocr_text"] or "Текст не распознан"))
    body = f'''<header><div><h1>Чек #{payment_id}</h1><div class="subtitle">@{html.escape(str(row["username"] or "нет"))} · Telegram ID {row["tg_id"]} · {html.escape(str(row["created_at"] or ""))}</div></div><a class="button secondary" href="/payments">Назад</a></header>{duplicate_html}<div class="grid"><div class="card wide" style="text-align:center"><img src="/payments/{payment_id}/receipt/image" alt="Чек #{payment_id}" style="display:block;max-width:100%;max-height:78vh;margin:auto;border-radius:10px;object-fit:contain" loading="eager"></div><div class="card side"><h2>Результат OCR</h2><p>Статус: <span class="code">{status}</span></p><p>Сумма: <strong>{amount}</strong><br>Дата: <strong>{html.escape(str(row["receipt_date"] or "—"))}</strong><br>Имя: <strong>{html.escape(str(row["receipt_receiver"] or "—"))}</strong><br>Номер: <strong>{html.escape(str(row["receipt_phone"] or "—"))}</strong></p>{checks_html}{reasons_html}</div><div class="card full"><h2>Распознанный текст</h2><pre>{ocr_text}</pre></div></div>'''
    return page(request, f"Чек #{payment_id}", body, "payments")


@app.get("/payments/{payment_id}/receipt/image")
def receipt_image(request: Request, payment_id: int):
    require_auth(request)
    content, media_type, filename = telegram_receipt_file(payment_id)
    return Response(
        content,
        media_type=media_type,
        headers={
            "Content-Disposition": f'inline; filename="{filename}"',
            "Content-Length": str(len(content)),
        },
    )


def approve_payment_logic(payment_id: int) -> tuple[bool, str]:
    result = approve_payment_sync(payment_id, "web", days=30, db_path=config.DB_PATH)
    if not result.success:
        return False, result.message
    if result.already_processed:
        return True, "Платёж уже был подтверждён; повторное продление не выполнено"
    subscription = result.subscription
    if not subscription:
        return False, "Не получены данные активированной подписки"
    action = "активирована" if subscription.created else "продлена"
    notification = (
        f"🎉 Ваша подписка {config.SERVICE_NAME} успешно {action} "
        f"до {fmt_date(subscription.expiry_time)}!"
    )
    sent, detail = telegram_send(subscription.tg_id, notification)
    if not sent:
        return True, f"Подписка {action}, но Telegram-уведомление не доставлено: {detail}"
    return True, f"Подписка {action}"


@app.post("/payments/{payment_id}/approve")
def approve_payment(request: Request, payment_id: int):
    require_auth(request)
    ok, message = approve_payment_logic(payment_id)
    if not ok:
        set_flash(request, message, "bad")
    else:
        audit(str(request.session.get("user", "web")), "approve_payment", str(payment_id))
        set_flash(request, message)
    return RedirectResponse("/payments", 303)


@app.post("/payments/{payment_id}/decline")
def decline_payment(request: Request, payment_id: int):
    require_auth(request)
    try:
        payment = decline_payment_sync(payment_id, "web", db_path=config.DB_PATH)
    except LookupError as error:
        raise HTTPException(404, str(error)) from error
    except Exception as error:
        set_flash(request, str(error), "bad")
        return RedirectResponse("/payments", 303)
    telegram_send(int(payment["tg_id"]), "❌ Платёж не подтверждён. Проверьте чек или обратитесь к администратору.")
    audit(str(request.session.get("user", "web")), "decline_payment", str(payment_id))
    set_flash(request, "Платёж отклонён")
    return RedirectResponse("/payments", 303)


@app.get("/monitoring", response_class=HTMLResponse)
def monitoring(request: Request):
    require_auth(request)
    vm = psutil.virtual_memory()
    swap = psutil.swap_memory()
    disk = psutil.disk_usage("/")
    boot = datetime.fromtimestamp(psutil.boot_time())
    load = os.getloadavg()
    net = psutil.net_io_counters()
    processes: list[str] = []
    candidates = sorted(
        psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]),
        key=lambda process: process.info.get("memory_percent") or 0,
        reverse=True,
    )[:12]
    for process in candidates:
        processes.append(
            f'<tr><td>{process.info["pid"]}</td><td>{html.escape(process.info["name"] or "")}</td><td>{process.info.get("cpu_percent",0):.1f}%</td><td>{process.info.get("memory_percent",0):.1f}%</td></tr>'
        )
    body = f'''<header><div><h1>Мониторинг сервера</h1><div class="subtitle">Ресурсы, сеть и процессы</div></div></header><div class="grid"><div class="card metric"><div class="label">CPU</div><div class="value">{psutil.cpu_percent():.0f}%</div><div class="hint">Load: {load[0]:.2f} / {load[1]:.2f} / {load[2]:.2f}</div></div><div class="card metric"><div class="label">RAM</div><div class="value">{vm.percent:.0f}%</div><div class="hint">{fmt_bytes(vm.used)} из {fmt_bytes(vm.total)}</div></div><div class="card metric"><div class="label">Swap</div><div class="value">{swap.percent:.0f}%</div><div class="hint">{fmt_bytes(swap.used)} из {fmt_bytes(swap.total)}</div></div><div class="card metric"><div class="label">Диск</div><div class="value">{disk.percent:.0f}%</div><div class="hint">Свободно {fmt_bytes(disk.free)}</div></div><div class="card wide chart-card"><div class="section-title"><h2>CPU в реальном времени</h2><span class="badge good">3 сек</span></div><div id="monitor-chart" class="chart"></div></div><div class="card side"><h2>Сеть с запуска</h2><p style="font-size:25px">↓ {fmt_bytes(net.bytes_recv)}</p><p style="font-size:25px">↑ {fmt_bytes(net.bytes_sent)}</p><p class="subtitle">Uptime с {boot.strftime('%d.%m.%Y %H:%M')}</p></div><div class="card full table-wrap"><div class="section-title"><h2>Процессы по памяти</h2></div><table><thead><tr><th>PID</th><th>Процесс</th><th>CPU</th><th>RAM</th></tr></thead><tbody>{''.join(processes)}</tbody></table></div></div>'''
    script = '''<script>const a=[];async function t(){let d=await(await fetch('/api/metrics')).json();a.push(d.cpu);if(a.length>50)a.shift();let w=800,h=210,p=a.map((v,i)=>`${i*w/Math.max(1,a.length-1)},${h-v*h/100}`).join(' ');document.getElementById('monitor-chart').innerHTML=`<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><polyline points="${p}"/></svg>`}t();setInterval(t,3000)</script>'''
    return page(request, "Мониторинг", body, "monitoring", script)


def safe_backup(name: str) -> Path:
    root = Path(config.BACKUP_DIR).resolve()
    path = (root / Path(name).name).resolve()
    if root not in path.parents or not path.is_file() or not path.name.endswith(".tar.gz"):
        raise HTTPException(404)
    return path


@app.get("/backups", response_class=HTMLResponse)
def backups(request: Request):
    require_auth(request)
    folder = Path(config.BACKUP_DIR)
    folder.mkdir(parents=True, exist_ok=True)
    try:
        state_path = Path(getattr(config, "BACKUP_STATE_PATH", "/var/lib/vpn-service/backup-state.json"))
        backup_state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.is_file() else {}
    except Exception:
        backup_state = {}
    pending = backup_state.get("pending_deliveries", []) if isinstance(backup_state, dict) else []
    pending_count = len(pending) if isinstance(pending, list) else 0
    rows = "".join(
        f'<tr><td>{html.escape(file.name)}</td><td>{fmt_bytes(file.stat().st_size)}</td><td>{datetime.fromtimestamp(file.stat().st_mtime).strftime("%d.%m.%Y %H:%M")}</td><td><a class="button small secondary" href="/backups/{quote(file.name)}/download">Скачать</a> <form class="inline" method="post" action="/backups/{quote(file.name)}/restore" onsubmit="return confirm(\'Восстановить базы и конфигурацию из архива?\')"><button class="small">Восстановить</button></form> <form class="inline" method="post" action="/backups/{quote(file.name)}/delete"><button class="small danger">Удалить</button></form></td></tr>'
        for file in sorted(folder.glob("*.tar.gz"), key=lambda item: item.stat().st_mtime, reverse=True)[:100]
    )
    with database() as connection:
        runs = connection.execute("SELECT * FROM backup_runs ORDER BY id DESC LIMIT 10").fetchall()
    run_rows = "".join(
        f'<tr><td>{html.escape(row["created_at"] or "")}</td><td>{html.escape(row["filename"] or "—")}</td><td>{status_badge(bool(row["telegram_ok"]), "Отправлен", "Ошибка")}</td><td>{status_badge(bool(row["yandex_ok"]), "Загружен", "Не загружен")}</td><td>{html.escape(row["error"] or row["yandex_detail"] or row["telegram_detail"] or "")}</td></tr>'
        for row in runs
    )
    queue_notice = (f" Сейчас в очереди повторной доставки: <strong>{pending_count}</strong>. Неудачные загрузки автоматически повторяются." if pending_count else " Загрузка в облака подтверждается после создания архива; при временной ошибке доставка автоматически попадёт в очередь повторов.")
    body = f'''<header><div><h1>Резервные копии</h1><div class="subtitle">Полная папка бота, SQLite-снимки бота и 3x-ui, systemd и манифест</div></div><form method="post" action="/backups/create"><button>＋ Создать и отправить сейчас</button></form></header><div class="notice">Плановый таймер запускается ежедневно, но новый полный архив создаётся только раз в {int(getattr(config, 'BACKUP_INTERVAL_DAYS', 3))} дня. Файловая блокировка исключает одновременные дубли.{queue_notice}</div><div class="card table-wrap"><table><thead><tr><th>Архив</th><th>Размер</th><th>Дата</th><th>Действия</th></tr></thead><tbody>{rows or '<tr><td colspan="4">Бэкапов пока нет.</td></tr>'}</tbody></table></div><div class="card table-wrap" style="margin-top:15px"><div class="section-title"><h2>Последние доставки</h2></div><table><thead><tr><th>Дата</th><th>Файл</th><th>Telegram</th><th>Яндекс.Диск</th><th>Подробности</th></tr></thead><tbody>{run_rows or '<tr><td colspan="5">Запусков пока нет.</td></tr>'}</tbody></table></div>'''
    return page(request, "Бэкапы", body, "backups")


@app.post("/backups/create")
def create_backup(request: Request):
    require_auth(request)
    try:
        result = subprocess.run(
            [str(PYTHON), str(APP_DIR / "backup.py"), "--force"],
            capture_output=True,
            text=True,
            timeout=3600,
            check=False,
        )
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout or "Неизвестная ошибка")[-1000:])
        set_flash(request, "Полный бэкап создан и отправка выполнена")
    except Exception as error:
        set_flash(request, f"Ошибка бэкапа: {error}", "bad")
    audit(str(request.session.get("user", "web")), "backup_create")
    return RedirectResponse("/backups", 303)


@app.get("/backups/{name}/download")
def backup_download(request: Request, name: str):
    require_auth(request)
    return FileResponse(safe_backup(name), filename=Path(name).name)


@app.post("/backups/{name}/delete")
def backup_delete(request: Request, name: str):
    require_auth(request)
    safe_backup(name).unlink()
    audit(str(request.session.get("user", "web")), "backup_delete", name)
    set_flash(request, "Архив удалён")
    return RedirectResponse("/backups", 303)


def safe_extract_backup(archive_path: Path, destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    with tarfile.open(archive_path, "r:gz") as archive:
        members = archive.getmembers()
        for member in members:
            if member.issym() or member.islnk() or member.isdev() or not (member.isfile() or member.isdir()):
                raise RuntimeError("Архив содержит ссылки или специальные файлы")
            name = member.name.replace("\\", "/")
            if not name or name.startswith("/") or ".." in Path(name).parts:
                raise RuntimeError("Архив содержит небезопасный путь")
            target = (destination / name).resolve()
            if root != target and root not in target.parents:
                raise RuntimeError("Архив выходит за каталог распаковки")
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise RuntimeError("Не удалось прочитать файл из архива")
            with source, target.open("wb") as output:
                shutil.copyfileobj(source, output)
            os.chmod(target, member.mode & 0o777)
    return destination / "vpn_service_backup"


def restore_sqlite(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    source_connection = sqlite3.connect(source, timeout=30)
    target_connection = sqlite3.connect(target, timeout=30)
    try:
        source_connection.backup(target_connection)
        target_connection.commit()
    finally:
        target_connection.close()
        source_connection.close()


@app.post("/backups/{name}/restore")
def backup_restore(request: Request, name: str):
    require_auth(request)
    archive = safe_backup(name)
    work = Path(tempfile.mkdtemp(prefix="vpn_restore_"))
    try:
        root = safe_extract_backup(archive, work)
        if not root.is_dir():
            raise RuntimeError("В архиве нет каталога vpn_service_backup")
        bot_root = root / "bot"
        bot_db_candidates = [
            root / "databases" / "vpn_bot.db",
            bot_root / "data" / "vpn_bot.db",
            root / "vpn_bot.db",
        ]
        xui_candidates = [root / "databases" / "x-ui.db", root / "x-ui.db"]
        config_candidates = [bot_root / "config.py", root / "config.py"]
        bot_source = next((path for path in bot_db_candidates if path.is_file()), None)
        xui_source = next((path for path in xui_candidates if path.is_file()), None)
        config_source = next((path for path in config_candidates if path.is_file()), None)
        if bot_source:
            restore_sqlite(bot_source, Path(config.DB_PATH))
        if xui_source and Path(config.XUI_DB_PATH).parent.exists():
            restore_sqlite(xui_source, Path(config.XUI_DB_PATH))
        if config_source:
            temporary = CONFIG_PATH.with_suffix(".restore.tmp")
            shutil.copy2(config_source, temporary)
            os.chmod(temporary, 0o600)
            temporary.replace(CONFIG_PATH)
        if not any((bot_source, xui_source, config_source)):
            raise RuntimeError("Подходящие базы и config.py в архиве не найдены")
        audit(str(request.session.get("user", "web")), "backup_restore", name)
        set_flash(request, "Базы и конфигурация восстановлены; службы перезапускаются")
        schedule_restart(["x-ui", "vpn-service-bot", "vpn-service-web"], delay=2)
    except Exception as error:
        set_flash(request, f"Ошибка восстановления: {error}", "bad")
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return RedirectResponse("/backups", 303)


@app.get("/logs", response_class=HTMLResponse)
def logs(request: Request, service: str = "bot", lines: int = 300):
    require_auth(request)
    unit = {
        "bot": "vpn-service-bot",
        "web": "vpn-service-web",
        "backup": "vpn-service-backup",
        "reminders": "vpn-service-reminders",
        "update": "vpn-service-update*",
    }.get(service, "vpn-service-bot")
    lines = max(50, min(lines, 2000))
    if unit.endswith("*"):
        data = shell(["journalctl", "-u", unit, "-n", str(lines), "--no-pager"])
    else:
        data = shell(["journalctl", "-u", unit, "-n", str(lines), "--no-pager"])
    body = f'''<header><div><h1>Журналы</h1><div class="subtitle">Последние сообщения systemd</div></div></header><div class="toolbar"><form><select name="service"><option value="bot" {'selected' if service=='bot' else ''}>Telegram-бот</option><option value="web" {'selected' if service=='web' else ''}>Веб-панель</option><option value="backup" {'selected' if service=='backup' else ''}>Бэкапы</option><option value="reminders" {'selected' if service=='reminders' else ''}>Напоминания</option><option value="update" {'selected' if service=='update' else ''}>Обновления</option></select><input type="number" name="lines" value="{lines}" min="50" max="2000"><button>Показать</button></form></div><pre>{html.escape(data)}</pre>'''
    return page(request, "Журналы", body, "logs")


def replace_assignment(text: str, name: str, value: Any) -> str:
    line = f"{name} = {value!r}"
    pattern = rf"(?m)^{re.escape(name)}\s*=.*$"
    return re.sub(pattern, line, text) if re.search(pattern, text) else text.rstrip() + "\n" + line + "\n"


def save_config_values(values: dict[str, Any]) -> None:
    text = CONFIG_PATH.read_text(encoding="utf-8")
    backup = CONFIG_PATH.with_name(f"config.py.before_web_{int(time.time())}")
    shutil.copy2(CONFIG_PATH, backup)
    for key, value in values.items():
        text = replace_assignment(text, key, value)
    temporary = CONFIG_PATH.with_suffix(".py.tmp")
    temporary.write_text(text, encoding="utf-8")
    os.chmod(temporary, 0o600)
    temporary.replace(CONFIG_PATH)
    for key, value in values.items():
        setattr(config, key, value)
    invalidate_snapshot_cache()
    update_manager.invalidate_update_cache()


def schedule_restart(units: list[str], delay: int = 2) -> None:
    safe_units = [unit for unit in units if re.fullmatch(r"[A-Za-z0-9_.@*-]+", unit)]
    if not safe_units:
        return
    command = f"sleep {max(1, delay)}; systemctl restart {' '.join(safe_units)}"
    subprocess.Popen(
        ["/bin/bash", "-c", command],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
        close_fds=True,
    )


def _config_text(name: str, default: Any = "") -> str:
    return html.escape(str(getattr(config, name, default) or ""), quote=True)


def _config_checked(name: str, default: bool = False) -> str:
    return "checked" if bool(getattr(config, name, default)) else ""


def _password_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    iterations = 260_000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations).hex()
    return f"pbkdf2_sha256${iterations}${salt.hex()}${digest}"


def _http_url(
    value: str,
    label: str,
    *,
    allow_empty: bool = False,
    trailing_slash: bool = False,
) -> str:
    clean = str(value or "").strip()
    if not clean and allow_empty:
        return ""
    parts = urlsplit(clean)
    if parts.scheme not in {"http", "https"} or not parts.netloc:
        raise HTTPException(400, f"{label}: нужен полный URL с http:// или https://")
    if parts.username or parts.password:
        raise HTTPException(400, f"{label}: логин и пароль нельзя хранить внутри URL")
    if len(clean) > 1000:
        raise HTTPException(400, f"{label}: URL слишком длинный")
    return clean.rstrip("/") + "/" if trailing_slash else clean.rstrip("/")


def _form_int(form: Any, name: str, default: int, minimum: int, maximum: int, label: str) -> int:
    try:
        value = int(str(form.get(name, default)).strip())
    except (TypeError, ValueError) as error:
        raise HTTPException(400, f"{label}: требуется целое число") from error
    if not minimum <= value <= maximum:
        raise HTTPException(400, f"{label}: допустимо от {minimum} до {maximum}")
    return value


def _form_float(form: Any, name: str, default: float, minimum: float, maximum: float, label: str) -> float:
    try:
        value = float(str(form.get(name, default)).strip().replace(",", "."))
    except (TypeError, ValueError) as error:
        raise HTTPException(400, f"{label}: требуется число") from error
    if not minimum <= value <= maximum:
        raise HTTPException(400, f"{label}: значение вне допустимого диапазона")
    return value


@app.get("/settings", response_class=HTMLResponse)
def settings(request: Request):
    require_auth(request)
    reminder_value = ",".join(map(str, getattr(config, "REMINDER_DAYS", [7, 3, 1, 0])))
    admin_value = ",".join(map(str, getattr(config, "ADMIN_IDS", [])))
    publisher = update_manager.publisher_enabled()
    role_label = "Главная панель обновлений" if publisher else "Ведомая панель"
    role_class = "good" if publisher else "warn"
    current_username = str(getattr(config, "WEB_USERNAME", ""))
    subscription_days = int(getattr(config, "SUBSCRIPTION_DAYS", 30))
    update_source_control = (
        '<div class="setting"><label>Защищённый логин главной панели</label><input value="menshikovivan" disabled></div>'
        '<div class="setting"><label>URL главной панели</label><input type="url" name="update_master_url" value="{0}" placeholder="https://master.example.com"><div class="muted">На главной панели игнорируется. На остальных обязателен.</div></div>'.format(html.escape(str(getattr(config, "UPDATE_MASTER_URL", ""))))
        if publisher else
        '<div class="setting"><label>Источник обновлений</label><div class="notice">Адрес главной панели скрыт. Настройка источника доступна только на главной панели.</div><input type="hidden" name="update_master_url" value=""></div>'
    )
    body = f'''
<header>
  <div><h1>Настройки</h1><div class="subtitle">Разделены по назначению. Секреты можно оставить пустыми, чтобы не менять.</div></div>
  <span class="badge {role_class}">{html.escape(role_label)}</span>
</header>
<form method="post" autocomplete="off">
  <div class="tabs" data-tabs>
    <button type="button" data-tab="bot">Бот и сервис</button>
    <button type="button" data-tab="payment">Оплата и чеки</button>
    <button type="button" data-tab="xui">3x-ui</button>
    <button type="button" data-tab="security">Панель и защита</button>
    <button type="button" data-tab="updates">Обновления</button>
    <button type="button" data-tab="data">Бэкапы и данные</button>
  </div>

  <section class="setting-section" data-tab-section="bot">
    <div class="grid">
      <div class="card half">
        <h2>Основные параметры</h2>
        <div class="setting"><label>Название сервиса</label><input name="service_name" value="{_config_text('SERVICE_NAME')}" maxlength="100" required></div>
        <div class="setting"><label>Telegram Bot Token</label><input type="password" name="bot_token" placeholder="Пусто — оставить текущий" autocomplete="new-password"><div class="muted">Текущий токен никогда не выводится в браузер.</div></div>
        <div class="setting"><label>Telegram ID администраторов</label><input name="admin_ids" value="{html.escape(admin_value)}" placeholder="123456789, 987654321" required><div class="muted">Положительные ID через запятую, пробел или точку с запятой.</div></div>
        <label class="check-row"><input type="checkbox" name="panel_notify_admin_messages" value="1" {'checked' if bool(getattr(config, 'PANEL_NOTIFY_ADMIN_MESSAGES', True)) else ''}> Показывать уведомления и для сообщений от Telegram-администраторов</label>
        <div class="setting"><label>Срок одной покупки, дней</label><input type="number" name="subscription_days" value="{subscription_days}" min="1" max="3650" required></div>
      </div>
      <div class="card half">
        <h2>Тексты и интерактивность</h2>
        <div class="setting"><label>Приветствие / текст главного меню</label><textarea name="bot_welcome_text" maxlength="3500" placeholder="Пусто — стандартный текст. Можно использовать {{service}}.">{_config_text('BOT_WELCOME_TEXT')}</textarea></div>
        <div class="setting"><label>Подсказка перед обращением в поддержку</label><textarea name="bot_support_prompt" maxlength="1500" placeholder="Пусто — стандартная подсказка.">{_config_text('BOT_SUPPORT_PROMPT')}</textarea></div>
        <div class="setting"><label>Ссылка на Incy</label><input type="url" name="faq_incy_url" value="{_config_text('FAQ_INCY_URL', 'https://apps.apple.com/ru/app/incy/id6756943388')}" required></div>
        <div class="two">
          <div class="setting"><label>Обновлять Telegram-привязку, сек.</label><input type="number" name="bot_identity_refresh_seconds" value="{int(getattr(config, 'BOT_IDENTITY_REFRESH_SECONDS', 600))}" min="60" max="86400"></div>
          <div class="setting"><label>Синхронизация с 3x-ui, сек.</label><input type="number" name="bot_sync_interval_seconds" value="{int(getattr(config, 'BOT_SYNC_INTERVAL_SECONDS', 3600))}" min="300" max="86400"></div>
        </div>
      </div>
      <div class="card full">
        <div class="section-title"><h2>Массовая рассылка из веб-панели</h2><a class="button secondary small" href="/broadcast">Открыть рассылку</a></div>
        <div class="two">
          <div class="setting"><label>Максимальный файл, МБ</label><input type="number" name="broadcast_media_max_mb" value="{int(getattr(config, 'BROADCAST_MEDIA_MAX_MB', 45))}" min="1" max="49"><div class="muted">Фото, видео или документ загружается в Telegram один раз, затем используется полученный file_id.</div></div>
          <div class="setting"><label>Пауза между получателями, сек.</label><input type="number" step="0.01" name="broadcast_send_delay_seconds" value="{float(getattr(config, 'BROADCAST_SEND_DELAY_SECONDS', 0.04)):g}" min="0.02" max="5"><div class="muted">Небольшая пауза снижает риск ограничений Telegram при большой базе.</div></div>
          <div class="setting"><label>Считать рассылку зависшей через, сек.</label><input type="number" name="broadcast_stale_seconds" value="{int(getattr(config, 'BROADCAST_STALE_SECONDS', 7200))}" min="300" max="86400"></div>
        </div>
      </div>
    </div>
  </section>

  <section class="setting-section" data-tab-section="payment">
    <div class="grid">
      <div class="card half">
        <h2>Реквизиты оплаты</h2>
        <div class="setting"><label>Цена за {subscription_days} дней, ₽</label><input name="price" type="number" value="{int(getattr(config, 'PAYMENT_PRICE', 150))}" min="0" max="10000000" required></div>
        <div class="setting"><label>Телефон / реквизиты</label><input name="phone" value="{_config_text('PAYMENT_PHONE')}" maxlength="500"></div>
        <div class="setting"><label>Банк</label><input name="bank" value="{_config_text('PAYMENT_BANK')}" maxlength="200"></div>
        <div class="setting"><label>Получатель</label><input name="receiver" value="{_config_text('PAYMENT_RECEIVER')}" maxlength="200"></div>
        <div class="notice">Бот выдаёт ровно выбранный срок подписки. Переплата не увеличивает срок автоматически.</div>
      </div>
      <div class="card half">
        <h2>OCR и автопроверка</h2>
        <div class="check-row"><label><input type="checkbox" name="receipt_ocr_enabled" value="1" {_config_checked('RECEIPT_OCR_ENABLED', True)}> Локально распознавать чеки</label></div>
        <div class="check-row"><label><input type="checkbox" name="receipt_auto_approve" value="1" {_config_checked('RECEIPT_AUTO_APPROVE', True)}> Автоматически подтверждать при успешных фильтрах</label></div>
        <div class="check-row"><label><input type="checkbox" name="receipt_allow_masked_phone" value="1" {_config_checked('RECEIPT_ALLOW_MASKED_PHONE', True)}> Разрешать частично скрытый телефон</label></div>
        <div class="two">
          <div class="setting"><label>Минимальная сумма, ₽</label><input name="receipt_min_amount" type="number" step="0.01" value="{float(getattr(config, 'RECEIPT_MIN_AMOUNT', 150)):g}" min="0" max="10000000"></div>
          <div class="setting"><label>Максимальный возраст, часов</label><input name="receipt_max_age_hours" type="number" value="{int(getattr(config, 'RECEIPT_MAX_AGE_HOURS', 24))}" min="1" max="168"></div>
        </div>
        <div class="setting"><label>Дополнительные варианты имени</label><textarea name="receipt_aliases" maxlength="2000" placeholder="Иван И.; И. Иванов">{_config_text('RECEIPT_RECEIVER_ALIASES')}</textarea></div>
      </div>
      <div class="card full">
        <h2>Фильтры и движок OCR</h2>
        <div class="two">
          <div>
            <div class="check-row"><label><input type="checkbox" name="receipt_filter_name" value="1" {_config_checked('RECEIPT_FILTER_NAME', True)}> Проверять имя получателя</label></div>
            <div class="check-row"><label><input type="checkbox" name="receipt_filter_phone" value="1" {_config_checked('RECEIPT_FILTER_PHONE', False)}> Проверять телефон</label></div>
            <div class="check-row"><label><input type="checkbox" name="receipt_filter_amount" value="1" {_config_checked('RECEIPT_FILTER_AMOUNT', True)}> Проверять сумму</label></div>
            <div class="check-row"><label><input type="checkbox" name="receipt_filter_date" value="1" {_config_checked('RECEIPT_FILTER_DATE', False)}> Проверять дату</label></div>
            <div class="check-row"><label><input type="checkbox" name="receipt_filter_status" value="1" {_config_checked('RECEIPT_FILTER_STATUS', True)}> Блокировать отменённые / ошибочные чеки</label></div>
            <div class="check-row"><label><input type="checkbox" name="receipt_filter_duplicate" value="1" {_config_checked('RECEIPT_FILTER_DUPLICATE', True)}> Блокировать дубликаты</label></div>
          </div>
          <div>
            <div class="setting"><label>Часовой пояс чеков</label><input name="receipt_timezone" value="{_config_text('RECEIPT_TIMEZONE', 'Europe/Moscow')}" maxlength="100" required></div>
            <div class="setting"><label>Языки Tesseract</label><input name="receipt_ocr_languages" value="{_config_text('RECEIPT_OCR_LANGUAGES', 'rus+eng')}" maxlength="80" required></div>
            <div class="setting"><label>Тайм-аут одного прохода, сек.</label><input name="receipt_ocr_timeout" type="number" value="{int(getattr(config, 'RECEIPT_OCR_TIMEOUT', 20))}" min="5" max="120"></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="setting-section" data-tab-section="xui">
    <div class="grid">
      <div class="card half">
        <h2>Подключение к 3x-ui</h2>
        <div class="setting"><label>URL панели / API</label><input type="url" name="base_url" value="{_config_text('BASE_URL')}" required></div>
        <div class="setting"><label>Базовый URL подписок</label><input type="url" name="sub_url" value="{_config_text('SUB_BASE_URL')}" required></div>
        <div class="setting"><label>API-токен 3x-ui</label><input type="password" name="api_token" placeholder="Пусто — оставить текущий" autocomplete="new-password"></div>
        <div class="check-row"><label><input type="checkbox" name="xui_verify_tls" value="1" {_config_checked('XUI_VERIFY_TLS', False)}> Проверять TLS-сертификат 3x-ui</label></div>
      </div>
      <div class="card half">
        <h2>Синхронизация и уведомления</h2>
        <div class="setting"><label>Кэш снимка 3x-ui, секунд</label><input name="cache_seconds" type="number" value="{int(getattr(config, 'XUI_CACHE_SECONDS', 15))}" min="1" max="300"></div>
        <div class="setting"><label>Дни напоминаний</label><input name="reminder_days" value="{html.escape(reminder_value)}" required><div class="muted">Например: 7, 3, 1, 0.</div></div>
        <div class="notice">Общий трафик берётся из счётчиков inbound. Сумма по пользователям используется только для детализации и не складывает дубли одного клиента.</div>
      </div>
    </div>
  </section>

  <section class="setting-section" data-tab-section="security">
    <div class="grid">
      <div class="card half">
        <h2>Доступ к веб-панели</h2>
        <div class="setting"><label>Логин панели</label><input name="web_username" value="{html.escape(current_username)}" minlength="3" maxlength="64" required><div class="muted">Только логин <span class="code">menshikovivan</span> получает роль главного сервера обновлений.</div></div>
        <div class="setting"><label>Новый пароль</label><input type="password" name="web_password" minlength="10" placeholder="Пусто — оставить текущий" autocomplete="new-password"></div>
        <div class="setting"><label>Повтор нового пароля</label><input type="password" name="web_password_confirm" minlength="10" placeholder="Повторите новый пароль" autocomplete="new-password"></div>
        <div class="check-row"><label><input type="checkbox" name="web_cookie_https_only" value="1" {_config_checked('WEB_COOKIE_HTTPS_ONLY', False)}> Передавать cookie только по HTTPS</label></div>
        <div class="check-row"><label><input type="checkbox" name="web_trust_proxy_headers" value="1" {_config_checked('WEB_TRUST_PROXY_HEADERS', False)}> Доверять X-Forwarded-For от reverse proxy</label></div>
      </div>
      <div class="card half">
        <h2>Защита от перебора</h2>
        <div class="two">
          <div class="setting"><label>Ошибок до блокировки</label><input type="number" name="web_login_max_attempts" value="{int(getattr(config, 'WEB_LOGIN_MAX_ATTEMPTS', 5))}" min="2" max="20"></div>
          <div class="setting"><label>Окно ошибок, сек.</label><input type="number" name="web_login_window_seconds" value="{int(getattr(config, 'WEB_LOGIN_WINDOW_SECONDS', 900))}" min="30" max="86400"></div>
          <div class="setting"><label>Первая блокировка, сек.</label><input type="number" name="web_login_block_seconds" value="{int(getattr(config, 'WEB_LOGIN_BLOCK_SECONDS', 900))}" min="30" max="86400"></div>
          <div class="setting"><label>Максимальная блокировка, сек.</label><input type="number" name="web_login_max_block_seconds" value="{int(getattr(config, 'WEB_LOGIN_MAX_BLOCK_SECONDS', 86400))}" min="30" max="604800"></div>
        </div>
        <div class="setting"><label>Срок веб-сессии, сек.</label><input type="number" name="web_session_max_age_seconds" value="{int(getattr(config, 'WEB_SESSION_MAX_AGE_SECONDS', 28800))}" min="900" max="604800"></div>
        <div class="setting"><label>Хранить журнал попыток, дней</label><input type="number" name="web_login_security_retention_days" value="{int(getattr(config, 'WEB_LOGIN_SECURITY_RETENTION_DAYS', 30))}" min="1" max="365"></div>
      </div>
    </div>
  </section>

  <section class="setting-section" data-tab-section="updates">
    <div class="grid">
      <div class="card half">
        <h2>Топология обновлений</h2>
        <div class="notice"><b>Текущая роль:</b> {html.escape(role_label)}.<br>Роль вычисляется только по логину веб-панели; старый переключатель издателя игнорируется.</div>
        {update_source_control}
        <div class="setting"><label>Общий токен обновлений</label><input type="password" name="update_api_token" placeholder="Пусто — оставить текущий" autocomplete="new-password"><div class="muted">Одинаковый длинный токен должен быть сохранён на главной и ведомых панелях.</div></div>
      </div>
      <div class="card half">
        <h2>Проверка и загрузка</h2>
        <div class="setting"><label>Интервал проверки, секунд</label><input type="number" name="update_check_interval" value="{int(getattr(config, 'UPDATE_CHECK_INTERVAL', 60))}" min="15" max="86400"></div>
        <div class="setting"><label>Максимальный архив, МБ</label><input type="number" name="update_max_archive_mb" value="{int(getattr(config, 'UPDATE_MAX_ARCHIVE_MB', 1024))}" min="64" max="4096"></div>
        <div class="setting"><label>Считать задачу зависшей через, сек.</label><input type="number" name="update_stale_job_seconds" value="{int(getattr(config, 'UPDATE_STALE_JOB_SECONDS', 7200))}" min="900" max="86400"><div class="muted">После этого разрешается повторный запуск, если worker аварийно завершился.</div></div>
        <div class="check-row"><label><input type="checkbox" name="update_verify_tls" value="1" {_config_checked('UPDATE_VERIFY_TLS', True)}> Проверять TLS главной панели</label></div>
        <a class="button secondary" href="/updates">Открыть центр обновлений</a>
      </div>
    </div>
  </section>

  <section class="setting-section" data-tab-section="data">
    <div class="grid">
      <div class="card half">
        <h2>Бэкапы</h2>
        <div class="two">
          <div class="setting"><label>Хранить локально, дней</label><input type="number" name="backup_keep_days" value="{int(getattr(config, 'BACKUP_KEEP_DAYS', 14))}" min="1" max="365"></div>
          <div class="setting"><label>Интервал бэкапа, дней</label><input type="number" name="backup_interval_days" value="{int(getattr(config, 'BACKUP_INTERVAL_DAYS', 3))}" min="1" max="30"></div>
          <div class="setting"><label>Часть Telegram, МБ</label><input type="number" name="backup_telegram_part_mb" value="{int(getattr(config, 'BACKUP_TELEGRAM_PART_MB', 45))}" min="5" max="49"></div>
        </div>
        <div class="check-row"><label><input type="checkbox" name="backup_telegram" value="1" {_config_checked('BACKUP_TELEGRAM', True)}> Отправлять резервные копии в Telegram</label></div>
        <div class="check-row"><label><input type="checkbox" name="backup_include_venv" value="1" {_config_checked('BACKUP_INCLUDE_VENV', True)}> Включать Python-окружение</label></div>
        <div class="settings-links"><a class="button secondary" href="/settings/yandex">Яндекс.Диск</a></div>
      </div>
      <div class="card half">
        <h2>Нагрузка и хранение истории</h2>
        <div class="setting"><label>Хранить чат и действия, дней</label><input type="number" name="user_event_keep_days" value="{int(getattr(config, 'USER_EVENT_KEEP_DAYS', 365))}" min="1" max="3650"></div>
        <div class="setting"><label>Максимум записей истории</label><input type="number" name="user_event_max_rows" value="{int(getattr(config, 'USER_EVENT_MAX_ROWS', 250000))}" min="1000" max="5000000"></div>
        <div class="setting"><label>Интервал записи метрик, сек.</label><input type="number" name="metrics_store_interval_seconds" value="{int(getattr(config, 'METRICS_STORE_INTERVAL_SECONDS', 60))}" min="15" max="3600"></div>
        <div class="setting"><label>Максимум архива импорта ID, МБ</label><input type="number" name="identity_import_max_mb" value="{int(getattr(config, 'IDENTITY_IMPORT_MAX_MB', 512))}" min="10" max="2048"></div>
        <div class="two">
          <div class="setting"><label>Максимальный файл в чате, МБ</label><input type="number" name="chat_media_max_mb" value="{int(getattr(config, 'CHAT_MEDIA_MAX_MB', 100))}" min="1" max="2000"></div>
          <div class="setting"><label>Хранить кэш медиа, дней</label><input type="number" name="chat_media_cache_days" value="{int(getattr(config, 'CHAT_MEDIA_CACHE_DAYS', 30))}" min="1" max="3650"></div>
          <div class="setting"><label>Максимальный кэш медиа, МБ</label><input type="number" name="chat_media_cache_max_mb" value="{int(getattr(config, 'CHAT_MEDIA_CACHE_MAX_MB', 512))}" min="16" max="10240"></div>
        </div>
        <div class="muted">История очищается без тяжёлого VACUUM. Фото и видео кэшируются отдельно и удаляются по возрасту и общему размеру.</div>
      </div>
    </div>
  </section>

  <div class="card full settings-actions">
    <div><strong>Сохранение применит конфигурацию атомарно.</strong><div class="muted">Бот и веб-панель автоматически перезапустятся через несколько секунд.</div></div>
    <button type="submit">Сохранить настройки</button>
  </div>
</form>
'''
    return page(request, "Настройки", body, "settings")


@app.post("/settings")
async def save_settings(request: Request):
    require_auth(request)
    form = await request.form()

    def text_value(name: str, default: str = "") -> str:
        return str(form.get(name, default) or "").strip()

    def checked(name: str) -> bool:
        return text_value(name) == "1"

    service_name = text_value("service_name")
    if not service_name or len(service_name) > 100:
        raise HTTPException(400, "Название сервиса должно содержать от 1 до 100 символов")

    raw_admin_ids = text_value("admin_ids")
    try:
        admin_ids = sorted({int(value) for value in re.split(r"[,;\s]+", raw_admin_ids) if value})
    except ValueError as error:
        raise HTTPException(400, "Telegram ID администраторов должны быть целыми числами") from error
    if not admin_ids or any(value <= 0 for value in admin_ids):
        raise HTTPException(400, "Нужен хотя бы один положительный Telegram ID администратора")

    web_username = text_value("web_username")
    if not re.fullmatch(r"[A-Za-z0-9_.@-]{3,64}", web_username):
        raise HTTPException(400, "Логин панели: 3–64 символа, латиница, цифры и . _ @ -")
    web_password = text_value("web_password")
    if web_password:
        if len(web_password) < 10 or len(web_password) > 200:
            raise HTTPException(400, "Новый пароль должен содержать от 10 до 200 символов")
        if web_password != text_value("web_password_confirm"):
            raise HTTPException(400, "Повтор нового пароля не совпадает")

    try:
        reminder_days = sorted(
            {int(value) for value in re.split(r"[,;\s]+", text_value("reminder_days")) if value},
            reverse=True,
        )
    except ValueError as error:
        raise HTTPException(400, "Дни напоминаний должны быть целыми числами") from error
    if not reminder_days or any(day < 0 or day > 365 for day in reminder_days):
        raise HTTPException(400, "Некорректный список дней напоминаний")

    receipt_timezone = text_value("receipt_timezone", "Europe/Moscow")
    try:
        ZoneInfo(receipt_timezone)
    except ZoneInfoNotFoundError as error:
        raise HTTPException(400, "Неизвестный часовой пояс чеков") from error
    receipt_languages = text_value("receipt_ocr_languages", "rus+eng")
    if not re.fullmatch(r"[A-Za-z0-9_]+(?:\+[A-Za-z0-9_]+)*", receipt_languages) or len(receipt_languages) > 80:
        raise HTTPException(400, "Некорректный список языков OCR")

    base_url = _http_url(text_value("base_url"), "URL 3x-ui", trailing_slash=True)
    sub_url = _http_url(text_value("sub_url"), "URL подписок", trailing_slash=True)
    faq_incy_url = _http_url(text_value("faq_incy_url"), "Ссылка Incy")
    is_publisher = web_username == "menshikovivan"
    raw_update_master_url = text_value("update_master_url")
    if not is_publisher and not raw_update_master_url:
        update_master_url = str(getattr(config, "UPDATE_MASTER_URL", "")).strip()
    else:
        update_master_url = _http_url(
            raw_update_master_url,
            "URL главной панели обновлений",
            allow_empty=is_publisher,
        )
    if not is_publisher and not update_master_url:
        raise HTTPException(400, "Для ведомой панели не настроен источник обновлений")
    if is_publisher:
        update_master_url = ""
    else:
        try:
            update_master_url = update_manager.normalize_master_url(update_master_url)
        except update_manager.UpdateError as error:
            raise HTTPException(400, f"URL главной панели обновлений: {error}") from error

    welcome_text = text_value("bot_welcome_text")
    support_prompt = text_value("bot_support_prompt")
    aliases = text_value("receipt_aliases")
    if len(welcome_text) > 3500 or len(support_prompt) > 1500 or len(aliases) > 2000:
        raise HTTPException(400, "Один из текстовых параметров превышает допустимую длину")

    login_block = _form_int(form, "web_login_block_seconds", 900, 30, 86_400, "Первая блокировка")
    login_max_block = _form_int(form, "web_login_max_block_seconds", 86_400, 30, 604_800, "Максимальная блокировка")
    if login_max_block < login_block:
        raise HTTPException(400, "Максимальная блокировка не может быть короче первой")

    values: dict[str, Any] = {
        "SERVICE_NAME": service_name,
        "ADMIN_IDS": admin_ids,
        "PANEL_NOTIFY_ADMIN_MESSAGES": checked("panel_notify_admin_messages"),
        "SUBSCRIPTION_DAYS": _form_int(form, "subscription_days", 30, 1, 3650, "Срок подписки"),
        "BOT_WELCOME_TEXT": welcome_text,
        "BOT_SUPPORT_PROMPT": support_prompt,
        "FAQ_INCY_URL": faq_incy_url,
        "BOT_IDENTITY_REFRESH_SECONDS": _form_int(form, "bot_identity_refresh_seconds", 600, 60, 86_400, "Обновление Telegram-привязки"),
        "BOT_SYNC_INTERVAL_SECONDS": _form_int(form, "bot_sync_interval_seconds", 3600, 300, 86_400, "Синхронизация бота"),
        "BROADCAST_MEDIA_MAX_MB": _form_int(form, "broadcast_media_max_mb", 45, 1, 49, "Размер файла рассылки"),
        "BROADCAST_SEND_DELAY_SECONDS": _form_float(form, "broadcast_send_delay_seconds", 0.04, 0.02, 5.0, "Пауза рассылки"),
        "BROADCAST_STALE_SECONDS": _form_int(form, "broadcast_stale_seconds", 7200, 300, 86_400, "Тайм-аут рассылки"),
        "PAYMENT_PRICE": _form_int(form, "price", 150, 0, 10_000_000, "Цена"),
        "PAYMENT_PHONE": text_value("phone")[:500],
        "PAYMENT_BANK": text_value("bank")[:200],
        "PAYMENT_RECEIVER": text_value("receiver")[:200],
        "RECEIPT_OCR_ENABLED": checked("receipt_ocr_enabled"),
        "RECEIPT_AUTO_APPROVE": checked("receipt_auto_approve"),
        "RECEIPT_ALLOW_MASKED_PHONE": checked("receipt_allow_masked_phone"),
        "RECEIPT_FILTER_NAME": checked("receipt_filter_name"),
        "RECEIPT_FILTER_PHONE": checked("receipt_filter_phone"),
        "RECEIPT_FILTER_AMOUNT": checked("receipt_filter_amount"),
        "RECEIPT_FILTER_DATE": checked("receipt_filter_date"),
        "RECEIPT_FILTER_STATUS": checked("receipt_filter_status"),
        "RECEIPT_FILTER_DUPLICATE": checked("receipt_filter_duplicate"),
        "RECEIPT_RECEIVER_ALIASES": aliases,
        "RECEIPT_MIN_AMOUNT": _form_float(form, "receipt_min_amount", 150.0, 0, 10_000_000, "Минимальная сумма"),
        "RECEIPT_MAX_AGE_HOURS": _form_int(form, "receipt_max_age_hours", 24, 1, 168, "Возраст чека"),
        "RECEIPT_TIMEZONE": receipt_timezone,
        "RECEIPT_OCR_LANGUAGES": receipt_languages,
        "RECEIPT_OCR_TIMEOUT": _form_int(form, "receipt_ocr_timeout", 20, 5, 120, "Тайм-аут OCR"),
        "BASE_URL": base_url,
        "MASTER_API_URL": base_url,
        "SUB_BASE_URL": sub_url,
        "XUI_CACHE_SECONDS": _form_int(form, "cache_seconds", 15, 1, 300, "Кэш 3x-ui"),
        "XUI_VERIFY_TLS": checked("xui_verify_tls"),
        "REMINDER_DAYS": reminder_days,
        "WEB_USERNAME": web_username,
        "WEB_COOKIE_HTTPS_ONLY": checked("web_cookie_https_only"),
        "WEB_TRUST_PROXY_HEADERS": checked("web_trust_proxy_headers"),
        "WEB_SESSION_MAX_AGE_SECONDS": _form_int(form, "web_session_max_age_seconds", 28_800, 900, 604_800, "Срок сессии"),
        "WEB_LOGIN_MAX_ATTEMPTS": _form_int(form, "web_login_max_attempts", 5, 2, 20, "Ошибки входа"),
        "WEB_LOGIN_WINDOW_SECONDS": _form_int(form, "web_login_window_seconds", 900, 30, 86_400, "Окно ошибок"),
        "WEB_LOGIN_BLOCK_SECONDS": login_block,
        "WEB_LOGIN_MAX_BLOCK_SECONDS": login_max_block,
        "WEB_LOGIN_SECURITY_RETENTION_DAYS": _form_int(form, "web_login_security_retention_days", 30, 1, 365, "Хранение попыток входа"),
        "UPDATE_PUBLISHER_USERNAME": "menshikovivan",
        "UPDATE_IS_PUBLISHER": is_publisher,
        "UPDATE_MASTER_URL": update_master_url,
        "UPDATE_CHECK_INTERVAL": _form_int(form, "update_check_interval", 60, 15, 86_400, "Интервал обновлений"),
        "UPDATE_VERIFY_TLS": checked("update_verify_tls"),
        "UPDATE_MAX_ARCHIVE_MB": _form_int(form, "update_max_archive_mb", 1024, 64, 4096, "Размер архива обновления"),
        "UPDATE_STALE_JOB_SECONDS": _form_int(form, "update_stale_job_seconds", 7200, 900, 86_400, "Тайм-аут зависшей задачи"),
        "BACKUP_KEEP_DAYS": _form_int(form, "backup_keep_days", 14, 1, 365, "Хранение бэкапов"),
        "BACKUP_INTERVAL_DAYS": _form_int(form, "backup_interval_days", 3, 1, 30, "Интервал бэкапов"),
        "BACKUP_TELEGRAM": checked("backup_telegram"),
        "BACKUP_TELEGRAM_PART_MB": _form_int(form, "backup_telegram_part_mb", 45, 5, 49, "Размер части Telegram"),
        "BACKUP_INCLUDE_VENV": checked("backup_include_venv"),
        "USER_EVENT_KEEP_DAYS": _form_int(form, "user_event_keep_days", 365, 1, 3650, "Хранение истории"),
        "USER_EVENT_MAX_ROWS": _form_int(form, "user_event_max_rows", 250_000, 1000, 5_000_000, "Лимит истории"),
        "METRICS_STORE_INTERVAL_SECONDS": _form_int(form, "metrics_store_interval_seconds", 60, 15, 3600, "Интервал метрик"),
        "IDENTITY_IMPORT_MAX_MB": _form_int(form, "identity_import_max_mb", 512, 10, 2048, "Размер импорта"),
        "CHAT_MEDIA_MAX_MB": _form_int(form, "chat_media_max_mb", 100, 1, 2000, "Размер медиа в чате"),
        "CHAT_MEDIA_CACHE_DAYS": _form_int(form, "chat_media_cache_days", 30, 1, 3650, "Хранение кэша медиа"),
        "CHAT_MEDIA_CACHE_MAX_MB": _form_int(form, "chat_media_cache_max_mb", 512, 16, 10240, "Размер кэша медиа"),
    }
    if web_password:
        values["WEB_PASSWORD_HASH"] = _password_hash(web_password)
    bot_token = text_value("bot_token")
    if bot_token:
        if len(bot_token) > 300:
            raise HTTPException(400, "Telegram-токен слишком длинный")
        values["BOT_TOKEN"] = bot_token
    api_token = text_value("api_token")
    if api_token:
        if len(api_token) > 2000:
            raise HTTPException(400, "API-токен 3x-ui слишком длинный")
        values["MASTER_API_TOKEN"] = api_token
    update_token = text_value("update_api_token")
    if update_token:
        if len(update_token) < 24 or len(update_token) > 512:
            raise HTTPException(400, "Токен обновлений должен содержать от 24 до 512 символов")
        values["UPDATE_API_TOKEN"] = update_token

    save_config_values(values)
    request.session["user"] = web_username
    auth_security.prune(db_path=config.DB_PATH)
    user_events.prune_events(
        keep_days=int(values["USER_EVENT_KEEP_DAYS"]),
        max_rows=int(values["USER_EVENT_MAX_ROWS"]),
        db_path=config.DB_PATH,
    )
    audit(web_username, "settings_update", ",".join(sorted(values)))
    role_text = "главной" if is_publisher else "ведомой"
    set_flash(request, f"Настройки сохранены. Панель работает в роли {role_text}; службы перезапускаются.")
    schedule_restart(["vpn-service-bot", "vpn-service-web", "vpn-service-backup.service", "vpn-service-backup.timer", "vpn-service-reminders.service", "vpn-service-reminders.timer"], delay=2)
    return RedirectResponse("/settings", 303)


@app.get("/settings/yandex", response_class=HTMLResponse)
def yandex_settings(request: Request):
    require_auth(request)
    enabled = bool(getattr(config, "YANDEX_DISK_ENABLED", False))
    mode = str(getattr(config, "YANDEX_DISK_MODE", "oauth")).strip().lower()
    if mode not in {"oauth", "local"}:
        mode = "oauth"
    path_value = str(getattr(config, "YANDEX_DISK_PATH", "VPN-Service-Backups"))
    local_path = str(getattr(config, "YANDEX_LOCAL_PATH", "/mnt/yandex-disk"))
    require_mount = bool(getattr(config, "YANDEX_LOCAL_REQUIRE_MOUNT", True))
    token_set = bool(str(getattr(config, "YANDEX_DISK_TOKEN", "")).strip())
    upload_retries = max(1, int(getattr(config, "YANDEX_UPLOAD_RETRIES", 3)))
    verify_attempts = max(1, int(getattr(config, "YANDEX_UPLOAD_VERIFY_ATTEMPTS", 8)))
    verify_delay = max(0.0, float(getattr(config, "YANDEX_UPLOAD_VERIFY_DELAY", 1.5)))
    body = f'''<header><div><h1>Яндекс.Диск</h1><div class="subtitle">OAuth REST API или локально смонтированный WebDAV-каталог</div></div></header><div class="grid"><div class="card half"><h2>Подключение</h2><form method="post"><div class="setting"><label><input type="checkbox" name="enabled" value="1" {'checked' if enabled else ''}> Включить загрузку на Яндекс.Диск</label></div><div class="setting"><label>Режим</label><select name="mode"><option value="oauth" {'selected' if mode == 'oauth' else ''}>OAuth REST API</option><option value="local" {'selected' if mode == 'local' else ''}>Локально смонтированный WebDAV</option></select></div><div class="setting"><label>OAuth-токен (только для режима OAuth)</label><input type="password" name="token" placeholder="{'Токен уже сохранён; пусто — не менять' if token_set else 'Введите OAuth-токен'}"></div><div class="setting"><label>Точка монтирования (локальный режим)</label><input name="local_path" value="{html.escape(local_path)}" placeholder="/mnt/yandex-disk"></div><div class="setting"><label><input type="checkbox" name="require_mount" value="1" {'checked' if require_mount else ''}> Требовать настоящую точку монтирования (защита от записи на системный диск)</label></div><div class="setting"><label>Каталог для бэкапов</label><input name="path" value="{html.escape(path_value)}" required></div><div class="three"><div class="setting"><label>Попыток загрузки</label><input type="number" name="upload_retries" value="{upload_retries}" min="1" max="10"></div><div class="setting"><label>Проверок файла</label><input type="number" name="verify_attempts" value="{verify_attempts}" min="1" max="30"></div><div class="setting"><label>Пауза проверки, сек.</label><input type="number" step="0.1" name="verify_delay" value="{verify_delay:g}" min="0" max="30"></div></div><button name="action" value="save">Сохранить</button> <button class="secondary" name="action" value="test">Проверить подключение</button></form></div><div class="card half"><h2>Локальный режим</h2><p>Установщик включает скрипт <span class="code">configure_yandex_webdav.sh</span>. Он монтирует <span class="code">https://webdav.yandex.ru</span> через davfs2.</p><p class="danger">Доступ по WebDAV предоставляется на тарифах Яндекс 360.</p><p>Для авторизации используйте логин Яндекса и отдельный пароль приложения WebDAV, а не основной пароль аккаунта.</p><pre>sudo /root/vpn_bot/configure_yandex_webdav.sh</pre><p class="muted">Перед созданием каталога панель выполняет PROPFIND, поэтому существующая папка больше не создаёт шумный HTTP 405. PUT и проверка размера выполняются через отдельные соединения. Если ответ PUT потерян, но файл уже сохранён, бэкап считается успешным после точного сравнения размера. При подтверждённой ошибке прямого WebDAV используется резервная запись через активную точку монтирования.</p></div></div>'''
    return page(request, "Яндекс.Диск", body, "yandex")


@app.post("/settings/yandex")
def save_yandex_settings(
    request: Request,
    enabled: str | None = Form(None),
    mode: str = Form("oauth"),
    token: str = Form(""),
    local_path: str = Form("/mnt/yandex-disk"),
    require_mount: str | None = Form(None),
    path: str = Form("VPN-Service-Backups"),
    upload_retries: int = Form(3),
    verify_attempts: int = Form(8),
    verify_delay: float = Form(1.5),
    action: str = Form("save"),
):
    require_auth(request)
    mode = mode.strip().lower()
    if mode not in {"oauth", "local"}:
        raise HTTPException(400, "Некорректный режим Яндекс.Диска")
    token_value = token.strip() or str(getattr(config, "YANDEX_DISK_TOKEN", "")).strip()
    local_path_value = str(Path(local_path.strip() or "/mnt/yandex-disk").expanduser())
    if not Path(local_path_value).is_absolute():
        raise HTTPException(400, "Точка монтирования должна быть абсолютным путём")
    if not 1 <= int(upload_retries) <= 10:
        raise HTTPException(400, "Количество попыток загрузки должно быть от 1 до 10")
    if not 1 <= int(verify_attempts) <= 30:
        raise HTTPException(400, "Количество проверок файла должно быть от 1 до 30")
    if not 0 <= float(verify_delay) <= 30:
        raise HTTPException(400, "Пауза проверки должна быть от 0 до 30 секунд")
    if action == "test":
        ok, detail = test_yandex_connection(
            token_value,
            mode=mode,
            local_path=local_path_value,
            require_mount=require_mount == "1",
        )
        set_flash(request, detail, "good" if ok else "bad")
        return RedirectResponse("/settings/yandex", 303)
    clean_path = path.strip().strip("/") or "VPN-Service-Backups"
    values: dict[str, Any] = {
        "YANDEX_DISK_ENABLED": enabled == "1",
        "YANDEX_DISK_MODE": mode,
        "YANDEX_DISK_PATH": clean_path,
        "YANDEX_LOCAL_PATH": local_path_value,
        "YANDEX_LOCAL_REQUIRE_MOUNT": require_mount == "1",
        "YANDEX_UPLOAD_RETRIES": int(upload_retries),
        "YANDEX_UPLOAD_VERIFY_ATTEMPTS": int(verify_attempts),
        "YANDEX_UPLOAD_VERIFY_DELAY": float(verify_delay),
    }
    if token.strip():
        values["YANDEX_DISK_TOKEN"] = token.strip()
    save_config_values(values)
    audit(str(request.session.get("user", "web")), "yandex_settings", f"{mode}: {clean_path}")
    set_flash(request, "Настройки Яндекс.Диска сохранены")
    schedule_restart(["vpn-service-web"], delay=2)
    return RedirectResponse("/settings/yandex", 303)


def require_update_api_token(request: Request) -> None:
    expected = str(getattr(config, "UPDATE_API_TOKEN", "")).strip()
    if not expected:
        raise HTTPException(503, "API обновлений не настроен")
    authorization = request.headers.get("Authorization", "")
    supplied = authorization[7:].strip() if authorization.lower().startswith("bearer ") else ""
    supplied = supplied or request.headers.get("X-Update-Token", "").strip()
    if not supplied or not _secure_text_compare(supplied, expected):
        raise HTTPException(401, "Неверный токен обновлений")


@app.get("/panel/api/updates/latest", include_in_schema=False)
@app.get("/api/updates/latest")
def updates_latest_api(request: Request):
    if not update_manager.publisher_enabled():
        raise HTTPException(404)
    require_update_api_token(request)
    metadata = update_manager.latest_local_update(verify=False)
    if not metadata:
        return JSONResponse({"detail": "Обновление ещё не загружено"}, status_code=404)
    return update_manager.api_metadata(metadata)


@app.get("/panel/api/updates/download/{filename}", include_in_schema=False)
@app.get("/api/updates/download/{filename}")
def updates_download_api(request: Request, filename: str):
    if not update_manager.publisher_enabled():
        raise HTTPException(404)
    require_update_api_token(request)
    metadata = update_manager.latest_local_update()
    if not metadata or Path(filename).name != metadata.get("filename"):
        raise HTTPException(404)
    path = Path(str(metadata.get("path") or ""))
    if not path.is_file():
        raise HTTPException(404)
    return FileResponse(path, filename=path.name, media_type="application/gzip")


@app.get("/api/updates/status")
def updates_status_api(request: Request):
    require_auth(request)
    status = update_manager.read_status()
    return {
        **status,
        "state": str(status.get("state") or "idle"),
        "progress": int(status.get("progress") or 0),
        "busy": update_manager.update_job_busy(status),
        "installed_version": update_manager.current_version(),
    }


@app.get("/api/updates/availability")
def updates_availability_api(request: Request):
    require_auth(request)
    try:
        info = update_manager.check_available_update(force=False)
    except Exception as error:
        info = {"available": False, "error": str(error), "installed_version": update_manager.current_version()}
    return {
        "available": bool(info.get("available")),
        "version": str(info.get("version") or ""),
        "installed_version": str(info.get("installed_version") or update_manager.current_version()),
        "error": str(info.get("error") or ""),
        "source": str(info.get("source") or ""),
    }


@app.get("/api/updates/log")
def updates_log_api(request: Request):
    require_auth(request)
    path = update_manager.update_log_path()
    if not path.is_file():
        return PlainTextResponse("Журнал установки пока пуст.")
    return FileResponse(path, media_type="text/plain; charset=utf-8", filename="vpn-service-update.log")


# Совместимость: старые клиенты /panel автоматически направляются на новые API-алиасы.
# Старое значение с /panel версия 2.6.4 исправляет автоматически
def can_publish_update(request: Request) -> bool:
    return bool(request.session.get("auth")) and update_manager.publisher_enabled()


@app.get("/updates", response_class=HTMLResponse)
def updates_page(request: Request):
    require_auth(request)
    info = update_manager.cached_update_info()
    status = update_manager.read_status()
    publisher = can_publish_update(request)
    local = update_manager.latest_local_update(verify=False) if publisher else None
    previous_versions = update_manager.list_preupdate_backups()
    rollback_candidate = previous_versions[0] if previous_versions else None
    busy = update_manager.update_job_busy(status)
    state_names = {
        "idle": "Ожидание",
        "queued": "В очереди",
        "checking": "Проверка версии",
        "downloading": "Скачивание",
        "verifying": "Проверка архива",
        "extracting": "Распаковка",
        "scheduled": "Запланировано",
        "installing": "Установка",
        "migrating": "Обновление базы",
        "rolling-back": "Восстановление предыдущей версии",
        "restarting": "Перезапуск служб",
        "health-check": "Проверка запуска",
        "completed": "Завершено",
        "failed": "Ошибка",
    }
    state_code = str(status.get("state") or "idle")
    state_text = state_names.get(state_code, state_code)
    state_badge_class = "bad" if state_code == "failed" else ("warn" if busy else "good")
    source_code = str(info.get("source") or "")
    source_text = {
        "local": "локальный архив главной панели",
        "remote": "главная панель обновлений",
    }.get(source_code, source_code or "—")
    configured_source = str(
        info.get("configured_master_url")
        or getattr(config, "UPDATE_MASTER_URL", "")
        or ""
    ).strip()
    metadata_url = str(info.get("metadata_url") or "").strip()
    source_details = ""
    if publisher:
        if source_code == "remote" and configured_source:
            source_details += f'<p>Настроено: <span class="code">{html.escape(configured_source)}</span></p>'
        if metadata_url:
            source_details += f'<p>Ответил API: <span class="code">{html.escape(metadata_url)}</span></p>'
    if info.get("fallback_used"):
        source_details += '<div class="notice">Старый суффикс /panel исправлен автоматически; обновление получено с корня этой же главной панели.</div>'
    state_badge = status_badge(bool(info.get("available")), "Доступно", "Актуально")
    installed_notes = update_manager.installed_changelog()
    installed_changelog_text = str(installed_notes.get("text") or "").strip()
    installed_changelog_version = str(installed_notes.get("version") or update_manager.current_version())
    installed_changelog_block = (
        f'<div class="card full changelog-card"><div class="section-title"><h2>Последняя установленная версия — {html.escape(installed_changelog_version)}</h2><span class="badge good">CHANGELOG</span></div><pre class="changelog">{html.escape(installed_changelog_text)}</pre></div>'
        if installed_changelog_text
        else ''
    )
    changelog_text = str(info.get("changelog") or "").strip()
    changelog_block = (
        f'<div class="card full changelog-card" style="color:var(--text);background:var(--panel);"><div class="section-title"><h2>Что изменилось в {html.escape(str(info.get("version") or "текущей версии"))}</h2><span class="badge good">CHANGELOG</span></div><pre class="changelog">{html.escape(changelog_text)}</pre></div>'
        if info.get("available") and changelog_text
        else ('<div class="card full"><h2>Что изменилось</h2><p class="muted">Для этой версии в релизном архиве не найден файл RELEASE_NOTES.</p></div>' if info.get("available") else '')
    )
    rollback_block = ''
    if rollback_candidate:
        rollback_block = f'''<div class="card full"><div class="section-title"><h2>Откат к предыдущей версии</h2><span class="badge warn">Резервная копия найдена</span></div>
<p>Последняя сохранённая версия: <strong>{html.escape(str(rollback_candidate.get("version") or "неизвестно"))}</strong> · {html.escape(str(rollback_candidate.get("filename") or ""))}</p>
<p class="muted">Откат восстанавливает файлы приложения и сохранённую systemd-конфигурацию перед обновлением.</p>
<form method="post" action="/updates/rollback" onsubmit="return confirm('Откатить систему к предыдущей сохранённой версии? Текущая версия будет заменена.')"><input type="hidden" name="backup_path" value="{html.escape(str(rollback_candidate.get("path") or ""), quote=True)}"><button class="danger" {'disabled' if busy else ''}>Откатить к {html.escape(str(rollback_candidate.get("version") or "предыдущей версии"))}</button></form></div>'''
    apply_form = (
        '<form id="apply-update-form" method="post" action="/updates/apply">'
        f'<button id="apply-update-button" data-confirm="Установить обновление и автоматически перезапустить службы?" {"disabled" if busy else ""}>'
        'Установить обновление</button></form>'
        if info.get("available")
        else '<form method="post" action="/updates/check"><button class="secondary">Проверить сейчас</button></form>'
    )
    manual_block = ""
    if publisher:
        token_fingerprint = hashlib.sha256(str(getattr(config, "UPDATE_API_TOKEN", "")).encode()).hexdigest()[:12]
        publisher_block = f'''<div class="card half"><h2>Главная панель обновлений</h2>
<p>Источник жёстко закреплён за логином <span class="code">{html.escape(update_manager.PUBLISHER_USERNAME)}</span>. Переключить другую панель в главную нельзя.</p>
<p>Опубликовано: <strong id="published-version">{html.escape(str(local.get('version') if local else 'нет'))}</strong></p>
<form id="publish-update-form" method="post" action="/updates/publish" enctype="multipart/form-data">
<div class="setting"><label>Полный архив релиза .tar.gz</label><input id="publish-archive" type="file" name="archive" accept=".tar.gz,application/gzip" required></div>
<button id="publish-button">Проверить и опубликовать</button>
<div id="upload-progress" class="file-progress"><div class="progress large"><span id="upload-progress-bar" style="width:0%"></span></div><div id="upload-progress-text" class="muted">Загрузка…</div></div>
</form><hr style="border:0;border-top:1px solid var(--line);margin:20px 0">
<form method="post" action="/updates/token"><div class="setting"><label>Общий API-токен главной и ведомых панелей</label><input name="api_token" type="password" minlength="32" required placeholder="Не менее 32 символов"><div class="muted" style="margin-top:5px">Текущий отпечаток: <span class="code">{token_fingerprint}</span></div></div><button class="secondary">Сменить общий токен</button></form></div>'''
    else:
        publisher_block = f'''<div class="card half"><h2>Источник обновлений</h2>
<p>Эта панель получает обновления с защищённого сервера обновлений.</p>
<p class="muted">Адрес и идентификатор главной панели скрыты от пользователей этой панели.</p></div>'''
        manual_block = f'''<div class="card full"><div class="section-title"><h2>Ручная установка архива</h2><span class="badge warn">Резервный способ</span></div>
<p class="muted">Можно загрузить полный архив релиза прямо на эту ведомую панель. Он проходит ту же проверку путей, специальных файлов, версии, размера и SHA-256, что и онлайн-обновление.</p>
<form id="manual-update-form" method="post" action="/updates/upload-and-apply" enctype="multipart/form-data">
<div class="setting"><label>Архив обновления .tar.gz</label><input id="manual-update-archive" type="file" name="archive" accept=".tar.gz,application/gzip" required></div>
<label class="check-row"><input type="checkbox" name="allow_reinstall" value="1"> Разрешить переустановку той же версии (использовать только для восстановления повреждённой установки)</label>
<button id="manual-update-button" {'disabled' if busy else ''}>Проверить файл и установить</button>
<div id="manual-upload-progress" class="file-progress"><div class="progress large"><span id="manual-upload-progress-bar" style="width:0%"></span></div><div id="manual-upload-progress-text" class="muted">Загрузка архива…</div></div>
</form></div>'''
    error = f'<div class="notice">{html.escape(str(info.get("error")))}</div>' if info.get("error") else ""
    progress_value = max(0, min(100, int(status.get("progress") or 0)))
    status_message = str(status.get("message") or status.get("detail") or "Установка ещё не запускалась")
    status_error = str(status.get("error") or "")
    progress_html = f"""<div class="card full update-progress-card"><div class="section-title"><h2>Ход установки</h2><span id="update-state" class="badge {state_badge_class}">{html.escape(state_text)}</span></div>
<div class="status-panel"><div class="progress large"><span id="update-progress-bar" style="width:{progress_value}%"></span></div><div class="progress-meta"><span id="update-message">{html.escape(status_message)}</span><strong id="update-progress-value">{progress_value}%</strong></div><div id="update-error" class="notice" style="{'display:block' if status_error else 'display:none'};margin-top:14px">{html.escape(status_error)}</div><p class="muted" id="update-connection-note">Страница продолжает опрос во время перезапуска веб-панели; ручное обновление не требуется.</p></div>
<p><a href="/api/updates/log" class="button secondary small" target="_blank">Открыть журнал установки</a></p></div>"""
    body = f"""<header><div><h1>Обновления</h1><div class="subtitle">Проверяемая установка с постоянным прогрессом и автоматическим восстановлением связи после перезапуска</div></div></header>{error}{progress_html}
<div class="grid"><div class="card half"><div class="section-title"><h2>Текущая установка</h2>{state_badge}</div>
<p>Установлено: <strong id="update-current-version">{html.escape(update_manager.current_version())}</strong></p>
<p>Доступная версия: <strong>{html.escape(str(info.get('version') or '—'))}</strong></p>
<p>Источник: <span class="code">{html.escape(source_text)}</span></p>{source_details}{apply_form}</div>{publisher_block}{installed_changelog_block}{changelog_block}{rollback_block}{manual_block}</div>"""
    initial = json.dumps(status, ensure_ascii=False, default=str).replace("<", "\\u003c")
    script = r'''<script>
(function(){
const initial=__INITIAL__;
const pageVersion=__PAGE_VERSION__;
const busyStates=new Set(['queued','checking','downloading','verifying','extracting','scheduled','installing','migrating','rolling-back','restarting','health-check']);
const stateLabels={idle:'Ожидание',queued:'В очереди',checking:'Проверка версии',downloading:'Скачивание',verifying:'Проверка архива',extracting:'Распаковка',scheduled:'Запланировано',installing:'Установка',migrating:'Обновление базы','rolling-back':'Восстановление предыдущей версии',restarting:'Перезапуск служб','health-check':'Проверка запуска',completed:'Завершено',failed:'Ошибка'};
const phaseCaps={queue:3,acknowledged:4,check:7,download:30,verify:32,extract:49,install:52,dependencies:59,'stop-services':63,backup:69,files:74,python:84,database:90,services:95,restart:97,health:99,complete:100,failed:99};
let lastStatus=initial||{};let lastState=String(lastStatus.state||'idle');let currentJob=String(lastStatus.job_id||'');let serverProgress=Math.max(0,Math.min(100,Number(lastStatus.progress||0)));let shownProgress=serverProgress;let goalProgress=serverProgress;let lastServerUpdate=performance.now();let reloadScheduled=false;
const bar=document.getElementById('update-progress-bar');const value=document.getElementById('update-progress-value');const note=document.getElementById('update-connection-note');
function paintProgress(){if(bar)bar.style.width=shownProgress.toFixed(2)+'%';if(value)value.textContent=Math.floor(shownProgress)+'%';}
function animateProgress(now){if(busyStates.has(lastState)){const cap=Math.max(serverProgress,Number(phaseCaps[String(lastStatus.phase||'')]||serverProgress));const elapsed=Math.max(0,(now-lastServerUpdate)/1000);const span=Math.max(0,cap-serverProgress);const interpolated=serverProgress+span*(1-Math.exp(-elapsed/7));goalProgress=Math.max(goalProgress,Math.min(cap,interpolated));}else{goalProgress=serverProgress;}const delta=goalProgress-shownProgress;if(Math.abs(delta)>0.015){if(delta>0)shownProgress+=Math.min(delta,Math.max(0.035,delta*0.075));else shownProgress=Math.max(goalProgress,shownProgress-Math.max(0.1,Math.abs(delta)*0.2));paintProgress();}requestAnimationFrame(animateProgress);}
function setRequestError(text){const error=document.getElementById('update-error');if(error){error.textContent=text||'';error.style.display=text?'block':'none';}if(note&&text)note.textContent='Задача не была подтверждена сервером. Исправьте указанную ошибку и повторите запуск.';}
function renderStatus(data){data=data||{};const nextJob=String(data.job_id||currentJob||'');const nextProgress=Math.max(0,Math.min(100,Number(data.progress||0)));if(nextJob&&currentJob&&nextJob!==currentJob){shownProgress=nextProgress;goalProgress=nextProgress;}currentJob=nextJob;serverProgress=nextProgress;goalProgress=Math.max(goalProgress,serverProgress);lastServerUpdate=performance.now();lastStatus=data;lastState=String(data.state||'idle');const message=document.getElementById('update-message');if(message)message.textContent=data.message||data.detail||'Ожидание запуска';const badge=document.getElementById('update-state');if(badge){badge.textContent=stateLabels[lastState]||lastState||'Ожидание';badge.className='badge '+(lastState==='failed'?'bad':(lastState==='completed'||lastState==='idle'?'good':'warn'));}const error=document.getElementById('update-error');if(error){error.textContent=data.error||'';error.style.display=data.error?'block':'none';}const busy=busyStates.has(lastState);if(bar)bar.classList.toggle('active',busy);if(lastState==='completed'){serverProgress=100;goalProgress=100;shownProgress=100;}const apply=document.getElementById('apply-update-button');if(apply)apply.disabled=busy;const manual=document.getElementById('manual-update-button');if(manual)manual.disabled=busy;const version=document.getElementById('update-current-version');if(version&&data.installed_version)version.textContent=data.installed_version;if(note)note.textContent='Статус получен: '+(data.updated_at||'только что')+'. Во время перезапуска подключение восстановится автоматически.';if(data.installed_version&&String(data.installed_version)!==String(pageVersion)&&!reloadScheduled){reloadScheduled=true;if(note)note.textContent='Веб-панель уже запущена на новой версии. Переподключаем интерфейс без ручной перезагрузки…';setTimeout(()=>{window.location.replace('/updates?installed='+encodeURIComponent(String(data.installed_version))+'&job='+encodeURIComponent(currentJob));},900);}paintProgress();return data;}
async function fetchStatus(){const response=await fetch('/api/updates/status',{cache:'no-store',credentials:'same-origin'});if(!response.ok)throw new Error('HTTP '+response.status);return renderStatus(await response.json());}
function scheduleStatusCheck(delay){setTimeout(()=>{fetchStatus().catch(()=>{});},Math.max(0,Number(delay)||0));}
async function poll(){try{await fetchStatus();}catch(_error){if(note)note.textContent='Веб-панель перезапускается или временно недоступна. Повторное подключение выполняется автоматически…';}finally{setTimeout(poll,busyStates.has(lastState)?850:4000);}}
function optimisticStart(messageText){lastState='queued';lastStatus={...lastStatus,state:'queued',phase:'queue',message:messageText||'Запрос отправлен; ожидается подтверждение фоновой задачи'};serverProgress=Math.max(1,Math.min(serverProgress||1,3));goalProgress=Math.max(goalProgress,serverProgress);const message=document.getElementById('update-message');if(message)message.textContent=lastStatus.message;const badge=document.getElementById('update-state');if(badge){badge.textContent='В очереди';badge.className='badge warn';}if(bar)bar.classList.add('active');setRequestError('');if(note)note.textContent='Запрос передан серверу. Даже если веб-служба перезапустится до HTTP-ответа, статус будет восстановлен из файла задачи.';}
const applyForm=document.getElementById('apply-update-form');
if(applyForm)applyForm.addEventListener('submit',async(event)=>{event.preventDefault();if(!window.confirm('Установить обновление и автоматически перезапустить службы?'))return;const button=document.getElementById('apply-update-button');if(button)button.disabled=true;optimisticStart('Запрос на онлайн-обновление отправлен');try{const response=await fetch('/updates/apply',{method:'POST',headers:{Accept:'application/json'},credentials:'same-origin',keepalive:true});let data={};try{data=await response.json();}catch(_e){}if(!response.ok){setRequestError(data.detail||data.error||'Сервер отклонил запуск обновления');lastState=String((lastStatus&&lastStatus.state)||'idle');if(button)button.disabled=false;return;}renderStatus(data.status||data);scheduleStatusCheck(250);}catch(_error){if(note)note.textContent='HTTP-ответ прервался во время запуска. Это не считается ошибкой установки: проверяем постоянный статус задачи…';scheduleStatusCheck(600);}});
const publishForm=document.getElementById('publish-update-form');
if(publishForm)publishForm.addEventListener('submit',(event)=>{event.preventDefault();const xhr=new XMLHttpRequest();const progress=document.getElementById('upload-progress');const uploadBar=document.getElementById('upload-progress-bar');const text=document.getElementById('upload-progress-text');const button=document.getElementById('publish-button');progress.classList.add('visible');button.disabled=true;text.textContent='Загрузка архива…';xhr.open('POST','/updates/publish');xhr.setRequestHeader('Accept','application/json');xhr.upload.onprogress=(e)=>{if(e.lengthComputable){const p=Math.round(e.loaded/e.total*100);uploadBar.style.width=p+'%';text.textContent='Загружено '+p+'%';}};xhr.onload=()=>{button.disabled=false;let data={};try{data=JSON.parse(xhr.responseText);}catch(_e){}if(xhr.status>=200&&xhr.status<300){uploadBar.style.width='100%';text.textContent='Архив проверен и опубликован: '+(data.version||'готово');const published=document.getElementById('published-version');if(published&&data.version)published.textContent=data.version;}else{text.textContent='Ошибка: '+(data.detail||data.error||'HTTP '+xhr.status);}};xhr.onerror=()=>{button.disabled=false;text.textContent='Ошибка соединения при загрузке';};xhr.send(new FormData(publishForm));});
const manualForm=document.getElementById('manual-update-form');
if(manualForm)manualForm.addEventListener('submit',(event)=>{event.preventDefault();if(!window.confirm('Проверить загруженный архив и установить его на этой панели?'))return;const xhr=new XMLHttpRequest();const progress=document.getElementById('manual-upload-progress');const uploadBar=document.getElementById('manual-upload-progress-bar');const text=document.getElementById('manual-upload-progress-text');const button=document.getElementById('manual-update-button');progress.classList.add('visible');button.disabled=true;text.textContent='Загрузка архива на панель…';xhr.open('POST','/updates/upload-and-apply');xhr.setRequestHeader('Accept','application/json');xhr.upload.onprogress=(e)=>{if(e.lengthComputable){const p=Math.round(e.loaded/e.total*100);uploadBar.style.width=p+'%';text.textContent='Загружено '+p+'%';}};xhr.onload=()=>{let data={};try{data=JSON.parse(xhr.responseText);}catch(_e){}if(xhr.status>=200&&xhr.status<300){uploadBar.style.width='100%';text.textContent='Архив проверен; установка запущена';optimisticStart('Ручной архив принят, запускается фоновая установка');renderStatus(data.status||data);scheduleStatusCheck(250);}else{button.disabled=false;text.textContent='Ошибка: '+(data.detail||data.error||'HTTP '+xhr.status);setRequestError(data.detail||data.error||'Архив не принят');}};xhr.onerror=()=>{optimisticStart('Загрузка завершилась разрывом соединения; проверяется статус задачи');text.textContent='Соединение прервалось. Если архив был принят, прогресс появится автоматически.';scheduleStatusCheck(700);};xhr.send(new FormData(manualForm));});
renderStatus(initial);requestAnimationFrame(animateProgress);setTimeout(poll,450);
})();
</script>'''.replace('__INITIAL__', initial).replace('__PAGE_VERSION__', json.dumps(update_manager.current_version()))
    return page(request, "Обновления", body, "updates", script)

@app.post("/updates/check")
def updates_check(request: Request):
    require_auth(request)
    info = update_manager.check_available_update(force=True)
    if info.get("available"):
        set_flash(request, f"Доступно обновление {info.get('version')}")
    elif info.get("error"):
        set_flash(request, str(info["error"]), "bad")
    else:
        set_flash(request, "Установлена актуальная версия")
    return RedirectResponse("/updates", 303)


@app.post("/updates/config")
def updates_config(
    request: Request,
    master_url: str = Form(),
    api_token: str = Form(""),
    verify_tls: str | None = Form(None),
):
    require_auth(request)
    if update_manager.publisher_enabled():
        raise HTTPException(403, "Главная панель закреплена за пользователем menshikovivan")
    validated_master_url = _http_url(master_url, "URL главной панели")
    try:
        validated_master_url = update_manager.normalize_master_url(validated_master_url)
    except update_manager.UpdateError as error:
        raise HTTPException(400, f"URL главной панели: {error}") from error
    values: dict[str, Any] = {
        "UPDATE_MASTER_URL": validated_master_url,
        "UPDATE_VERIFY_TLS": verify_tls == "1",
    }
    token = api_token.strip()
    if token:
        if len(token) < 32:
            raise HTTPException(400, "API-токен должен содержать не менее 32 символов")
        values["UPDATE_API_TOKEN"] = token
    save_config_values(values)
    audit(str(request.session.get("user", "web")), "update_source_changed", values["UPDATE_MASTER_URL"])
    set_flash(request, "Источник обновлений сохранён; веб-панель перезапускается")
    schedule_restart(["vpn-service-web"], delay=2)
    return RedirectResponse("/updates", 303)


@app.post("/updates/token")
def updates_token(request: Request, api_token: str = Form()):
    require_auth(request)
    if not can_publish_update(request):
        raise HTTPException(403, "Токен настраивается на главной панели")
    token = api_token.strip()
    if len(token) < 32:
        set_flash(request, "API-токен должен содержать не менее 32 символов", "bad")
        return RedirectResponse("/updates", 303)
    save_config_values({"UPDATE_API_TOKEN": token})
    audit(str(request.session.get("user", "web")), "update_api_token_changed")
    set_flash(request, "Общий API-токен сохранён; укажите его на ведомых панелях")
    schedule_restart(["vpn-service-web"], delay=2)
    return RedirectResponse("/updates", 303)


@app.post("/updates/role")
def updates_role(request: Request, publisher: str = Form("0")):
    require_auth(request)
    set_flash(
        request,
        "Роль обновлений больше не переключается вручную: только панель menshikovivan является главной.",
        "bad",
    )
    return RedirectResponse("/updates", 303)

@app.post("/updates/publish")
async def updates_publish(request: Request, archive: UploadFile = File(...)):
    require_auth(request)
    wants_json = "application/json" in request.headers.get("accept", "")
    if not can_publish_update(request):
        raise HTTPException(403, "Публикация доступна только главной панели menshikovivan")
    max_size = max(1, int(getattr(config, "UPDATE_MAX_ARCHIVE_MB", 1024))) * 1024 * 1024
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(prefix="vpn_update_upload_", suffix=".tar.gz", delete=False) as handle:
            temp_path = Path(handle.name)
            total = 0
            while True:
                chunk = await archive.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_size:
                    raise update_manager.UpdateError("Архив превышает допустимый размер")
                handle.write(chunk)
        metadata = update_manager.publish_update(temp_path, archive.filename or "update.tar.gz")
        audit(str(request.session.get("user", "web")), "publish_update", str(metadata.get("version")))
        if wants_json:
            return JSONResponse({"ok": True, **update_manager.api_metadata(metadata)})
        set_flash(request, f"Обновление {metadata.get('version')} опубликовано")
    except Exception as error:
        if wants_json:
            return JSONResponse({"ok": False, "detail": str(error)}, status_code=400)
        set_flash(request, f"Архив отклонён: {error}", "bad")
    finally:
        if temp_path:
            temp_path.unlink(missing_ok=True)
        await archive.close()
    return RedirectResponse("/updates", 303)


@app.post("/updates/upload-and-apply")
async def updates_upload_and_apply(
    request: Request,
    archive: UploadFile = File(...),
    allow_reinstall: str | None = Form(None),
):
    """Validate a locally uploaded release and install it on a follower panel."""
    require_auth(request)
    if update_manager.publisher_enabled():
        raise HTTPException(403, "На главной панели используйте публикацию архива")
    if update_manager.update_job_busy():
        return JSONResponse(
            {"ok": False, "detail": "Другая установка обновления уже выполняется"},
            status_code=409,
        )
    max_size = max(1, int(getattr(config, "UPDATE_MAX_ARCHIVE_MB", 1024))) * 1024 * 1024
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(prefix="vpn_manual_update_", suffix=".tar.gz", delete=False) as handle:
            temp_path = Path(handle.name)
            total = 0
            while True:
                chunk = await archive.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_size:
                    raise update_manager.UpdateError("Архив превышает допустимый размер")
                handle.write(chunk)
        metadata = update_manager.store_manual_update(
            temp_path,
            archive.filename or "update.tar.gz",
            allow_reinstall=allow_reinstall == "1",
        )
        actor = str(request.session.get("user", "web"))
        job = update_manager.start_update_job(actor, update_info=metadata)
        status = update_manager.read_status()
        audit(actor, "manual_update_uploaded", f"{metadata.get('version')}:{metadata.get('sha256')}")
        return JSONResponse(
            {"ok": True, "version": metadata.get("version"), "job": job, "status": status},
            status_code=202,
        )
    except update_manager.UpdateError as error:
        return JSONResponse({"ok": False, "detail": str(error)}, status_code=409)
    finally:
        if temp_path:
            temp_path.unlink(missing_ok=True)
        await archive.close()

@app.post("/updates/apply")
def updates_apply(request: Request):
    require_auth(request)
    wants_json = "application/json" in request.headers.get("accept", "")
    try:
        info = update_manager.check_available_update(force=True)
        if not info.get("available"):
            raise update_manager.UpdateError(str(info.get("error") or "Новой версии нет"))
        job = update_manager.start_update_job(
            str(request.session.get("user", "web")),
            update_info=info,
        )
        audit(str(request.session.get("user", "web")), "apply_update", str(info.get("version")))
        status = update_manager.read_status()
        if wants_json:
            return JSONResponse({"ok": True, "job": job, "status": status}, status_code=202)
        set_flash(request, f"Обновление {info.get('version')} запущено; прогресс появится на этой странице")
    except Exception as error:
        if wants_json:
            return JSONResponse({"ok": False, "detail": str(error)}, status_code=409)
        set_flash(request, f"Не удалось запустить обновление: {error}", "bad")
    return RedirectResponse("/updates", 303)

@app.post("/updates/rollback")
def updates_rollback(request: Request, backup_path: str = Form(...)):
    require_auth(request)
    wants_json = "application/json" in request.headers.get("accept", "")
    try:
        job = update_manager.start_rollback_job(str(request.session.get("user", "web")), backup_path)
        audit(str(request.session.get("user", "web")), "rollback_update", Path(backup_path).name)
        status = update_manager.read_status()
        if wants_json:
            return JSONResponse({"ok": True, "job": job, "status": status}, status_code=202)
        set_flash(request, "Откат запущен; дождитесь завершения проверки служб")
    except Exception as error:
        if wants_json:
            return JSONResponse({"ok": False, "detail": str(error)}, status_code=409)
        set_flash(request, f"Не удалось запустить откат: {error}", "bad")
    return RedirectResponse("/updates", 303)

@app.get("/diagnostics", response_class=HTMLResponse)
def diagnostics(request: Request):
    require_auth(request)
    units = {
        name: service_state(name)
        for name in (
            "vpn-service-bot",
            "vpn-service-web",
            "vpn-service-backup.timer",
            "vpn-service-reminders.timer",
        )
    }
    try:
        snapshot = fetch_and_sync(force=True, db_path=config.DB_PATH)
        api_ok = not bool(snapshot.get("stale"))
        api_text = "Подключено" if api_ok else str(snapshot.get("error") or "Доступен только кэш")
    except Exception as error:
        snapshot = {"stale": True, "error": str(error), "clients": []}
        api_ok, api_text = False, str(error)
    try:
        tg = httpx.get(f"https://api.telegram.org/bot{config.BOT_TOKEN}/getMe", timeout=10).json()
        tg_ok = bool(tg.get("ok"))
        tg_text = "Подключено" if tg_ok else str(tg.get("description") or tg)
    except Exception:
        tg_ok, tg_text = False, "Ошибка подключения к Telegram API"
    try:
        tesseract_path = shutil.which("tesseract")
        if not tesseract_path:
            raise RuntimeError("команда tesseract не найдена")
        language_result = subprocess.run(
            [tesseract_path, "--list-langs"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        available_languages = {
            line.strip() for line in language_result.stdout.splitlines() if line.strip()
        }
        required_languages = {
            item for item in str(getattr(config, "RECEIPT_OCR_LANGUAGES", "rus+eng")).split("+") if item
        }
        missing_languages = sorted(required_languages - available_languages)
        ocr_ok = language_result.returncode == 0 and not missing_languages
        ocr_text = (
            "Tesseract доступен: " + ", ".join(sorted(required_languages))
            if ocr_ok
            else "Не найдены языки: " + ", ".join(missing_languages)
        )
    except Exception as error:
        ocr_ok, ocr_text = False, str(error)
    audit_result = service_audit.audit()
    update_info = update_manager.check_available_update(force=True)
    local_report = platform_diagnostics.build_report(
        snapshot=snapshot, db_path=config.DB_PATH, update_info=update_info
    )
    db_report = local_report["database"]
    storage_report = local_report["storage"]
    permissions_report = local_report["config_permissions"]
    update_report = local_report["updates"]
    publisher = update_manager.publisher_enabled()
    update_report = update_topology_public(update_report, publisher)
    traffic_report = local_report["traffic"]
    checks_data = [
        ("Telegram-бот", units["vpn-service-bot"] == "active", units["vpn-service-bot"]),
        ("Веб-панель", units["vpn-service-web"] == "active", units["vpn-service-web"]),
        ("3x-ui API", api_ok, api_text),
        ("Telegram API", tg_ok, tg_text),
        ("OCR чеков", ocr_ok, ocr_text),
        ("Таймер бэкапа", units["vpn-service-backup.timer"] == "active", units["vpn-service-backup.timer"]),
        ("Напоминания", units["vpn-service-reminders.timer"] == "active", units["vpn-service-reminders.timer"]),
        ("Дубликаты запуска", bool(audit_result.get("healthy")), "Не обнаружены" if audit_result.get("healthy") else "Обнаружены"),
        (
            "SQLite",
            bool(db_report.get("healthy")),
            f"quick_check={db_report.get('quick_check')}; journal={db_report.get('journal_mode')}",
        ),
        (
            "Свободное место",
            bool(storage_report.get("healthy")),
            f"Свободно {fmt_bytes(int(storage_report.get('free') or 0))} ({storage_report.get('free_percent')}%)",
        ),
        (
            "Права config.py",
            bool(permissions_report.get("healthy")),
            f"Режим {permissions_report.get('mode')}",
        ),
        (
            "Схема обновлений",
            bool(update_report.get("healthy")),
            "Главная панель" if update_report.get("role") == "publisher" else "Ведомая панель",
        ),
    ]
    checks = "".join(
        f'<div class="card metric"><div class="label">{html.escape(label)}</div><div class="value" style="font-size:20px">{status_badge(ok,"Работает","Ошибка")}</div><div class="hint">{html.escape(detail)}</div></div>'
        for label, ok, detail in checks_data
    )
    unit_rows = "".join(
        f'<tr><td>{html.escape(unit.get("name", ""))}</td><td>{html.escape(unit.get("active", ""))}</td><td>{html.escape(unit.get("enabled", ""))}</td><td>{"Да" if unit.get("canonical") else "Нет"}</td><td>{html.escape(unit.get("working_directory", ""))}</td></tr>'
        for unit in audit_result.get("units", [])
    )
    process_rows = "".join(
        f'<tr><td>{process.get("pid")}</td><td>{html.escape(process.get("command", ""))}</td></tr>'
        for process in audit_result.get("processes", [])
    )
    duplicate_details = html.escape(
        json.dumps(
            {
                "duplicate_units": audit_result.get("duplicate_units", []),
                "duplicate_processes": audit_result.get("duplicate_processes", {}),
                "cron_references": audit_result.get("cron_references", []),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    identity_ok = (
        int(db_report.get("placeholder_tg_ids") or 0) == 0
        and int(db_report.get("missing_usernames") or 0) == 0
        and int(db_report.get("duplicate_emails") or 0) == 0
        and int(db_report.get("duplicate_uuids") or 0) == 0
    )
    update_errors = update_report.get("errors") or []
    update_warnings = update_report.get("warnings") or []
    update_error_html = (
        "<div class=\"notice\">" + html.escape("; ".join(map(str, update_errors))) + "</div>"
        if update_errors else ""
    )
    update_warning_html = (
        "<div class=\"notice\">" + html.escape("; ".join(map(str, update_warnings))) + "</div>"
        if update_warnings else ""
    )
    update_endpoint_html = "".join(
        f'<li><span class="code">{html.escape(str(endpoint))}</span></li>'
        for endpoint in update_report.get("candidate_endpoints", [])
    )
    if update_endpoint_html:
        update_endpoint_html = f'<p>Проверяемые API:</p><ul>{update_endpoint_html}</ul>'
    resolved_update_html = ""
    if update_report.get("metadata_url"):
        resolved_update_html = (
            '<p>Ответил API: <span class="code">'
            + html.escape(str(update_report.get("metadata_url")))
            + '</span></p>'
        )
    last_update = update_report.get("last_status") if isinstance(update_report.get("last_status"), dict) else {}
    last_update_html = (
        '<p>Последняя задача: <span class="code">'
        + html.escape(str(last_update.get("job_id") or "—"))
        + '</span> · состояние <b>'
        + html.escape(str(last_update.get("state") or "idle"))
        + '</b> · этап '
        + html.escape(str(last_update.get("phase") or "—"))
        + ' · прогресс '
        + html.escape(str(int(last_update.get("progress") or 0)))
        + '% · запуск '
        + html.escape(str(last_update.get("launcher") or "—"))
        + ' · обновлено '
        + html.escape(str(last_update.get("updated_at") or "—"))
        + '</p>'
    )
    traffic_note = (
        "Главный виджет платформы использует netTraffic из server/status — тот же тип счётчика, что главная страница 3x-ui. "
        "Inbound хранит суммарную историю входящих подключений, а список пользователей — дедуплицированную детализацию; "
        "поэтому эти три значения не обязаны совпадать."
        if traffic_report.get("server_counter_available")
        else
        "Эта версия 3x-ui не вернула server/status, поэтому главный виджет использует резервную сумму inbound. "
        "Пользовательская сумма дедуплицирована и предназначена только для детализации."
    )
    if publisher:
        update_topology_html = (
            '<p>Локальный пользователь панели: <span class="code">'
            + html.escape(str(update_report.get("username") or "—"))
            + '</span></p><p>Источник: <span class="code">'
            + html.escape(str(update_report.get("master_url") or "локальный издатель"))
            + '</span></p>'
            + update_endpoint_html + resolved_update_html + last_update_html
            + '<p class="muted">Сетевые адреса источника доступны только издателю.</p>'
        )
    else:
        update_topology_html = (
            '<p>Проверка канала обновлений выполнена. Адрес и идентификатор главной панели скрыты.</p>'
            '<p class="muted">Для управления источником обновлений обратитесь к владельцу главной панели.</p>'
        )
    body = f'''<header><div><h1>Диагностика</h1><div class="subtitle">Службы, база, Telegram-привязки, обновления и сверка трафика</div></div><div class="actions"><a class="button secondary" href="/api/diagnostics" target="_blank">JSON-отчёт</a><form method="post" action="/diagnostics/fix-duplicates"><button class="secondary">Удалить дубли запусков</button></form><form method="post" action="/service/all/restart"><button>Перезапустить всё</button></form></div></header>
<div class="grid">{checks}
<div class="card half"><div class="section-title"><h2>Telegram-привязки</h2>{status_badge(identity_ok, "Готово", "Нужна проверка")}</div><div class="numbers"><div><small>Всего</small><strong>{db_report.get('users', 0)}</strong></div><div><small>Положительный TG ID</small><strong>{db_report.get('positive_tg_ids', 0)}</strong></div><div><small>Временный ID</small><strong>{db_report.get('placeholder_tg_ids', 0)}</strong></div></div><p class="muted">Без ника: {db_report.get('missing_usernames', 0)} · без email: {db_report.get('missing_emails', 0)} · без UUID: {db_report.get('missing_uuids', 0)} · дубли email/UUID: {db_report.get('duplicate_emails', 0)}/{db_report.get('duplicate_uuids', 0)}</p><div class="actions"><a class="button small" href="/users/import-identities">Восстановить из старой БД</a><a class="button small secondary" href="/users">Проверить вручную</a></div></div>
<div class="card half"><div class="section-title"><h2>Защита и журнал</h2>{status_badge(True, "Включено", "Ошибка")}</div><div class="numbers"><div><small>Активные блокировки</small><strong>{db_report.get('blocked_logins', 0)}</strong></div><div><small>События пользователей</small><strong>{db_report.get('events', 0)}</strong></div><div><small>Размер БД</small><strong>{fmt_bytes(int(db_report.get('size') or 0))}</strong></div></div><p class="muted">Лимит применяется одновременно к паре IP + логин и ко всем попыткам с одного IP, поэтому смена вводимого логина не обходит блокировку. Состояние сохраняется после перезапуска.</p></div>
<div class="card full"><div class="section-title"><h2>Сверка трафика 3x-ui</h2>{status_badge(bool(traffic_report.get('healthy')), "Актуально", "Кэш/ошибка")}</div><div class="numbers"><div><small>Главная 3x-ui</small><strong>{fmt_bytes(int(traffic_report.get('server_used') or 0)) if traffic_report.get('server_counter_available') else 'Нет данных'}</strong></div><div><small>История inbound</small><strong>{fmt_bytes(int(traffic_report.get('inbound_used') or 0))}</strong></div><div><small>По пользователям</small><strong>{fmt_bytes(int(traffic_report.get('client_used') or 0))}</strong></div><div><small>Удалено повторов</small><strong>{traffic_report.get('duplicate_records_removed', 0)}</strong></div></div><p class="muted">Разница main↔users: {fmt_bytes(abs(int(traffic_report.get('dashboard_difference') or 0)))} · inbound↔users: {fmt_bytes(abs(int(traffic_report.get('difference') or 0)))} · пользователей: {traffic_report.get('clients', 0)}.</p><div class="notice">{html.escape(traffic_note)}</div></div>
<div class="card full"><div class="section-title"><h2>Обновления</h2><span class="badge {'good' if update_report.get('healthy') else 'bad'}">{html.escape('Издатель' if publisher else 'Ведомая панель')}</span></div>{update_error_html}{update_warning_html}{update_topology_html}</div><div class="card full table-wrap"><div class="section-title"><h2>Связанные systemd units</h2></div><table><thead><tr><th>Unit</th><th>Active</th><th>Enabled</th><th>Штатный</th><th>Рабочая папка</th></tr></thead><tbody>{unit_rows or '<tr><td colspan="5">systemd недоступен или units не найдены.</td></tr>'}</tbody></table></div>
<div class="card full table-wrap"><div class="section-title"><h2>Запущенные процессы проекта</h2></div><table><thead><tr><th>PID</th><th>Команда</th></tr></thead><tbody>{process_rows or '<tr><td colspan="2">Процессы не найдены.</td></tr>'}</tbody></table></div>
<div class="card full"><h2>Детали дубликатов</h2><pre>{duplicate_details}</pre></div><div class="card full"><h2>Сведения</h2><p>Версия: {html.escape(update_manager.current_version())}</p><p>Порт: {config.WEB_PORT}</p><p>База: {html.escape(str(config.DB_PATH))}</p><p>3x-ui DB: {html.escape(str(config.XUI_DB_PATH))}</p><p><a href="/health">Проверить /health</a></p></div></div>'''
    return page(request, "Диагностика", body, "diagnostics")


@app.get("/api/diagnostics")
def diagnostics_api(request: Request):
    require_auth(request)
    try:
        snapshot = fetch_and_sync(force=True, db_path=config.DB_PATH)
    except Exception as error:
        snapshot = {"stale": True, "error": str(error), "clients": []}
    update_info = update_manager.check_available_update(force=True)
    publisher = update_manager.publisher_enabled()
    report = platform_diagnostics.build_report(snapshot=snapshot, db_path=config.DB_PATH, update_info=update_info)
    report["updates"] = update_topology_public(report.get("updates") or {}, publisher)
    return report


@app.post("/diagnostics/fix-duplicates")
def diagnostics_fix_duplicates(request: Request):
    require_auth(request)
    result = service_audit.fix()
    actions = result.get("actions", [])
    if actions:
        set_flash(request, "Устранено: " + "; ".join(map(str, actions)))
    elif result.get("after", {}).get("healthy"):
        set_flash(request, "Дублирующие службы и cron-задания не обнаружены")
    else:
        set_flash(request, "Часть дублей требует ручной проверки процессов", "bad")
    audit(str(request.session.get("user", "web")), "fix_duplicate_services", json.dumps(actions, ensure_ascii=False))
    return RedirectResponse("/diagnostics", 303)


@app.post("/service/{target}/restart")
def restart_service(request: Request, target: str):
    require_auth(request)
    mapping = {
        "bot": ["vpn-service-bot"],
        "web": ["vpn-service-web"],
        "all": ["vpn-service-bot", "vpn-service-web", "vpn-service-backup.timer", "vpn-service-reminders.timer"],
    }
    units = mapping.get(target)
    if not units:
        raise HTTPException(404)
    audit(str(request.session.get("user", "web")), "restart_service", target)
    set_flash(request, "Службы перезапускаются")
    schedule_restart(units, delay=2)
    return RedirectResponse("/diagnostics" if target == "all" else "/", 303)


@app.post("/sync")
def sync(request: Request):
    require_auth(request)
    try:
        snapshot = fetch_and_sync(force=True, db_path=config.DB_PATH)
        if snapshot.get("stale"):
            raise RuntimeError(str(snapshot.get("error") or "3x-ui API недоступна"))
        set_flash(request, f"Получены актуальные данные: {len(snapshot.get('clients', []))} пользователей")
    except Exception as error:
        set_flash(request, f"Синхронизация не выполнена: {error}", "bad")
    referer = request.headers.get("referer", "/")
    parsed = urlsplit(referer)
    destination = parsed.path or "/"
    if parsed.query:
        destination += f"?{parsed.query}"
    return RedirectResponse(destination, 303)


@app.get("/health", response_class=PlainTextResponse)
def health():
    return f"OK {config.SERVICE_NAME} Web Panel v{update_manager.current_version()}"
