"""Persistent lightweight notifications shown in the web control panel.

Message unread state lives in :mod:`user_events`. This module keeps compact
cursors for other panel events that already have durable source tables. Payment
notifications are derived from the monotonically increasing ``payments.id`` so
no extra write is required in the Telegram receipt handler.
"""
from __future__ import annotations

import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

import config

_SCHEMA_LOCK = threading.Lock()
_SCHEMA_READY: set[str] = set()
PAYMENTS_CHANNEL = "payments"


def _db_path(db_path: str | Path | None = None) -> str:
    return str(db_path or config.DB_PATH)


@contextmanager
def _connect(db_path: str | Path | None = None) -> Iterator[sqlite3.Connection]:
    path = Path(_db_path(db_path))
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(path), timeout=20)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA busy_timeout=20000")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def _table_exists(connection: sqlite3.Connection, name: str) -> bool:
    return bool(
        connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (str(name),)
        ).fetchone()
    )


def _columns(connection: sqlite3.Connection, table: str) -> set[str]:
    return {str(row[1]) for row in connection.execute(f"PRAGMA table_info({table})")}


def ensure_schema(db_path: str | Path | None = None) -> None:
    key = str(Path(_db_path(db_path)).resolve())
    if key in _SCHEMA_READY:
        return
    with _SCHEMA_LOCK:
        if key in _SCHEMA_READY:
            return
        with _connect(db_path) as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS panel_notification_state (
                    channel TEXT PRIMARY KEY,
                    last_read_id INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
            state_columns = _columns(connection, "panel_notification_state")
            if "last_read_id" not in state_columns:
                connection.execute(
                    "ALTER TABLE panel_notification_state ADD COLUMN last_read_id INTEGER NOT NULL DEFAULT 0"
                )
            if "updated_at" not in state_columns:
                connection.execute(
                    "ALTER TABLE panel_notification_state ADD COLUMN updated_at TEXT"
                )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_panel_notification_state_updated
                ON panel_notification_state(updated_at)
                """
            )
            # The first migration must not turn all historical receipts into new
            # alerts. If the cursor row is absent, baseline it at the current max.
            baseline = 0
            if _table_exists(connection, "payments"):
                baseline = int(
                    connection.execute("SELECT COALESCE(MAX(id),0) FROM payments").fetchone()[0]
                    or 0
                )
            connection.execute(
                """
                INSERT OR IGNORE INTO panel_notification_state(channel,last_read_id,updated_at)
                VALUES(?,?,CURRENT_TIMESTAMP)
                """,
                (PAYMENTS_CHANNEL, baseline),
            )
        _SCHEMA_READY.add(key)


def _with_busy_retry(operation):
    for attempt in range(5):
        try:
            return operation()
        except sqlite3.OperationalError as error:
            message = str(error).lower()
            if attempt >= 4 or not any(token in message for token in ("locked", "busy")):
                raise
            time.sleep(0.04 * (2 ** attempt))
    raise RuntimeError("Не удалось обновить уведомления панели")


def payment_notifications_summary(
    *,
    db_path: str | Path | None = None,
) -> dict[str, Any]:
    """Return unread payment count and a compact preview of the newest receipt."""
    ensure_schema(db_path)
    with _connect(db_path) as connection:
        if not _table_exists(connection, "payments"):
            return {"total": 0, "last_payment_id": 0, "latest": None}
        state = connection.execute(
            "SELECT last_read_id FROM panel_notification_state WHERE channel=?",
            (PAYMENTS_CHANNEL,),
        ).fetchone()
        last_read = max(0, int(state["last_read_id"] or 0)) if state else 0
        totals = connection.execute(
            "SELECT COUNT(*), COALESCE(MAX(id),0) FROM payments WHERE id>?",
            (last_read,),
        ).fetchone()
        payment_columns = _columns(connection, "payments")
        username_expr = "COALESCE(username,'')" if "username" in payment_columns else "''"
        amount_expr = "amount" if "amount" in payment_columns else "NULL"
        receipt_amount_expr = (
            "receipt_amount" if "receipt_amount" in payment_columns else "NULL"
        )
        status_expr = "status" if "status" in payment_columns else "'pending'"
        created_expr = "created_at" if "created_at" in payment_columns else "''"
        tg_expr = "tg_id" if "tg_id" in payment_columns else "0"
        latest = connection.execute(
            f"""
            SELECT id,{tg_expr} AS tg_id,{username_expr} AS username,
                   {amount_expr} AS amount,{receipt_amount_expr} AS receipt_amount,
                   {status_expr} AS status,{created_expr} AS created_at
            FROM payments WHERE id>? ORDER BY id DESC LIMIT 1
            """,
            (last_read,),
        ).fetchone()
    latest_payload: dict[str, Any] | None = None
    if latest:
        raw_amount = latest["receipt_amount"]
        if raw_amount is None:
            raw_amount = latest["amount"]
        try:
            amount = float(raw_amount) if raw_amount is not None else None
        except (TypeError, ValueError):
            amount = None
        latest_payload = {
            "id": int(latest["id"]),
            "tg_id": int(latest["tg_id"]),
            "username": str(latest["username"] or ""),
            "amount": amount,
            "status": str(latest["status"] or "pending"),
            "created_at": str(latest["created_at"] or ""),
        }
    return {
        "total": max(0, int(totals[0] or 0)),
        "last_payment_id": max(0, int(totals[1] or 0)),
        "latest": latest_payload,
    }


def _mark_payments_read_once(
    through_payment_id: int | None,
    db_path: str | Path | None,
) -> dict[str, int]:
    with _connect(db_path) as connection:
        connection.execute("BEGIN IMMEDIATE")
        if not _table_exists(connection, "payments"):
            current_max = 0
        else:
            current_max = int(
                connection.execute("SELECT COALESCE(MAX(id),0) FROM payments").fetchone()[0]
                or 0
            )
        state = connection.execute(
            "SELECT last_read_id FROM panel_notification_state WHERE channel=?",
            (PAYMENTS_CHANNEL,),
        ).fetchone()
        previous = max(0, int(state["last_read_id"] or 0)) if state else 0
        if through_payment_id is None:
            target = current_max
        else:
            target = min(current_max, max(previous, int(through_payment_id)))
        target = max(previous, target)
        connection.execute(
            """
            INSERT INTO panel_notification_state(channel,last_read_id,updated_at)
            VALUES(?,?,CURRENT_TIMESTAMP)
            ON CONFLICT(channel) DO UPDATE SET
                last_read_id=excluded.last_read_id,
                updated_at=CURRENT_TIMESTAMP
            """,
            (PAYMENTS_CHANNEL, target),
        )
        remaining = 0
        if _table_exists(connection, "payments"):
            remaining = int(
                connection.execute(
                    "SELECT COUNT(*) FROM payments WHERE id>?", (target,)
                ).fetchone()[0]
                or 0
            )
        return {"last_read_id": target, "remaining": remaining}


def mark_payments_read(
    *,
    through_payment_id: int | None = None,
    db_path: str | Path | None = None,
) -> dict[str, int]:
    """Mark current/newer payments read up to an optional exact ID boundary."""
    ensure_schema(db_path)
    return _with_busy_retry(
        lambda: _mark_payments_read_once(through_payment_id, db_path)
    )


def mark_payments_page_opened(
    *,
    db_path: str | Path | None = None,
) -> dict[str, int]:
    """Opening the payments section acknowledges every payment committed so far."""
    return mark_payments_read(through_payment_id=None, db_path=db_path)
