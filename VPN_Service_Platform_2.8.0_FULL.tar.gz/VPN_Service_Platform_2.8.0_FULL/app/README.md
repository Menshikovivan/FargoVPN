# VPN Service Platform 2.6.9 — компоненты

- `main.py` — Telegram-бот, динамические inline-меню, удаление старой `ReplyKeyboardMarkup` и журнал событий;
- `webapp.py` — веб-панель, чат, уведомления, оплаты, настройки и обновления;
- `user_events.py` — история переписки, SQLite-триггер и состояние непрочитанных;
- `panel_notifications.py` — компактное состояние уведомлений об оплатах;
- `backup.py` — локальный архив, Telegram, Яндекс.Диск и rclone;
- `update_manager.py` / `update_worker.py` — постоянные фоновые обновления;
- `broadcast_manager.py` / `broadcast_worker.py` — массовая рассылка;
- `diagnostics.py` — проверка базы, уведомлений, хранилища, обновлений и трафика.

Видимая навигация Telegram-бота создаётся через `InlineKeyboardBuilder`. `ReplyKeyboardRemove` используется только для одноразового удаления клавиатуры, оставшейся на устройствах после старых выпусков.
