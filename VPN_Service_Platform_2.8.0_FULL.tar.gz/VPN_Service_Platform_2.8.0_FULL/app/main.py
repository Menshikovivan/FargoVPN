# -*- coding: utf-8 -*-
import sys
import logging
import asyncio
import html
import sqlite3
import time
from datetime import datetime
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware, Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    CallbackQuery,
    KeyboardButton,
    KeyboardButtonRequestUsers,
    Message,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    UsersShared,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage

import config as config
import user_events
from init_db import migrate as migrate_database
from services.xui_api import (
    bytes_to_gb,
    change_client_days_sync,
    delete_client_sync,
    fetch_and_sync,
    fetch_snapshot_sync,
    inbound_ids_sync,
)
from services.subscriptions import (
    approve_payment_sync,
    decline_payment_sync,
    ensure_subscription_sync,
    recover_user_identity_sync,
    bind_database_user_tg_id_sync,
)
from services.media import download_telegram_file
from services.telegram_events import (
    incoming_message_event_payload,
    safe_int,
    telegram_message_media,
)
from services.receipt_ocr import ReceiptAnalysis, analyze_payment_receipt
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
                    handlers=[logging.StreamHandler(sys.stdout)])
logger = logging.getLogger(__name__)

INCY_APP_URL = str(
    getattr(config, "FAQ_INCY_URL", "https://apps.apple.com/ru/app/incy/id6756943388")
).strip() or "https://apps.apple.com/ru/app/incy/id6756943388"
IDENTITY_REFRESH_SECONDS = max(60, int(getattr(config, "BOT_IDENTITY_REFRESH_SECONDS", 600)))
SUBSCRIPTION_DAYS = max(1, min(3650, int(getattr(config, "SUBSCRIPTION_DAYS", 30))))
_IDENTITY_REFRESHED_AT: dict[int, float] = {}

# Telegram keeps ReplyKeyboardMarkup on the client until the bot explicitly
# sends ReplyKeyboardRemove. Older FargoVPN releases used a persistent reply
# keyboard, therefore simply switching the code to inline keyboards is not
# enough: users can continue seeing the old fixed panel indefinitely.
_LEGACY_REPLY_KEYBOARD_CLEARED: set[int] = set()
_LEGACY_REPLY_KEYBOARD_IN_FLIGHT: set[int] = set()
_LEGACY_REPLY_KEYBOARD_DELETE_TASKS: set[asyncio.Task[Any]] = set()


def _event_chat_id(event: Any) -> int:
    """Return the chat where a legacy reply keyboard must be removed."""
    message = event if isinstance(event, Message) else getattr(event, "message", None)
    chat = getattr(message, "chat", None)
    try:
        chat_id = int(getattr(chat, "id", 0) or 0)
    except (TypeError, ValueError):
        chat_id = 0
    if chat_id:
        return chat_id
    from_user = getattr(event, "from_user", None)
    try:
        return int(getattr(from_user, "id", 0) or 0)
    except (TypeError, ValueError):
        return 0


async def _delete_legacy_keyboard_notice_later(
    bot_instance: Bot, chat_id: int, message_id: int
) -> None:
    """Keep the removal update long enough for Telegram clients, then tidy it."""
    await asyncio.sleep(1.0)
    try:
        await bot_instance.delete_message(chat_id=chat_id, message_id=message_id)
    except Exception as error:
        # Removal has already been delivered. A failed cosmetic delete must not
        # make the old keyboard return or interrupt the user's action.
        logger.debug(
            "Не удалось удалить служебное сообщение очистки клавиатуры в чате %s: %s",
            chat_id,
            error,
        )


async def ensure_legacy_reply_keyboard_removed(
    bot_instance: Bot, chat_id: int
) -> bool:
    """Hide the fixed keyboard left by old versions, once per chat/process.

    The cleanup message is sent through the base Bot implementation so it is
    not written to the web-panel conversation journal. Inline keyboards are
    unaffected and remain the only visible navigation after cleanup.
    """
    try:
        normalized_chat_id = int(chat_id)
    except (TypeError, ValueError):
        return False
    if not normalized_chat_id:
        return False
    if (
        normalized_chat_id in _LEGACY_REPLY_KEYBOARD_CLEARED
        or normalized_chat_id in _LEGACY_REPLY_KEYBOARD_IN_FLIGHT
    ):
        return False

    _LEGACY_REPLY_KEYBOARD_IN_FLIGHT.add(normalized_chat_id)
    try:
        cleanup_message = await Bot.send_message(
            bot_instance,
            chat_id=normalized_chat_id,
            text="✅ Меню обновлено",
            reply_markup=ReplyKeyboardRemove(remove_keyboard=True),
            disable_notification=True,
        )
        _LEGACY_REPLY_KEYBOARD_CLEARED.add(normalized_chat_id)
        task = asyncio.create_task(
            _delete_legacy_keyboard_notice_later(
                bot_instance, normalized_chat_id, int(cleanup_message.message_id)
            )
        )
        _LEGACY_REPLY_KEYBOARD_DELETE_TASKS.add(task)
        task.add_done_callback(_LEGACY_REPLY_KEYBOARD_DELETE_TASKS.discard)
        logger.info(
            "Старая фиксированная Telegram-клавиатура скрыта для чата %s",
            normalized_chat_id,
        )
        return True
    except Exception as error:
        # Do not block the requested bot action. The next interaction will retry.
        logger.warning(
            "Не удалось скрыть старую Telegram-клавиатуру в чате %s: %s",
            normalized_chat_id,
            error,
        )
        return False
    finally:
        _LEGACY_REPLY_KEYBOARD_IN_FLIGHT.discard(normalized_chat_id)


def incoming_event_payload(event: Any) -> tuple[str, str, dict[str, Any]]:
    if isinstance(event, CallbackQuery):
        message = getattr(event, "message", None)
        metadata = {
            "telegram_message_id": safe_int(getattr(message, "message_id", 0)),
            "callback_data": str(getattr(event, "data", "") or "")[:500],
        }
        return "telegram_callback", f"Нажата кнопка: {str(event.data or '')}", metadata
    return incoming_message_event_payload(event)


class JournalBot(Bot):
    """Record outgoing messages in the shared web-panel conversation history."""

    @staticmethod
    def _target_id(chat_id: int | str) -> int:
        try:
            value = int(chat_id)
            return value if value != 0 else 0
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _media_text(label: str, kwargs: dict[str, Any]) -> str:
        caption = str(kwargs.get("caption") or "").strip()
        return f"[{label}]" + (f"\n{caption}" if caption else "")

    @staticmethod
    def _record_outgoing(
        target_id: int,
        text: str,
        *,
        event_type: str,
        success: bool = True,
        error: Exception | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        if not target_id:
            return
        payload = dict(metadata or {})
        if error:
            payload["error"] = str(error)[:800]
        user_events.safe_record_event(
            target_id,
            direction="out",
            event_type=event_type,
            text=text,
            actor="telegram_bot",
            success=success,
            metadata=payload or None,
            db_path=config.DB_PATH,
        )

    async def send_message(self, chat_id: int | str, text: str, *args: Any, **kwargs: Any):
        target_id = self._target_id(chat_id)
        if target_id:
            await ensure_legacy_reply_keyboard_removed(self, target_id)
        try:
            result = await super().send_message(chat_id, text, *args, **kwargs)
        except Exception as error:
            self._record_outgoing(
                target_id, text, event_type="bot_message", success=False, error=error
            )
            raise
        self._record_outgoing(target_id, text, event_type="bot_message")
        return result

    async def send_photo(self, chat_id: int | str, photo: Any, *args: Any, **kwargs: Any):
        target_id = self._target_id(chat_id)
        if target_id:
            await ensure_legacy_reply_keyboard_removed(self, target_id)
        text = self._media_text("Фото", kwargs)
        try:
            result = await super().send_photo(chat_id, photo, *args, **kwargs)
        except Exception as error:
            self._record_outgoing(
                target_id, text, event_type="bot_photo", success=False, error=error
            )
            raise
        media = telegram_message_media(result)
        self._record_outgoing(
            target_id, text, event_type="bot_photo", metadata={"media": media} if media else None
        )
        return result

    async def send_document(self, chat_id: int | str, document: Any, *args: Any, **kwargs: Any):
        target_id = self._target_id(chat_id)
        if target_id:
            await ensure_legacy_reply_keyboard_removed(self, target_id)
        text = self._media_text("Документ", kwargs)
        try:
            result = await super().send_document(chat_id, document, *args, **kwargs)
        except Exception as error:
            self._record_outgoing(
                target_id, text, event_type="bot_document", success=False, error=error
            )
            raise
        media = telegram_message_media(result)
        self._record_outgoing(
            target_id, text, event_type="bot_document", metadata={"media": media} if media else None
        )
        return result

    async def send_video(self, chat_id: int | str, video: Any, *args: Any, **kwargs: Any):
        target_id = self._target_id(chat_id)
        if target_id:
            await ensure_legacy_reply_keyboard_removed(self, target_id)
        text = self._media_text("Видео", kwargs)
        try:
            result = await super().send_video(chat_id, video, *args, **kwargs)
        except Exception as error:
            self._record_outgoing(
                target_id, text, event_type="bot_video", success=False, error=error
            )
            raise
        media = telegram_message_media(result)
        self._record_outgoing(
            target_id, text, event_type="bot_video", metadata={"media": media} if media else None
        )
        return result


def refresh_telegram_identity(tg_id: int, username: str | None) -> None:
    """Refresh Telegram identity with a low-cost throttle on every interaction."""
    tg_id = int(tg_id)
    if tg_id <= 0:
        return
    clean_username = str(username or "").strip().lstrip("@")[:100]
    now = time.monotonic()
    due = now - _IDENTITY_REFRESHED_AT.get(tg_id, 0.0) >= IDENTITY_REFRESH_SECONDS
    with sqlite3.connect(config.DB_PATH, timeout=20) as connection:
        connection.execute("PRAGMA busy_timeout=20000")
        row = connection.execute("SELECT username,email FROM users WHERE tg_id=?", (tg_id,)).fetchone()
        if row and clean_username and clean_username != str(row[0] or ""):
            connection.execute(
                "UPDATE users SET username=?,identity_source='telegram',identity_updated_at=CURRENT_TIMESTAMP WHERE tg_id=?",
                (clean_username, tg_id),
            )
    if not due and row and row[1]:
        return
    try:
        recover_user_identity_sync(tg_id, clean_username, config.DB_PATH, False)
        _IDENTITY_REFRESHED_AT[tg_id] = now
    except Exception as error:
        logger.debug("Не удалось обновить Telegram-привязку %s: %s", tg_id, error)


class EventJournalMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[Any, dict[str, Any]], Awaitable[Any]],
        event: Any,
        data: dict[str, Any],
    ) -> Any:
        from_user = getattr(event, "from_user", None)
        tg_id = int(getattr(from_user, "id", 0) or 0)
        bot_instance = data.get("bot")
        if bot_instance is not None:
            chat_id = _event_chat_id(event) or tg_id
            if chat_id:
                await ensure_legacy_reply_keyboard_removed(bot_instance, chat_id)
        if tg_id:
            username = str(getattr(from_user, "username", "") or "")
            try:
                await asyncio.to_thread(refresh_telegram_identity, tg_id, username)
            except Exception as error:
                logger.warning("Не удалось обновить Telegram-привязку %s: %s", tg_id, error)
            event_type, text, metadata = incoming_event_payload(event)
            user_events.safe_record_event(
                tg_id,
                username=username,
                direction="in",
                event_type=event_type,
                text=text,
                actor=f"telegram:@{username}" if username else f"telegram:{tg_id}",
                metadata=metadata,
                db_path=config.DB_PATH,
            )
        return await handler(event, data)


bot = JournalBot(token=config.BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
dp.message.outer_middleware(EventJournalMiddleware())
dp.callback_query.outer_middleware(EventJournalMiddleware())

class FSMStates(StatesGroup):
    wait_for_receipt = State()
    wait_for_admin_msg = State()
    wait_for_user_support_msg = State()
    wait_for_broadcast_msg = State()
    wait_for_manual_username = State()

MANUAL_USER_REQUEST_ID = 2704


async def get_all_inbound_ids() -> list[int]:
    try:
        return await asyncio.to_thread(inbound_ids_sync)
    except Exception as error:
        logger.error("Ошибка сбора инбаундов: %s", error)
        return []

async def get_client_from_panel(email: str) -> dict | None:
    """Return the normalized current 3x-ui client snapshot."""
    try:
        snapshot = await asyncio.to_thread(fetch_snapshot_sync, False)
        return snapshot.get("by_email", {}).get(email.lower().strip())
    except Exception as error:
        logger.error("Ошибка получения клиента (email): %s", error)
        return None


async def update_client_in_panel(
    client_email: str,
    _client_uuid: str,
    _sub_id: str,
    days_increment: int,
    tg_id: int = 0,
) -> dict | None:
    try:
        days_increment = int(days_increment)
        return await asyncio.to_thread(
            change_client_days_sync,
            client_email,
            days_increment,
            int(tg_id) if int(tg_id) > 0 else None,
        )
    except Exception as error:
        logger.error("Ошибка update_client_in_panel: %s", error)
        return None


async def delete_client_from_panel(client_email: str) -> bool:
    try:
        await asyncio.to_thread(delete_client_sync, client_email, False)
        return True
    except Exception as error:
        logger.error("Ошибка удаления %s: %s", client_email, error)
        return False

async def sync_panel_to_db() -> bool:
    try:
        snapshot = await asyncio.to_thread(fetch_and_sync, True, config.DB_PATH)
        if snapshot.get("stale"):
            logger.error("Синхронизация 3x-ui не выполнена: %s", snapshot.get("error"))
            return False
        return True
    except Exception as error:
        logger.error(f"Ошибка синхронизации: {error}")
        return False

def init_db():
    migrate_database()
    user_events.ensure_schema(config.DB_PATH)

init_db()

def db_get_user(tg_id: int) -> dict:
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE tg_id = ?", (tg_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def db_upsert_user(tg_id: int, username: str, uuid_str: str, email: str, expiry_time: int, sub_id: str, is_active: int = 1, reminder_days: int = -1):
    clean_name = username.replace("@", "").strip() if username else None
    conn = sqlite3.connect(config.DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""INSERT INTO users (tg_id, username, uuid, email, expiry_time, enable, sub_id, last_online, last_reminder_days) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(tg_id) DO UPDATE SET username=excluded.username, uuid=excluded.uuid, email=excluded.email,
        expiry_time=excluded.expiry_time, enable=excluded.enable, sub_id=excluded.sub_id, last_online=excluded.last_online, last_reminder_days=excluded.last_reminder_days""",
        (tg_id, clean_name, uuid_str, email, int(expiry_time), is_active, sub_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), reminder_days))
    conn.commit()
    conn.close()

def get_user_menu(user_id: int):
    user = db_get_user(user_id)
    now_ms = int(time.time() * 1000)
    active = bool(
        user
        and bool(user.get("enable", 1))
        and (int(user.get("expiry_time") or 0) <= 0 or int(user.get("expiry_time") or 0) > now_ms)
    )
    builder = InlineKeyboardBuilder()
    builder.button(
        text="🟢 Моя подписка" if active else "📊 Моя статистика",
        callback_data="menu:stats",
    )
    builder.button(
        text="🔄 Продлить VPN" if user else "💳 Купить VPN",
        callback_data="menu:buy",
    )
    builder.button(text="📚 FAQ и подключение", callback_data="menu:faq")
    builder.button(text="💬 Написать администратору", callback_data="menu:support")
    if user_id in config.ADMIN_IDS:
        builder.button(text="🛠 Администрирование", callback_data="menu:admin")
        builder.adjust(2, 2, 1)
    else:
        builder.adjust(2, 2)
    return builder.as_markup()

def get_admin_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="👥 Пользователи", callback_data="admin:users")
    builder.button(text="✉ Рассылка", callback_data="admin:broadcast")
    builder.button(text="🔄 Синхронизация 3x-ui", callback_data="admin:sync")
    builder.button(text="📋 Подписки", callback_data="admin:subscriptions")
    builder.button(text="🔑 Выдать доступ", callback_data="admin:grant")
    builder.button(text="🏠 Меню пользователя", callback_data="menu:home")
    builder.adjust(2, 2, 1, 1)
    return builder.as_markup()


def get_faq_menu():
    builder = InlineKeyboardBuilder()
    builder.button(text="📱 Подключение через Incy", callback_data="faq:incy")
    builder.button(text="📘 Подключение через HApp", callback_data="faq:happ")
    builder.button(text="🛟 Если VPN не подключается", callback_data="faq:troubleshoot")
    builder.button(text="🏠 Главное меню", callback_data="menu:home")
    builder.adjust(1)
    return builder.as_markup()


def get_instruction_menu(*, include_store: bool = False):
    builder = InlineKeyboardBuilder()
    if include_store:
        builder.button(text="📲 Открыть Incy в App Store", url=INCY_APP_URL)
    builder.button(text="📚 Все инструкции", callback_data="menu:faq")
    builder.button(text="🏠 Главное меню", callback_data="menu:home")
    builder.adjust(1)
    return builder.as_markup()


def home_text(*, first_visit: bool = False) -> str:
    custom = str(getattr(config, "BOT_WELCOME_TEXT", "") or "").strip()
    if custom:
        rendered = custom.replace("{service}", str(config.SERVICE_NAME))
        return html.escape(rendered[:3500])
    if first_visit:
        return (
            f"👋 Добро пожаловать в <b>{html.escape(str(config.SERVICE_NAME))}</b>!\n\n"
            "Здесь можно проверить подписку, продлить доступ, открыть инструкции "
            "и написать администратору."
        )
    return (
        f"<b>🏠 {html.escape(str(config.SERVICE_NAME))}</b>\n\n"
        "Выберите действие. Кнопки меняются в зависимости от состояния вашей подписки."
    )


async def send_home(message: Message, user_id: int) -> None:
    await message.answer(
        home_text(),
        parse_mode="HTML",
        reply_markup=get_user_menu(user_id),
    )


async def resolve_user(user_id: int, username: str | None) -> dict | None:
    try:
        return await asyncio.to_thread(
            recover_user_identity_sync,
    bind_database_user_tg_id_sync,
            user_id,
            username,
            config.DB_PATH,
            False,
        )
    except Exception as error:
        logger.error("Ошибка восстановления пользователя %s: %s", user_id, error)
        return db_get_user(user_id)


async def send_user_stats(message: Message, user_id: int, username: str | None) -> None:
    u = await resolve_user(user_id, username)
    if not u:
        await message.answer(
            "❌ Активная подписка не найдена. Оформите или продлите доступ через меню.",
            reply_markup=get_user_menu(user_id),
        )
        return

    panel_client = await get_client_from_panel(str(u.get("email") or ""))
    status_emoji, expiry_str, up_gb, down_gb = "🟢 Активен", "Бессрочно", 0.0, 0.0
    if panel_client:
        ts = int(panel_client.get("expiry_time", 0) or 0)
        if ts > 0:
            expiry_str = datetime.fromtimestamp(ts / 1000).strftime("%Y-%m-%d %H:%M:%S")
            if ts < int(time.time() * 1000):
                status_emoji = "🔴 Истёк"
        if not panel_client.get("enable", True):
            status_emoji = "🔴 Отключён"
        up_gb = bytes_to_gb(panel_client.get("up", 0) or 0)
        down_gb = bytes_to_gb(panel_client.get("down", 0) or 0)
    else:
        local_expiry = int(u.get("expiry_time") or 0)
        if local_expiry > 0:
            expiry_str = datetime.fromtimestamp(local_expiry / 1000).strftime("%Y-%m-%d %H:%M:%S")
            if local_expiry < int(time.time() * 1000):
                status_emoji = "🔴 Истёк"
        if not bool(u.get("enable", 1)):
            status_emoji = "🔴 Отключён"
        up_gb = bytes_to_gb(u.get("up", 0) or 0)
        down_gb = bytes_to_gb(u.get("down", 0) or 0)

    sub_id = str(u.get("sub_id") or "").strip()
    sub_url = f"{config.SUB_BASE_URL}{sub_id}".replace("http://", "https://") if sub_id else ""
    total_tr = round(up_gb + down_gb, 2)
    subscription_line = (
        f"<code>{html.escape(sub_url)}</code>"
        if sub_url
        else "<i>Ссылка временно недоступна; обратитесь к администратору.</i>"
    )
    text = (
        f"<b>📊 Подписка {html.escape(str(config.SERVICE_NAME))}</b>\n\n"
        f"📅 Срок до: <code>{html.escape(expiry_str)}</code>\n"
        f"⚡ Статус: <b>{status_emoji}</b>\n"
        f"📤 Отдано: <code>{up_gb} GB</code>\n"
        f"📥 Скачано: <code>{down_gb} GB</code>\n"
        f"🔄 Общий трафик: <code>{total_tr} GB</code>\n\n"
        f"🔗 <b>Ссылка подписки для Incy / HApp:</b>\n{subscription_line}"
    )
    builder = InlineKeyboardBuilder()
    builder.button(text="📱 Подключить через Incy", callback_data="faq:incy")
    builder.button(text="📘 Подключить через HApp", callback_data="faq:happ")
    builder.button(text="🔄 Продлить", callback_data="menu:buy")
    builder.button(text="🏠 Главное меню", callback_data="menu:home")
    builder.adjust(2, 2)
    await message.answer(text, reply_markup=builder.as_markup(), parse_mode="HTML")


def payment_text() -> str:
    return (
        f"<b>💳 Оплата подписки {html.escape(str(config.SERVICE_NAME))}</b>\n\n"
        f"• Цена: <code>{int(config.PAYMENT_PRICE)}</code> ₽ / {SUBSCRIPTION_DAYS} дней\n"
        f"• Номер: <code>{html.escape(str(config.PAYMENT_PHONE))}</code>\n"
        f"• Банк: <b>{html.escape(str(config.PAYMENT_BANK))}</b>\n"
        f"• Получатель: <b>{html.escape(str(config.PAYMENT_RECEIVER))}</b>\n\n"
        "После перевода сразу пришлите скриншот чека как фото или файл изображения. "
        "Бот проверит чек и сообщит результат."
    )


async def start_purchase(message: Message, state: FSMContext) -> None:
    await state.set_state(FSMStates.wait_for_receipt)
    await message.answer(payment_text(), parse_mode="HTML")


async def start_support(message: Message, state: FSMContext) -> None:
    prompt = str(getattr(config, "BOT_SUPPORT_PROMPT", "") or "").strip()
    await message.answer(
        prompt[:1500]
        or "💬 Напишите вопрос одним сообщением. Он появится у администратора и в истории веб-панели."
    )
    await state.set_state(FSMStates.wait_for_user_support_msg)

@dp.message(CommandStart())
async def cmd_start(msg: Message, state: FSMContext):
    args = str(getattr(msg, "text", "") or "").split(maxsplit=1)
    payload = args[1].strip() if len(args) > 1 else ""
    if payload.startswith("bind_"):
        token = payload[5:].strip()
        with sqlite3.connect(config.DB_PATH, timeout=20) as connection:
            row = connection.execute(
                "SELECT local_tg_id,expires_at,consumed_at FROM telegram_link_requests WHERE token=?",
                (token,),
            ).fetchone()
        if not row:
            await msg.answer("❌ Ссылка привязки недействительна или уже удалена.")
            return
        if row[2]:
            await msg.answer("ℹ️ Эта ссылка уже использовалась.")
            return
        if str(row[1]) < datetime.utcnow().replace(tzinfo=None).isoformat(timespec="seconds"):
            await msg.answer("❌ Срок действия ссылки истёк. Попросите администратора создать новую.")
            return
        try:
            bound = await asyncio.to_thread(
                bind_database_user_tg_id_sync,
                int(row[0]),
                int(msg.from_user.id),
                str(getattr(msg.from_user, "username", "") or ""),
                config.DB_PATH,
            )
            with sqlite3.connect(config.DB_PATH, timeout=20) as connection:
                connection.execute(
                    "UPDATE telegram_link_requests SET consumed_at=CURRENT_TIMESTAMP,resolved_tg_id=? WHERE token=?",
                    (int(msg.from_user.id), token),
                )
            await msg.answer(
                "✅ Telegram успешно привязан. Теперь администратор увидит ваш Telegram ID в панели."
            )
        except Exception as error:
            await msg.answer(f"❌ Не удалось выполнить привязку: {html.escape(str(error)[:400])}", parse_mode="HTML")
        return
    await state.clear()
    await send_home(msg, msg.from_user.id)

@dp.callback_query(F.data.startswith("menu:"))
async def dynamic_user_menu(call: CallbackQuery, state: FSMContext):
    if not call.message:
        await call.answer()
        return
    action = str(call.data or "").split(":", 1)[-1]
    user_id = int(call.from_user.id)
    if action == "admin" and user_id not in config.ADMIN_IDS:
        await call.answer("Недостаточно прав", show_alert=True)
        return
    await call.answer()
    if action == "home":
        await state.clear()
        await send_home(call.message, user_id)
    elif action == "stats":
        await state.clear()
        await send_user_stats(call.message, user_id, call.from_user.username)
    elif action == "buy":
        await start_purchase(call.message, state)
    elif action == "support":
        await start_support(call.message, state)
    elif action == "faq":
        await state.clear()
        await call.message.answer(
            "<b>📚 FAQ и инструкции</b>\n\nВыберите приложение или раздел помощи.",
            parse_mode="HTML",
            reply_markup=get_faq_menu(),
        )
    elif action == "admin":
        await state.clear()
        await call.message.answer(
            f"<b>🛠 Администрирование {html.escape(str(config.SERVICE_NAME))}</b>",
            parse_mode="HTML",
            reply_markup=get_admin_menu(),
        )


@dp.callback_query(F.data.startswith("faq:"))
async def faq_callbacks(call: CallbackQuery, state: FSMContext):
    await call.answer()
    await state.clear()
    if not call.message:
        return
    action = str(call.data or "").split(":", 1)[-1]
    if action == "incy":
        text = (
            "<b>📱 Подключение через Incy</b>\n\n"
            "1. Откройте «Моя подписка» и скопируйте ссылку подписки.\n"
            "2. Установите и откройте Incy.\n"
            "3. Выберите добавление или импорт подписки и вставьте скопированный URL.\n"
            "4. Сохраните подписку, обновите список серверов и выберите подходящий сервер.\n"
            "5. Нажмите подключение и разрешите iOS создать VPN-конфигурацию.\n\n"
            "Названия пунктов могут немного отличаться в разных версиях приложения."
        )
        await call.message.answer(
            text,
            parse_mode="HTML",
            reply_markup=get_instruction_menu(include_store=True),
        )
    elif action == "happ":
        await call.message.answer(
            "<b>📘 Подключение через HApp</b>\n\n"
            "1. Откройте «Моя подписка» и скопируйте ссылку.\n"
            "2. В HApp нажмите «+» и выберите добавление подписки.\n"
            "3. Вставьте URL, сохраните и обновите список серверов.\n"
            "4. Выберите сервер и подключитесь.",
            parse_mode="HTML",
            reply_markup=get_instruction_menu(),
        )
    elif action == "troubleshoot":
        await call.message.answer(
            "<b>🛟 Если VPN не подключается</b>\n\n"
            "• Обновите подписку внутри приложения.\n"
            "• Проверьте, что срок подписки не истёк и доступ не заблокирован.\n"
            "• Переключите сервер или протокол.\n"
            "• Отключите другой VPN/Private Relay и повторите подключение.\n"
            "• Перезапустите приложение и интернет-соединение.\n\n"
            "Если проблема остаётся, отправьте администратору модель устройства, приложение и текст ошибки.",
            parse_mode="HTML",
            reply_markup=get_instruction_menu(),
        )

@dp.callback_query(F.data == "show_instruction")
async def process_instruction(call: CallbackQuery):
    await call.answer()
    await call.message.answer(
        "<b>📘 Подключение через HApp</b>\n\n"
        "Скопируйте ссылку подписки, нажмите «+», добавьте подписку по URL, сохраните и обновите список серверов.",
        parse_mode="HTML",
        reply_markup=get_instruction_menu(),
    )

@dp.message(lambda m: m.text and "Статистика" in m.text)
async def user_stats(msg: Message):
    await send_user_stats(msg, msg.from_user.id, msg.from_user.username)

@dp.message(lambda m: m.text and "Купить" in m.text)
async def buy_vpn(msg: Message, state: FSMContext):
    await start_purchase(msg, state)

def receipt_ocr_options() -> dict:
    return {
        "receiver": str(getattr(config, "PAYMENT_RECEIVER", "")),
        "phone": str(getattr(config, "PAYMENT_PHONE", "")),
        "minimum_amount": float(getattr(config, "RECEIPT_MIN_AMOUNT", 150)),
        "max_age_hours": int(getattr(config, "RECEIPT_MAX_AGE_HOURS", 24)),
        "aliases": getattr(config, "RECEIPT_RECEIVER_ALIASES", ""),
        "allow_masked_phone": bool(getattr(config, "RECEIPT_ALLOW_MASKED_PHONE", True)),
        "timezone_name": str(getattr(config, "RECEIPT_TIMEZONE", "Europe/Moscow")),
        "languages": str(getattr(config, "RECEIPT_OCR_LANGUAGES", "rus+eng")),
        "timeout_seconds": int(getattr(config, "RECEIPT_OCR_TIMEOUT", 20)),
        "check_name": bool(getattr(config, "RECEIPT_FILTER_NAME", True)),
        "check_phone": bool(getattr(config, "RECEIPT_FILTER_PHONE", False)),
        "check_amount": bool(getattr(config, "RECEIPT_FILTER_AMOUNT", True)),
        "check_date": bool(getattr(config, "RECEIPT_FILTER_DATE", False)),
        "check_status": bool(getattr(config, "RECEIPT_FILTER_STATUS", True)),
        "check_duplicate": bool(getattr(config, "RECEIPT_FILTER_DUPLICATE", True)),
    }


def mark_receipt_error(payment_id: int, error: Exception) -> None:
    conn = sqlite3.connect(config.DB_PATH)
    try:
        conn.execute(
            "UPDATE payments SET ocr_status='error',last_error=? WHERE id=?",
            (f"OCR: {str(error)[:900]}", int(payment_id)),
        )
        conn.commit()
    finally:
        conn.close()


async def send_subscription_activated(user_id: int, subscription) -> str:
    expiry_date = datetime.fromtimestamp(subscription.expiry_time / 1000).strftime("%Y-%m-%d %H:%M:%S")
    action = "активирована" if subscription.created else "продлена"
    try:
        await bot.send_message(
            chat_id=user_id,
            text=(
                f"🎉 Ваша подписка {config.SERVICE_NAME} успешно {action} до "
                f"<code>{expiry_date}</code>!\nСсылка доступна в меню «📊 Моя Статистика»."
            ),
            parse_mode="HTML",
        )
    except Exception as error:
        logger.warning("Подписка активирована, но уведомление пользователю %s не доставлено: %s", user_id, error)
    return expiry_date


async def send_receipt_to_admin(msg: Message, admin_id: int, file_id: str, caption: str, reply_markup=None) -> None:
    if msg.photo:
        await bot.send_photo(
            chat_id=admin_id,
            photo=file_id,
            caption=caption,
            reply_markup=reply_markup,
            parse_mode="HTML",
        )
    else:
        await bot.send_document(
            chat_id=admin_id,
            document=file_id,
            caption=caption,
            reply_markup=reply_markup,
            parse_mode="HTML",
        )


@dp.message(F.photo, FSMStates.wait_for_receipt)
@dp.message(F.document, FSMStates.wait_for_receipt)
async def process_receipt_photo(msg: Message, state: FSMContext):
    if msg.photo:
        file_id = msg.photo[-1].file_id
    elif msg.document:
        filename = str(msg.document.file_name or "").lower()
        mime_type = str(msg.document.mime_type or "").lower()
        if not (mime_type.startswith("image/") or filename.endswith((".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"))):
            await msg.answer("❌ Пришлите чек как фотографию или файл изображения.")
            return
        file_id = msg.document.file_id
    else:
        return

    conn = sqlite3.connect(config.DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO payments (tg_id, username, telegram_file_id, amount, ocr_status) VALUES (?, ?, ?, ?, 'not_checked')",
        (msg.from_user.id, msg.from_user.username or "", file_id, config.PAYMENT_PRICE),
    )
    payment_id = int(cur.lastrowid)
    conn.commit()
    conn.close()

    analysis: ReceiptAnalysis | None = None
    approval = None
    ocr_enabled = bool(getattr(config, "RECEIPT_OCR_ENABLED", True))
    if ocr_enabled:
        try:
            content, _media_type, _filename = await asyncio.to_thread(
                download_telegram_file,
                config.BOT_TOKEN,
                file_id,
                45.0,
            )
            analysis = await asyncio.to_thread(
                analyze_payment_receipt,
                config.DB_PATH,
                payment_id,
                content,
                **receipt_ocr_options(),
            )
            if analysis.passed and bool(getattr(config, "RECEIPT_AUTO_APPROVE", True)):
                approval = await asyncio.to_thread(
                    approve_payment_sync,
                    payment_id,
                    "ocr:auto",
                    SUBSCRIPTION_DAYS,
                    config.DB_PATH,
                )
        except Exception as error:
            logger.exception("Ошибка автоматического распознавания чека %s", payment_id)
            await asyncio.to_thread(mark_receipt_error, payment_id, error)

    automatically_approved = bool(approval and approval.success and not approval.already_processed and approval.subscription)
    if automatically_approved:
        subscription = approval.subscription
        expiry_date = datetime.fromtimestamp(subscription.expiry_time / 1000).strftime("%Y-%m-%d %H:%M:%S")
        action = "активирована" if subscription.created else "продлена"
        user_reply = (
            f"✅ Чек распознан и подтверждён автоматически. Подписка {action} до "
            f"<code>{expiry_date}</code>. Выдано {SUBSCRIPTION_DAYS} дней по выбранному тарифу."
        )
    else:
        user_reply = "⏳ Ваш чек принят и отправлен на проверку администратору."

    user_info = (
        f"📑 Чек #{payment_id} от @{html.escape(msg.from_user.username or 'нет')} "
        f"(ID: <code>{msg.from_user.id}</code>)"
    )
    if analysis:
        user_info += "\n\n<b>Автопроверка:</b>\n<pre>" + html.escape(analysis.compact_summary()) + "</pre>"
    elif not ocr_enabled:
        user_info += "\n\n⚪ Автопроверка отключена в настройках."
    else:
        user_info += "\n\n⚠ OCR не завершён; требуется ручная проверка."

    builder = None
    if automatically_approved:
        user_info += f"\n\n✅ <b>Подтверждено автоматически, выдано {SUBSCRIPTION_DAYS} дней.</b>"
    else:
        if approval and not approval.success:
            user_info += "\n\n⚠ Совпадения найдены, но активация не выполнена: " + html.escape(approval.message)
        keyboard = InlineKeyboardBuilder()
        keyboard.button(text="☑ Подтвердить", callback_data=f"approve_{msg.from_user.id}_{payment_id}")
        keyboard.button(text="❌ Отказать", callback_data=f"decline_{msg.from_user.id}_{payment_id}")
        keyboard.adjust(1)
        builder = keyboard.as_markup()

    admin_caption = user_info
    if len(admin_caption) > 1024:
        admin_caption = (
            f"📑 Чек #{payment_id} от @{html.escape(msg.from_user.username or 'нет')} "
            f"(ID: <code>{msg.from_user.id}</code>)\n\n"
            "⚠ Подробный результат OCR слишком длинный; откройте чек в веб-панели."
        )
    for admin_id in config.ADMIN_IDS:
        try:
            await send_receipt_to_admin(msg, admin_id, file_id, admin_caption, builder)
        except Exception as error:
            logger.error("Ошибка отправки чека админу %s: %s", admin_id, error)
    await msg.answer(user_reply, reply_markup=get_user_menu(msg.from_user.id), parse_mode="HTML")
    await state.clear()

@dp.message(lambda m: m.text and "Связь" in m.text)
async def support_request(msg: Message, state: FSMContext):
    await start_support(msg, state)

@dp.message(FSMStates.wait_for_user_support_msg)
async def process_support_msg(msg: Message, state: FSMContext):
    support_text = str(msg.text or msg.caption or "").strip()
    media = telegram_message_media(msg)
    if not support_text and not media:
        await msg.answer("Пожалуйста, отправьте текст, фотографию или видео.")
        return
    user_events.safe_record_event(
        msg.from_user.id,
        username=msg.from_user.username,
        direction="system",
        event_type="support_forwarded",
        text="Обращение передано администраторам",
        actor="telegram_bot",
        db_path=config.DB_PATH,
    )
    media_label = ""
    if media:
        media_label = "фотографию" if media.get("kind") == "photo" else "видео" if media.get("kind") == "video" else "файл"
    for admin_id in config.ADMIN_IDS:
        try:
            heading = (
                f"📬 Поддержка от @{msg.from_user.username or 'нет'} "
                f"(ID: {msg.from_user.id})"
            )
            if media_label:
                heading += f" прислал(а) {media_label}."
            if support_text and not media:
                heading += f":\n\n{support_text}"
            await bot.send_message(chat_id=admin_id, text=heading)
            if media:
                await bot.copy_message(
                    chat_id=admin_id,
                    from_chat_id=msg.chat.id,
                    message_id=msg.message_id,
                )
        except Exception as error:
            logger.warning("Не удалось доставить обращение админу %s: %s", admin_id, error)
    await msg.answer("✅ Сообщение доставлено. Ответ придёт в этот чат.", reply_markup=get_user_menu(msg.from_user.id))
    await state.clear()


async def send_crm_list(message: Message) -> None:
    with sqlite3.connect(config.DB_PATH, timeout=20) as connection:
        rows = connection.execute(
            "SELECT tg_id,username,enable,expiry_time FROM users ORDER BY username COLLATE NOCASE, tg_id LIMIT 100"
        ).fetchall()
    if not rows:
        await message.answer("📉 База пользователей пуста.", reply_markup=get_admin_menu())
        return
    now_ms = int(time.time() * 1000)
    builder = InlineKeyboardBuilder()
    for tg_id, username, enabled, expiry in rows:
        active = bool(enabled) and (int(expiry or 0) <= 0 or int(expiry or 0) > now_ms)
        label = f"{'🟢' if active else '🔴'} @{username}" if username else f"{'🟢' if active else '🔴'} ID {tg_id}"
        builder.button(text=label[:48], callback_data=f"crmv_{tg_id}")
    builder.button(text="⬅ Админ-меню", callback_data="menu:admin")
    builder.adjust(2)
    await message.answer(
        f"<b>👥 Пользователи</b>\n\nПоказано {len(rows)} записей. Выберите карточку:",
        reply_markup=builder.as_markup(),
        parse_mode="HTML",
    )


async def run_admin_sync(message: Message) -> None:
    await message.answer("⏳ Получаю актуальные данные из 3x-ui…")
    success = await sync_panel_to_db()
    await message.answer(
        "✅ Пользователи и трафик синхронизированы."
        if success
        else "❌ Синхронизация не выполнена. Проверьте доступность и токен 3x-ui.",
        reply_markup=get_admin_menu(),
    )


def subscription_report_text() -> str:
    with sqlite3.connect(config.DB_PATH, timeout=20) as connection:
        users = connection.execute(
            "SELECT username,tg_id,expiry_time,last_reminder_days,enable FROM users ORDER BY expiry_time"
        ).fetchall()
    if not users:
        return "📭 Пользователи с подписками не найдены."
    now_ms = int(time.time() * 1000)
    lines = ["📋 <b>Подписки и уведомления</b>\n"]
    for username, tg_id, expiry_time, last_reminder, enabled in users:
        mention = f"@{html.escape(str(username))}" if username else f"ID <code>{tg_id}</code>"
        expiry_value = int(expiry_time or 0)
        if not enabled:
            state = "заблокирован ⛔"
        elif expiry_value <= 0:
            state = "бессрочно ♾"
        elif expiry_value <= now_ms:
            state = "истёк ❌"
        else:
            days_left = max(0, (datetime.fromtimestamp(expiry_value / 1000).date() - datetime.now().date()).days)
            reminder = "не отправлялось" if int(last_reminder or -1) == -1 else f"за {last_reminder} дн."
            state = f"{days_left} дн. · уведомление {reminder}"
        lines.append(f"• {mention} — {state}")
    return "\n".join(lines)


async def send_subscription_report(message: Message) -> None:
    text = subscription_report_text()
    chunks = [text[index:index + 3900] for index in range(0, len(text), 3900)] or [text]
    for index, chunk in enumerate(chunks):
        await message.answer(
            chunk,
            parse_mode="HTML",
            reply_markup=get_admin_menu() if index == len(chunks) - 1 else None,
        )


@dp.callback_query(F.data.startswith("admin:"))
async def dynamic_admin_menu(call: CallbackQuery, state: FSMContext):
    if call.from_user.id not in config.ADMIN_IDS:
        await call.answer("Недостаточно прав", show_alert=True)
        return
    await call.answer()
    if not call.message:
        return
    action = str(call.data or "").split(":", 1)[-1]
    if action == "users":
        await send_crm_list(call.message)
    elif action == "sync":
        await run_admin_sync(call.message)
    elif action == "subscriptions":
        await send_subscription_report(call.message)
    elif action == "broadcast":
        await state.set_state(FSMStates.wait_for_broadcast_msg)
        builder = InlineKeyboardBuilder()
        builder.button(text="❌ Отмена", callback_data="admin:cancel")
        await call.message.answer(
            "📢 Отправьте текст, фото, документ или видео для рассылки всем пользователям.",
            reply_markup=builder.as_markup(),
        )
    elif action == "grant":
        await state.set_state(FSMStates.wait_for_manual_username)
        keyboard = ReplyKeyboardMarkup(
            keyboard=[[
                KeyboardButton(
                    text="🔎 Выбрать пользователя в Telegram",
                    request_users=KeyboardButtonRequestUsers(
                        request_id=MANUAL_USER_REQUEST_ID,
                        user_is_bot=False,
                        max_quantity=1,
                        request_name=True,
                        request_username=True,
                    ),
                )
            ]],
            resize_keyboard=True,
            one_time_keyboard=True,
        )
        await call.message.answer(
            "👤 Введите имя пользователя. Telegram ID указывать необязательно.\n"
            "Примеры: <code>ivan</code> или <code>123456789 ivan</code>.\n\n"
            "Либо нажмите кнопку ниже и выберите человека прямо из Telegram —\n"
            "в этом случае Telegram передаст боту настоящий ID автоматически.",
            parse_mode="HTML",
            reply_markup=keyboard,
        )
    elif action == "cancel":
        await state.clear()
        await call.message.answer("Действие отменено.", reply_markup=get_admin_menu())

@dp.message(lambda m: m.text and "Синхронизация" in m.text)
async def cmd_sync_button(msg: Message):
    if msg.from_user.id not in config.ADMIN_IDS:
        return
    await run_admin_sync(msg)

@dp.callback_query(F.data.startswith("approve_"))
async def handle_pay_approve_callback(call: CallbackQuery):
    if call.from_user.id not in config.ADMIN_IDS:
        try:
            await call.answer("Нет доступа", show_alert=True)
        except Exception:
            pass
        return
    try: await call.answer("Обработка подтверждения...", show_alert=False)
    except: pass
    try:
        parts = call.data.split("_")
        payment_id = int(parts[2]) if len(parts) > 2 else 0
        if payment_id <= 0:
            raise ValueError("В кнопке отсутствует номер платежа")

        result = await asyncio.to_thread(
            approve_payment_sync,
            payment_id,
            str(call.from_user.id),
            SUBSCRIPTION_DAYS,
            config.DB_PATH,
        )
        if not result.success:
            await call.message.answer(f"❌ Платёж не подтверждён: {result.message}")
            return
        if result.already_processed:
            await call.message.answer("ℹ️ Этот чек уже был подтверждён ранее; повторное продление не выполнено.")
            return

        subscription = result.subscription
        if not subscription:
            raise RuntimeError("Результат активации подписки отсутствует")
        user_id = int(subscription.tg_id)
        action = "активирована" if subscription.created else "продлена"
        expiry_date = await send_subscription_activated(user_id, subscription)
        user_events.safe_record_event(
            user_id,
            username=subscription.username,
            direction="system",
            event_type="payment_approved",
            text=f"Платёж #{payment_id} подтверждён; доступ продлён на {SUBSCRIPTION_DAYS} дн.",
            actor=f"admin:{call.from_user.id}",
            metadata={"payment_id": payment_id, "expiry_time": subscription.expiry_time},
            db_path=config.DB_PATH,
        )
        caption = (call.message.caption or "Чек") + f"\n\n✅ Одобрено. Подписка {action} до {expiry_date}"
        await call.message.edit_caption(caption=caption, reply_markup=None)
    except Exception as err:
        logger.exception("Ошибка модерации чека")
        await call.message.answer(f"❌ Ошибка модерации чека: {err}")

@dp.callback_query(F.data.startswith("decline_"))
async def handle_pay_decline_callback(call: CallbackQuery):
    if call.from_user.id not in config.ADMIN_IDS:
        try:
            await call.answer("Нет доступа", show_alert=True)
        except Exception:
            pass
        return
    try: await call.answer("Заявка отклонена", show_alert=False)
    except: pass
    try:
        parts = call.data.split("_")
        payment_id = int(parts[2]) if len(parts) > 2 else 0
        if payment_id <= 0:
            raise ValueError("В кнопке отсутствует номер платежа")
        payment = await asyncio.to_thread(
            decline_payment_sync,
            payment_id,
            str(call.from_user.id),
            config.DB_PATH,
        )
        user_id = int(payment["tg_id"])
        user_events.safe_record_event(
            user_id,
            username=str(payment.get("username") or ""),
            direction="system",
            event_type="payment_declined",
            text=f"Платёж #{payment_id} отклонён администратором",
            actor=f"admin:{call.from_user.id}",
            metadata={"payment_id": payment_id},
            db_path=config.DB_PATH,
        )
        try:
            await bot.send_message(chat_id=user_id, text="❌ Ваш чек об оплате отклонён администратором. Проверьте перевод.")
        except Exception as error:
            logger.warning("Не удалось уведомить пользователя %s об отклонении: %s", user_id, error)
        await call.message.edit_caption(caption=(call.message.caption or "Чек") + "\n\n❌ Отклонено администратором.", reply_markup=None)
    except Exception as error:
        await call.message.answer(f"❌ Не удалось отклонить чек: {error}")

@dp.message(lambda m: m.text and "Рассылка" in m.text)
async def broad_start(msg: Message, state: FSMContext):
    if msg.from_user.id not in config.ADMIN_IDS:
        return
    builder = InlineKeyboardBuilder()
    builder.button(text="❌ Отмена", callback_data="admin:cancel")
    await msg.answer(
        "📢 Отправьте текст, фото, документ или видео для массовой рассылки всем пользователям:",
        reply_markup=builder.as_markup(),
    )
    await state.set_state(FSMStates.wait_for_broadcast_msg)

@dp.message(FSMStates.wait_for_broadcast_msg)
async def broad_proc(msg: Message, state: FSMContext):
    if msg.from_user.id not in config.ADMIN_IDS:
        await state.clear()
        return
    if msg.text == "❌ Отмена рассылки":
        await state.clear()
        return await msg.answer("❌ Рассылка успешно отменена.", reply_markup=get_admin_menu())
    await state.clear()
    conn = sqlite3.connect(config.DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT tg_id FROM users")
    users = cursor.fetchall()
    conn.close()
    await msg.answer(f"🚀 Запуск рассылки по базе из {len(users)} записей...")
    cnt = 0
    failed = 0
    for row in users:
        try:
            target_id = int(row[0])
            if target_id <= 0:
                continue
            if msg.photo: await bot.send_photo(chat_id=target_id, photo=msg.photo[-1].file_id, caption=msg.caption)
            elif msg.document: await bot.send_document(chat_id=target_id, document=msg.document.file_id, caption=msg.caption)
            elif msg.video: await bot.send_video(chat_id=target_id, video=msg.video.file_id, caption=msg.caption)
            else: await bot.send_message(chat_id=target_id, text=msg.text)
            cnt += 1
            await asyncio.sleep(0.04)
        except Exception as error:
            failed += 1
            logger.debug("Рассылка пользователю %s не доставлена: %s", row[0], error)
    user_events.safe_record_event(
        msg.from_user.id,
        username=msg.from_user.username,
        direction="system",
        event_type="broadcast_completed",
        text=f"Рассылка завершена: доставлено {cnt}, ошибок {failed}",
        actor=f"admin:{msg.from_user.id}",
        metadata={"delivered": cnt, "failed": failed, "total": len(users)},
        db_path=config.DB_PATH,
    )
    await msg.answer(
        f"☑ Рассылка завершена. Доставлено: {cnt}; ошибок: {failed}.",
        reply_markup=get_admin_menu(),
    )

@dp.message(lambda m: m.text and "Управление" in m.text)
async def crm_main(msg: Message):
    if msg.from_user.id not in config.ADMIN_IDS:
        return
    await send_crm_list(msg)

@dp.callback_query(F.data.startswith("crmv_"))
async def crmview_card(call: CallbackQuery):
    if call.from_user.id not in config.ADMIN_IDS:
        await call.answer("Недостаточно прав", show_alert=True)
        return
    await call.answer()
    tg_id = int(call.data.split("_")[-1])
    u = db_get_user(tg_id)
    if not u: return
    builder = InlineKeyboardBuilder()
    builder.button(text=f"➕ Продлить {SUBSCRIPTION_DAYS} дней", callback_data=f"crmmod_{SUBSCRIPTION_DAYS}_{tg_id}")
    builder.button(text=f"➖ Урезать {SUBSCRIPTION_DAYS} дней", callback_data=f"crmmod_-{SUBSCRIPTION_DAYS}_{tg_id}")
    builder.button(text="🗑 Полностью удалить", callback_data=f"crmdel_{tg_id}")
    builder.adjust(2, 1)
    date_str = "Бессрочно" if u["expiry_time"] <= 0 else datetime.fromtimestamp(u["expiry_time"] / 1000).strftime("%Y-%m-%d %H:%M:%S")
    card = f"<b>👤 КЛИЕНТ CRM:</b>\n\n🆔 TG ID: <code>{tg_id}</code>\n👤 Ник: @{u['username'] or 'нет'}\n📧 Email: <code>{u['email']}</code>\n📅 До: <code>{date_str}</code>"
    await call.message.answer(card, reply_markup=builder.as_markup(), parse_mode="HTML")

@dp.callback_query(F.data.startswith("crmmod_"))
async def crm_mod_proc(call: CallbackQuery):
    if call.from_user.id not in config.ADMIN_IDS:
        await call.answer("Недостаточно прав", show_alert=True)
        return
    await call.answer("Изменение...")
    parts = call.data.split("_")
    days = int(parts[1])
    tg_id = int(parts[-1])
    u = db_get_user(tg_id)
    if not u: return
    
    panel_client = await update_client_in_panel(
        u["email"], u["uuid"], u["sub_id"], days, tg_id=tg_id
    )
    if panel_client:
        now_ts = int(time.time() * 1000)
        new_expiry_ts = int(panel_client.get("expiry_time") or 0)
        new_expiry_str = (
            "Бессрочно"
            if new_expiry_ts <= 0
            else datetime.fromtimestamp(new_expiry_ts / 1000).strftime("%Y-%m-%d %H:%M:%S")
        )
        db_upsert_user(
            tg_id,
            u["username"],
            str(panel_client.get("uuid") or u["uuid"] or ""),
            str(panel_client.get("email") or u["email"] or ""),
            new_expiry_ts,
            str(panel_client.get("sub_id") or u["sub_id"] or ""),
            1 if bool(panel_client.get("enable", True)) and (new_expiry_ts <= 0 or new_expiry_ts > now_ts) else 0,
            -1,
        )
        user_events.safe_record_event(
            tg_id,
            username=str(u.get("username") or ""),
            direction="system",
            event_type="subscription_days_changed",
            text=f"Срок изменён администратором на {days:+d} дн.",
            actor=f"admin:{call.from_user.id}",
            metadata={"expiry_time": new_expiry_ts},
            db_path=config.DB_PATH,
        )
        await call.message.answer(f"✅ Срок подписки изменён на {days:+d} дн. Новая дата: {new_expiry_str}", reply_markup=get_admin_menu())
    else:
        await call.message.answer("❌ Ошибка изменения срока на панели 3X-UI.", reply_markup=get_admin_menu())

@dp.callback_query(F.data.startswith("crmdel_"))
async def crm_delete_proc(call: CallbackQuery):
    if call.from_user.id not in config.ADMIN_IDS:
        await call.answer("Недостаточно прав", show_alert=True)
        return
    await call.answer("Удаление...")
    tg_id = int(call.data.split("_")[-1])
    u = db_get_user(tg_id)
    if not u: return
    panel_success = await delete_client_from_panel(u["email"])
    if not panel_success:
        await call.message.answer(
            "❌ 3x-ui не подтвердила удаление. Локальная запись сохранена.",
            reply_markup=get_admin_menu(),
        )
        return
    user_events.safe_record_event(
        tg_id,
        username=str(u.get("username") or ""),
        direction="system",
        event_type="user_deleted",
        text="Пользователь удалён администратором через Telegram-бота",
        actor=f"admin:{call.from_user.id}",
        metadata={"email": str(u.get("email") or "")},
        db_path=config.DB_PATH,
    )
    conn = sqlite3.connect(config.DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM users WHERE tg_id = ?", (tg_id,))
    conn.commit()
    conn.close()
    await call.message.answer(f"🗑 Пользователь успешно удален из базы бота и панели 3X-UI!", reply_markup=get_admin_menu())
    await call.message.delete()

@dp.message(lambda m: m.text and "Администратора" in m.text)
@dp.message(Command("admin"))
async def cmd_admin_kb(msg: Message, state: FSMContext):
    await state.clear()
    if msg.from_user.id in config.ADMIN_IDS:
        await msg.answer(
            f"<b>🛠 Администрирование {html.escape(str(config.SERVICE_NAME))}</b>",
            parse_mode="HTML",
            reply_markup=get_admin_menu(),
        )

@dp.message(lambda m: m.text and "вручную" in m.text)
async def manual_grant_start(msg: Message, state: FSMContext):
    if msg.from_user.id not in config.ADMIN_IDS: return
    keyboard = ReplyKeyboardMarkup(
        keyboard=[[
            KeyboardButton(
                text="🔎 Выбрать пользователя в Telegram",
                request_users=KeyboardButtonRequestUsers(
                    request_id=MANUAL_USER_REQUEST_ID,
                    user_is_bot=False,
                    max_quantity=1,
                    request_name=True,
                    request_username=True,
                ),
            )
        ]],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
    await msg.answer(
        "👤 Введите данные пользователя.\n\n"
        "С Telegram: <code>123456789 ivan</code>\n"
        "Без Telegram: <code>ivan</code> — только имя, без ID\n\n"
        "Или выберите человека кнопкой ниже — Telegram передаст настоящий ID автоматически.\n\n"
        "Для пользователя без Telegram доступ создаётся локально, "
        "а введённый ник станет именем клиента в 3x-ui.",
        parse_mode="HTML",
        reply_markup=keyboard,
    )
    await state.set_state(FSMStates.wait_for_manual_username)

@dp.message(F.users_shared, FSMStates.wait_for_manual_username)
async def manual_grant_from_shared_user(msg: Message, state: FSMContext):
    if msg.from_user.id not in config.ADMIN_IDS:
        await state.clear()
        return
    shared = msg.users_shared
    if shared is None or not shared.user_ids:
        await msg.answer("❌ Telegram не передал выбранного пользователя.")
        return
    tg_id = int(shared.user_ids[0])
    username = ""
    try:
        selected = shared.users[0] if shared.users else None
        username = str(getattr(selected, "username", "") or "").strip().lstrip("@")
        if not username:
            first_name = str(getattr(selected, "first_name", "") or "").strip()
            last_name = str(getattr(selected, "last_name", "") or "").strip()
            username = " ".join(x for x in (first_name, last_name) if x)
    except Exception:
        username = ""
    if not username:
        username = f"tg_{tg_id}"
    await state.clear()
    try:
        subscription = await asyncio.to_thread(
            ensure_subscription_sync,
            tg_id,
            username,
            SUBSCRIPTION_DAYS,
            config.DB_PATH,
        )
    except Exception as error:
        logger.exception("Ошибка выдачи по выбранному Telegram пользователю %s", tg_id)
        await msg.answer(
            f"❌ Не удалось создать или продлить подписку: <code>{html.escape(str(error)[:500])}</code>",
            parse_mode="HTML",
            reply_markup=ReplyKeyboardRemove(),
        )
        return
    full_sub_url = f"{config.SUB_BASE_URL}{subscription.sub_id}".replace("http://", "https://")
    action = "создана" if subscription.created else "продлена"
    try:
        user_events.safe_record_event(
            subscription.tg_id,
            username=subscription.username,
            direction="system",
            event_type="subscription_granted",
            text=f"Администратор выдал доступ на {SUBSCRIPTION_DAYS} дн.",
            actor=f"admin:{msg.from_user.id}",
            metadata={"expiry_time": subscription.expiry_time, "source": "telegram_user_picker"},
            db_path=config.DB_PATH,
        )
    except Exception:
        pass
    await msg.answer(
        f"✅ Подписка {action} для <b>@{html.escape(username)}</b>.\n"
        f"Telegram ID: <code>{tg_id}</code>\n"
        f"Ссылка подписки:\n<code>{full_sub_url}</code>",
        parse_mode="HTML",
        reply_markup=ReplyKeyboardRemove(),
    )


@dp.message(FSMStates.wait_for_manual_username)
async def manual_grant_process(msg: Message, state: FSMContext):
    if msg.from_user.id not in config.ADMIN_IDS:
        await state.clear()
        return
    parts = (msg.text or "").strip().split(maxsplit=1)
    raw_first = parts[0] if parts else ""
    target_tg_id = 0
    target_username = ""
    try:
        parsed_id = int(raw_first)
        if parsed_id > 0:
            target_tg_id = parsed_id
            target_username = parts[1].strip().lstrip("@") if len(parts) > 1 else ""
        else:
            raise ValueError
    except (ValueError, IndexError):
        target_username = (msg.text or "").strip().lstrip("@")[:80]

    if not target_username:
        await msg.answer(
            "❌ Укажите ник. Примеры: <code>123456789 ivan</code> или просто <code>ivan</code>.",
            parse_mode="HTML",
        )
        return
    await state.clear()
    try:
        subscription = await asyncio.to_thread(
            ensure_subscription_sync,
            target_tg_id,
            target_username,
            SUBSCRIPTION_DAYS,
            config.DB_PATH,
        )
    except Exception as error:
        logger.exception("Ошибка ручной выдачи для Telegram ID %s", target_tg_id)
        await msg.answer(
            f"❌ Не удалось создать или продлить подписку: <code>{html.escape(str(error)[:500])}</code>",
            parse_mode="HTML",
            reply_markup=get_admin_menu(),
        )
        return

    full_sub_url = f"{config.SUB_BASE_URL}{subscription.sub_id}".replace("http://", "https://")
    action = "создана" if subscription.created else "продлена"
    user_events.safe_record_event(
        subscription.tg_id,
        username=subscription.username,
        direction="system",
        event_type="subscription_granted",
        text=f"Администратор выдал доступ на {SUBSCRIPTION_DAYS} дн.",
        actor=f"admin:{msg.from_user.id}",
        metadata={"expiry_time": subscription.expiry_time},
        db_path=config.DB_PATH,
    )
    delivery_note = ""
    if subscription.tg_id > 0:
        try:
            await bot.send_message(
                subscription.tg_id,
                "✅ Администратор активировал вашу VPN-подписку.\n\n"
                f"Ссылка подписки:\n<code>{full_sub_url}</code>",
                parse_mode="HTML",
            )
            delivery_note = "\n📨 Ссылка отправлена пользователю в Telegram."
        except Exception as error:
            logger.info("Не удалось отправить ручную подписку пользователю %s: %s", subscription.tg_id, error)
            delivery_note = "\n⚠️ Бот не смог написать пользователю; передайте ссылку вручную."
        target_label = f"TG ID <code>{subscription.tg_id}</code>"
    else:
        target_label = f"локальный пользователь <b>{html.escape(subscription.username)}</b>"
        delivery_note = "\nℹ️ Telegram-привязки нет, ссылку нужно передать пользователю вручную."
    await msg.answer(
        f"✅ Подписка {action} для {target_label}.\n"
        f"Ссылка подписки:\n<code>{full_sub_url}</code>{delivery_note}",
        parse_mode="HTML",
        reply_markup=get_admin_menu(),
    )

@dp.message(lambda m: m.text and "Выйти" in m.text)
async def back_to_user_menu(msg: Message):
    await send_home(msg, msg.from_user.id)

@dp.message(lambda m: m.text and "Подписки и уведомления" in m.text)
async def admin_subscriptions_report(msg: Message):
    if msg.from_user.id not in config.ADMIN_IDS:
        return
    await send_subscription_report(msg)

async def main():
    await asyncio.to_thread(
        user_events.prune_events,
        keep_days=max(1, int(getattr(config, "USER_EVENT_KEEP_DAYS", 365))),
        max_rows=max(1_000, int(getattr(config, "USER_EVENT_MAX_ROWS", 250_000))),
        db_path=config.DB_PATH,
    )
    inbound_ids = await get_all_inbound_ids()
    if inbound_ids: logger.info(f"{config.SERVICE_NAME}: Связь с 3X-UI установлена! Доступно {len(inbound_ids)} инбаундов.")
    else: logger.warning("⚠ ВНИМАНИЕ: Список инбаундов пуст при старте.")
    await sync_panel_to_db()
    async def auto_sync_loop():
        maintenance_runs = 0
        while True:
            await asyncio.sleep(max(300, int(getattr(config, "BOT_SYNC_INTERVAL_SECONDS", 3600))))
            await sync_panel_to_db()
            maintenance_runs += 1
            if maintenance_runs % 24 == 0:
                await asyncio.to_thread(
                    user_events.prune_events,
                    keep_days=max(1, int(getattr(config, "USER_EVENT_KEEP_DAYS", 365))),
                    max_rows=max(1_000, int(getattr(config, "USER_EVENT_MAX_ROWS", 250_000))),
                    db_path=config.DB_PATH,
                )
    asyncio.create_task(auto_sync_loop())
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == '__main__':
    asyncio.run(main())
