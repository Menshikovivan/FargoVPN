# VPN Service Platform 2.8.0

Полная платформа управления VPN-сервисом: Telegram-бот, веб-панель, интеграция с 3x-ui, платежи и OCR, медиачат, массовая рассылка, резервные копии и централизованные обновления.

## Что изменилось в 2.8.0

- Исправлен `500 Internal Server Error` при входе в веб-панель с кириллическим/Unicode-логином или паролем.
- Сравнение чувствительных строк переведено на UTF-8 байты с сохранением constant-time проверки.
- Исправлена логика определения снимков для rollback.
- Добавлены regression-тесты для новых исправлений.

Подробности: [RELEASE_NOTES_2.8.0.md](RELEASE_NOTES_2.8.0.md).

## Установка

Для новой установки используйте `START_HERE.md` и `install_with_web.sh`.
Для обновления существующей установки используйте:

```bash
sudo bash install_with_web.sh --update-existing /root/vpn_bot
```

## После установки

```bash
curl -fsS http://127.0.0.1:8088/health
sudo systemctl status vpn-service-bot vpn-service-web --no-pager
```

Ожидаемая версия: `2.8.0`.
