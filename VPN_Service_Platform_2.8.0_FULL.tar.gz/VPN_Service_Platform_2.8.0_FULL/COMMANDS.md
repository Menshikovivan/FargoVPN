# Команды VPN Service Platform 2.6.9

## Службы

```bash
sudo systemctl status vpn-service-bot vpn-service-web --no-pager
sudo systemctl restart vpn-service-bot vpn-service-web
sudo journalctl -u vpn-service-bot -u vpn-service-web -n 300 --no-pager
```

## Диагностика

```bash
sudo /root/vpn_bot/.venv/bin/python /root/vpn_bot/diagnostics.py --live --json
```

## Яндекс.Диск

```bash
sudo /root/vpn_bot/.venv/bin/python /root/vpn_bot/backup.py --test-yandex
sudo journalctl -u vpn-service-backup.service -n 300 --no-pager
```

## Принудительный бэкап

```bash
sudo /root/vpn_bot/.venv/bin/python /root/vpn_bot/backup.py --force
```

## Обновление

```bash
cd /root/VPN_Service_Platform_2.6.9_FULL
sudo bash install_with_web.sh --update-existing /root/vpn_bot
```

## Проверка удаления старой Telegram-клавиатуры

```bash
sudo journalctl -u vpn-service-bot -n 200 --no-pager | grep -F 'Старая фиксированная Telegram-клавиатура скрыта'
```
