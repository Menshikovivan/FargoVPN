#!/usr/bin/env bash
set -Eeuo pipefail
export PYTHONUTF8=1

[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo 'Запустите установщик через sudo или от пользователя root.'; exit 1; }

PACKAGE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
SRC="$PACKAGE_ROOT/app"
DEFAULT_TARGET="/root/vpn_bot"
TARGET="$DEFAULT_TARGET"
BACKUP="/var/backups/vpn-service"
VERSION="$(cat "$SRC/VERSION" 2>/dev/null || echo 2.8.0)"
TMP=""
PREUPDATE_BACKUP=""
PREUPDATE_BACKUP_PART=""
PREUPDATE_SYSTEMD_DIR=""
NONINTERACTIVE=0
MODE=""
OLD=""
RESTORE=""
PROFILE=""
PROFILE_EXPLICIT=0
UPDATE_PATH=""

usage() {
  cat <<USAGE
Использование: $0 [--profile full|lite] [--update-existing /путь/к/приложению]

Без параметра --update-existing установщик предлагает:
  1) новую установку
  2) обновление существующей установки
  3) восстановление конфигурации и баз данных из резервной копии
USAGE
}

while (($#)); do
  case "$1" in
    --profile)
      [[ $# -ge 2 ]] || { echo 'После --profile необходимо указать значение full или lite.' >&2; exit 2; }
      PROFILE="${2,,}"
      PROFILE_EXPLICIT=1
      shift 2
      ;;
    --update-existing)
      [[ $# -ge 2 ]] || { echo 'После --update-existing необходимо указать путь к существующей установке.' >&2; exit 2; }
      UPDATE_PATH=$2
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Неизвестный аргумент: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

[[ -z $PROFILE || $PROFILE == full || $PROFILE == lite ]] || {
  echo 'Профиль должен иметь значение full или lite.' >&2
  exit 2
}

INSTALL_LOG="/var/log/vpn-service-install.log"
mkdir -p "$(dirname "$INSTALL_LOG")"
# Сохраняем полный журнал установки, не скрывая вывод в терминале.
exec > >(tee -a "$INSTALL_LOG") 2>&1

log_step() {
  echo
  echo "[Установщик FargoVPN] $*"
}

require_command() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "Не найдена обязательная команда: $1" >&2
    exit 1
  }
}

preflight() {
  log_step "Предварительная проверка системы"
  require_command bash
  require_command python3
  require_command systemctl
  require_command tar

  python3 - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit(f"Требуется Python 3.10 или новее; обнаружена версия {sys.version.split()[0]}")
print(f"Python {sys.version.split()[0]}: версия подходит")
PY

  if [[ ! -d /run/systemd/system ]]; then
    echo 'systemd не запущен. Для установки нужен обычный сервер Ubuntu/Debian, загруженный с systemd.' >&2
    exit 1
  fi

  local free_kb
  free_kb=$(df -Pk "$PACKAGE_ROOT" | awk 'NR==2 {print $4}')
  if [[ ${free_kb:-0} -lt 1048576 ]]; then
    echo 'Для установки требуется не менее 1 ГБ свободного места на диске.' >&2
    exit 1
  fi
}

apt_install() {
  local packages=("$@")
  local missing=()
  local package status attempt
  for package in "${packages[@]}"; do
    status=$(dpkg-query -W -f='${Status}' "$package" 2>/dev/null || true)
    [[ $status == 'install ok installed' ]] || missing+=("$package")
  done
  if ((${#missing[@]} == 0)); then
    log_step "Системные зависимости уже установлены; запуск APT пропущен"
    return 0
  fi

  log_step "Устанавливаются недостающие системные зависимости: ${missing[*]}"
  for attempt in 1 2 3; do
    if apt-get update && apt-get install -y --no-install-recommends "${missing[@]}"; then
      return 0
    fi
    echo "Попытка APT №$attempt завершилась ошибкой; выполняется повтор..." >&2
    sleep 3
  done
  echo 'Не удалось установить пакеты через APT. Подробности: /var/log/vpn-service-install.log.' >&2
  return 1
}

pip_install() {
  local requirements=$1
  local stamp="$TARGET/.venv/.vpn-requirements.sha256"
  local digest installed=''
  digest=$(python3 - "$requirements" <<'PYREQ'
from hashlib import sha256
from pathlib import Path
import sys
print(sha256(Path(sys.argv[1]).read_bytes()).hexdigest())
PYREQ
  )
  [[ ! -f $stamp ]] || installed=$(cat "$stamp" 2>/dev/null || true)
  if [[ $installed == "$digest" ]] \
     && "$TARGET/.venv/bin/python" -c 'import pip' >/dev/null 2>&1; then
    log_step "Состав Python-зависимостей не изменился; установка через pip пропущена"
    return 0
  fi

  log_step "Устанавливаются Python-зависимости из $requirements"
  "$TARGET/.venv/bin/python" -m pip install --disable-pip-version-check --upgrade pip wheel
  "$TARGET/.venv/bin/python" -m pip install --disable-pip-version-check -r "$requirements"
  printf '%s\n' "$digest" > "$stamp"
  chmod 600 "$stamp"
}

# Python, запущенный с путём к скрипту, автоматически видит каталог скрипта.
# При передаче кода через stdin Python видит только текущий каталог установщика.
# Поэтому все проверки stdin/-c с импортом модулей приложения выполняются из TARGET:
# так сохранённый config.py и локальные модули доступны во время обновления.
target_python() {
  (
    cd "$TARGET"
    PYTHONPATH="$TARGET${PYTHONPATH:+:$PYTHONPATH}" exec "$TARGET/.venv/bin/python" "$@"
  )
}

preflight

write_update_status() {
  local state=$1
  local detail=${2:-}
  local progress=${3:-}
  local phase=${4:-$state}
  [[ -n ${VPN_UPDATE_STATUS_FILE:-} ]] || return 0
  python3 - "$VPN_UPDATE_STATUS_FILE" "$state" "$VERSION" "$detail" "${PROFILE:-unknown}" "$progress" "$phase" "${VPN_UPDATE_JOB_ID:-}" <<'PY'
import fcntl, json, os, pathlib, secrets, sys, threading
from datetime import datetime, timezone
path = pathlib.Path(sys.argv[1])
path.parent.mkdir(parents=True, exist_ok=True)
lock_path = path.with_name(path.name + ".lock")
with lock_path.open("a+") as lock_handle:
    try:
        os.chmod(lock_path, 0o600)
    except OSError:
        pass
    fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
    try:
        previous = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(previous, dict):
            previous = {}
    except Exception:
        previous = {}
    data = {
        **previous,
        "state": sys.argv[2],
        "version": sys.argv[3],
        "detail": sys.argv[4],
        "message": sys.argv[4],
        "profile": sys.argv[5],
        "phase": sys.argv[7],
        "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    if sys.argv[6]:
        data["progress"] = max(
            int(previous.get("progress") or 0),
            max(0, min(100, int(sys.argv[6]))),
        )
    if sys.argv[8]:
        data["job_id"] = sys.argv[8]
    if sys.argv[2] in {"completed", "failed"}:
        data["finished_at"] = data["updated_at"]
    tmp = path.with_name(
        f".{path.name}.{os.getpid()}.{threading.get_ident()}.{secrets.token_hex(4)}.tmp"
    )
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.chmod(tmp, 0o600)
        tmp.replace(path)
    finally:
        tmp.unlink(missing_ok=True)
PY
}

cleanup() {
  [[ -z ${PREUPDATE_BACKUP_PART:-} ]] || rm -f -- "$PREUPDATE_BACKUP_PART"
  [[ -z $TMP ]] || rm -rf "$TMP"
}

restart_unit_family() {
  local unit
  for unit in "$@"; do
    if systemctl cat "$unit" >/dev/null 2>&1; then
      systemctl enable "$unit" >/dev/null 2>&1 || true
      systemctl restart "$unit" >/dev/null 2>&1 || true
      return 0
    fi
  done
  return 0
}

restart_existing_services() {
  systemctl daemon-reload >/dev/null 2>&1 || true
  restart_unit_family vpn-service-bot.service fargovpn-bot.service
  restart_unit_family vpn-service-web.service fargovpn-web.service
  restart_unit_family vpn-service-backup.timer fargovpn-backup.timer
  restart_unit_family vpn-service-reminders.timer fargovpn-reminders.timer
}

on_error() {
  local code=$?
  local line=${1:-неизвестно}
  local command=${2:-неизвестная_команда}
  local rollback_note=''
  trap - ERR
  set +e

  if [[ -n ${PREUPDATE_BACKUP:-} && -f $PREUPDATE_BACKUP \
        && -n ${TARGET:-} && $TARGET == /* && $TARGET != / && ${#TARGET} -gt 5 ]]; then
    write_update_status "rolling-back" "Ошибка установки; восстанавливается предыдущая версия" "${VPN_UPDATE_PROGRESS:-50}" "rollback"
    for unit in vpn-service-bot.service vpn-service-web.service vpn-service-backup.timer vpn-service-reminders.timer; do
      systemctl stop "$unit" >/dev/null 2>&1 || true
    done
    rm -rf -- "$TARGET"
    mkdir -p "$(dirname "$TARGET")"
    if tar -xzf "$PREUPDATE_BACKUP" -C "$(dirname "$TARGET")"; then
      if [[ -n ${PREUPDATE_SYSTEMD_DIR:-} && -d $PREUPDATE_SYSTEMD_DIR ]]; then
        rm -f \
          /etc/systemd/system/vpn-service-bot.service \
          /etc/systemd/system/vpn-service-web.service \
          /etc/systemd/system/vpn-service-backup.service \
          /etc/systemd/system/vpn-service-backup.timer \
          /etc/systemd/system/vpn-service-reminders.service \
          /etc/systemd/system/vpn-service-reminders.timer \
          /etc/systemd/system/vpn-service-update@.service \
          /etc/systemd/system/vpn-service-broadcast@.service
        cp -a "$PREUPDATE_SYSTEMD_DIR"/. /etc/systemd/system/ 2>/dev/null || true
      fi
      restart_existing_services
      rollback_note=" Предыдущая версия и systemd-службы автоматически восстановлены из $PREUPDATE_BACKUP."
    else
      rollback_note=" Автоматический откат из $PREUPDATE_BACKUP не удался; требуется ручное восстановление."
    fi
  else
    # Если файлы ещё не заменялись, например не удалось создать резервную копию,
    # возвращаем неизменённую установку в рабочее состояние, а не оставляем
    # её службы остановленными.
    restart_existing_services
    rollback_note=" Текущие файлы не заменялись; прежние службы запущены повторно."
  fi

  write_update_status "failed" "Ошибка на строке $line: $command.$rollback_note" "${VPN_UPDATE_PROGRESS:-50}" "failed"
  echo "Установка завершилась ошибкой на строке $line: $command.$rollback_note" >&2
  exit "$code"
}

trap cleanup EXIT
trap 'on_error "$LINENO" "$BASH_COMMAND"' ERR

ask() {
  local name=$1 prompt=$2 default=${3:-} secret=${4:-no} value=''
  while [[ -z $value ]]; do
    if [[ $secret == yes ]]; then
      read -rsp "$prompt${default:+ [$default]}: " value
      echo
    else
      read -rp "$prompt${default:+ [$default]}: " value
    fi
    value=${value:-$default}
  done
  printf -v "$name" '%s' "$value"
}

choose_profile() {
  local choice=''
  cat <<'EOF_PROFILE'
Профиль установки:
1) Полный (full): Telegram-бот и веб-панель администратора
2) Облегчённый (lite): только Telegram-бот, без веб-панели и её зависимостей
EOF_PROFILE
  read -rp 'Выберите профиль [1]: ' choice
  case ${choice:-1} in
    1) PROFILE=full ;;
    2) PROFILE=lite ;;
    *) echo 'Некорректный выбор профиля.' >&2; exit 1 ;;
  esac
}

project_dir() {
  local path=${1%/}
  if [[ -f "$path/main.py" && -f "$path/config.py" ]]; then
    realpath -m "$path"
    return 0
  fi
  if [[ -f "$path/app/main.py" && -f "$path/app/config.py" ]]; then
    realpath -m "$path/app"
    return 0
  fi
  return 1
}

config_literal() {
  local path=$1 name=$2
  python3 - "$path" "$name" <<'PY'
import ast, pathlib, sys
path = pathlib.Path(sys.argv[1])
name = sys.argv[2]
try:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        if any(isinstance(target, ast.Name) and target.id == name for target in node.targets):
            value = ast.literal_eval(node.value)
            if isinstance(value, bool):
                print("true" if value else "false")
            elif isinstance(value, (str, int, float)):
                print(value)
            break
except Exception:
    pass
PY
}

find_old() {
  local paths=() path normalized unit
  for unit in fargovpn-bot fargovpn-web vpn-service-bot vpn-service-web; do
    path=$(systemctl show -p WorkingDirectory --value "$unit.service" 2>/dev/null || true)
    [[ -z $path ]] || paths+=("$path")
  done
  paths+=("/root/vpn_bot" "/opt/vpn-service/app" "/opt/vpn-service" "/opt/fargovpn" "/opt/fargovpn-bot" "/root/FargoVPN_Bot" "/srv/vpn-bot")
  for path in "${paths[@]}"; do
    normalized=$(project_dir "$path" 2>/dev/null || true)
    [[ -z $normalized ]] || printf '%s\n' "$normalized"
  done | awk 'NF && !seen[$0]++'
}

if [[ -n $UPDATE_PATH ]]; then
  OLD=$(project_dir "$UPDATE_PATH" || true)
  [[ -n $OLD ]] || { echo 'В указанной установке не найдены main.py и config.py.' >&2; exit 2; }
  TARGET="$OLD"
  MODE=2
  NONINTERACTIVE=1
else
  cat <<EOF_MENU
========================================
 VPN Service Platform $VERSION
========================================
Каталог приложения по умолчанию: $DEFAULT_TARGET
1) Новая установка
2) Обновление существующей установки
3) Восстановление конфигурации и баз данных из резервной копии
EOF_MENU
  read -rp 'Выберите вариант: ' MODE
  [[ $MODE =~ ^[123]$ ]] || { echo 'Некорректный выбор.' >&2; exit 1; }
  if [[ $MODE == 2 ]]; then
    mapfile -t LIST < <(find_old)
    if ((${#LIST[@]})); then
      echo 'Найдены установки:'
      for index in "${!LIST[@]}"; do echo "$((index + 1))) ${LIST[$index]}"; done
      echo "$(( ${#LIST[@]} + 1 ))) Указать путь вручную"
      read -rp 'Выберите вариант: ' number
      if [[ $number =~ ^[0-9]+$ ]] && ((number >= 1 && number <= ${#LIST[@]})); then
        OLD=${LIST[$((number - 1))]}
      else
        ask MANUAL 'Каталог существующей установки'
        OLD=$(project_dir "$MANUAL" || true)
      fi
    else
      ask MANUAL 'Каталог существующей установки'
      OLD=$(project_dir "$MANUAL" || true)
    fi
    [[ -n $OLD ]] || { echo 'Существующая установка не найдена.' >&2; exit 1; }
    TARGET="$OLD"
  elif [[ $MODE == 3 ]]; then
    ask RESTORE 'Путь к резервной копии .tar.gz'
    [[ -f $RESTORE ]] || { echo 'Архив резервной копии не найден.' >&2; exit 1; }
  fi
fi

if [[ -n $OLD && -f $OLD/config.py ]]; then
  detected_backup=$(config_literal "$OLD/config.py" BACKUP_DIR)
  [[ -z $detected_backup || $detected_backup != /* ]] || BACKUP=$detected_backup
  if [[ -z $PROFILE ]]; then
    detected_profile=$(config_literal "$OLD/config.py" INSTALL_PROFILE)
    case ${detected_profile,,} in
      full|lite) PROFILE=${detected_profile,,} ;;
    esac
  fi
fi

if [[ -z $PROFILE ]]; then
  if [[ $MODE == 2 && $NONINTERACTIVE -eq 1 ]]; then
    # В версиях до 2.4.0 не было маркера профиля; по умолчанию использовался полный профиль.
    PROFILE=full
  else
    choose_profile
  fi
fi

[[ $PROFILE == full || $PROFILE == lite ]] || { echo 'Некорректный профиль установки.' >&2; exit 2; }
if [[ $PROFILE == full ]]; then
  [[ -f "$SRC/webapp.py" && -f "$SRC/update_manager.py" && -f "$SRC/requirements.txt" ]] || {
    echo 'Этот архив содержит облегчённую сборку и не может установить полный профиль с веб-панелью.' >&2
    exit 2
  }
else
  [[ -f "$SRC/requirements-lite.txt" ]] || { echo 'Не найден файл requirements-lite.txt.' >&2; exit 2; }
fi

VPN_UPDATE_PROGRESS=52
write_update_status "installing" "Проверяются системные пакеты" "$VPN_UPDATE_PROGRESS" "dependencies"
export DEBIAN_FRONTEND=noninteractive
if command -v debconf-set-selections >/dev/null 2>&1; then
  echo 'davfs2 davfs2/suid_file boolean false' | debconf-set-selections || true
fi
apt_install python3 python3-venv python3-pip curl sqlite3 rclone davfs2 ca-certificates iproute2 openssl rsync tesseract-ocr tesseract-ocr-rus tesseract-ocr-eng
require_command rsync
require_command curl
require_command ss
VPN_UPDATE_PROGRESS=58
write_update_status "installing" "Системные зависимости готовы" "$VPN_UPDATE_PROGRESS" "dependencies"
mkdir -p "$BACKUP" "$(dirname "$TARGET")" /var/lib/vpn-service/updates /var/lib/vpn-service/broadcasts /var/cache/vpn-service/chat-media
chmod 700 /var/lib/vpn-service/updates /var/lib/vpn-service/broadcasts /var/cache/vpn-service/chat-media

VPN_UPDATE_PROGRESS=60
write_update_status "installing" "Останавливаются службы перед безопасной заменой файлов" "$VPN_UPDATE_PROGRESS" "stop-services"
for unit in \
  fargovpn-bot fargovpn-web fargovpn-backup fargovpn-reminders \
  vpn-service-bot vpn-service-web vpn-service-backup.service vpn-service-backup.timer \
  vpn-service-reminders.service vpn-service-reminders.timer; do
  systemctl stop "$unit" 2>/dev/null || true
done
VPN_UPDATE_PROGRESS=62
write_update_status "installing" "Службы остановлены; подготавливается резервная копия" "$VPN_UPDATE_PROGRESS" "stop-services"

TMP=$(mktemp -d)
PREUPDATE_SYSTEMD_DIR="$TMP/systemd"
mkdir -p "$PREUPDATE_SYSTEMD_DIR"
for unit_file in \
  vpn-service-bot.service vpn-service-web.service \
  vpn-service-backup.service vpn-service-backup.timer \
  vpn-service-reminders.service vpn-service-reminders.timer \
  vpn-service-update@.service vpn-service-broadcast@.service \
  fargovpn-bot.service fargovpn-web.service \
  fargovpn-backup.service fargovpn-backup.timer \
  fargovpn-reminders.service fargovpn-reminders.timer; do
  [[ ! -f /etc/systemd/system/$unit_file ]] || cp -a "/etc/systemd/system/$unit_file" "$PREUPDATE_SYSTEMD_DIR/"
done
VPN_UPDATE_PROGRESS=64
write_update_status "installing" "Создаётся резервная копия текущей установки" "$VPN_UPDATE_PROGRESS" "backup"
if [[ -n $OLD ]]; then
  stamp=$(date +%Y%m%d_%H%M%S)
  completed_backup="$BACKUP/pre_update_${stamp}.tar.gz"
  PREUPDATE_BACKUP_PART="${completed_backup}.part"
  rm -f -- "$PREUPDATE_BACKUP_PART"
  tar -czf "$PREUPDATE_BACKUP_PART" -C "$(dirname "$OLD")" "$(basename "$OLD")"
  tar -tzf "$PREUPDATE_BACKUP_PART" >/dev/null
  chmod 600 "$PREUPDATE_BACKUP_PART"
  mv -f -- "$PREUPDATE_BACKUP_PART" "$completed_backup"
  PREUPDATE_BACKUP_PART=""
  PREUPDATE_BACKUP="$completed_backup"
  systemd_backup="${completed_backup%.tar.gz}.systemd.tar.gz"
  systemd_part="${systemd_backup}.part"
  rm -f -- "$systemd_part"
  systemd_files=()
  while IFS= read -r -d '' unit_file; do
    systemd_files+=("$(basename "$unit_file")")
  done < <(find "$PREUPDATE_SYSTEMD_DIR" -maxdepth 1 -type f -print0)
  if ((${#systemd_files[@]})); then
    tar -czf "$systemd_part" -C "$PREUPDATE_SYSTEMD_DIR" "${systemd_files[@]}"
    tar -tzf "$systemd_part" >/dev/null
    chmod 600 "$systemd_part"
    mv -f -- "$systemd_part" "$systemd_backup"
  fi
  cp "$OLD/config.py" "$TMP/config.py"
  for database_file in "$OLD/vpn_bot.db" "$OLD/data/vpn_bot.db"; do
    if [[ -f $database_file ]]; then
      cp "$database_file" "$TMP/vpn_bot.db"
      break
    fi
  done
fi
VPN_UPDATE_PROGRESS=68
write_update_status "installing" "Резервная копия текущей установки проверена" "$VPN_UPDATE_PROGRESS" "backup"

if [[ -n $RESTORE ]]; then
  export RESTORE TMP
  python3 <<'PY'
import os, pathlib, shutil, tarfile
archive_path = pathlib.Path(os.environ["RESTORE"])
destination = pathlib.Path(os.environ["TMP"])
root = destination.resolve()
with tarfile.open(archive_path, "r:gz") as archive:
    for member in archive.getmembers():
        name = member.name.replace("\\", "/")
        pure = pathlib.PurePosixPath(name)
        if (
            not name
            or member.issym()
            or member.islnk()
            or member.isdev()
            or not (member.isfile() or member.isdir())
            or name.startswith("/")
            or ".." in pure.parts
        ):
            raise SystemExit("Небезопасная структура архива резервной копии")
        target = (destination / name).resolve()
        if target != root and root not in target.parents:
            raise SystemExit("Небезопасный путь в архиве резервной копии")
        if member.isdir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        source = archive.extractfile(member)
        if source is None:
            raise SystemExit("Не удалось прочитать файл из резервной копии")
        with source, target.open("wb") as output:
            shutil.copyfileobj(source, output)
        os.chmod(target, member.mode & 0o777)
PY
  for candidate in \
    "$TMP/vpn_service_backup/bot/config.py" \
    "$TMP/vpn_service_backup/config.py" \
    "$TMP/config.py"; do
    [[ -f $candidate ]] && { cp "$candidate" "$TMP/restored_config.py"; break; }
  done
  for candidate in \
    "$TMP/vpn_service_backup/databases/vpn_bot.db" \
    "$TMP/vpn_service_backup/bot/data/vpn_bot.db" \
    "$TMP/vpn_service_backup/vpn_bot.db"; do
    [[ -f $candidate ]] && { cp "$candidate" "$TMP/restored_vpn_bot.db"; break; }
  done
fi

VPN_UPDATE_PROGRESS=70
write_update_status "installing" "Копируются файлы новой версии" "$VPN_UPDATE_PROGRESS" "files"
mkdir -p "$TARGET/data"
rsync -a --checksum --delete \
  --exclude='config.py' \
  --exclude='data/' \
  --exclude='.venv/' \
  --exclude='__pycache__/' \
  "$SRC/" "$TARGET/"
# Persist the changelog of the release that is actually installed. This keeps it
# available on the Updates page even after the release archive is removed.
release_notes_source="$PACKAGE_ROOT/RELEASE_NOTES_${VERSION}.md"
if [[ -f "$release_notes_source" ]]; then
  cp -f "$release_notes_source" "$TARGET/INSTALLED_CHANGELOG.md"
  printf '%s\n' "$VERSION" > "$TARGET/INSTALLED_CHANGELOG_VERSION"
  chmod 600 "$TARGET/INSTALLED_CHANGELOG.md" "$TARGET/INSTALLED_CHANGELOG_VERSION"
fi
find "$TARGET" -type d -name __pycache__ -prune -exec rm -rf {} +
VPN_UPDATE_PROGRESS=73
write_update_status "installing" "Файлы новой версии скопированы и сверены" "$VPN_UPDATE_PROGRESS" "files"

[[ -f $TMP/config.py ]] && cp "$TMP/config.py" "$TARGET/config.py"
[[ -f $TMP/vpn_bot.db ]] && cp "$TMP/vpn_bot.db" "$TARGET/data/vpn_bot.db"
[[ -f $TMP/restored_config.py ]] && cp "$TMP/restored_config.py" "$TARGET/config.py"
[[ -f $TMP/restored_vpn_bot.db ]] && cp "$TMP/restored_vpn_bot.db" "$TARGET/data/vpn_bot.db"

if [[ $PROFILE == lite ]]; then
  rm -f "$TARGET/webapp.py" "$TARGET/update_manager.py" "$TARGET/requirements.txt"
fi

VPN_UPDATE_PROGRESS=75
write_update_status "installing" "Проверяется Python-окружение" "$VPN_UPDATE_PROGRESS" "python"
if [[ ! -x "$TARGET/.venv/bin/python" ]] \
   || ! "$TARGET/.venv/bin/python" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
  log_step "Создаётся новое виртуальное окружение Python"
  rm -rf "$TARGET/.venv"
  python3 -m venv "$TARGET/.venv"
else
  log_step "Существующее виртуальное окружение Python исправно и будет использовано повторно"
fi
if [[ $PROFILE == full ]]; then
  REQUIREMENTS="$TARGET/requirements.txt"
else
  REQUIREMENTS="$TARGET/requirements-lite.txt"
fi
pip_install "$REQUIREMENTS"
VPN_UPDATE_PROGRESS=83
write_update_status "installing" "Python-зависимости установлены" "$VPN_UPDATE_PROGRESS" "python"
command -v tesseract >/dev/null
tesseract --list-langs 2>/dev/null | grep -qx 'rus'
tesseract --list-langs 2>/dev/null | grep -qx 'eng'

if [[ ! -f "$TARGET/config.py" ]]; then
  [[ $NONINTERACTIVE -eq 0 ]] || { echo 'При неинтерактивном обновлении не найден config.py.' >&2; exit 1; }
  ask SERVICE_NAME 'Название VPN-сервиса' 'FargoVPN'
  ask BOT_TOKEN 'Токен Telegram-бота'
  ask ADMIN_IDS 'Telegram ID администраторов через запятую'
  ask BASE_URL 'Адрес 3x-ui, заканчивающийся символом /'
  ask API_TOKEN 'API-токен 3x-ui' '' yes
  ask SUB_URL 'Базовый URL подписки'
  ask PRICE 'Цена за 30 дней' '150'
  ask PHONE 'Реквизиты для оплаты'
  ask BANK 'Банк'
  ask RECEIVER 'Получатель'

  WEB_USER=admin
  WEB_PORT=8088
  HASH=''
  SECRET=$(openssl rand -hex 32)
  if [[ $PROFILE == full ]]; then
    ask WEB_USER 'Логин веб-панели' 'admin'
    while true; do
      ask WEB_PORT 'Порт веб-панели' '8088'
      [[ $WEB_PORT =~ ^[0-9]+$ ]] && ((WEB_PORT >= 1024 && WEB_PORT <= 65535)) || { WEB_PORT=''; continue; }
      if ss -H -ltn "sport = :$WEB_PORT" | grep -q .; then
        echo 'Этот порт уже занят.'
        WEB_PORT=''
        continue
      fi
      break
    done
    ask WEB_PASS 'Пароль веб-панели' '' yes
    HASH=$("$TARGET/.venv/bin/python" - "$WEB_PASS" <<'PY'
import hashlib, secrets, sys
salt = secrets.token_bytes(16)
iterations = 260000
value = hashlib.pbkdf2_hmac("sha256", sys.argv[1].encode(), salt, iterations).hex()
print(f"pbkdf2_sha256${iterations}${salt.hex()}${value}")
PY
    )
  fi

  UPDATE_TOKEN=$(openssl rand -hex 32)
  export TARGET BACKUP PROFILE SERVICE_NAME BOT_TOKEN ADMIN_IDS BASE_URL API_TOKEN SUB_URL PRICE PHONE BANK RECEIVER WEB_USER WEB_PORT HASH SECRET UPDATE_TOKEN
  "$TARGET/.venv/bin/python" <<'PY'
import os, pathlib
q = lambda name: repr(os.environ[name])
ids = [int(value.strip()) for value in os.environ["ADMIN_IDS"].replace(";", ",").split(",") if value.strip()]
target = pathlib.Path(os.environ["TARGET"])
profile = os.environ["PROFILE"]
publisher = profile == "full" and os.environ["WEB_USER"] == "menshikovivan"
path = target / "config.py"
path.write_text(f'''import aiohttp
INSTALL_PROFILE = {profile!r}
SERVICE_NAME = {q("SERVICE_NAME")}
BOT_TOKEN = {q("BOT_TOKEN")}
ADMIN_IDS = {ids!r}
PANEL_NOTIFY_ADMIN_MESSAGES = True
SUBSCRIPTION_DAYS = 30
BOT_WELCOME_TEXT = ""
BOT_SUPPORT_PROMPT = ""
FAQ_INCY_URL = "https://apps.apple.com/ru/app/incy/id6756943388"
BOT_IDENTITY_REFRESH_SECONDS = 600
BOT_SYNC_INTERVAL_SECONDS = 3600
DB_PATH = {str(target / "data/vpn_bot.db")!r}
BASE_URL = {q("BASE_URL")}
MASTER_API_URL = BASE_URL
MASTER_API_TOKEN = {q("API_TOKEN")}
SUB_BASE_URL = {q("SUB_URL")}
PAYMENT_PRICE = {int(os.environ["PRICE"])}
PAYMENT_PHONE = {q("PHONE")}
PAYMENT_BANK = {q("BANK")}
PAYMENT_RECEIVER = {q("RECEIVER")}
RECEIPT_OCR_ENABLED = True
RECEIPT_AUTO_APPROVE = True
RECEIPT_MIN_AMOUNT = 150.0
RECEIPT_MAX_AGE_HOURS = 24
RECEIPT_RECEIVER_ALIASES = ""
RECEIPT_ALLOW_MASKED_PHONE = True
RECEIPT_TIMEZONE = "Europe/Moscow"
RECEIPT_OCR_LANGUAGES = "rus+eng"
RECEIPT_OCR_TIMEOUT = 20
RECEIPT_FILTER_NAME = True
RECEIPT_FILTER_PHONE = False
RECEIPT_FILTER_AMOUNT = True
RECEIPT_FILTER_DATE = False
RECEIPT_FILTER_STATUS = True
RECEIPT_FILTER_DUPLICATE = True
API_TIMEOUT = aiohttp.ClientTimeout(total=12.0)
WEB_HOST = "0.0.0.0"
WEB_PORT = {int(os.environ["WEB_PORT"])}
WEB_USERNAME = {q("WEB_USER")}
WEB_PASSWORD_HASH = {q("HASH")}
WEB_SECRET_KEY = {q("SECRET")}
WEB_COOKIE_HTTPS_ONLY = False
WEB_SESSION_MAX_AGE_SECONDS = 28800
WEB_TRUST_PROXY_HEADERS = False
WEB_LOGIN_MAX_ATTEMPTS = 5
WEB_LOGIN_WINDOW_SECONDS = 900
WEB_LOGIN_BLOCK_SECONDS = 900
WEB_LOGIN_MAX_BLOCK_SECONDS = 86400
WEB_LOGIN_SECURITY_RETENTION_DAYS = 30
XUI_DB_PATH = "/etc/x-ui/x-ui.db"
XUI_CACHE_SECONDS = 15
XUI_VERIFY_TLS = False
REMINDER_DAYS = [7, 3, 1, 0]
REMINDER_LOCK_PATH = "/run/vpn-service-reminders.lock"
METRICS_STORE_INTERVAL_SECONDS = 60
IDENTITY_IMPORT_MAX_MB = 512
USER_EVENT_KEEP_DAYS = 365
USER_EVENT_MAX_ROWS = 250000
CHAT_MEDIA_MAX_MB = 100
CHAT_MEDIA_CACHE_DIR = "/var/cache/vpn-service/chat-media"
CHAT_MEDIA_CACHE_DAYS = 30
CHAT_MEDIA_CACHE_MAX_MB = 512
BROADCAST_DIR = "/var/lib/vpn-service/broadcasts"
BROADCAST_MEDIA_MAX_MB = 45
BROADCAST_SEND_DELAY_SECONDS = 0.04
BROADCAST_STALE_SECONDS = 7200
BACKUP_DIR = {q("BACKUP")}
BACKUP_KEEP_DAYS = 14
BACKUP_INTERVAL_DAYS = 3
BACKUP_TELEGRAM = True
BACKUP_TELEGRAM_PART_MB = 45
BACKUP_INCLUDE_VENV = True
BACKUP_LOCK_PATH = "/run/vpn-service-backup.lock"
BACKUP_STATE_PATH = "/var/lib/vpn-service/backup-state.json"
YANDEX_DISK_ENABLED = False
YANDEX_DISK_MODE = "oauth"
YANDEX_DISK_TOKEN = ""
YANDEX_DISK_PATH = "VPN-Service-Backups"
YANDEX_LOCAL_PATH = "/mnt/yandex-disk"
YANDEX_LOCAL_REQUIRE_MOUNT = True
YANDEX_WEBDAV_URL = "https://webdav.yandex.ru"
YANDEX_DAVFS_SECRETS_PATH = "/etc/davfs2/secrets"
YANDEX_UPLOAD_RETRIES = 3
YANDEX_UPLOAD_VERIFY_ATTEMPTS = 8
YANDEX_UPLOAD_VERIFY_DELAY = 1.5
RCLONE_REMOTE = ""
RCLONE_PATH = "VPN-Service-Backups"
UPDATE_DIR = "/var/lib/vpn-service/updates"
UPDATE_PUBLISHER_USERNAME = "menshikovivan"
UPDATE_IS_PUBLISHER = {publisher!r}
UPDATE_MASTER_URL = ""
UPDATE_API_TOKEN = {q("UPDATE_TOKEN")}
UPDATE_CHECK_INTERVAL = 60
UPDATE_VERIFY_TLS = True
UPDATE_MAX_ARCHIVE_MB = 1024
UPDATE_STALE_JOB_SECONDS = 7200
''', encoding="utf-8")
PY
fi

export TARGET BACKUP PROFILE
"$TARGET/.venv/bin/python" <<'PY'
from pathlib import Path
import ast, hashlib, os, re, secrets, sys
path = Path(os.environ["TARGET"]) / "config.py"
text = path.read_text(encoding="utf-8")

def set_value(name, value):
    global text
    line = f"{name} = {value!r}"
    pattern = rf"(?m)^{re.escape(name)}\s*=.*$"
    text = re.sub(pattern, line, text) if re.search(pattern, text) else text.rstrip() + "\n" + line + "\n"

def ensure(name, value):
    if not re.search(rf"(?m)^{re.escape(name)}\s*=", text):
        set_value(name, value)

def literal(name, default=None):
    try:
        tree = ast.parse(text)
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == name for target in node.targets):
                return ast.literal_eval(node.value)
    except Exception:
        return default
    return default

set_value("INSTALL_PROFILE", os.environ["PROFILE"])
set_value("DB_PATH", str(Path(os.environ["TARGET"]) / "data/vpn_bot.db"))
set_value("BACKUP_DIR", os.environ["BACKUP"])
ensure("SERVICE_NAME", "FargoVPN")
ensure("PANEL_NOTIFY_ADMIN_MESSAGES", True)
ensure("SUBSCRIPTION_DAYS", 30)
ensure("BOT_WELCOME_TEXT", "")
ensure("BOT_SUPPORT_PROMPT", "")
ensure("FAQ_INCY_URL", "https://apps.apple.com/ru/app/incy/id6756943388")
ensure("BOT_IDENTITY_REFRESH_SECONDS", 600)
ensure("BOT_SYNC_INTERVAL_SECONDS", 3600)
ensure("BACKUP_TELEGRAM", True)
ensure("BACKUP_TELEGRAM_PART_MB", 45)
ensure("BACKUP_KEEP_DAYS", 14)
ensure("BACKUP_INTERVAL_DAYS", 3)
ensure("BACKUP_INCLUDE_VENV", True)
ensure("BACKUP_LOCK_PATH", "/run/vpn-service-backup.lock")
ensure("BACKUP_STATE_PATH", "/var/lib/vpn-service/backup-state.json")
ensure("XUI_DB_PATH", "/etc/x-ui/x-ui.db")
ensure("XUI_CACHE_SECONDS", 15)
ensure("XUI_VERIFY_TLS", False)
ensure("REMINDER_DAYS", [7, 3, 1, 0])
ensure("REMINDER_LOCK_PATH", "/run/vpn-service-reminders.lock")
ensure("METRICS_STORE_INTERVAL_SECONDS", 60)
ensure("IDENTITY_IMPORT_MAX_MB", 512)
ensure("USER_EVENT_KEEP_DAYS", 365)
ensure("USER_EVENT_MAX_ROWS", 250000)
ensure("CHAT_MEDIA_MAX_MB", 100)
ensure("CHAT_MEDIA_CACHE_DIR", "/var/cache/vpn-service/chat-media")
ensure("CHAT_MEDIA_CACHE_DAYS", 30)
ensure("CHAT_MEDIA_CACHE_MAX_MB", 512)
ensure("BROADCAST_DIR", "/var/lib/vpn-service/broadcasts")
ensure("BROADCAST_MEDIA_MAX_MB", 45)
ensure("BROADCAST_SEND_DELAY_SECONDS", 0.04)
ensure("BROADCAST_STALE_SECONDS", 7200)
ensure("WEB_HOST", "0.0.0.0")
ensure("WEB_PORT", 8088)
ensure("WEB_USERNAME", "admin")
ensure("WEB_PASSWORD_HASH", "")
ensure("WEB_COOKIE_HTTPS_ONLY", False)
ensure("WEB_SESSION_MAX_AGE_SECONDS", 28800)
ensure("WEB_TRUST_PROXY_HEADERS", False)
ensure("WEB_LOGIN_MAX_ATTEMPTS", 5)
ensure("WEB_LOGIN_WINDOW_SECONDS", 900)
ensure("WEB_LOGIN_BLOCK_SECONDS", 900)
ensure("WEB_LOGIN_MAX_BLOCK_SECONDS", 86400)
ensure("WEB_LOGIN_SECURITY_RETENTION_DAYS", 30)
legacy_password = str(literal("WEB_PASSWORD_HASH", "") or "")
if legacy_password and not legacy_password.startswith("pbkdf2_sha256$"):
    salt = secrets.token_bytes(16)
    iterations = 260000
    digest = hashlib.pbkdf2_hmac("sha256", legacy_password.encode("utf-8"), salt, iterations)
    set_value("WEB_PASSWORD_HASH", f"pbkdf2_sha256${iterations}${salt.hex()}${digest.hex()}")
if not str(literal("WEB_SECRET_KEY", "") or "").strip():
    set_value("WEB_SECRET_KEY", secrets.token_hex(32))
ensure("RECEIPT_OCR_ENABLED", True)
ensure("RECEIPT_AUTO_APPROVE", True)
ensure("RECEIPT_MIN_AMOUNT", 150.0)
ensure("RECEIPT_MAX_AGE_HOURS", 24)
ensure("RECEIPT_RECEIVER_ALIASES", "")
ensure("RECEIPT_ALLOW_MASKED_PHONE", True)
ensure("RECEIPT_TIMEZONE", "Europe/Moscow")
ensure("RECEIPT_OCR_LANGUAGES", "rus+eng")
ensure("RECEIPT_OCR_TIMEOUT", 20)
ensure("RECEIPT_FILTER_NAME", True)
ensure("RECEIPT_FILTER_PHONE", False)
ensure("RECEIPT_FILTER_AMOUNT", True)
ensure("RECEIPT_FILTER_DATE", False)
ensure("RECEIPT_FILTER_STATUS", True)
ensure("RECEIPT_FILTER_DUPLICATE", True)
ensure("YANDEX_DISK_ENABLED", False)
ensure("YANDEX_DISK_MODE", "oauth")
ensure("YANDEX_DISK_TOKEN", "")
ensure("YANDEX_DISK_PATH", "VPN-Service-Backups")
ensure("YANDEX_LOCAL_PATH", "/mnt/yandex-disk")
ensure("YANDEX_LOCAL_REQUIRE_MOUNT", True)
ensure("YANDEX_WEBDAV_URL", "https://webdav.yandex.ru")
ensure("YANDEX_DAVFS_SECRETS_PATH", "/etc/davfs2/secrets")
ensure("YANDEX_UPLOAD_RETRIES", 3)
ensure("YANDEX_UPLOAD_VERIFY_ATTEMPTS", 8)
ensure("YANDEX_UPLOAD_VERIFY_DELAY", 1.5)
ensure("RCLONE_REMOTE", "")
ensure("RCLONE_PATH", "VPN-Service-Backups")
ensure("UPDATE_DIR", "/var/lib/vpn-service/updates")
ensure("UPDATE_PUBLISHER_USERNAME", "menshikovivan")
ensure("UPDATE_MASTER_URL", "")
if not str(literal("UPDATE_API_TOKEN", "") or "").strip():
    set_value("UPDATE_API_TOKEN", secrets.token_hex(32))
ensure("UPDATE_CHECK_INTERVAL", 60)
ensure("UPDATE_VERIFY_TLS", True)
ensure("UPDATE_MAX_ARCHIVE_MB", 1024)
ensure("UPDATE_STALE_JOB_SECONDS", 7200)
if literal("UPDATE_IS_PUBLISHER", None) is None:
    set_value(
        "UPDATE_IS_PUBLISHER",
        os.environ["PROFILE"] == "full" and str(literal("WEB_USERNAME", "")) == "menshikovivan",
    )
path.write_text(text, encoding="utf-8")
PY

if [[ $PROFILE == full ]]; then
  mapfile -t WEB_INFO < <(target_python <<'PY'
import config
stored = str(getattr(config, "WEB_PASSWORD_HASH", ""))
parts = stored.split("$")
ready = stored.startswith("pbkdf2_sha256$") and len(parts) == 4 and bool(getattr(config, "WEB_USERNAME", ""))
print("1" if ready else "0")
print(str(getattr(config, "WEB_USERNAME", "admin") or "admin"))
print(str(getattr(config, "WEB_PORT", 8088) or 8088))
PY
  )
  if [[ ${WEB_INFO[0]:-0} != 1 ]]; then
    [[ $NONINTERACTIVE -eq 0 ]] || {
      echo 'Для полного профиля не заданы WEB_USERNAME и WEB_PASSWORD_HASH; один раз запустите установщик в интерактивном режиме.' >&2
      exit 1
    }
    ask WEB_USER 'Логин веб-панели' "${WEB_INFO[1]:-admin}"
    while true; do
      ask WEB_PORT 'Порт веб-панели' "${WEB_INFO[2]:-8088}"
      [[ $WEB_PORT =~ ^[0-9]+$ ]] && ((WEB_PORT >= 1024 && WEB_PORT <= 65535)) || { WEB_PORT=''; continue; }
      if ss -H -ltn "sport = :$WEB_PORT" | grep -q .; then
        echo 'Этот порт уже занят.'
        WEB_PORT=''
        continue
      fi
      break
    done
    ask WEB_PASS 'Пароль веб-панели' '' yes
    HASH=$("$TARGET/.venv/bin/python" - "$WEB_PASS" <<'PY'
import hashlib, secrets, sys
salt = secrets.token_bytes(16)
iterations = 260000
value = hashlib.pbkdf2_hmac("sha256", sys.argv[1].encode(), salt, iterations).hex()
print(f"pbkdf2_sha256${iterations}${salt.hex()}${value}")
PY
    )
    SECRET=$(openssl rand -hex 32)
    export TARGET WEB_USER WEB_PORT HASH SECRET
    "$TARGET/.venv/bin/python" <<'PY'
from pathlib import Path
import os, re
path = Path(os.environ["TARGET"]) / "config.py"
text = path.read_text(encoding="utf-8")
for name, value in {
    "WEB_USERNAME": os.environ["WEB_USER"],
    "WEB_PORT": int(os.environ["WEB_PORT"]),
    "WEB_PASSWORD_HASH": os.environ["HASH"],
    "WEB_SECRET_KEY": os.environ["SECRET"],
}.items():
    line = f"{name} = {value!r}"
    pattern = rf"(?m)^{re.escape(name)}\s*=.*$"
    text = re.sub(pattern, line, text) if re.search(pattern, text) else text.rstrip() + "\n" + line + "\n"
path.write_text(text, encoding="utf-8")
PY
  fi
fi

chmod 600 "$TARGET/config.py"
VPN_UPDATE_PROGRESS=86
write_update_status "migrating" "Проверяется конфигурация и обновляется база" "$VPN_UPDATE_PROGRESS" "database"
log_step "Проверка конфигурации и Python-модулей"
"$TARGET/.venv/bin/python" -m py_compile "$TARGET"/*.py "$TARGET"/services/*.py
target_python - <<'PY'
import importlib
import config
assert str(config.SERVICE_NAME).strip(), "Параметр SERVICE_NAME пуст"
assert str(config.BOT_TOKEN).strip(), "Параметр BOT_TOKEN пуст"
assert isinstance(config.ADMIN_IDS, list) and config.ADMIN_IDS, "Список ADMIN_IDS пуст"
for module in ("main", "backup", "trigger_reminders", "sync_users", "service_audit"):
    importlib.import_module(module)
if str(getattr(config, "INSTALL_PROFILE", "full")).lower() == "full":
    importlib.import_module("webapp")
print("Проверка импортов и синтаксиса Python: успешно")
PY
"$TARGET/.venv/bin/python" "$TARGET/init_db.py"
VPN_UPDATE_PROGRESS=89
write_update_status "migrating" "Конфигурация и структура базы данных проверены" "$VPN_UPDATE_PROGRESS" "database"

VPN_UPDATE_PROGRESS=91
write_update_status "installing" "Обновляются systemd-службы" "$VPN_UPDATE_PROGRESS" "services"
cat > /etc/systemd/system/vpn-service-bot.service <<EOF_UNIT
[Unit]
Description=Telegram-бот VPN Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET
ExecStart=$TARGET/.venv/bin/python $TARGET/main.py
Restart=on-failure
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF_UNIT

if [[ $PROFILE == full ]]; then
  PORT=$(target_python -c 'import config; print(int(config.WEB_PORT))')
  cat > /etc/systemd/system/vpn-service-web.service <<EOF_UNIT
[Unit]
Description=Веб-панель VPN Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET
ExecStart=$TARGET/.venv/bin/uvicorn webapp:app --app-dir $TARGET --host 0.0.0.0 --port $PORT --workers 1
Restart=on-failure
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF_UNIT
else
  systemctl disable --now vpn-service-web.service >/dev/null 2>&1 || true
  rm -f /etc/systemd/system/vpn-service-web.service
fi

if [[ $PROFILE == full ]]; then
  cat > /etc/systemd/system/vpn-service-update@.service <<EOF_UNIT
[Unit]
Description=Фоновое обновление VPN Service (%i)
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=root
WorkingDirectory=$TARGET
ExecStart=$TARGET/.venv/bin/python $TARGET/update_worker.py --job-id %i --startup-delay 4
Nice=10
IOSchedulingClass=best-effort
TimeoutStartSec=infinity
Environment=PYTHONUNBUFFERED=1
EOF_UNIT

  cat > /etc/systemd/system/vpn-service-broadcast@.service <<EOF_UNIT
[Unit]
Description=Массовая Telegram-рассылка VPN Service (%i)
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=root
WorkingDirectory=$TARGET
ExecStart=$TARGET/.venv/bin/python $TARGET/broadcast_worker.py --job-id %i --startup-delay 1
Nice=10
IOSchedulingClass=best-effort
TimeoutStartSec=infinity
Environment=PYTHONUNBUFFERED=1
EOF_UNIT
else
  rm -f \
    /etc/systemd/system/vpn-service-update@.service \
    /etc/systemd/system/vpn-service-broadcast@.service
fi

cat > /etc/systemd/system/vpn-service-backup.service <<EOF_UNIT
[Unit]
Description=Полная резервная копия VPN Service
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=root
WorkingDirectory=$TARGET
ExecStart=$TARGET/.venv/bin/python $TARGET/backup.py --scheduled
EOF_UNIT

cat > /etc/systemd/system/vpn-service-backup.timer <<'EOF_UNIT'
[Unit]
Description=Ежедневная проверка необходимости резервной копии VPN Service

[Timer]
OnCalendar=*-*-* 03:00:00
Persistent=true
AccuracySec=5m

[Install]
WantedBy=timers.target
EOF_UNIT

cat > /etc/systemd/system/vpn-service-reminders.service <<EOF_UNIT
[Unit]
Description=Напоминания о VPN-подписке
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
User=root
WorkingDirectory=$TARGET
ExecStart=$TARGET/.venv/bin/python $TARGET/trigger_reminders.py
EOF_UNIT

cat > /etc/systemd/system/vpn-service-reminders.timer <<'EOF_UNIT'
[Unit]
Description=Ежедневные напоминания о VPN-подписке

[Timer]
OnCalendar=*-*-* 09:00:00
Persistent=true
AccuracySec=5m

[Install]
WantedBy=timers.target
EOF_UNIT

systemctl daemon-reload
VPN_UPDATE_PROGRESS=94
write_update_status "installing" "Файлы systemd-служб обновлены" "$VPN_UPDATE_PROGRESS" "services"
"$TARGET/.venv/bin/python" "$TARGET/service_audit.py" --fix --json >/var/log/vpn-service-audit-install.json 2>&1 || true
# Предыдущая установка могла быть запущена вручную, вне systemd. Такой процесс
# удерживает Telegram getUpdates и создаёт впечатление, что новый бот не работает.
# Останавливаем только процессы, которые однозначно запускают точки входа проекта.
target_python - <<'PY'
from pathlib import Path
import os, signal, time
import service_audit

current = os.getpid()
for item in service_audit.relevant_processes():
    pid = int(item["pid"])
    command = str(item["command"])
    if pid == current:
        continue
    if not any(marker in command for marker in ("main.py", "webapp.py", "backup.py", "trigger_reminders.py")):
        continue
    try:
        os.kill(pid, signal.SIGTERM)
        print(f"Остановлен старый процесс FargoVPN {pid}: {command}")
    except ProcessLookupError:
        pass
    except PermissionError:
        print(f"Не удалось остановить старый процесс FargoVPN {pid}: недостаточно прав")

time.sleep(1)
for item in service_audit.relevant_processes():
    pid = int(item["pid"])
    if pid == current:
        continue
    try:
        os.kill(pid, signal.SIGKILL)
        print(f"Принудительно остановлен зависший процесс FargoVPN {pid}")
    except (ProcessLookupError, PermissionError):
        pass
PY
systemctl daemon-reload
VERIFY_UNITS=(
  /etc/systemd/system/vpn-service-bot.service
  /etc/systemd/system/vpn-service-backup.service
  /etc/systemd/system/vpn-service-backup.timer
  /etc/systemd/system/vpn-service-reminders.service
  /etc/systemd/system/vpn-service-reminders.timer
)
if [[ $PROFILE == full ]]; then
  VERIFY_UNITS+=(
    /etc/systemd/system/vpn-service-web.service
    /etc/systemd/system/vpn-service-update@.service
    /etc/systemd/system/vpn-service-broadcast@.service
  )
fi
if ! systemd-analyze verify "${VERIFY_UNITS[@]}"; then
  echo 'Проверка unit-файлов systemd завершилась ошибкой. Службы не запущены.' >&2
  exit 1
fi

VPN_UPDATE_PROGRESS=96
write_update_status "restarting" "Перезапускаются службы" "$VPN_UPDATE_PROGRESS" "restart"
systemctl enable vpn-service-bot.service vpn-service-backup.timer vpn-service-reminders.timer
if [[ $PROFILE == full ]]; then
  systemctl enable vpn-service-web.service
fi
systemctl restart vpn-service-bot.service
if [[ $PROFILE == full ]]; then
  systemctl restart vpn-service-web.service
fi
systemctl restart vpn-service-backup.timer
systemctl restart vpn-service-reminders.timer

VPN_UPDATE_PROGRESS=98
write_update_status "health-check" "Проверяется запуск бота и веб-панели" "$VPN_UPDATE_PROGRESS" "health"
systemctl is-active --quiet vpn-service-bot.service || {
  journalctl -u vpn-service-bot -n 120 --no-pager
  exit 1
}

if [[ $PROFILE == full ]]; then
  for _ in $(seq 1 40); do
    if curl -fsS -H 'Cache-Control: no-cache' "http://127.0.0.1:$PORT/health" | grep -Fq "$VERSION"; then
      break
    fi
    sleep 1
  done
  if ! curl -fsS -H 'Cache-Control: no-cache' "http://127.0.0.1:$PORT/health" | grep -Fq "$VERSION"; then
    echo "Веб-панель не запустилась корректно на порту $PORT (ожидалась версия $VERSION)." >&2
    journalctl -u vpn-service-web -n 150 --no-pager
    exit 1
  fi
fi

systemctl reset-failed >/dev/null 2>&1 || true
if [[ $PROFILE == full ]]; then
  PROFILE_LABEL="полный (full)"
  PROFILE_STATUS="Полный профиль"
else
  PROFILE_LABEL="облегчённый (lite)"
  PROFILE_STATUS="Облегчённый профиль"
fi
write_update_status "completed" "$PROFILE_STATUS установлен; проверки служб пройдены" "100" "complete"
IP=$(hostname -I | awk '{print $1}')
echo '========================================'
echo "Установка/обновление завершено: версия $VERSION"
echo "Профиль: $PROFILE_LABEL"
echo "Каталог приложения: $TARGET"
if [[ $PROFILE == full ]]; then
  echo "Веб-панель: http://${IP:-SERVER_IP}:$PORT"
  echo "Проверка состояния: http://${IP:-SERVER_IP}:$PORT/health"
  echo "При необходимости откройте порт в брандмауэре: ufw allow $PORT/tcp"
fi
echo "Настройка локального WebDAV Яндекс.Диска: $TARGET/configure_yandex_webdav.sh"
