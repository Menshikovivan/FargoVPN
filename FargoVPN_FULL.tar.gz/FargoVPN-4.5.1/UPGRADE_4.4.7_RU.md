# Обновление FargoVPN до 4.4.7

Для 4.4.7 рекомендуется один раз выполнить обновление из SSH-консоли. После этого следующие релизы снова можно устанавливать через веб-панель.

## 1. Перейти в /root и проверить архив

```bash
cd /root
tar -tzf VPN_Service_Platform_4.4.7_FULL.tar.gz | head -30
```

Внутри должен быть каталог `FargoVPN-4.4.7/`.

## 2. Проверить незавершённую старую задачу обновления

```bash
systemctl list-units --all 'vpn-service-update*' --no-pager
cat /var/lib/vpn-service/updates/status.json 2>/dev/null || true
```

Если старая задача действительно всё ещё выполняется, остановите только её unit по точному имени из первой команды.

## 3. Распаковать 4.4.7

```bash
cd /root
rm -rf /root/FargoVPN-4.4.7
tar -xzf /root/VPN_Service_Platform_4.4.7_FULL.tar.gz -C /root
```

## 4. Запустить обновление существующего `/root/vpn_bot`

```bash
cd /root/FargoVPN-4.4.7
export VPN_UPDATE_STATUS_FILE=/var/lib/vpn-service/updates/status.json
export VPN_UPDATE_JOB_ID="console-$(date +%s)"
bash ./install.sh --profile full --update-existing /root/vpn_bot
```

На обновлении 4.4.7 установленный Nginx L4 Stream Router Mask не переустанавливается, не обновляется и не проверяется через GitHub. Установщик должен перейти от подготовки к системным пакетам без зависания на 50%.

## 5. Проверить после установки

```bash
cat /root/vpn_bot/VERSION
cat /root/vpn_bot/app/VERSION 2>/dev/null || true
systemctl is-active vpn-service-bot.service
systemctl is-active vpn-service-web.service
systemctl is-active vpn-service-web.socket

SOCKET=$(python3 -c 'import sys; sys.path.insert(0,"/root/vpn_bot"); import config; print(getattr(config,"WEB_SOCKET_PATH","/run/vpn-service/fargovpn.sock"))')
curl --unix-socket "$SOCKET" -fsS --max-time 5 http://localhost/health
```

## 6. Проверить отсутствие устаревшей установки age/certbot в новом установщике

```bash
grep -n '^apt_install python3 python3-venv' /root/FargoVPN-4.4.7/install.sh
grep -nE '^apt_install .* (age|certbot)( |$)|age-keygen -[oy]' /root/FargoVPN-4.4.7/install.sh || true
```

В первой команде `age` и `certbot` отсутствуют. Исторические имена `BACKUP_AGE_*` могут встречаться только в коде очистки старого конфига; новый установщик их не создаёт.
