# FargoVPN 4.5 — диагностика совместного сбоя FargoVPN web + 3x-ui

Цель: зафиксировать состояние сервера в момент, когда web-панель FargoVPN и 3x-ui перестают открываться, но Telegram-бот продолжает отвечать.

Команды ниже не изменяют конфигурацию. Выполняйте их от root или через `sudo`.

## 1. Время, uptime и нагрузка

```bash
date -Is
hostname
uptime
free -h
swapon --show
df -hT
df -ih
vmstat 1 10
```

При наличии `sysstat`:

```bash
iostat -xz 1 10
pidstat -dur 1 10
```

Что подтверждает проблему:
- `si/so` в `vmstat` — активный swap;
- большой `%wa` — ожидание диска;
- в `iostat` устройство имеет высокий `%util` и растёт `await` — дисковое давление;
- `df -h`/`df -i` показывает почти заполненный диск или inode.

## 2. Kernel/OOM/I/O

```bash
dmesg -T | grep -Ei 'oom|out of memory|killed process|i/o error|blk|nvme|ext4|xfs|reset|hung task'
journalctl -k --since '30 min ago' --no-pager | grep -Ei 'oom|out of memory|killed process|i/o error|blk|nvme|ext4|xfs|reset|hung task'
```

`Killed process`, `Out of memory`, I/O errors или reset устройства во время окна сбоя — прямое подтверждение соответствующего класса причины.

## 3. Статус и рестарты всех ключевых сервисов

```bash
for s in vpn-service-bot vpn-service-web vpn-service-web.socket vpn-service-nginx-guard vpn-service-backup vpn-service-backup.timer vpn-service-reminders vpn-service-reminders.timer nginx x-ui xray; do
  echo
  echo "===== $s ====="
  systemctl --no-pager --full status "$s" 2>/dev/null | sed -n '1,18p'
done
```

История рестартов:

```bash
journalctl -u vpn-service-bot -u vpn-service-web -u vpn-service-web.socket -u vpn-service-nginx-guard -u vpn-service-backup -u nginx -u x-ui -u xray --since '1 hour ago' --no-pager
```

Ищите `Started`, `Stopped`, `Main process exited`, `failed`, `Restart`, `code=`, `status=` с точным временем.

Если одновременно перезапустились nginx, web или x-ui ровно в момент отказа — это уже подтверждённая корреляция, а не гипотеза.

## 4. Локальный FargoVPN socket

```bash
ls -la /run/vpn-service/
ss -lxnp | grep -F 'fargovpn.sock' || true
curl --unix-socket /run/vpn-service/fargovpn.sock -fsS http://localhost/healthz
```

Если `/healthz` отвечает локально во время внешнего отказа, приложение и Unix socket живы, а искать нужно между nginx и клиентом/сетью.

## 5. Локальный 3x-ui

Сначала выясните реальный порт из systemd/config:

```bash
systemctl cat x-ui 2>/dev/null | grep -E 'ExecStart|Environment|EnvironmentFile'
ss -lntp | grep -E ':10443|:2053|:2096|:443' || true
```

Затем локально проверьте тот порт, который фактически использует 3x-ui:

```bash
curl -kI --max-time 5 http://127.0.0.1:PORT/ || true
```

`PORT` замените фактическим портом. Важна не конкретная строка ответа, а отличие local vs public.

## 6. Nginx access/error и HTTP-коды

```bash
nginx -t
nginx -T 2>&1 | grep -nE 'listen .*443|server_name|limit_req_zone|limit_req|fargovpn|proxy_pass|proxy_read_timeout|proxy_connect_timeout'

tail -n 200 /var/log/nginx/error.log

tail -n 500 /var/log/nginx/access.log | grep -E ' (429|499|500|502|503|504) '
```

Интерпретация:
- `429` — rate limit;
- `499` — клиент разорвал соединение до ответа nginx;
- `502` — nginx не получил корректный ответ upstream;
- `504` — upstream не ответил в заданный timeout;
- отсутствие записей при реальном обращении может указывать, что запрос не доходит до nginx.

## 7. Fail2ban и firewall

```bash
fail2ban-client status 2>/dev/null || true
fail2ban-client status sshd 2>/dev/null || true
fail2ban-client status nginx-http-auth 2>/dev/null || true
journalctl -u fail2ban --since '1 hour ago' --no-pager 2>/dev/null | grep -Ei 'Ban|Unban|Found' || true
ufw status verbose 2>/dev/null || true
nft list ruleset 2>/dev/null | sed -n '1,240p'
```

Блокировка конкретного IP в точное время инцидента — подтверждение ban-сценария. Политика web login FargoVPN сама по себе не объясняет недоступность 3x-ui.

## 8. Сокеты и TCP-состояния

```bash
ss -s
ss -lntp
ss -nt state time-wait | wc -l
ss -nt state syn-sent | wc -l
ss -nt state syn-recv | wc -l
```

Очень большое число `TIME-WAIT`, `SYN-SENT` или `SYN-RECV` относительно обычного состояния требует отдельной проверки; само по себе число без базовой линии не доказывает неисправность.

## 9. Systemd timers и cron

```bash
systemctl list-timers --all --no-pager
systemctl list-unit-files --type=timer --no-pager | grep -E 'fargo|vpn-service|backup|reminder' || true
crontab -l 2>/dev/null || true
grep -RniE 'fargovpn|vpn-service|backup|remote-backup' /etc/cron.d /etc/crontab /var/spool/cron/crontabs 2>/dev/null || true
```

Особенно отметьте, запускался ли `vpn-service-backup.service` прямо перед проблемой.

## 10. Логи FargoVPN

```bash
journalctl -u vpn-service-bot --since '30 min ago' --no-pager
journalctl -u vpn-service-web --since '30 min ago' --no-pager
journalctl -u vpn-service-backup --since '30 min ago' --no-pager
journalctl -u vpn-service-nginx-guard --since '30 min ago' --no-pager
```

Поищите сообщения `performance operation=xui_http`, ошибки socket, 429/502/503/504, traceback и неожиданные restart.

## 11. Что прислать для установления причины

Нужен один набор вывода, захватывающий 5–10 минут до отказа и 5–10 минут после восстановления:

```bash
date -Is
uptime
free -h
swapon --show
df -hT
vmstat 1 10
systemctl --failed --no-pager
systemctl list-timers --all --no-pager
journalctl -u vpn-service-web -u nginx -u x-ui -u xray -u vpn-service-backup -u vpn-service-nginx-guard --since '20 min ago' --no-pager
journalctl -k --since '20 min ago' --no-pager | grep -Ei 'oom|out of memory|killed process|i/o error|hung task|reset' || true
tail -n 500 /var/log/nginx/access.log | grep -E ' (429|499|502|503|504) ' || true
tail -n 200 /var/log/nginx/error.log
ss -s
ls -la /run/vpn-service/
curl --unix-socket /run/vpn-service/fargovpn.sock -fsS http://localhost/healthz
```

Эти данные позволяют различить: ресурсную деградацию, рестарт процесса, socket/upstream проблему, rate-limit/ban или внешний сетевой путь.
