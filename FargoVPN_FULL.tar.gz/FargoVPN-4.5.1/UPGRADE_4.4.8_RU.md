# Обновление FargoVPN до 4.4.8

## Установка из веб-панели

Для существующего FargoVPN 4.4.6/4.4.7 загрузите релиз `VPN_Service_Platform_4.4.8_FULL.tar.gz` во вкладке обновлений и запустите штатное обновление.

При `--update-existing` установщик FargoVPN не должен переустанавливать или обновлять Nginx L4 Stream Router Mask и не должен выполнять сетевые проверки GitHub для Mask.

## Аварийная установка из SSH

Архив предполагается в `/root`.

### 1. Проверить архив

```bash
cd /root
sha256sum VPN_Service_Platform_4.4.8_FULL.tar.gz
``` 

Значение SHA-256 указано в релизе.

### 2. Проверить зависшие update jobs

```bash
systemctl list-units --all 'vpn-service-update*' --no-pager
cat /var/lib/vpn-service/updates/status.json 2>/dev/null || true
```

Не останавливайте сервисы FargoVPN, nginx или x-ui без необходимости. Если действительно осталась зависшая задача обновления, останавливайте только соответствующий update unit по точному имени.

### 3. Распаковать

```bash
cd /root
rm -rf /root/FargoVPN-4.4.8
tar -xzf /root/VPN_Service_Platform_4.4.8_FULL.tar.gz -C /root
```

### 4. Обновить существующий `/root/vpn_bot`

```bash
cd /root/FargoVPN-4.4.8
export VPN_UPDATE_STATUS_FILE=/var/lib/vpn-service/updates/status.json
export VPN_UPDATE_JOB_ID="console-$(date +%s)"
bash ./install.sh --profile full --update-existing /root/vpn_bot
```

### 5. Проверить версию и сервисы

```bash
cat /root/vpn_bot/VERSION
cat /root/vpn_bot/app/VERSION 2>/dev/null || true
systemctl is-active vpn-service-bot.service
systemctl is-active vpn-service-web.service
systemctl is-active vpn-service-web.socket
systemctl is-active vpn-service-backup.timer
systemctl is-active vpn-service-reminders.timer
```

Все активные сервисы должны вернуть `active`, версия — `4.4.8`.

### 6. Проверить health endpoint

```bash
SOCKET=$(/root/vpn_bot/.venv/bin/python -c 'import sys; sys.path.insert(0,"/root/vpn_bot"); import config; print(getattr(config,"WEB_SOCKET_PATH","/run/vpn-service/fargovpn.sock"))')
curl --unix-socket "$SOCKET" -fsS --max-time 5 http://localhost/health
```

### 7. Проверить установщик на лишние зависимости

```bash
grep -n '^apt_install python3 python3-venv' /root/FargoVPN-4.4.8/install.sh
grep -nE '^apt_install .* (age)( |$)|age-keygen -[oy]' /root/FargoVPN-4.4.8/install.sh || true
grep -nE 'rm .*certbot|apt-get .*remove.*certbot|apt .*remove.*certbot' /root/FargoVPN-4.4.8/install.sh || true
```

`age` не должен быть системной зависимостью нового установщика. Команда проверки удаления `certbot` ничего не должна вывести: установленный `certbot` не удаляется и не изменяется.
