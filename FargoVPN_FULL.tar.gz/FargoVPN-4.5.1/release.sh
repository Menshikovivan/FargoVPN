#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
VERSION_FILE="$ROOT/VERSION"
APP_VERSION_FILE="$ROOT/app/VERSION"
INSTALLED_VERSION_FILE="$ROOT/INSTALLED_CHANGELOG_VERSION"

read_version() {
  local value
  value="$(tr -d '[:space:]' < "$VERSION_FILE")"
  [[ "$value" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || {
    echo "Некорректная версия в VERSION: '$value'" >&2
    exit 1
  }
  printf '%s\n' "$value"
}

increment_patch() {
  local current major minor patch
  current="$(read_version)"
  IFS=. read -r major minor patch <<< "$current"
  patch="${patch:-0}"
  printf '%s.%s.%s\n' "$major" "$minor" "$((patch + 1))"
}

increment_minor() {
  local current major minor patch
  current="$(read_version)"
  IFS=. read -r major minor patch <<< "$current"
  printf '%s.%s.0\n' "$major" "$((minor + 1))"
}

sync_project_version() {
  local current="$1" next="$2"
  printf '%s\n' "$next" > "$VERSION_FILE"
  printf '%s\n' "$next" > "$APP_VERSION_FILE"
  printf '%s\n' "$next" > "$INSTALLED_VERSION_FILE"

  python3 - "$ROOT" "$current" "$next" <<'PYUPD'
from pathlib import Path
import re, sys
root=Path(sys.argv[1]); current=sys.argv[2]; next_version=sys.argv[3]
readme=root/"README.md"
text=readme.read_text(encoding="utf-8")
if current not in text:
    raise SystemExit(f"Текущая версия {current} не найдена в README.md")
text=text.replace(current, next_version)
readme.write_text(text, encoding="utf-8")
notes=root/f"RELEASE_NOTES_{next_version}.md"
if not notes.exists():
    notes.write_text(f"# FargoVPN {next_version}\n\n## Изменения\n\n- Заполнить changelog перед публикацией релиза.\n", encoding="utf-8")
PYUPD
}

CURRENT="$(read_version)"
case "${1:-patch}" in
  patch)
    NEXT="$(increment_patch)"
    sync_project_version "$CURRENT" "$NEXT"
    echo "Версия: $CURRENT -> $NEXT"
    ;;
  minor)
    NEXT="$(increment_minor)"
    sync_project_version "$CURRENT" "$NEXT"
    echo "Версия: $CURRENT -> $NEXT"
    ;;
  show)
    echo "$CURRENT"
    ;;
  *)
    echo "Использование: $0 [patch|minor|show]" >&2
    exit 2
    ;;
esac
