from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_backup_contains_required_postgresql_dumps_and_telegram_delivery():
    text = (ROOT / "backup.py").read_text(encoding="utf-8")
    assert 'databases / "fargovpn.sql"' in text
    assert 'databases / "xui.sql"' in text
    assert 'def send_to_telegram_sync' in text
    assert 'def _deliver_archive' in text


def test_removed_remote_backup_runtime_is_absent():
    for relative in ["backup.py", "config.example.py", "webapp.py", "install.sh"]:
        text = (ROOT / relative).read_text(encoding="utf-8")
        assert not any(token.lower() in text.lower() for token in ("yan" + "dex", "yadi" + "sk", "web" + "dav", "dav" + "fs")), relative
    assert not (ROOT / ("yan" + "dex" + "_" + "web" + "dav" + ".py")).exists()


def test_backup_service_runs_daily_check():
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert "ExecStart=$TARGET/.venv/bin/python $TARGET/backup.py --scheduled" in installer
    assert "OnCalendar=*-*-* 03:30:00" in installer
    assert "Persistent=true" in installer
    assert "OnUnitActiveSec=15m" not in installer
    assert "systemctl enable vpn-service-bot.service vpn-service-backup.timer" in installer


def test_manual_backup_is_available_and_detached():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    assert 'callback_data="admin:backup"' in text
    assert 'async def run_admin_backup' in text
    assert 'launch_detached' in text
    assert '[sys.executable, str(APP_DIR / "backup.py"), "--force"]' in text
    assert '@dp.message(Command("backup"))' in text


def test_backup_live_state_contract():
    text = (ROOT / "backup.py").read_text(encoding="utf-8")
    web = (ROOT / "webapp.py").read_text(encoding="utf-8")
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert 'BACKUP_LIVE_STATE_PATH' in text
    assert 'def _live_event' in text
    assert 'def read_live_state' in text
    assert '"phase": "start"' in text
    assert '"telegram"' in text
    assert '@app.get("/api/backup/live"' in web
    assert 'service == "backup-live"' in web
    assert 'value="backup-live"' in web
    assert 'BACKUP_LIVE_STATE_PATH' in installer


def test_users_query_is_postgres_safe():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "COLLATE NOCASE" not in text
    assert "LOWER(COALESCE(username" in text
