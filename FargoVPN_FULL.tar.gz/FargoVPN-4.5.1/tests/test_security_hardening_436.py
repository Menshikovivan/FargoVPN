from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def source(name: str) -> str:
    return (ROOT / name).read_text(encoding="utf-8")


def test_autoapproval_remains_enabled_and_used():
    assert "RECEIPT_AUTO_APPROVE = True" in source("config.example.py")
    assert 'getattr(config, "RECEIPT_AUTO_APPROVE", True)' in source("main.py")


def test_payment_approval_uses_atomic_claim_and_reconciliation_state():
    text = source("services/subscriptions.py")
    assert "WHERE id=? AND status='pending'" in text
    assert "RETURNING *" in text
    assert "status='processing' AND processed_by=?" in text
    assert "def reset_payment_processing_sync" in text


def test_panel_mutations_require_session_csrf_header():
    web = source("webapp.py")
    js = source("static/panel.js")
    assert 'request.headers.get("x-csrf-token")' in web
    assert 'meta name="fargovpn-csrf-token"' in web
    assert "headers.set('X-CSRF-Token', CSRF_TOKEN)" in js


def test_custom_upload_xhrs_forward_session_csrf_header():
    web = source("webapp.py")
    assert web.count("xhr.setRequestHeader('X-CSRF-Token',csrfToken)") == 3
    assert web.count("const csrfMeta=document.querySelector('meta[name=\"fargovpn-csrf-token\"]')") == 2


def test_remote_backups_are_plain_tar_gz_and_live_restore_is_off():
    backup = source("backup.py")
    installer = source("install.sh")
    web = source("webapp.py")
    assert "encrypted_delivery_copy" not in backup
    assert "age-keygen -o" not in installer
    assert '["age-keygen", "-y"' not in installer
    assert "BACKUP_AGE_RECIPIENT" not in backup
    assert "age-keygen -y" not in installer
    assert 'BACKUP_ALLOW_INPLACE_RESTORE", False' in web
    assert (ROOT / "restore_staged.py").is_file()


def test_cabinet_links_are_one_time_hashes():
    text = source("cabinet_service.py")
    assert "secrets.token_urlsafe(32)" in text
    assert "hashlib.sha256(token.encode()).hexdigest()" in text
    assert "consumed_at IS NULL" in text
    assert 'CABINET_ALLOW_LEGACY_TOKENS", False' in text


def test_new_clients_use_managed_inbound_allowlist():
    text = source("services/xui_api.py")
    assert 'getattr(config, "XUI_MANAGED_INBOUND_IDS", [])' in text
    assert 'def ensure_client_inbounds_sync(' in text
    assert "Нет активных inbound 3x-ui для выдачи клиентов" in text


def test_user_actions_have_database_rate_limits():
    main = source("main.py")
    schema = source("init_db.py")
    assert '"receipt"' in main and '"support"' in main
    assert "CREATE TABLE IF NOT EXISTS action_rate_limits" in schema
    assert (ROOT / "rate_limit.py").is_file()


def test_existing_update_never_touches_external_mask():
    installer = source("install.sh")
    start = installer.index("choose_mask() {")
    end = installer.index("install_mask_router() {", start)
    block = installer[start:end]
    assert "if [[ -n $UPDATE_PATH ]]; then" in block
    assert "MASK_MODE=no" in block
    assert "MASK_ACTION=skip" in block
    update_branch = block[block.index("if [[ -n $UPDATE_PATH ]]; then"):]
    assert update_branch.index("return 0") < update_branch.index("refresh_mask_metadata")


def test_installer_does_not_install_obsolete_age_or_certbot():
    installer = source("install.sh")
    package_line = next(line for line in installer.splitlines() if line.startswith("apt_install python3 python3-venv"))
    assert " age" not in package_line
    assert " certbot" not in package_line
    assert "age-keygen -o" not in installer
    assert "age-keygen -y" not in installer
