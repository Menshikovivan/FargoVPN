import sqlite3


def test_inbound_ids_include_all_enabled_inbounds_by_default(monkeypatch):
    from services import xui_api

    monkeypatch.setattr(xui_api, "request_json_sync", lambda *a, **k: {
        "success": True,
        "obj": [
            {"id": 5, "enable": True, "protocol": "vless"},
            {"id": 9, "enable": True, "protocol": "hysteria"},
            {"id": 12, "enable": False, "protocol": "vless"},
        ],
    })
    monkeypatch.setattr(xui_api.config, "XUI_MANAGED_INBOUND_IDS", [], raising=False)
    assert xui_api.inbound_ids_sync() == [5, 9]


def test_inbound_id_allowlist_remains_explicit(monkeypatch):
    from services import xui_api

    monkeypatch.setattr(xui_api, "request_json_sync", lambda *a, **k: {
        "success": True,
        "obj": [
            {"id": 5, "enable": True, "protocol": "vless"},
            {"id": 9, "enable": True, "protocol": "hysteria"},
        ],
    })
    monkeypatch.setattr(xui_api.config, "XUI_MANAGED_INBOUND_IDS", [9], raising=False)
    assert xui_api.inbound_ids_sync() == [9]


def test_add_client_verifies_and_repairs_missing_inbounds(monkeypatch):
    from services import xui_api

    calls = []
    state = {"ids": [5]}

    def fake_request(method, path, payload=None, **kwargs):
        calls.append((method, path, payload))
        if path == "panel/api/clients/add":
            return {"success": True, "obj": {}}
        if path.endswith("/attach"):
            state["ids"] = [5, 9]
            return {"success": True, "obj": {}}
        raise AssertionError(path)

    monkeypatch.setattr(xui_api, "request_json_sync", fake_request)
    monkeypatch.setattr(xui_api, "invalidate_snapshot_cache", lambda: None)
    monkeypatch.setattr(
        xui_api,
        "get_client_record_sync",
        lambda email: {
            "client": {"email": email, "comment": "Иван"},
            "inbound_ids": list(state["ids"]),
            "normalized": {"uuid": "u"},
            "editable_client": {"email": email, "uuid": "u"},
            "raw": {},
        },
    )

    xui_api.add_client_sync({"email": "ivan", "uuid": "u", "id": "u"}, [5, 9])
    assert any(
        path.endswith("/attach") and payload == {"inboundIds": [9]}
        for _, path, payload in calls
    )


def test_sync_snapshot_imports_3xui_comment_into_local_notes(tmp_path):
    from services import xui_api

    db = tmp_path / "users.db"
    with sqlite3.connect(db) as conn:
        conn.execute(
            "CREATE TABLE users (tg_id INTEGER PRIMARY KEY, username TEXT, uuid TEXT, email TEXT, "
            "expiry_time INTEGER, enable INTEGER, up INTEGER, down INTEGER, total INTEGER, sub_id TEXT, "
            "last_online TEXT, last_online_ts INTEGER, last_sync_at TEXT, last_reminder_days INTEGER, "
            "identity_source TEXT, identity_updated_at TEXT, notes TEXT)"
        )
        conn.execute(
            "INSERT INTO users(tg_id,username,uuid,email,expiry_time,enable,up,down,total,sub_id,last_reminder_days,notes) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (123, "tgname", "u", "u@example", 0, 1, 0, 0, 0, "s", -1, "старое"),
        )
        conn.commit()

    snapshot = {"clients": [{
        "email": "u@example", "uuid": "u", "tg_id": 123, "expiry_time": 0,
        "enable": True, "up": 0, "down": 0, "total": 0, "sub_id": "s",
        "comment": "Иван Петров", "last_online_ts": 0,
    }]}
    import sqlite3 as sqlite_module
    original_connect = xui_api.database_adapter.connect
    try:
        def connect(path, timeout=20):
            connection = sqlite_module.connect(path, timeout=timeout)
            connection.create_function("GREATEST", 2, max)
            return connection

        xui_api.database_adapter.connect = connect
        xui_api.sync_snapshot_to_db(snapshot, db)
    finally:
        xui_api.database_adapter.connect = original_connect
    with sqlite3.connect(db) as conn:
        assert conn.execute("SELECT notes FROM users WHERE tg_id=123").fetchone()[0] == "Иван Петров"


def test_web_user_detail_has_comment_form_and_sync_route():
    from pathlib import Path

    text = Path("webapp.py").read_text(encoding="utf-8")
    assert '@app.post("/users/id/{tg_id}/comment")' in text
    assert 'name="comment"' in text
    assert 'update_client_sync(email, {"comment": clean_comment}' in text
    assert 'UPDATE users SET notes=? WHERE tg_id=?' in text
    assert 'str(item.get("comment") or item.get("username")' in text
