from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_success_response_precedes_optional_referral_bookkeeping():
    source = (ROOT / "main.py").read_text(encoding="utf-8")
    start = source.index("async def process_referral_code")
    end = source.index("@dp.callback_query", start)
    block = source[start:end]

    answer = block.index("Авторизация подтверждена! Добро пожаловать в FargoVPN.")
    reward = block.index("referral_rewards.register_referral_if_needed")
    journal = block.index("user_events.safe_record_event")

    assert answer < reward
    assert answer < journal
    assert "_schedule_event_record(" in block


def test_registration_commit_does_not_run_optional_reward_ledger():
    source = (ROOT / "main.py").read_text(encoding="utf-8")
    start = source.index("def register_referral_user")
    end = source.index("def invitation_text", start)
    block = source[start:end]

    assert "connection.commit()" in block
    assert "referral_rewards.register_referral_if_needed" not in block


def test_registration_database_error_is_reported_to_user():
    source = (ROOT / "main.py").read_text(encoding="utf-8")
    start = source.index("async def process_referral_code")
    end = source.index("@dp.callback_query", start)
    block = source[start:end]

    assert "Временная ошибка регистрации" in block
    assert "logger.exception(" in block
