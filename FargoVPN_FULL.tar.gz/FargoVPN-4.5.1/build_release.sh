#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
VERSION_FILE="$ROOT/VERSION"
version="$(tr -d '[:space:]' < "$VERSION_FILE")"
[[ "$version" =~ ^[0-9]+\.[0-9]+(\.[0-9]+)?$ ]] || { echo "Некорректная VERSION: $version" >&2; exit 1; }

for marker in "$ROOT/app/VERSION" "$ROOT/INSTALLED_CHANGELOG_VERSION"; do
  [[ -f "$marker" ]] || { echo "Не найден version marker: $marker" >&2; exit 1; }
  [[ "$(tr -d '[:space:]' < "$marker")" == "$version" ]] || {
    echo "Расхождение version markers: $marker" >&2
    exit 1
  }
done

ARCHIVE="$ROOT/../VPN_Service_Platform_${version}_FULL.tar.gz"
PACKAGE_NAME="$(basename "$ROOT")"
[[ "$PACKAGE_NAME" != "." && "$PACKAGE_NAME" != ".." ]] || { echo "Некорректное имя каталога проекта" >&2; exit 1; }
if find "$ROOT" -type l -print -quit | grep -q .; then
  echo "В дереве релиза найдена символическая ссылка; сборка остановлена." >&2
  find "$ROOT" -type l -print >&2
  exit 1
fi
rm -f "$ARCHIVE"
tar -czf "$ARCHIVE" \
  --exclude="$PACKAGE_NAME/config.py" \
  --exclude="$PACKAGE_NAME/config.py.before_*" \
  --exclude="$PACKAGE_NAME/config.py.corrupt.*" \
  --exclude="$PACKAGE_NAME/data" \
  --exclude="$PACKAGE_NAME/.venv" \
  --exclude="$PACKAGE_NAME/__pycache__" \
  --exclude="$PACKAGE_NAME/.pytest_cache" \
  --exclude="$PACKAGE_NAME/pytest-of-root" \
  --exclude="$PACKAGE_NAME/*/.pytest_cache" \
  --exclude="$PACKAGE_NAME/*/__pycache__" \
  --exclude="$PACKAGE_NAME/*.pyc" \
  --exclude="$PACKAGE_NAME/*/*.pyc" \
  --exclude="$PACKAGE_NAME/tests/_temp_*" \
  --exclude="$PACKAGE_NAME/tmp*" \
  --exclude="$PACKAGE_NAME/*.tar" \
  --exclude="$PACKAGE_NAME/*.tar.gz" \
  --exclude="$PACKAGE_NAME/*.zip" \
  --exclude="$PACKAGE_NAME/*.bak" \
  --exclude="$PACKAGE_NAME/*.orig" \
  --exclude="$PACKAGE_NAME/*~" \
  -C "$ROOT/.." "$PACKAGE_NAME"
printf 'Собран FargoVPN %s\n' "$version"
printf 'Архив: %s\n' "$ARCHIVE"
printf 'SHA-256: %s\n' "$(sha256sum "$ARCHIVE" | awk '{print $1}')"
