# Обновление FargoVPN 4.4.10 → 4.5

## 1. Перед обновлением

Не выполняйте обновление во время обслуживания клиентов. Сначала сохраните конфигурацию FargoVPN, PostgreSQL и systemd-единицы.

```bash
sudo mkdir -p /var/backups/fargovpn-upgrade-$(date +%Y%m%d-%H%M%S)
B=/var/backups/fargovpn-upgrade-$(date +%Y%m%d-%H%M%S)
sudo mkdir -p "$B"
sudo cp -a /root/vpn_bot/config.py "$B/" 2>/dev/null || true
sudo cp -a /etc/systemd/system/vpn-service-*.service /etc/systemd/system/vpn-service-*.socket "$B/" 2>/dev/null || true
sudo -u postgres pg_dump --format=custom --file="$B/fargovpn.dump" fargovpn 2>/dev/null || true
sudo sha256sum /root/VPN_Service_Platform_4.5_FULL.tar.gz
```

Если база или каталог приложения у вас расположены иначе, подставьте фактические пути.

## 2. Проверить архив

```bash
cd /root
tar -tzf VPN_Service_Platform_4.5_FULL.tar.gz | head -40
```

Внутри должен быть каталог `FargoVPN-4.5/`.

## 3. Распаковать и обновить существующую установку

```bash
cd /root
rm -rf /root/FargoVPN-4.5
tar -xzf /root/VPN_Service_Platform_4.5_FULL.tar.gz
cd /root/FargoVPN-4.5
bash ./install.sh --profile full --update-existing /root/vpn_bot
```

Передавать токен Telegram, пароль PostgreSQL или API-токен 3x-ui в командной строке не требуется.

## 4. Проверить после обновления

```bash
sudo systemctl daemon-reload
sudo systemctl status vpn-service-bot vpn-service-web vpn-service-web.socket vpn-service-backup.timer vpn-service-reminders.timer --no-pager
sudo systemctl list-timers --all | grep -E 'vpn-service-(backup|reminders)'
curl --unix-socket /run/vpn-service/fargovpn.sock -fsS http://localhost/healthz
sudo grep -RniE 'legacy|remote-backup' /root/vpn_bot --exclude='cleanup_legacy_remote_backup.sh' || true
```

Также откройте «Настройки → 3x-ui» и проверьте список inbound. Для нового тестового клиента выберите один inbound и убедитесь, что клиент создан только в нём.

## 5. Откат

Сначала остановите только FargoVPN-службы:

```bash
sudo systemctl stop vpn-service-bot vpn-service-web vpn-service-web.socket vpn-service-backup.timer vpn-service-reminders.timer || true
```

Верните исходный каталог из заранее сохранённой копии/архива 4.4.10. После возврата:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now vpn-service-web.socket vpn-service-bot vpn-service-backup.timer vpn-service-reminders.timer
sudo systemctl restart vpn-service-web
```

Для возврата базы PostgreSQL используйте `pg_restore` только из проверенного дампа и только после отдельной проверки целевой базы.

## Важно о старом внешнем backup

При обновлении 4.5 установщик запускает `scripts/cleanup_legacy_remote_backup.sh`. Скрипт сначала сохраняет затрагиваемые системные файлы и затем отключает legacy-автозапуск внешней доставки. Telegram-backup не удаляется.
