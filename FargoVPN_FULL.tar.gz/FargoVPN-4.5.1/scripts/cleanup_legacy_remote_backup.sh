#!/usr/bin/env bash
set -euo pipefail

# One-time cleanup for FargoVPN installations that previously used Yandex WebDAV.
# The script does not touch the current Telegram backup service/timer.

TS=$(date -u +%Y%m%d_%H%M%S)

backup_file() {
  local path="$1"
  [[ -f "$path" ]] || return 0
  cp -a -- "$path" "${path}.fargovpn-cleanup.${TS}"
}

TARGET=${1:-/root/vpn_bot}
for file in "$TARGET/config.py" "$TARGET/.env" /etc/default/vpn-service /etc/default/fargovpn; do
  [[ -f "$file" ]] || continue
  if grep -Eq '^\s*(YANDEX_|RCLONE_|DAVFS_)' "$file"; then
    backup_file "$file"
    sed -Ei '/^\s*(YANDEX_|RCLONE_|DAVFS_)/d' "$file"
  fi
done

# Disable the historical generic FargoVPN backup alias too. The 4.5 installer
# creates and manages only vpn-service-backup.service/timer, preventing duplicate workers.
for unit in fargovpn-backup.service fargovpn-backup.timer; do
  systemctl disable --now "$unit" >/dev/null 2>&1 || true
done

# Stop only legacy remote-backup/mount units; never stop vpn-service-backup.service itself.
mapfile -t UNITS < <(
  systemctl list-unit-files --no-legend 2>/dev/null |
    awk '{print $1}' |
    grep -Ei 'yandex|YandexDisk|vpn-service.*remote-backup|fargovpn.*remote-backup' || true
)
for unit in "${UNITS[@]}"; do
  systemctl disable --now "$unit" >/dev/null 2>&1 || true
done

# Remove exact Yandex davfs mount if still active.
if findmnt -rn -S 'https://webdav.yandex.ru*' >/dev/null 2>&1; then
  while read -r target; do
    [[ -n "$target" ]] && umount -l -- "$target" >/dev/null 2>&1 || true
  done < <(findmnt -rn -S 'https://webdav.yandex.ru*' -o TARGET 2>/dev/null || true)
fi
if mountpoint -q /media/YandexDisk 2>/dev/null; then
  umount -l /media/YandexDisk >/dev/null 2>&1 || true
fi

# Comment only exact legacy Yandex/davfs fstab rows; unrelated mounts remain untouched.
if [[ -f /etc/fstab ]]; then
  if grep -Eiq 'webdav\.yandex\.ru|/media/YandexDisk' /etc/fstab; then
    backup_file /etc/fstab
    python3 - <<'PY'
from pathlib import Path
import re
p=Path('/etc/fstab')
out=[]
for line in p.read_text(encoding='utf-8', errors='ignore').splitlines(True):
    stripped=line.strip()
    fields=stripped.split()
    legacy=(not stripped.startswith('#') and len(fields)>=3 and
            ('webdav.yandex.ru' in fields[0] or fields[1] == '/media/YandexDisk'))
    if legacy:
        end='\n' if line.endswith('\n') else ''
        out.append('# FARGOVPN legacy remote-backup disabled: '+line.rstrip('\n')+end)
    else:
        out.append(line)
p.write_text(''.join(out), encoding='utf-8')
PY
  fi
fi

# Remove legacy credentials without touching unrelated davfs entries.
if [[ -f /etc/davfs2/secrets ]]; then
  if grep -Eiq 'webdav\.yandex\.ru|YandexDisk' /etc/davfs2/secrets; then
    backup_file /etc/davfs2/secrets
    python3 - <<'PY'
from pathlib import Path
p=Path('/etc/davfs2/secrets')
lines=p.read_text(encoding='utf-8', errors='ignore').splitlines(True)
kept=[line for line in lines if not any(x.lower() in line.lower() for x in ('webdav.yandex.ru','yandexdisk'))]
p.write_text(''.join(kept), encoding='utf-8')
PY
  fi
fi

# Remove old scheduled commands that explicitly reference Yandex/davfs/WebDAV.
if command -v crontab >/dev/null 2>&1; then
  if crontab -l -u root 2>/dev/null | grep -Eiq 'yandex|yadisk|webdav'; then
    crontab -l -u root 2>/dev/null | grep -Eiv 'yandex|yadisk|webdav' | crontab -u root -
  fi
fi
for file in /etc/cron.d/* /etc/crontab; do
  [[ -f "$file" ]] || continue
  if grep -Eiq 'yandex|yadisk|webdav' "$file"; then
    backup_file "$file"
    sed -Ei '/yandex|yadisk|webdav/ s/^/# FARGOVPN legacy remote-backup disabled: /I' "$file"
  fi
done

# Remove legacy unit files after they are stopped/disabled.
for pattern in /etc/systemd/system/*yandex* /etc/systemd/system/*Yandex* /etc/systemd/system/media-YandexDisk.* /etc/systemd/system/*remote-backup* /etc/systemd/system/fargovpn-backup.service /etc/systemd/system/fargovpn-backup.timer; do
  [[ -e "$pattern" ]] || continue
  rm -f -- "$pattern"
done
systemctl daemon-reload

# Purge davfs2 only when no active davfs mount or remaining davfs config exists.
if ! findmnt -rn -t davfs >/dev/null 2>&1; then
  shopt -s nullglob
  remaining=()
  [[ ! -d /etc/davfs2 ]] || remaining=(/etc/davfs2/*)
  if (( ${#remaining[@]} == 0 )); then
    apt-get purge -y davfs2 >/dev/null 2>&1 || true
    apt-get autoremove -y >/dev/null 2>&1 || true
    rmdir /etc/davfs2 /media/YandexDisk 2>/dev/null || true
  fi
fi

# Remove legacy Yandex destination entries from the backup queue while keeping current Telegram queue items.
STATE=/var/lib/vpn-service/backup-state.json
if [[ -f "$STATE" ]]; then
  backup_file "$STATE"
  python3 - "$STATE" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1])
try: data=json.loads(p.read_text(encoding='utf-8'))
except Exception: raise SystemExit(0)
if isinstance(data,dict) and isinstance(data.get('pending_deliveries'),list):
    for item in data['pending_deliveries']:
        if isinstance(item,dict) and isinstance(item.get('remaining'),list):
            item['remaining']=[x for x in item['remaining'] if str(x).lower() not in {'yandex','yadisk','webdav'}]
            if not item['remaining']:
                item['_drop']=True
    data['pending_deliveries']=[x for x in data['pending_deliveries'] if isinstance(x,dict) and not x.get('_drop')]
p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
PY
fi

echo "Legacy remote-backup cleanup completed at $TS UTC."
