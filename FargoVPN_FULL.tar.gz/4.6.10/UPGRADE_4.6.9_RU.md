# FargoVPN 4.6.9 — инструкция обновления

## 1. Резервная копия

Перед обновлением сохраните текущую конфигурацию и VAPID private key. Для VAPID важно сохранить именно файл:

`/var/lib/vpn-service/vapid_private.pem`

Не генерируйте новый VAPID key без необходимости: существующие browser subscriptions привязаны к public key.

## 2. Обновление исходников

Распакуйте `VPN_Service_Platform_4.6.9_FULL.tar.gz` рядом с текущей установкой и выполните штатный updater:

```bash
sudo ./install.sh --update-existing /opt/vpn-service
```

Подставьте фактический путь вашей установки вместо `/opt/vpn-service`.

Установщик обновляет PostgreSQL schema и version markers. Новая колонка `panel_push_subscriptions.vapid_public_key` добавляется автоматически.

## 3. Проверка VAPID

В `/settings` → Push выполните «Проверить».

Особенно важно, чтобы `Subject` был реальным URL/`mailto:` и не содержал `localhost`, `.local` или `.invalid`.

Для текущего домена панели корректный вариант выглядит как:

`https://menshikovivan.site`

Private VAPID key должен оставаться на том же сервере. 4.6.9 синхронизирует public key из private key при восстановленном/устаревшем `config.py`.

## 4. iPhone / Safari

Откройте панель в Safari, добавьте её на экран «Домой», запустите через иконку PWA и после этого включите Push.

Если ранее у этого PWA была старая PushSubscription, повторное нажатие «Включить Push» в 4.6.9 обнаружит другой `applicationServerKey`, удалит старую подписку и создаст новую.

## 5. Desktop browser

При `AbortError: Error retrieving push subscription` 4.6.9 автоматически делает один reset регистрации Service Worker/cache и повторяет подписку.

Если браузер снова возвращает тот же `AbortError`, проблема уже находится в его push transport/profile (например, блокировщик, VPN/proxy или недоступный browser push service), а не в HTTP route FargoVPN. В таком случае откройте журнал Push: там будет видно, был ли выполнен reset и обе попытки subscribe.

## 6. Nginx L4 / 3x-ui

Обновление FargoVPN не требует менять существующую схему Itman75 Nginx-L4-Stream-Router-Mask-for-3x-ui.

Не добавляйте второй L4/L7 proxy поверх действующего маршрутизатора только ради Push. Push использует HTTPS panel origin (`https://menshikovivan.site`), а VAPID audience берётся из origin push endpoint (`https://web.push.apple.com`, FCM/другой push provider и т. п.).

Для 3x-ui оставьте текущую L4/XHTTP цепочку и не меняйте `acceptProxyProtocol` без проверки, где именно в цепочке реально приходит PROXY protocol.

## 7. Контроль после обновления

```bash
systemctl is-active vpn-service-bot.service
systemctl is-active vpn-service-web.service
curl -sS -I https://menshikovivan.site/fargovpn-admin-4etluxi6ghlicd9b/service-worker.js
```

Затем в панели:

1. Проверить Push.
2. Включить Push.
3. Отправить тест.
4. Убедиться в журнале, что доставка завершилась `HTTP 201/202` без `BadJwtToken`.
