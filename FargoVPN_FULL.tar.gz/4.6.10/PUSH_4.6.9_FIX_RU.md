# Push/Web Push: исправления 4.6.9

## Диагноз по предоставленному логу

1. Service Worker регистрируется корректно: HTTP 200, `application/javascript`, `Service-Worker-Allowed` покрывает нужный scope, браузер выбирает ожидаемый scope.
2. Ошибка `AbortError: Error retrieving push subscription` возникает внутри `PushManager` после готового Service Worker и до отправки `POST /api/panel/push/subscribe`. Это отдельный browser-side контур и не является ошибкой маршрутизации Nginx L4.
3. На iPhone результат `reason=BadJwtToken` приходит уже от Push provider. Для Apple это означает проблему VAPID JWT: подпись/ключ, `sub`, `aud` или срок `exp`.

## Что изменено

- Private VAPID key является источником истины: `PUSH_VAPID_PUBLIC_KEY` автоматически синхронизируется с ним при восстановлении/старом `config.py`.
- `PUSH_VAPID_SUBJECT` валидируется как URL или `mailto:`. Localhost/local/invalid subject не принимаются.
- В диагностике показывается эффективный VAPID subject, но private key никогда не выводится.
- Для каждой новой browser PushSubscription в БД сохраняется VAPID public key, который использовался при её регистрации.
- При смене VAPID key старая подписка определяется и удаляется с требованием повторной регистрации.
- Ответы push provider с JSON `reason` сохраняются как `reason=...`.
- `VapidPkHashMismatch`, HTTP 404 и HTTP 410 удаляют мёртвую/несовместимую подписку.
- `BadJwtToken` не удаляет endpoint автоматически: это может быть ошибка server-side VAPID configuration, а не мёртвый endpoint.
- При browser `AbortError`/`Error retrieving push subscription` один раз выполняется контролируемый reset регистрации Service Worker и cache, затем делается повторная подписка.
- При наличии существующей подписки проверяется `applicationServerKey`; stale subscription на старом VAPID key удаляется перед новой подпиской.
- `applicationServerKey` передаётся как точный 65-byte uncompressed P-256 `ArrayBuffer`.

## После установки

Открыть настройки панели → Push и сначала нажать «Проверить». Ожидаемое состояние:

- `VAPID: готов`;
- `Subject: https://<ваш-домен>` либо корректный `mailto:`;
- private/public pair синхронизирован;
- после «Включить Push» число подписок становится `1`.

Для Safari/iPhone панель должна быть добавлена на экран «Домой» и запущена как PWA.

При `BadJwtToken` журнал теперь должен показать как минимум `reason=BadJwtToken`; рядом сохраняется диагностическая подсказка проверить `PUSH_VAPID_SUBJECT`, audience push-service и private/public VAPID key.
