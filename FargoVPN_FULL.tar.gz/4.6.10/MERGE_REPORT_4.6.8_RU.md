# Отчёт о слиянии и полном аудите FargoVPN 4.6.8

## 1. Исходные данные и методика

Проверены два загруженных source-архива:

- `VPN_Service_Platform_4.5.5_FULL.tar.gz` — стабильная production-база.
- `VPN_Service_Platform_4.6.7_FULL.tar.gz` — кумулятивная ветка с изменениями 4.5.6–4.6.7.

Нормализованный diff показал: 113 файлов в 4.5.5, 124 файла в 4.6.7; все 113 файлов 4.5.5 присутствуют в 4.6.7. Из них 16 общих файлов изменены, 11 добавлены только в 4.6.7, old-only файлов нет.

Полный построчный diff 4.5.5 → 4.6.7 сохранён отдельно как `AUDIT_DIFF_4.5.5_TO_4.6.7.patch`.

## 2. Решения merge

| Область | Решение | Почему |
|---|---|---|
| `install.sh` | Сохранены накопленные изменения 4.6.x поверх 4.5.5 | Они добавляют безопасное восстановление, внешнее Nginx/L4-подключение, rollback/health-check и корректное systemd-поведение. |
| `nginx_panel_guard.py` | Взята защищённая реализация 4.6.x | Она работает с уже установленным внешним Nginx, проверяет реально загруженный `nginx -T`, поддерживает Unix HTTPS socket/9443 и не требует внутреннего Nginx от FargoVPN. |
| `restore_manager.py` | Взята hardened-логика 4.6.x + дополнительные identity fixes 4.6.8 | Восстановление из legacy SQLite/PG должно сохранять `DATABASE_URL`, VAPID private key и сетевую конфигурацию; extraction и checksum-path traversal усилены. |
| `services/xui_api.py` | Сохранены identity sync, retry и absolute-expiry verification 4.6.x; расширен re-key в 4.6.8 | Положительный Telegram ID остаётся авторитетным; изменения 3x-ui не должны превращаться в дублирование клиента. Дополнительно перенесены referral/push/access/link rows. |
| `webapp.py` | Сохранены GitHub Releases, CSRF, push diagnostics, settings tabs и внешнее reverse-proxy поведение; в 4.6.8 добавлен полный publisher guard | Это функциональные изменения 4.6.x; проблема была не в самой модели обновлений, а в неполном разграничении доступа. |
| `user_events.py` | Сохранён PostgreSQL interval fix 4.6.7 | Предыдущая форма SQL приводила к ошибке обслуживания истории и могла вызывать циклические рестарты/нагрузку. |
| `static/panel.js` | Сохранён накопленный фикс 4.6.x | Нужен для корректного polling/unread и UX панели. |
| `CHANGELOG*`, `README.md`, version markers | Обновлены на 4.6.8 | Версия и documentation должны быть согласованы с фактическим релизом. |
| 11 файлов, добавленных 4.6.7 | Сохранены | Это release notes и тесты, которые не заменяют runtime-код 4.5.5, а документируют cumulative changes. |

## 3. Результат merge по ключевым системам

### Telegram/FSM/callbacks

Текущие producer-prefixes: `menu:`, `faq:`, `admin:`, `approve_`, `decline_`, `crmv_`, `crmmod_`, `crmdel_`. Найден handler для legacy callback `show_instruction`, который сейчас не создаётся новыми клавиатурами; он оставлен как backward-compatibility handler для старых сообщений.

Роутинг callback-хендлеров не имеет дублирующихся FastAPI routes; статический анализ веб-панели выявил 100 уникальных route paths и 0 дублей. Динамические ссылки вида `/users/id/{selected}`, `/messages?tg_id=...`, `/backups/...` соответствуют параметризованным обработчикам.

### Restore и Telegram identity

Авторитетным ключом остаётся положительный Telegram ID. Синхронизация 3x-ui не использует username как identity и не продвигает числовой email suffix сам по себе. При re-key placeholder ID теперь переносятся также referral ledger, Push subscriptions, pending registration, access/cabinet records и link requests.

**Фактическое количество затронутых пользователей из предоставленных архивов определить нельзя:** production PostgreSQL dump/SQLite DB в обоих архивах отсутствует. Для серверной диагностики добавлен `tools/diagnose_restore_identity.py`, который даёт число terminal Telegram failures, несовпадений `telegram_chat_id != tg_id`, потерянных ссылок и (опционально) конфликтов с live 3x-ui.

### Telegram API error isolation

`JournalBot` оборачивает отправку message/photo/document/video. Terminal ошибки `TelegramForbiddenError` и целевые `TelegramBadRequest` (`chat not found`, blocked, deactivated, no access и т.п.) записываются в `user_events` и не пробрасываются дальше. Остальные ошибки по-прежнему пробрасываются, чтобы не скрывать реальные сетевые/API-проблемы.

### Billing/payments

Одно начисление защищено compare-and-set claim: `pending -> processing -> approved`; повторное подтверждение уже approved платежа не выполняет второе продление. Неоднозначная ошибка 3x-ui оставляет платёж в `processing` для ручной сверки.

Дополнительная гонка между **разными** платежами одного клиента устранена сериализацией полного `ensure_subscription_sync()` через PostgreSQL advisory lock по Telegram ID. Это важно, поскольку 3x-ui renewal использует абсолютный `expiryTime`, вычисляемый из текущего срока.

Webhook внешней платёжной системы в source-коде не обнаружен: текущая модель оплаты основана на заявке/чеке и backend подтверждении. Поэтому webhook-idempotency конкретного внешнего провайдера нельзя утверждать как существующую функцию без отдельного provider adapter.

### Push

Причина сообщения `Не удалось включить Push: Error retrieving push subscription` может быть browser-side: предыдущий код трактовал любой exception от `pushManager.getSubscription()` как фатальный. В 4.6.8 `AbortError`/сообщение `retrieving push subscription` отдельно диагностируются и приводят к попытке новой `subscribe()`.

На сервере добавлена проверка VAPID private key, P-256 curve, public key и их соответствия. Подписка в БД хранится по endpoint, а frontend проверяет наличие `endpoint`, `keys.p256dh` и `keys.auth` перед POST.

Service Worker отдаётся с `Service-Worker-Allowed`, `Cache-Control: no-store` и тем же origin/prefix. Push traffic к provider endpoint браузер устанавливает напрямую; внешний Nginx L4/L7 routing панели не является прокси-контуром для push provider.

### Update access

Publisher теперь жёстко определяется как `menshikovivan` в runtime-коде. Значение `UPDATE_PUBLISHER_USERNAME` из config не используется как security boundary.

Для обычного аккаунта доступны check/install endpoints. Backend guard установлен также на GitHub test/config, publish, manual upload, force-version, rollback, update log, release list и legacy update config/token routes. Скрытие HTML элементов не является единственным механизмом защиты.

## 4. Найденные ошибки и статус

| Приоритет | Ошибка | Модуль | Статус |
|---|---|---|---|
| Критичный | Terminal Telegram chat errors могли прервать workflow отправки | `main.py` | **Исправлено** |
| Критичный | Неполный re-key после restore мог оставить платежи/историю/рефералы/Push под старым ID | `services/xui_api.py` | **Исправлено** |
| Критичный | Два разных платежа одного клиента могли конкурентно записать срок 3x-ui | `services/subscriptions.py` | **Исправлено** |
| Критичный | Некоторые update mutation endpoints были auth-only и не соответствовали требованию publisher-only | `webapp.py` | **Исправлено** |
| Высокий | Push status не проверял private/public VAPID pair на соответствие | `push_service.py` | **Исправлено** |
| Высокий | Browser `getSubscription()` exception отображалась как общий fatal Push error | `webapp.py` JS | **Исправлено** |
| Средний | В archive отсутствует production DB, поэтому runtime affected-user count нельзя вычислить офлайн | deployment artifact | **Требует данных целевого сервера** |
| Средний | Полный integration/stress run невозможен в clean source container без generated `config.py` и установленного `psycopg` | test environment | **Требует runtime окружения** |
| Низкий | Legacy callback `show_instruction` не производится текущими клавиатурами | `main.py` | **Оставлен намеренно для backward compatibility** |

## 5. Тестирование

Пройдено:

- `python -m compileall -q .` — PASS.
- 69 релизных/Nginx/restore/security/backup/migration contract tests — PASS.
- 10 новых 4.6.8 contract tests — PASS.
- Static route audit: 100 уникальных FastAPI routes, 0 duplicate route definitions.
- Archive security scan: в обоих исходных tar.gz нет абсолютных paths, `..`, symlinks/devices.
- Secret scan 4.6.8 tree: не обнаружены Telegram bot token, GitHub PAT, VAPID private key или PEM private key в source tree.

Полный `pytest` в clean source tree остановился на collection из-за отсутствующего generated `config.py` и отсутствующего `psycopg` в данном контейнере. Это ограничение окружения: install.sh намеренно генерирует `config.py`, а PostgreSQL runtime dependency указана в `requirements.txt`. Дополнительно для масштабирования добавлен составной индекс `payments(tg_id,status,id DESC)`, чтобы частые проверки оплаты по пользователю не превращались в полный scan.

Для live нагрузки добавлен `tools/stress_test_panel.py`; он не запускался против production, поскольку в текущем окружении нет адреса/сессии целевой панели. Скрипт рассчитан на `/health` и возвращает RPS, p50/p95/p99, error count.

## 6. Установка/обновление на сервере с Itman75/Nginx-L4

1. Убедиться, что внешний Nginx/L4 Router/Mask уже установлен и активен. FargoVPN **не должен** пытаться установить второй Nginx поверх него.
2. Перед обновлением сделать полный application/DB backup стандартным механизмом FargoVPN.
3. Запустить `install.sh` в режиме обновления существующей установки либо использовать текущий update worker, если сервер уже на 4.6.x.
4. Для полного профиля установщик проверяет `/etc/nginx/nginx.conf`, `stream.d/00-stream.conf`, затем через `nginx_panel_guard.py` находит реально загруженный HTTPS server, добавляет отдельный секретный URI к Unix socket `/run/vpn-service/fargovpn.sock`, делает `nginx -t`, reload и повторную проверку через `nginx -T`.
5. Не менять SNI/stream routing портов 3x-ui вручную из-за обновления FargoVPN. L4/router остаётся внешним слоем; FargoVPN подключается как отдельный web route. Для xHTTP/REALITY backend нельзя добавлять несовместимый второй Proxy Protocol слой — настройки `acceptProxyProtocol` должны соответствовать фактическому upstream chain.
6. После установки проверить: `systemctl status vpn-service-bot.service vpn-service-web.service nginx`, `curl -fsS https://<domain><prefix>/healthz`, затем открыть `/updates`.
7. Если Push используется, открывать панель по HTTPS на том же origin, зарегистрировать Service Worker и проверить `/settings` → Push diagnostics; private/public VAPID key должны быть согласованы.
8. Для restore identity после миграции сначала запускать `python tools/diagnose_restore_identity.py --xui --json` и только после анализа применять identity migration/rebind. Не менять Telegram ID массово по одному username.

## 7. Что осталось для production sign-off

Нужны именно серверные проверки, которых нет в source archives: реальный row count affected users, live Telegram `getChat`, live 3x-ui identity comparison, реальная Push subscription в браузере и конкурентная нагрузка на PostgreSQL/3x-ui. Код 4.6.8 подготовлен для этих проверок и не требует изменения архитектуры внешнего L4 Router.
