# FargoVPN 4.6.9 — release/audit report

## Причина выпуска

4.6.8 корректно регистрировала Service Worker и проверяла public VAPID key по длине, но не закрывала два сценария, проявившиеся после восстановления/переноса:

- browser `AbortError: Error retrieving push subscription` при создании PushSubscription;
- provider `BadJwtToken` на iOS/Safari.

## Исправления

| Область | 4.6.8 | 4.6.9 |
|---|---|---|
| VAPID public key | проверка private/public pair в status | private key — source of truth; stale/empty public автоматически синхронизируется |
| VAPID subject | auto-derived без строгой валидации | URL/mailto validation; local/invalid host отклоняется |
| Apple reason | raw response body | JSON `reason` сохраняется как `reason=...` |
| Subscription rotation | endpoint/keys | дополнительно хранится VAPID public key |
| Browser AbortError | повторный `subscribe()` | reset SW + cache + повторная регистрация, максимум 2 попытки |
| stale applicationServerKey | не проверялся | обнаруживается и старая subscription удаляется |
| backend subscribe | generic exception | HTTP 503 с причиной VAPID configuration |

## Изменённые файлы

- `push_service.py`
- `webapp.py`
- `init_db.py`
- `VERSION`, `app/VERSION`, `INSTALLED_CHANGELOG_VERSION`
- `RELEASE_NOTES_4.6.9.md`
- `CHANGELOG.md`
- `INSTALLED_CHANGELOG.md`
- `tools/stress_test_panel.py`
- `tools/diagnose_restore_identity.py`
- `tests/test_release_45_contract.py`
- `tests/test_release_468_contract.py`
- `tests/test_release_contract_current.py`
- `tests/test_release_469_contract.py`

## Проверки

- Python `compileall`: PASS.
- Встроенный JavaScript Push script через Node syntax check: PASS.
- VAPID crypto/claims test: PASS.
- 4.6.8/4.6.9 release contract tests: **18 PASS**.
- Совместимый статический/контрактный набор suite: **106 PASS, 1 SKIP**.

Полная runtime-suite против PostgreSQL не была выполнена в этом контейнере: отсутствует `psycopg` binary driver и нет доступного production PostgreSQL. Это ограничение окружения, а не результатом теста не следует считать отсутствие runtime-регрессий.

## Что ожидать после обновления

Если `VAPID Subject` корректен и private/public key совпадают, iPhone-подписка должна проходить без `BadJwtToken`. Для desktop browser повторный `AbortError` теперь получит controlled reset/retry; если обе попытки завершаются `AbortError`, лог укажет browser-side transport issue, а серверная часть при этом считается исправной.
