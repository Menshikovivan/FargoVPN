# FargoVPN 4.6.10 — release/audit report

## Telegram: кнопки подключения

Изменён сценарий подключения в Telegram:

`Как подключиться` → `🍎 iPhone / iPad` или `🤖 Android` → `🟢 INCY` / `⚡ HAPP`.

Длинные названия больше не используются как единственная кнопка. Для каждой платформы приложение открывается отдельной inline-кнопкой. На iPhone первым показывается INCY, на Android — HAPP; обе опции доступны.

Telegram Bot API не позволяет указывать произвольные native schemes вроде `happ://`/`incy://` непосредственно в поле inline-button URL: для `url` поддерживаются HTTP(S) и `tg://`. Поэтому добавлен короткоживущий подписанный HTTPS launcher. Он:

1. проверяет HMAC-подпись и срок действия;
2. получает пользователя по Telegram ID из подписанного токена;
3. получает актуальную подписку пользователя в момент клика;
4. выполняет native deep-link `happ://add/...` или `incy://add/...`.

Существующая веб-страница «Как подключиться» уже использует те же native deep-link форматы, поэтому Telegram использует тот же механизм передачи подписки.

## Push: анализ предоставленного браузерного журнала

По журналу 4.6.9:

- secure context — OK;
- Notification permission — `granted`;
- Service Worker HTTP 200 — OK;
- Content-Type — JavaScript;
- Service-Worker-Allowed и scope — корректны;
- VAPID public key — 65 bytes, uncompressed P-256;
- `PushSubscription` отсутствует;
- ошибка возникает внутри `PushManager.subscribe()` с `AbortError: Error retrieving push subscription`;
- POST `/api/panel/push/subscribe` после ошибки не выполняется.

Следовательно, эта конкретная desktop-проблема возникает до сохранения подписки на backend. Работа Push на iPhone с тем же сервером подтверждает, что серверный VAPID/backend-контур для этой конфигурации функционирует.

## Что изменено в 4.6.10

- Добавлена клиентская криптографическая проверка VAPID public key как P-256 точки.
- Добавлен `PushManager.permissionState(...)` в диагностический журнал.
- Добавлена проверка внешнего browser push transport:
  - Chromium: `https://fcm.googleapis.com/`;
  - другие браузеры: Mozilla push service URL.
- При `AbortError` выполняется одна контролируемая повторная попытка после проверки push transport.
- Если внешний push service недоступен, создаётся отдельный `PushTransportError`, а UI сообщает именно о сетевой/политической проблеме браузера.
- Убран бессмысленный повторный unregister/register Service Worker при каждом `subscribe()` AbortError: предыдущий лог уже показал, что такой reset не помогает.
- Service Worker cache-busting в 4.6.10 использует `v=4.6.10`.

## Проверка

Пройдено:

- `py_compile` для `main.py`, `webapp.py`, `cabinet_service.py` и новых contract tests;
- **58/58** релизных контрактных тестов — PASS;
- отдельный тестовый набор без production config/psycopg-зависимостей: **50 PASS, 1 SKIP, 7 не выполнились из-за отсутствующего окружения**;
- static callback audit: 18 literal callback_data и соответствующие equality/prefix handlers, несопоставленных callback не обнаружено;
- archive safety scan: абсолютных путей и `../` нет.

Полный `pytest` в текущем контейнере не является валидным production smoke test, потому что архивный проект ожидает сгенерированный runtime `config.py` и установленный `psycopg`. Это ограничение тестового окружения, а не намеренное изменение релиза.

## Ограничение desktop Push

4.6.10 не может программно заставить Chromium создать PushSubscription, если сам браузер или сеть не предоставляет ему доступ к browser push transport. Теперь журнал различает этот случай от ошибок VAPID/Service Worker/backend.

Для Chromium при `PushTransportError` следует проверить:

- исходящий HTTPS к `fcm.googleapis.com`;
- корпоративный proxy/VPN;
- firewall/антивирус с HTTPS filtering;
- `chrome://gcm-internals`.

Изменения 4.6.10 не требуют менять Nginx L4/Stream Router или PROXY protocol цепочку для 3x-ui.
