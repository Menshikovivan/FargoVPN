import hashlib, json, sqlite3, tarfile, tempfile, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def make_legacy_backup(base: Path, *, with_xui: bool = True) -> Path:
    stage = base / "stage" / "vpn_service_backup"
    (stage / "bot" / "data").mkdir(parents=True)
    db = stage / "bot" / "data" / "vpn_bot.db"
    conn = sqlite3.connect(db)
    conn.execute("create table users(id integer primary key, username text)")
    conn.execute("insert into users values(1,'demo')")
    conn.commit(); conn.close()
    if with_xui:
        (stage / "databases").mkdir(parents=True)
        xui = stage / "databases" / "xui.db"
        c = sqlite3.connect(xui); c.execute("create table settings(k text, v text)"); c.commit(); c.close()
    archive = base / "legacy.tar.gz"
    with tarfile.open(archive, "w:gz") as tar:
        tar.add(stage, arcname="vpn_service_backup")
    return archive

def split_archive(archive: Path, partdir: Path) -> None:
    data=archive.read_bytes(); cut=len(data)//2
    partdir.mkdir()
    (partdir/(archive.name+".part001")).write_bytes(data[:cut])
    (partdir/(archive.name+".part002")).write_bytes(data[cut:])

def test_prepare_accepts_legacy_sqlite_application_without_manifest():
    with tempfile.TemporaryDirectory() as td:
        base=Path(td); archive=make_legacy_backup(base); parts=base/"parts"; split_archive(archive,parts)
        work=base/"work"
        r=subprocess.run([sys.executable,str(ROOT/"restore_manager.py"),"--prepare-dir",str(parts),"--work-dir",str(work),"--json"],capture_output=True,text=True)
        assert r.returncode==0, r.stderr
        payload=json.loads(r.stdout)
        assert payload["manifest"]["application_database"] == "SQLite"
        assert payload["manifest"]["xui_database"] == "SQLite"

def test_prepare_allows_users_only_archive_without_xui():
    with tempfile.TemporaryDirectory() as td:
        base=Path(td); archive=make_legacy_backup(base,with_xui=False); parts=base/"parts"; split_archive(archive,parts)
        work=base/"work"
        r=subprocess.run([sys.executable,str(ROOT/"restore_manager.py"),"--prepare-dir",str(parts),"--work-dir",str(work),"--json"],capture_output=True,text=True)
        assert r.returncode==0, r.stderr
        payload=json.loads(r.stdout)
        assert payload["manifest"]["application_database"] == "SQLite"
        assert payload["manifest"]["xui_database"] == "missing"


def test_prepare_accepts_current_manifest_checksums_and_split_archive():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        stage = base / "stage" / "vpn_service_backup"
        (stage / "databases").mkdir(parents=True)
        db = stage / "databases" / "fargovpn.sql"
        db.write_text("CREATE TABLE users (id BIGINT PRIMARY KEY);\n")
        (stage / "manifest.json").write_text(json.dumps({"format": "FargoVPN", "application_dump": "databases/fargovpn.sql"}))
        (stage / "checksums.json").write_text(json.dumps({"databases/fargovpn.sql": hashlib.sha256(db.read_bytes()).hexdigest()}))
        archive = base / "current.tar.gz"
        with tarfile.open(archive, "w:gz") as bundle:
            bundle.add(stage, arcname="vpn_service_backup")
        parts = base / "parts"; split_archive(archive, parts)
        result = subprocess.run([sys.executable, str(ROOT / "restore_manager.py"), "--prepare-dir", str(parts), "--work-dir", str(base / "work"), "--json"], capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
        assert json.loads(result.stdout)["manifest"]["application_database"] == "PostgreSQL"


def test_prepare_rejects_checksum_path_outside_archive():
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        archive = make_legacy_backup(base)
        stage = base / "stage" / "vpn_service_backup"
        (stage / "checksums.json").write_text(json.dumps({"../../outside": "0" * 64}))
        with tarfile.open(archive, "w:gz") as bundle:
            bundle.add(stage, arcname="vpn_service_backup")
        parts = base / "parts"; split_archive(archive, parts)
        result = subprocess.run([sys.executable, str(ROOT / "restore_manager.py"), "--prepare-dir", str(parts), "--work-dir", str(base / "work"), "--json"], capture_output=True, text=True)
        assert result.returncode != 0
        assert "за пределы архива" in result.stderr
