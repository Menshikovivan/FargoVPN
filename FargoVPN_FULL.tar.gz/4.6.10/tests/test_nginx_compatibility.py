from pathlib import Path
import importlib.util
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def _guard_module():
    spec = importlib.util.spec_from_file_location("fargovpn_nginx_guard", ROOT / "nginx_panel_guard.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_guard_routes_fargovpn_to_unix_socket_and_keeps_3xui_path_separate():
    guard = _guard_module()
    guard.cfg = lambda name, default=None: {
        "WEB_DOMAIN": "vpn.example.com",
        "WEB_PUBLIC_PREFIX": "/fargovpn-admin-abc12345",
        "WEB_SOCKET_PATH": "/run/vpn-service/fargovpn.sock",
    }.get(name, default)
    original = """server {
    listen 443 ssl;
    server_name vpn.example.com;
    location ^~ /my-3x-panel/ { proxy_pass http://127.0.0.1:10443; }
    location / { return 200 ok; }
}
"""
    new = guard._insert_into_named_https_server(
        original,
        guard.block(guard.prefix(), "/run/vpn-service/fargovpn.sock"),
    )
    assert new is not None
    assert "location ^~ /my-3x-panel/" in new
    assert "location ^~ /fargovpn-admin-abc12345/" in new
    assert "proxy_pass http://unix:/run/vpn-service/fargovpn.sock:/;" in new
    assert "listen 443 ssl;" in new


def test_installer_does_not_install_nginx_but_requires_preexisting_router():
    text = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert "apt_install nginx" not in text
    assert "apt-get install nginx" not in text
    assert "systemctl enable nginx.service" not in text
    assert "setup_existing_nginx_route" in text
    assert "nginx.service" in text
    assert "00-stream.conf" in text


def test_installer_corrects_stale_socket_group_and_probes_as_nginx_worker():
    text = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert 'set_value("WEB_SOCKET_GROUP", nginx_group)' in text
    assert 'SocketGroup=$SOCKET_GROUP' in text
    assert 'runuser -u "$NGINX_WORKER_USER" -- curl --unix-socket "$SOCKET_PATH"' in text


def test_guard_recognizes_external_nginx_unix_virtual_host():
    guard = _guard_module()
    guard.cfg = lambda name, default=None: {
        "WEB_DOMAIN": "vpn.example.com",
        "WEB_PUBLIC_PREFIX": "/fargovpn-admin-abc12345",
    }.get(name, default)
    nginx_server = """server {
    listen unix:/dev/shm/nginx-http.sock ssl default_server proxy_protocol;
    listen 127.0.0.1:9443 ssl default_server proxy_protocol;
    server_name vpn.example.com;
}
"""
    assert guard._file_contains_target_server(nginx_server) is True


def test_router_main_unix_only_beats_separate_9443_fallback():
    guard = _guard_module()
    guard.cfg = lambda name, default=None: {
        "WEB_DOMAIN": "cdn.example.com",  # restored config can point at the 9443 fallback
        "WEB_PUBLIC_PREFIX": "/fargovpn-admin-abc12345",
    }.get(name, default)
    original = """server {
    listen unix:/dev/shm/nginx-http.sock ssl proxy_protocol;
    server_name vpn.example.com;
    location / { return 200; }
}
server {
    listen 127.0.0.1:9443 ssl proxy_protocol;
    server_name cdn.example.com;
    location / { return 200; }
}
"""
    assert guard._file_contains_target_server(original)
    inserted = guard._insert_into_named_https_server(original, guard.block(guard.prefix(), "/run/vpn-service/fargovpn.sock"))
    assert inserted is not None
    main, fallback = inserted.split("server {", 2)[1:]
    assert "location ^~ /fargovpn-admin-abc12345/" in main
    assert "fargovpn-admin-abc12345" not in fallback
    assert "limit_req zone=panel" not in inserted


def test_route_stays_inside_real_router_https_server():
    guard = _guard_module()
    guard.cfg = lambda name, default=None: {
        "WEB_DOMAIN": "cdn.example.com",
        "WEB_PUBLIC_PREFIX": "/fargovpn-admin-abc12345",
    }.get(name, default)
    # Structure of the supplied nginx -T /etc/nginx/conf.d/01-main.conf:
    # HTTP redirect, rejected default TLS host, then the masked primary host.
    original = """server {
    listen 80 default_server;
    server_name _;
    location / { return 301 https://$host$request_uri; }
}

server {
    listen unix:/dev/shm/nginx-http.sock ssl default_server proxy_protocol;
    listen 127.0.0.1:9443 ssl default_server proxy_protocol;
    server_name _;
    ssl_reject_handshake on;
}

server {
    listen unix:/dev/shm/nginx-http.sock ssl proxy_protocol;
    listen 127.0.0.1:9443 ssl proxy_protocol;
    server_name vpn.example.com;
    if ($badbot) { return 404; }
    location ^~ /my-3x-panel/ { proxy_pass http://127.0.0.1:10443; }
    location ~* ^/Stream-One-Path(/.*)?$ { proxy_pass http://xray_xhttp_stream; }
}
"""
    changed = guard._insert_into_named_https_server(original, guard.block(guard.prefix(), "/run/vpn-service/fargovpn.sock"))
    assert changed is not None
    assert "\nserver {\n# BEGIN FARGOVPN MANAGED LOCATION\n" in changed
    assert changed.count("# BEGIN FARGOVPN MANAGED LOCATION") == 1
    assert "ssl_reject_handshake on;\n}" in changed
    assert changed.index("server_name vpn.example.com") > changed.index("# BEGIN FARGOVPN MANAGED LOCATION")
    assert changed.index("# BEGIN FARGOVPN MANAGED LOCATION") > changed.index("ssl_reject_handshake on;")


def test_guard_extracts_domain_from_actual_external_unix_socket_https_server():
    guard = _guard_module()
    nginx_dump = """# configuration file /etc/nginx/conf.d/01-main.conf:
server {
    listen unix:/dev/shm/nginx-http.sock ssl default_server proxy_protocol;
    listen 127.0.0.1:9443 ssl default_server proxy_protocol;
    server_name example-vpn.example;
    location ^~ /fargovpn-admin-abc12345/ {
        proxy_pass http://unix:/run/vpn-service/fargovpn.sock:/;
    }
    location /my-3x-panel/ { proxy_pass http://127.0.0.1:10443; }
}
"""
    assert guard.public_domain_from_nginx_text(nginx_dump, "/fargovpn-admin-abc12345") == "example-vpn.example"


def test_guard_builds_public_panel_url_from_discovered_domain():
    guard = _guard_module()
    guard.cfg = lambda name, default=None: {
        "WEB_PUBLIC_PREFIX": "/fargovpn-admin-abc12345",
        "WEB_DOMAIN": "example-vpn.example",
    }.get(name, default)
    assert guard.public_url() == "https://example-vpn.example/fargovpn-admin-abc12345/"


def test_installer_prints_public_panel_url_after_successful_full_install():
    text = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert 'nginx_panel_guard.py" --print-url' in text
    assert 'Веб-панель FargoVPN: $PANEL_PUBLIC_URL' in text
    assert 'STATUS_DETAIL+="; Веб-панель: $PANEL_PUBLIC_URL"' in text


def test_guard_ignores_unloaded_conf_and_selects_loaded_vhost(tmp_path, monkeypatch):
    guard = _guard_module()
    loaded = tmp_path / "active.conf"
    stale = tmp_path / "01-main.conf"
    original = "server {\n listen 127.0.0.1:9443 ssl;\n server_name vpn.example.com;\n}\n"
    loaded.write_text(original)
    stale.write_text(original)
    monkeypatch.setattr(guard, "MAIN", stale)
    monkeypatch.setattr(guard, "cfg", lambda name, default=None: {
        "WEB_REVERSE_PROXY": True, "WEB_DOMAIN": "vpn.example.com",
        "WEB_PUBLIC_PREFIX": "/fargovpn-admin-abc12345",
    }.get(name, default))
    monkeypatch.setattr(guard, "_nginx_dump", lambda: f"# configuration file {loaded}:\n{loaded.read_text()}")
    monkeypatch.setattr(guard, "_persist_public_identity", lambda: "")
    monkeypatch.setattr(guard.subprocess, "run", lambda *a, **k: subprocess.CompletedProcess(a[0], 0))
    assert guard.ensure_once() is True
    assert "fargovpn-admin-abc12345" in loaded.read_text()
    assert stale.read_text() == original


def test_guard_rolls_back_if_loaded_route_cannot_be_confirmed(tmp_path, monkeypatch):
    guard = _guard_module()
    loaded = tmp_path / "active.conf"
    original = "server {\n listen 127.0.0.1:9443 ssl;\n server_name vpn.example.com;\n}\n"
    loaded.write_text(original)
    monkeypatch.setattr(guard, "cfg", lambda name, default=None: {
        "WEB_REVERSE_PROXY": True, "WEB_DOMAIN": "vpn.example.com",
        "WEB_PUBLIC_PREFIX": "/fargovpn-admin-abc12345",
    }.get(name, default))
    monkeypatch.setattr(guard, "_nginx_dump", lambda: f"# configuration file {loaded}:\n{original}")
    monkeypatch.setattr(guard.subprocess, "run", lambda *a, **k: subprocess.CompletedProcess(a[0], 0))
    assert guard.ensure_once() is False
    assert loaded.read_text() == original
    assert not loaded.with_name(loaded.name + ".fargovpn-backup").exists()
