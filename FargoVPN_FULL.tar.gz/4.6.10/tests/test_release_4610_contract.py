from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'main.py').read_text(encoding='utf-8')
CAB = (ROOT / 'cabinet_service.py').read_text(encoding='utf-8')
WEB = (ROOT / 'webapp.py').read_text(encoding='utf-8')


def test_connection_platform_buttons_are_compact_and_split_by_device():
    assert '🍎 iPhone / iPad' in MAIN
    assert '🤖 Android' in MAIN
    assert 'connect:ios' in MAIN
    assert 'connect:android' in MAIN
    assert 'F.data.startswith("faq:")' in MAIN


def test_native_app_launcher_is_signed_https_not_custom_scheme_in_telegram_keyboard():
    assert 'def make_app_launch_url' in CAB
    assert 'def verify_app_launch' in CAB
    assert 'app-launch-v1:' in CAB
    assert '⚡ HAPP — открыть и импортировать' in MAIN
    assert '🟢 INCY — открыть и импортировать' in MAIN
    assert 'make_app_launch_url(user_id, app_key)' in MAIN
    assert 'app_order = ' in MAIN
    assert '@app.get("/open-app/{app}"' in WEB
    assert 'cabinet_service.verify_app_launch' in WEB
    assert 'happ://add/' in WEB
    assert 'incy://add/' in WEB


def test_push_browser_diagnostics_are_present():
    assert 'PushManager.permissionState' in WEB
    assert 'validateVapidPoint' in WEB
    assert 'probeExternalPushService' in WEB
    assert 'fcm.googleapis.com' in WEB
    assert 'chrome://gcm-internals' in WEB
    assert 'PushTransportError' in WEB
    assert 'Внешний push-сервис' in WEB
