"""Regression: the settings form must reach the save handler with CSRF intact."""
import asyncio
from unittest.mock import Mock

import pytest
from fastapi import HTTPException
from starlette.datastructures import FormData

import webapp


class SettingsRequest:
    method = "POST"
    headers = {}
    session = {"auth": True, "user": "admin", "csrf_token": "valid-settings-csrf"}

    def __init__(self, token):
        self.token = token
        self.session = dict(type(self).session)

    async def form(self):
        return FormData({"csrf_token": self.token, "service_name": "FargoVPN"})


def test_settings_form_csrf_reaches_save_and_rejects_missing_token(monkeypatch):
    calls = []
    monkeypatch.setattr(webapp, "_save_settings", lambda request, form: calls.append(form["service_name"]) or "saved")
    assert asyncio.run(webapp.save_settings(SettingsRequest("valid-settings-csrf"))) == "saved"
    assert calls == ["FargoVPN"]
    with pytest.raises(HTTPException) as error:
        asyncio.run(webapp.save_settings(SettingsRequest("")))
    assert error.value.status_code == 403
    assert calls == ["FargoVPN"]


def test_restart_job_is_owned_by_systemd_and_web_restarts_last(monkeypatch):
    run = Mock(return_value=type("Result", (), {"returncode": 0, "stdout": "", "stderr": ""})())
    monkeypatch.setattr(webapp.subprocess, "run", run)
    webapp.schedule_restart(["vpn-service-web", "vpn-service-bot"], delay=2)
    command = run.call_args.args[0]
    assert command[0] == "systemd-run"
    assert "--on-active=2s" in command
    assert command[-2:] == ["vpn-service-bot", "vpn-service-web"]


def test_settings_write_persists_secrets_and_xui_url(tmp_path, monkeypatch):
    import importlib.util
    original = tmp_path / 'config.py'
    original.write_text('BOT_TOKEN = ""\nMASTER_API_TOKEN = ""\nBASE_URL = ""\n')
    monkeypatch.setattr(webapp, 'CONFIG_PATH', original)
    monkeypatch.setattr(webapp, 'invalidate_snapshot_cache', lambda: None)
    monkeypatch.setattr(webapp.update_manager, 'invalidate_update_cache', lambda: None)
    values = {'BOT_TOKEN': '123:abc\\def', 'MASTER_API_TOKEN': 'secret\\value',
              'BASE_URL': 'https://example.org/xui/', 'XUI_PANEL_URL': 'https://example.org/xui/panel/'}
    previous = {name: getattr(webapp.config, name, None) for name in (*values, 'WEB_REVERSE_PROXY', 'WEB_HOST', 'WEB_SOCKET_PATH', 'WEB_COOKIE_HTTPS_ONLY', 'WEB_TRUST_PROXY_HEADERS')}
    try:
        webapp.save_config_values(values)
        spec = importlib.util.spec_from_file_location('saved_config_check', original)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        for name, value in values.items():
            assert getattr(module, name) == value
        assert original.stat().st_mode & 0o777 == 0o600
    finally:
        for name, value in previous.items():
            if value is None:
                if hasattr(webapp.config, name):
                    delattr(webapp.config, name)
            else:
                setattr(webapp.config, name, value)


def test_settings_restart_does_not_start_backup_or_reminder_jobs():
    from pathlib import Path
    source = Path(webapp.__file__).read_text(encoding='utf-8')
    handler = source[source.index('def _save_settings('):source.index('@app.post("/api/tls/auto"')]
    assert 'schedule_restart(["vpn-service-bot.service", "vpn-service-web.service"]' in handler
    assert 'schedule_restart(["vpn-service-bot", "vpn-service-web", "vpn-service-backup.service"' not in handler


def test_xui_save_is_independent_of_unrelated_form_fields(monkeypatch):
    saved = []
    restarted = []
    monkeypatch.setattr(webapp, 'save_config_values', lambda values: saved.append(values.copy()))
    monkeypatch.setattr(webapp, 'schedule_restart', lambda units, delay=2: restarted.append(units))
    monkeypatch.setattr(webapp, 'audit', lambda *args: None)
    monkeypatch.setattr(webapp, 'public_path', lambda path: '/test' + path)
    request = SettingsRequest('valid-settings-csrf')
    async def connection_form():
        return FormData({'csrf_token': request.token, 'xui_panel_url': 'https://example.org/base/panel/',
                         'api_token': 'test-api-secret', 'xui_verify_tls': '1',
                         'service_name': '', 'reminder_days': ''})
    request.form = connection_form
    response = asyncio.run(webapp.save_xui_settings(request))
    assert response.status_code == 303
    assert response.headers['location'] == '/test/settings?tab=xui'
    assert saved[0]['MASTER_API_TOKEN'] == 'test-api-secret'
    assert saved[0]['BASE_URL'] == 'https://example.org/base/'
    assert saved[0]['XUI_PANEL_URL'] == 'https://example.org/base/panel'
    assert restarted == [['vpn-service-bot.service', 'vpn-service-web.service']]


def test_bot_event_prune_uses_valid_postgresql_day_interval(monkeypatch):
    from contextlib import contextmanager
    import user_events
    calls = []
    class Result:
        rowcount = 0
        def fetchone(self):
            return (0,)
    class Connection:
        def execute(self, sql, parameters=()):
            calls.append((sql, parameters))
            return Result()
    @contextmanager
    def fake_connect(path):
        yield Connection()
    monkeypatch.setattr(user_events, 'ensure_schema', lambda path: None)
    monkeypatch.setattr(user_events, '_connect', fake_connect)
    assert user_events.prune_events(keep_days=365) == 0
    assert "CURRENT_TIMESTAMP - (? * INTERVAL '1 day')" in calls[0][0]
    assert calls[0][1] == (365,)
