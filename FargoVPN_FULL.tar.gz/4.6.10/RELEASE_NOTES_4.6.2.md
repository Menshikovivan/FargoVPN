# FargoVPN 4.6.2

- Поддержка HTTPS virtual host внешнего Nginx/L4 на Unix socket без TCP 443/9443 в том же server.
- При наличии отдельного fallback 9443 всегда предпочитается основной Unix HTTPS host, даже если сохранённый WEB_DOMAIN относится к fallback.
- Убрана зависимость от необязательной внешней limit_req зоны panel; добавлена диагностика ошибок nginx -t/reload и дамп nginx -T при сбое.
- Сохранены исправления резервных копий и PostgreSQL ветки 4.6.0.
