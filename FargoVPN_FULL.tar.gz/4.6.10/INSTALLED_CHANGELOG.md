# FargoVPN 4.6.10

- Telegram: иерархия устройств → приложения, автозапуск HAPP/INCY через подписанный HTTPS launcher.
- Push: диагностика browser push transport, VAPID P-256 validation и controlled retry.

## 4.6.9

- Исправлена синхронизация VAPID public/private key после восстановления и диагностика Apple `BadJwtToken`.
- `PUSH_VAPID_SUBJECT` валидируется; stale/локальные subject больше не используются для Web Push.
- `PushSubscription` теперь связывается с VAPID public key, использованным при регистрации.
- Для browser `AbortError: Error retrieving push subscription` добавлен контролируемый reset Service Worker/cache и повторная подписка.
- HTTP provider `reason` сохраняется в журнале Push.

## 4.6.8

- Исправлена изоляция недоступных Telegram-чатов: terminal `Forbidden/BadRequest` больше не роняют рассылки, напоминания и другие workflow; ошибки журналируются с `user_id`.
- Restore identity re-key расширен на историю сообщений, платежи, Push subscriptions, pending registrations, access/cabinet records, referral ledger и Telegram link requests.
- Добавлена сериализация продлений подписки по Telegram ID через PostgreSQL advisory lock, чтобы два разных платежа одного клиента не потеряли дни при конкурентной записи в 3x-ui.
- Добавлена проверка целостности VAPID private/public pair и улучшена диагностика браузерной ошибки `Error retrieving push subscription`.
- Раздел обновлений и backend mutation routes ограничены publisher-аккаунтом `menshikovivan`; обычным аккаунтам доступны только проверка и установка обновления.
- Добавлен read-only диагностический скрипт `tools/diagnose_restore_identity.py` и внешний concurrency smoke-test `tools/stress_test_panel.py`.

# FargoVPN 4.6.7

- Устранён аварийный перезапуск бота из-за интервала PostgreSQL и добавлено независимое сохранение подключения 3x-ui.

# FargoVPN 4.6.6

- Проверка записанного config.py и секретов, резервный API 3x-ui, вкладки настроек и отмена запуска полного бэкапа при сохранении.

# FargoVPN 4.6.5

- Исправлено сохранение настроек (CSRF формы), отображение статуса секретов и надёжный перезапуск служб через systemd.

# FargoVPN 4.6.4

# FargoVPN 4.6.3

# FargoVPN 4.6.2

# FargoVPN 4.6.1

# FargoVPN 4.6.0

# FargoVPN 4.5.6

- Поддержано восстановление legacy SQLite-бэкапов FargoVPN без PostgreSQL dump.
- Пустая PostgreSQL больше не ошибочно считается уже мигрированной.
- Укреплена проверка маршрута внешнего Nginx без зависимости от точного форматирования `nginx -T`.
- `postgresql-common` добавлен в подготовку системных зависимостей.

# FargoVPN 4.5.5

- Исправлен явный запуск `vpn-service-bot.service` после обновления при наличии `BOT_TOKEN`.
- Добавлена структурированная диагностика падений bot/web без `journalctl`-мусора.
- Добавлено окно до 15 секунд для перехода web-service в `active` перед отклонением обновления.
- Исправлен вывод состояния PostgreSQL: DSN определяется через фактический импорт `config.py`.
- Сохранена схема с внешним Nginx без установки/перезаписи Nginx FargoVPN.
