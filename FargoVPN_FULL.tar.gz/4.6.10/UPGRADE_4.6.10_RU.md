# Обновление FargoVPN до 4.6.10

1. Сделать стандартный backup БД и текущего каталога FargoVPN.
2. Обновить архивом `VPN_Service_Platform_4.6.10_FULL.tar.gz` штатным механизмом панели или `install.sh`.
3. Не менять существующий `vapid_private.pem` / VAPID private key.
4. Перезапустить веб-панель/бот стандартной процедурой проекта.
5. В Telegram открыть `Как подключиться` → выбрать `🍎 iPhone / iPad` или `🤖 Android` → выбрать `🟢 INCY` или `⚡ HAPP`.
6. На desktop открыть `Настройки → Уведомления → Push`, нажать `Проверить`, затем `Включить`.
7. При повторном `AbortError` смотреть браузерный журнал: 4.6.10 покажет `PushTransportError` или доступность внешнего push-сервиса.

## Desktop Chrome/Edge

Если журнал показывает недоступность `https://fcm.googleapis.com/`, проверить корпоративный proxy, VPN, firewall и антивирусную HTTPS-фильтрацию. На Windows также можно проверить `chrome://gcm-internals`.

## Nginx L4 / 3x-ui

Изменения 4.6.10 не требуют менять L4 routing, Stream Router или PROXY protocol. HTTPS launcher и Push используют тот же внешний HTTPS origin панели.
