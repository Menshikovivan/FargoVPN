# FargoVPN 4.6.10

## Telegram: подключение

- Вместо длинных обрезаемых кнопок «подключиться…» теперь сначала отображаются `🍎 iPhone / iPad` и `🤖 Android`.
- Внутри платформы размещены отдельные кнопки `🟢 INCY` и `⚡ HAPP`; кнопка открывает HTTPS launcher, который передаёт текущую подписку в native-приложение автоматически.
- Для iPhone первым отображается INCY, для Android — HAPP; обе кнопки остаются доступны.
- Старые callback `faq:incy` / `faq:happ` сохранены для совместимости со старыми сообщениями.

## Browser Push

- По пользовательскому логу 4.6.9 ошибка возникает внутри `PushManager.subscribe()` до POST `/api/panel/push/subscribe`; Service Worker, HTTPS, permission и VAPID public key проходят.
- Поэтому 4.6.10 не маскирует проблему новым сбросом Service Worker: проверяется доступность внешнего push-сервиса браузера.
- Для Chromium используется диагностический probe `https://fcm.googleapis.com/`; при недоступности показывается отдельная причина `PushTransportError`.
- При доступном push-сервисе выполняется одна повторная попытка `subscribe()` без лишнего unregister/register SW.
- Это помогает отличить браузерную/сетевую блокировку от ошибок backend/VAPID.

## Важно

Работоспособность Push на iPhone при том же VAPID профиле означает, что серверная VAPID-конфигурация и Web Push backend уже функционируют для этой пары ключей. Desktop `AbortError` в данной точке находится раньше backend-запроса и обычно связан с состоянием браузера или его push transport/network policy.
