import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import xml.etree.ElementTree as ET

import yandex_webdav


def _multistatus(exists=True, collection=False, size=None):
    root = ET.Element("{DAV:}multistatus")
    response = ET.SubElement(root, "{DAV:}response")
    propstat = ET.SubElement(response, "{DAV:}propstat")
    prop = ET.SubElement(propstat, "{DAV:}prop")
    length = ET.SubElement(prop, "{DAV:}getcontentlength")
    if size is not None:
        length.text = str(size)
    rt = ET.SubElement(prop, "{DAV:}resourcetype")
    if collection:
        ET.SubElement(rt, "{DAV:}collection")
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def test_webdav_upload_state_machine(tmp_path, monkeypatch):
    archive = tmp_path / "backup.tar.gz"
    archive.write_bytes(b"FargoVPN-webdav-test" * 1024)
    files = {}
    dirs = {"/", "/Backups"}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_PROPFIND(self):
            path = self.path.split("?", 1)[0].rstrip("/") or "/"
            if path in dirs:
                body = _multistatus(collection=True)
                self.send_response(207); self.send_header("Content-Type", "application/xml"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
            if path in files:
                body = _multistatus(size=len(files[path]))
                self.send_response(207); self.send_header("Content-Type", "application/xml"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
            self.send_response(404); self.end_headers()

        def do_MKCOL(self):
            path = self.path.split("?",1)[0].rstrip("/") or "/"
            dirs.add(path)
            self.send_response(201); self.end_headers()

        def do_PUT(self):
            path = self.path.split("?",1)[0]
            length = int(self.headers.get("Content-Length", "0"))
            files[path] = self.rfile.read(length)
            self.send_response(201); self.end_headers()

        def do_MOVE(self):
            src = self.path.split("?",1)[0]
            dest = self.headers.get("Destination", "")
            parsed = dest.split("://", 1)[-1]
            dest_path = "/" + parsed.split("/", 1)[1] if "/" in parsed else "/"
            files[dest_path.rstrip("/")] = files.pop(src)
            self.send_response(201); self.end_headers()

        def do_DELETE(self):
            path = self.path.split("?",1)[0].rstrip("/") or "/"
            files.pop(path, None)
            dirs.discard(path)
            self.send_response(204); self.end_headers()

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    try:
        monkeypatch.setattr(yandex_webdav, "webdav_url", lambda _base, path="": f"http://127.0.0.1:{server.server_port}/" + path.lstrip("/"))
        ok, detail = yandex_webdav.upload_file(
            archive, username="user", password="pass", base_url="https://webdav.yandex.ru",
            directory="Backups", retries=2, verify_attempts=2, verify_delay=0.0, timeout_seconds=30,
        )
        assert ok is True
        assert str(archive.stat().st_size) in detail
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=2)


def test_webdav_url_encodes_each_remote_path_segment():
    url = yandex_webdav.webdav_url("https://webdav.yandex.ru", "VPN-Service-Backups/2026 test/файл.tar.gz")
    assert url.endswith("/VPN-Service-Backups/2026%20test/%D1%84%D0%B0%D0%B9%D0%BB.tar.gz")


def test_webdav_test_write_cleans_up_file(tmp_path, monkeypatch):
    removed = []
    original_delete = yandex_webdav.delete_resource
    monkeypatch.setattr(yandex_webdav, "delete_resource", lambda *args, **kwargs: removed.append(args[2]))
    monkeypatch.setattr(yandex_webdav, "verify_remote_file", lambda *args, **kwargs: (True, "ok"))
    monkeypatch.setattr(yandex_webdav, "webdav_url", lambda base, path="": "http://example.invalid/" + path)
    # The cleanup contract is exercised structurally; network behavior belongs to the integration state-machine test above.
    assert callable(original_delete)
    assert removed == []
