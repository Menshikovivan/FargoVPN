(function () {
  'use strict';
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const publicScopeMeta = document.querySelector('meta[name=\"fargovpn-sw-scope\"]');
  const PUBLIC_PREFIX = publicScopeMeta ? String(publicScopeMeta.content || '').replace(/\/$/, '') : '';
  const panelPath = (path) => {
    const raw = String(path || '/');
    if (!raw.startsWith('/')) return (PUBLIC_PREFIX ? PUBLIC_PREFIX + '/' : '/') + raw;
    return PUBLIC_PREFIX && !raw.startsWith(PUBLIC_PREFIX + '/') ? PUBLIC_PREFIX + raw : raw;
  };

  async function pollPlatformUpdate() {
    const slot = document.getElementById('global-update-slot');
    if (!slot || document.getElementById('global-update-banner')) return;
    try {
      const response = await fetch(panelPath('/api/panel/update-status'), {cache: 'no-store'});
      if (!response.ok) return;
      const data = await response.json();
      if (!data.available) return;
      const box = document.createElement('div');
      box.className = 'update-banner';
      box.id = 'global-update-banner';
      const strong = document.createElement('strong');
      strong.textContent = 'Доступно обновление ' + (data.version || '');
      const span = document.createElement('span');
      span.textContent = 'Новая версия готова к установке.';
      const link = document.createElement('a');
      link.className = 'button small';
      link.href = panelPath('/updates');
      link.textContent = 'Обновить';
      box.append(strong, span, link);
      slot.replaceWith(box);
    } catch (_) {}
  }

  function scrollPanelContainersToBottom(root = document) {
    const containers = root.querySelectorAll(
      '.chat-window, pre.auto-scroll-bottom, .log-output, [data-auto-scroll-bottom]'
    );
    containers.forEach((container) => {
      if (container && typeof container.scrollHeight === 'number') {
        container.scrollTop = container.scrollHeight;
      }
    });
  }

  function initBottomScroll() {
    const run = () => scrollPanelContainersToBottom();
    run();
    requestAnimationFrame(run);
    setTimeout(run, 80);
    document.querySelectorAll('.chat-window, pre.auto-scroll-bottom, .log-output, [data-auto-scroll-bottom]').forEach((container) => {
      if (container.dataset.bottomScrollObserver === '1' || typeof MutationObserver === 'undefined') return;
      container.dataset.bottomScrollObserver = '1';
      const observer = new MutationObserver(() => {
        if (!document.hidden) container.scrollTop = container.scrollHeight;
      });
      observer.observe(container, {childList: true, subtree: true});
    });
  }

  function initMobileNavigation() {
    const body = document.body;
    const root = document.documentElement;
    const toggle = document.getElementById('mobile-nav-toggle');
    const backdrop = document.getElementById('mobile-nav-backdrop');
    const aside = document.querySelector('body.panel-page > aside');
    if (!aside) return;

    const isMobile = () => window.matchMedia ? window.matchMedia('(max-width: 900px)').matches : window.innerWidth <= 900;
    const setOpen = (open) => {
      const mobile = isMobile();
      const next = Boolean(mobile && open);
      body.classList.toggle('mobile-nav-open', next);
      root.classList.toggle('mobile-menu-open', next);
      aside.setAttribute('aria-hidden', mobile && !next ? 'true' : 'false');
      if (toggle) {
        toggle.disabled = false;
        toggle.removeAttribute('disabled');
        toggle.removeAttribute('tabindex');
        toggle.setAttribute('aria-expanded', next ? 'true' : 'false');
        toggle.setAttribute('aria-label', next ? 'Закрыть меню' : 'Открыть меню');
        toggle.classList.toggle('is-open', next);
      }
      if (!mobile) {
        aside.style.removeProperty('transform');
        aside.style.removeProperty('visibility');
        aside.style.removeProperty('pointer-events');
      }
    };
    if (toggle && toggle.dataset.navBound !== '1') {
      toggle.dataset.navBound = '1';
      toggle.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (!isMobile()) return;
        setOpen(!body.classList.contains('mobile-nav-open'));
      }, {passive:false});
    }
    if (backdrop && backdrop.dataset.navBound !== '1') {
      backdrop.dataset.navBound = '1';
      backdrop.addEventListener('click', () => setOpen(false), {passive:true});
    }
    aside.addEventListener('click', (event) => {
      if (!isMobile()) return;
      const link = event.target.closest('nav a, .aside-foot a');
      if (link) setOpen(false);
    }, {passive:true});

    const sync = () => {
      if (isMobile()) {
        const narrow = window.innerWidth <= 600;
        aside.style.removeProperty('transform');
        aside.style.removeProperty('visibility');
        aside.style.removeProperty('pointer-events');
        aside.style.width = narrow ? '' : '230px';
        setOpen(body.classList.contains('mobile-nav-open'));
      } else {
        body.classList.remove('mobile-nav-open');
        root.classList.remove('mobile-menu-open');
        aside.style.removeProperty('transform');
        aside.style.removeProperty('visibility');
        aside.style.removeProperty('pointer-events');
        aside.style.removeProperty('width');
        aside.setAttribute('aria-hidden', 'false');
        if (toggle) {
          toggle.classList.remove('is-open');
          toggle.setAttribute('aria-expanded', 'false');
        }
      }
    };
    sync();
    window.addEventListener('resize', sync, {passive:true});
    window.addEventListener('orientationchange', () => setTimeout(sync, 0), {passive:true});
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && isMobile() && body.classList.contains('mobile-nav-open')) setOpen(false);
    });
  }

  function initTabs() {
    document.querySelectorAll('[data-tabs]').forEach((root) => {
      const buttons = Array.from(root.querySelectorAll('[data-tab]'));
      const sectionScope = root.parentElement || document;
      const sections = Array.from(sectionScope.querySelectorAll('[data-tab-section]'));
      const activate = (name, writeHash = true) => {
        buttons.forEach((button) => {
          const active = button.dataset.tab === name;
          button.classList.toggle('active', active);
          button.setAttribute('aria-selected', active ? 'true' : 'false');
        });
        sections.forEach((section) => section.classList.toggle('active', section.dataset.tabSection === name));
        if (writeHash && history.replaceState) history.replaceState(null, '', '#' + encodeURIComponent(name));
      };
      root.classList.add('tabs-ready');
      root.setAttribute('role', 'tablist');
      buttons.forEach((button) => {
        button.setAttribute('role', 'tab');
        button.addEventListener('click', (event) => {
          event.preventDefault();
          activate(button.dataset.tab);
        });
      });
      const rawHash = location.hash.slice(1);
      let requested = '';
      try { requested = decodeURIComponent(rawHash); } catch (_) { requested = rawHash; }
      const initial = buttons.some((button) => button.dataset.tab === requested)
        ? requested : (buttons[0] && buttons[0].dataset.tab);
      if (initial) activate(initial, false);
    });
  }

  function initConfirmations() {
    document.querySelectorAll('[data-confirm]').forEach((element) => {
      element.addEventListener('click', (event) => {
        if (!window.confirm(element.dataset.confirm || 'Продолжить?')) event.preventDefault();
      });
    });
  }

  function initSubscriptionRefreshTools() {
    const form = document.getElementById('subscription-refresh-form');
    const panel = document.getElementById('subscription-refresh-panel');
    if (!form || !panel) return;
    const start = document.getElementById('subscription-refresh-start');
    const box = document.getElementById('subscription-refresh-status');
    const get = (id) => document.getElementById(id);
    let active = false;
    const set = (id, value) => { const node = get(id); if (node) node.textContent = value == null ? '' : String(value); };
    const render = (data) => {
      if (!data || !data.state) return;
      active = ['queued', 'running'].includes(data.state);
      const progress = Math.max(0, Math.min(100, Number(data.progress) || 0));
      const bar = get('subscription-refresh-progress-bar');
      if (bar) bar.style.width = progress + '%';
      set('subscription-refresh-progress-percent', progress + '%');
      set('subscription-refresh-progress-text', data.message || 'Ожидание запуска');
      set('subscription-refresh-processed', (data.processed || 0) + ' / ' + (data.total || 0));
      set('subscription-refresh-delivered', data.delivered || 0);
      set('subscription-refresh-skipped', data.skipped || 0);
      set('subscription-refresh-failed', data.failed || 0);
      set('subscription-refresh-current', data.current_user ? 'Сейчас: ' + data.current_user + (data.last_action ? ' · ' + data.last_action : '') : '');
      set('subscription-refresh-log-body', Array.isArray(data.recent_log) && data.recent_log.length ? data.recent_log.join('\n') : (data.error || 'Журнал пока пуст.'));
      const badge = get('subscription-refresh-badge');
      if (badge) {
        badge.textContent = data.state === 'completed' ? 'Завершено' : data.state === 'failed' ? 'Ошибка' : active ? 'Выполняется' : 'Ожидание';
        badge.className = 'badge ' + (data.state === 'failed' ? 'bad' : data.state === 'completed' ? 'good' : active ? 'warn' : '');
      }
      if (start) { start.disabled = active; start.textContent = active ? '⏳ Выполняется…' : '↻ Запустить отправку'; }
      if (box) {
        box.hidden = !data.error;
        box.textContent = data.error ? 'Ошибка: ' + data.error : '';
        box.className = 'notice bad';
      }
    };
    const poll = async () => {
      try {
        const response = await fetch(panelPath('/api/users/subscription-refresh/status'), {cache:'no-store', credentials:'same-origin', headers:{Accept:'application/json'}});
        if (response.ok) render(await response.json());
      } catch (_) {}
      setTimeout(poll, active ? 900 : 5000);
    };
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!confirm('Разослать всем Telegram-пользователям их актуальные ссылки подписки?')) return;
      if (start) start.disabled = true;
      try {
        const response = await fetch(form.action, {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8','Accept':'application/json'}, body:new URLSearchParams(new FormData(form))});
        const data = await response.json().catch(() => ({}));
        if (!response.ok || data.ok === false) throw new Error(data.detail || data.error || 'Задача не запущена');
        render(data.status || data);
      } catch (error) {
        if (box) { box.hidden = false; box.textContent = 'Ошибка запуска: ' + (error.message || error); box.className = 'notice bad'; }
        if (start) start.disabled = false;
      }
    });
    poll();
  }

  function initUnreadMessages() {
    const badges = () => Array.from(document.querySelectorAll('[data-unread-total]'));
    let timer = 0;
    let inFlight = false;
    const refresh = async () => {
      if (inFlight || document.hidden) { timer = setTimeout(refresh, 15000); return; }
      inFlight = true;
      try {
        const response = await fetch(panelPath('/api/panel/messages/unread'), {
          credentials: 'same-origin', cache: 'no-store', headers: {Accept:'application/json'}
        });
        if (!response.ok) return;
        const data = await response.json();
        const total = Math.max(0, Number(data.total) || 0);
        badges().forEach((node) => { node.textContent = total ? String(total) : ''; node.hidden = !total; });
      } catch (_) {}
      finally { inFlight = false; timer = setTimeout(refresh, 15000); }
    };
    refresh();
    document.addEventListener('visibilitychange', () => { if (!document.hidden) { clearTimeout(timer); refresh(); } });
    window.addEventListener('pagehide', () => clearTimeout(timer), {once:true});
  }

  function startPanelScripts() {
    const safeInit = (name, fn) => { try { fn(); } catch (error) { console.error('[FargoVPN]', name, error); } };
    safeInit('bottom-scroll', initBottomScroll);
    safeInit('mobile-navigation', initMobileNavigation);
    safeInit('tabs', initTabs);
    safeInit('confirmations', initConfirmations);
    safeInit('subscription-refresh', initSubscriptionRefreshTools);
    safeInit('unread-messages', initUnreadMessages);
    setTimeout(pollPlatformUpdate, 3000);
    setInterval(pollPlatformUpdate, 60000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startPanelScripts, {once: true});
  } else {
    startPanelScripts();
  }
})();

/* FargoVPN 4.2.1 interaction layer. Keeps page-specific handlers intact. */
(function(){
  const root=document.documentElement;
  const body=document.body;
  if(!body.classList.contains('panel-page')) return;

  const nav=document.getElementById('panel-sidebar');
  if(nav){
    nav.addEventListener('mouseenter',()=>root.classList.add('fv42-nav-hover'),{passive:true});
    nav.addEventListener('mouseleave',()=>root.classList.remove('fv42-nav-hover'),{passive:true});
    nav.querySelectorAll('a').forEach(link=>{
      link.addEventListener('focus',()=>root.classList.add('fv42-nav-hover'),{passive:true});
      link.addEventListener('blur',()=>root.classList.remove('fv42-nav-hover'),{passive:true});
    });
  }

  document.querySelectorAll('.button,button,.quick-action,.header-icon').forEach((el)=>{
    el.addEventListener('click',()=>{
      el.classList.remove('fv42-pulse');
      void el.offsetWidth;
      el.classList.add('fv42-pulse');
    },{passive:true});
  });

  const search=document.querySelector('[data-panel-search]');
  if(search){
    search.addEventListener('keydown',(event)=>{
      if(event.key==='Escape') search.blur();
      if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){event.preventDefault();search.focus();}
    });
  }
})();
