# FargoVPN 4.3.4

- Исправлен GitHub main sync endpoint для обновления refs.
- Добавлен regression test на HTTP 404 при update reference.

# FargoVPN 4.3.1

Релиз 4.3.1: bootstrap-установщик через GitHub main, исправления installer/TLS/Yandex status, обновлённая документация и очищенный production-архив.
