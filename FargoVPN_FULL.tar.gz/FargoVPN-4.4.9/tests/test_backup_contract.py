from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_old_yandex_runtime_is_removed():
    for name in ["backup.py", "config.example.py", "webapp.py"]:
        text = (ROOT / name).read_text(encoding="utf-8")
        forbidden = [
            "YANDEX_DISK_MODE", "YANDEX_DISK_TOKEN", "YANDEX_LOCAL_PATH",
            "YANDEX_LOCAL_REQUIRE_MOUNT", "YANDEX_DAVFS_SECRETS_PATH",
            "RCLONE_REMOTE", "RCLONE_PATH", "cloud-api.yandex.net", "mount.davfs",
        ]
        assert not any(item in text for item in forbidden), name


def test_backup_has_both_postgresql_dumps():
    text = (ROOT / "backup.py").read_text(encoding="utf-8")
    assert 'databases / "fargovpn.sql"' in text
    assert 'databases / "xui.sql"' in text


def test_yandex_settings_panel_uses_davfs2_webdav():
    text = (ROOT / "webapp.py").read_text(encoding="utf-8")
    start = text.index('@app.get("/settings/yandex"')
    end = text.index('@app.get("/api/updates/status")', start)
    block = text[start:end]
    assert "YANDEX_DAVFS_MOUNT_POINT" in block
    assert "только на время проверки или доставки бэкапа" in block
    assert "Проверить подключение" in block
    assert "Создать тестовый файл" in block
    assert "YANDEX_DISK_TOKEN" not in block
    assert "YANDEX_DISK_MODE" not in block
    assert "xui_postgres_dsn_for_cli" in (ROOT / "backup.py").read_text(encoding="utf-8")


def test_users_query_is_postgres_safe():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "COLLATE NOCASE" not in text
    assert "LOWER(COALESCE(username" in text


def test_backup_transport_uses_system_davfs2_and_installer_installs_it():
    backup = (ROOT / "backup.py").read_text(encoding="utf-8")
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert "rclone" not in backup
    assert "httpx" not in (ROOT / "yandex_webdav.py").read_text(encoding="utf-8")
    assert "PROPFIND" not in (ROOT / "yandex_webdav.py").read_text(encoding="utf-8")
    assert "client.put" not in (ROOT / "yandex_webdav.py").read_text(encoding="utf-8")
    assert "configure_credentials" not in (ROOT / "yandex_webdav.py").read_text(encoding="utf-8")
    assert "configure_fstab" not in (ROOT / "yandex_webdav.py").read_text(encoding="utf-8")
    assert "cloud-api.yandex.net" not in backup
    assert "apt-get install" in installer
    assert " rclone" not in installer
    assert " davfs2" in installer
    assert '/media/YandexDisk' in installer
    assert '/etc/davfs2/secrets' in installer
    assert 'fstab.fargovpn-backup.' in installer
    assert 'FARGOVPN_DISABLED_YANDEX' in installer
    assert not (ROOT / "configure_yandex_webdav.sh").exists()

def test_yandex_navigation_is_separate_settings_panel():
    text = (ROOT / "webapp.py").read_text(encoding="utf-8")
    assert '("yandex", "/settings/yandex", "cloud", "Яндекс.Диск")' in text
    assert 'public_path("/settings/yandex")' in text

def test_telegram_idempotency_is_registered_before_handlers():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    middleware_pos = text.index("class TelegramUpdateIdempotencyMiddleware")
    registration_pos = text.index("dp.update.outer_middleware(TelegramUpdateIdempotencyMiddleware())")
    assert middleware_pos < registration_pos
    assert "claim_telegram_update" in text
    assert "mark_telegram_update_processed" in text
    assert "release_telegram_update" in text


def test_manual_backup_is_available_in_admin_bot():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    assert 'callback_data="admin:backup"' in text
    assert 'elif action == "backup":' in text
    assert 'async def run_admin_backup' in text
    assert 'launch_detached' in text
    assert '[sys.executable, str(APP_DIR / "backup.py"), "--force"]' in text
    assert '@dp.message(Command("backup"))' in text


def test_manual_backup_does_not_block_event_loop():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    start = text.index('async def run_admin_backup')
    end = text.index('@dp.callback_query(F.data.startswith("admin:"))', start)
    block = text[start:end]
    assert 'await asyncio.to_thread(' in block
    assert 'launch_detached' in block


def test_disabled_yandex_is_not_recorded_as_success():
    # Keep this contract independent from a production config.py / PostgreSQL DSN.
    text = (ROOT / "backup.py").read_text(encoding="utf-8")
    assert "def yandex_upload_enabled()" in text
    assert "and not yandex_upload_enabled():" in text
    assert 'detail = "Отключено: WebDAV-загрузка на Яндекс.Диск выключена в настройках"' in text


def test_backup_service_and_timer_use_real_backup_worker():
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert "ExecStart=$TARGET/.venv/bin/python $TARGET/backup.py --scheduled" in installer
    assert "OnBootSec=5m" in installer
    assert "OnUnitActiveSec=15m" in installer
    assert "Persistent=true" in installer
    assert "systemctl enable vpn-service-bot.service vpn-service-backup.timer" in installer


def test_backup_worker_force_mode_is_used_by_telegram_admin_button():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    start = text.index('async def run_admin_backup')
    end = text.index('@dp.callback_query(F.data.startswith("admin:"))', start)
    block = text[start:end]
    assert '[sys.executable, str(APP_DIR / "backup.py"), "--force"]' in block
    assert 'await asyncio.to_thread(' in block



def test_sqlite_snapshot_is_consistent_and_read_only(tmp_path, monkeypatch):
    import sqlite3
    import sys
    import types
    monkeypatch.setitem(sys.modules, "config", types.SimpleNamespace())
    import backup

    source = tmp_path / "x-ui.db"
    copy = tmp_path / "snapshot.db"
    conn = sqlite3.connect(source)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT)")
    conn.execute("INSERT INTO clients(name) VALUES (?)", ("client-1",))
    conn.commit()
    backup.sqlite_snapshot(source, copy)
    check = sqlite3.connect(copy)
    try:
        assert check.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert check.execute("SELECT name FROM clients").fetchone()[0] == "client-1"
    finally:
        check.close()
        conn.close()


def test_xui_snapshot_falls_back_to_legacy_sqlite(tmp_path, monkeypatch):
    import sqlite3
    import sys
    import types
    monkeypatch.setitem(sys.modules, "config", types.SimpleNamespace())
    import backup

    source = tmp_path / "x-ui.db"
    conn = sqlite3.connect(source)
    conn.execute("CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT)")
    conn.execute("INSERT INTO clients(name) VALUES ('sqlite-client')")
    conn.commit(); conn.close()
    monkeypatch.setattr(backup.config, "XUI_DB_ENV_FILE", str(tmp_path / "missing-x-ui.env"), raising=False)
    monkeypatch.setattr(backup.config, "XUI_DB_PATH", str(source), raising=False)
    monkeypatch.setattr(backup.config, "XUI_POSTGRES_DSN", "", raising=False)
    destination = tmp_path / "xui.db"
    backup.xui_postgres_snapshot(destination, timeout_seconds=30)
    check = sqlite3.connect(destination)
    try:
        assert check.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert check.execute("SELECT name FROM clients").fetchone()[0] == "sqlite-client"
    finally:
        check.close()


def test_backup_records_creation_failure_without_archive(tmp_path, monkeypatch):
    import sys
    import types
    monkeypatch.setitem(sys.modules, "config", types.SimpleNamespace())
    import backup

    monkeypatch.setattr(backup, "STATE_PATH", tmp_path / "state.json")
    monkeypatch.setattr(backup.config, "DB_PATH", str(tmp_path / "unused.db"), raising=False)
    backup._record_run(None, (False, "не отправлено"), (False, "не загружено"), "3x-ui база не найдена")
    # The function must not raise when the archive itself was never created.
    # A production DB is intentionally not required for this contract test.


def test_xui_postgres_mode_without_dsn_does_not_fallback_to_sqlite(tmp_path, monkeypatch):
    import sqlite3
    import sys
    import types
    monkeypatch.setitem(sys.modules, "config", types.SimpleNamespace())
    import backup

    source = tmp_path / "x-ui.db"
    conn = sqlite3.connect(source)
    conn.execute("CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT)")
    conn.commit(); conn.close()
    env = tmp_path / "x-ui.env"
    env.write_text("XUI_DB_TYPE=postgres\n", encoding="utf-8")
    monkeypatch.setattr(backup.config, "XUI_DB_ENV_FILE", str(env), raising=False)
    monkeypatch.setattr(backup.config, "XUI_DB_PATH", str(source), raising=False)
    monkeypatch.setattr(backup.config, "XUI_POSTGRES_DSN", "", raising=False)
    import pytest
    with pytest.raises(RuntimeError, match="XUI_DB_DSN"):
        backup.xui_postgres_snapshot(tmp_path / "xui.sql", timeout_seconds=30)


def test_backup_live_state_contract():
    text = (ROOT / "backup.py").read_text(encoding="utf-8")
    web = (ROOT / "webapp.py").read_text(encoding="utf-8")
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert 'BACKUP_LIVE_STATE_PATH' in text
    assert 'def _live_event' in text
    assert 'def read_live_state' in text
    assert '"phase": "start"' in text
    assert '"telegram"' in text and '"yandex"' in text
    assert '@app.get("/api/backup/live"' in web
    assert 'service == "backup-live"' in web
    assert 'value="backup-live"' in web
    assert "setTimeout(load,document.hidden?10000:(liveErrors>=3?5000:1000))" in web
    assert "json.dumps(public_path(\"/api/backup/live\"))" in web
    assert "Live-журнал недоступен" in web
    assert 'BACKUP_LIVE_STATE_PATH' in installer


def test_yandex_settings_use_dedicated_json_actions():
    text = (ROOT / "webapp.py").read_text(encoding="utf-8")
    assert '@app.post("/api/settings/yandex/test"' in text
    assert '@app.post("/api/settings/yandex/test-upload"' in text
    assert 'id="yandex-test-connection" type="button"' in text
    assert 'id="yandex-test-upload" type="button"' in text
    assert "X-CSRF-Token" in text
    assert "asyncio.to_thread(test_yandex_connection" in text
    assert "asyncio.to_thread(test_yandex_write" in text
