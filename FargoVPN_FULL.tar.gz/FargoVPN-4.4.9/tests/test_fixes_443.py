from __future__ import annotations

import importlib.util
import sqlite3
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_backup_module(monkeypatch):
    config = types.ModuleType("config")
    config.BACKUP_TELEGRAM = True
    config.ADMIN_IDS = [1]
    config.BOT_TOKEN = "token"
    config.SERVICE_NAME = "FargoVPN"
    config.DB_PATH = "unused"
    config.YANDEX_WEBDAV_ENABLED = True
    config.YANDEX_WEBDAV_URL = "https://webdav.yandex.ru:443"
    config.YANDEX_DAVFS_MOUNT_POINT = "/media/YandexDisk"
    config.YANDEX_DAVFS_SECRETS_FILE = "/etc/davfs2/secrets"
    config.YANDEX_DAVFS_FSTAB_FILE = "/etc/fstab"
    config.YANDEX_WEBDAV_USERNAME = "user"
    config.YANDEX_WEBDAV_APP_PASSWORD = "pass"
    config.YANDEX_WEBDAV_PATH = "VPN-Service-Backups"
    config.YANDEX_UPLOAD_RETRIES = 3
    config.YANDEX_UPLOAD_VERIFY_ATTEMPTS = 8
    config.YANDEX_UPLOAD_VERIFY_DELAY = 1.0
    config.YANDEX_UPLOAD_TIMEOUT_SECONDS = 900
    db = types.ModuleType("db")
    yandex = types.ModuleType("yandex_webdav")
    yandex.DEFAULT_URL = "https://webdav.yandex.ru:443"
    yandex.DEFAULT_MOUNT_POINT = "/media/YandexDisk"
    yandex.DEFAULT_SECRETS_FILE = "/etc/davfs2/secrets"
    yandex.DEFAULT_FSTAB = "/etc/fstab"
    monkeypatch.setitem(sys.modules, "config", config)
    monkeypatch.setitem(sys.modules, "db", db)
    monkeypatch.setitem(sys.modules, "yandex_webdav", yandex)
    spec = importlib.util.spec_from_file_location("backup_443_under_test", ROOT / "backup.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module, config


def extract_conversation_query() -> str:
    text = (ROOT / "user_events.py").read_text(encoding="utf-8")
    start = text.index("def conversation_users(")
    end = text.index("\n\ndef ", start + 1)
    block = text[start:end]
    marker = '"""SELECT events.tg_id,\n'
    query_start = block.index(marker) + 3
    query_end = block.index('"""', query_start)
    return block[query_start:query_end]


def test_conversation_users_groups_by_tg_id_and_keeps_latest_identity():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE users(tg_id INTEGER PRIMARY KEY, username TEXT);
        CREATE TABLE user_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tg_id INTEGER NOT NULL,
            username TEXT,
            direction TEXT,
            created_at TEXT
        );
        INSERT INTO users VALUES (100, 'canonical');
        INSERT INTO user_events(tg_id,username,direction,created_at) VALUES
            (100,'old_name','in','2026-09-20T10:00:00'),
            (100,'new_name','out','2026-09-20T10:01:00'),
            (100,'new_name','in','2026-09-20T10:02:00'),
            (200,'first','in','2026-09-20T09:00:00'),
            (200,'second','in','2026-09-20T09:01:00');
        """
    )
    rows = conn.execute(extract_conversation_query(), (100,)).fetchall()
    assert [row["tg_id"] for row in rows] == [200, 100]
    assert rows[0]["username"] == "second"
    assert rows[0]["total_events"] == 2
    assert rows[1]["username"] == "canonical"
    assert rows[1]["total_events"] == 3


def test_yandex_failure_isolated_from_telegram(monkeypatch, tmp_path):
    backup, _config = load_backup_module(monkeypatch)
    archive = tmp_path / "backup.tar.gz"
    archive.write_bytes(b"archive")
    monkeypatch.setattr(backup, "_destination_enabled", lambda name: name in {"telegram", "yandex"})
    monkeypatch.setattr(backup, "_live_event", lambda *args, **kwargs: None)
    monkeypatch.setattr(backup, "send_to_telegram_sync", lambda path: (True, "sent"))

    def fail_yandex(path):
        raise RuntimeError("WebDAV 401")

    monkeypatch.setattr(backup, "upload_to_yandex", fail_yandex)
    result = backup._deliver_archive(archive)
    assert result["telegram"] == (True, "sent")
    assert result["yandex"] == (False, "WebDAV 401")


def test_delivery_uses_original_tar_gz_for_both_remote_destinations(monkeypatch, tmp_path):
    backup, _config = load_backup_module(monkeypatch)
    archive = tmp_path / "backup.tar.gz"
    archive.write_bytes(b"archive")
    monkeypatch.setattr(backup, "_live_event", lambda *args, **kwargs: None)
    seen = {}
    def fake_telegram(path):
        seen["telegram"] = path
        return True, "sent"
    def fake_yandex(path):
        seen["yandex"] = path
        return True, "uploaded"
    monkeypatch.setattr(backup, "send_to_telegram_sync", fake_telegram)
    monkeypatch.setattr(backup, "upload_to_yandex", fake_yandex)
    monkeypatch.setattr(backup, "_destination_enabled", lambda name: name in {"telegram", "yandex"})
    result = backup._deliver_archive(archive)
    assert result["telegram"] == (True, "sent")
    assert result["yandex"] == (True, "uploaded")
    assert seen["telegram"] == archive
    assert seen["yandex"] == archive


def test_cleanup_removes_legacy_age_archives(tmp_path, monkeypatch):
    backup, config = load_backup_module(monkeypatch)
    root = tmp_path / "backups"
    root.mkdir()
    current = root / "vpn_service_full_backup_new.tar.gz"
    legacy = root / "vpn_service_full_backup_old.tar.gz.age"
    current.write_bytes(b"current")
    legacy.write_bytes(b"legacy")
    old_time = __import__("time").time() - 20 * 86400
    import os
    os.utime(current, (old_time, old_time))
    os.utime(legacy, (old_time, old_time))
    config.BACKUP_DIR = str(root)
    config.BACKUP_KEEP_DAYS = 14
    backup.cleanup_old_backups()
    assert not current.exists()
    assert not legacy.exists()

