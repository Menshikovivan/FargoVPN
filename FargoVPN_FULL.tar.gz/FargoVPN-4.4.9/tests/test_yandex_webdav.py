from pathlib import Path

import yandex_webdav


def test_mount_detection_reads_mountinfo_without_touching_mount(monkeypatch):
    mountinfo = (
        "59 30 0:47 / /media/YandexDisk rw,nosuid,nodev shared:295 "
        "- fuse https://webdav.yandex.ru:443 rw,user_id=0\n"
    )
    monkeypatch.setattr(Path, "read_text", lambda self, **kwargs: mountinfo)
    ok, detail = yandex_webdav.mounted_filesystem("/media/YandexDisk")
    assert ok is True
    assert "fuse" in detail
    assert "webdav.yandex.ru" in detail


def test_missing_mount_is_connected_on_demand(monkeypatch, tmp_path):
    source = Path(yandex_webdav.__file__).read_text(encoding="utf-8")
    states = iter([(False, "missing"), (True, "mounted")])
    monkeypatch.setattr(yandex_webdav, "mounted_filesystem", lambda _path: next(states))
    calls = []
    monkeypatch.setattr(
        yandex_webdav, "_run_command",
        lambda args, timeout: (calls.append((args, timeout)) or (0, "", False)),
    )
    ok, detail, owned = yandex_webdav.mount_filesystem(mount_point=str(tmp_path / "disk"))
    assert ok is True and owned is True
    assert "mounted" in detail
    assert calls[0][0][:3] == ["mount", "-t", "davfs"]
    assert "configure_credentials" not in source
    assert "configure_fstab" not in source
    assert "ensure_mounted" not in source


def test_upload_uses_mounted_filesystem_worker(tmp_path, monkeypatch):
    archive = tmp_path / "backup.tar.gz"
    archive.write_bytes(b"FargoVPN" * 1024)
    mount = tmp_path / "media"
    calls = []

    monkeypatch.setattr(
        yandex_webdav,
        "mounted_filesystem",
        lambda mount_point: (True, f"mounted {mount_point}"),
    )

    def fake_operation(operation, *, source, target, payload=b"", timeout_seconds=60):
        calls.append((operation, source, target, timeout_seconds))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())
        return True, "accepted"

    monkeypatch.setattr(yandex_webdav, "_run_filesystem_operation", fake_operation)
    ok, detail = yandex_webdav.upload_file(
        archive,
        directory="Backups",
        mount_point=str(mount),
        retries=1,
        timeout_seconds=17,
    )
    assert ok is True
    assert calls == [("copy", archive, mount / "Backups" / archive.name, 17)]
    assert "davfs2" in detail


def test_filesystem_timeout_is_reported_without_retry_storm(tmp_path, monkeypatch):
    archive = tmp_path / "backup.tar.gz"
    archive.write_bytes(b"archive")
    monkeypatch.setattr(yandex_webdav, "mounted_filesystem", lambda _path: (True, "mounted"))
    calls = []

    def timeout_operation(*args, **kwargs):
        calls.append(1)
        return False, "operation timeout"

    monkeypatch.setattr(yandex_webdav, "_run_filesystem_operation", timeout_operation)
    ok, detail = yandex_webdav.upload_file(
        archive, mount_point=str(tmp_path / "mount"), retries=3, timeout_seconds=1
    )
    assert ok is False
    assert "timeout" in detail
    assert len(calls) == 1


def test_test_write_leaves_visible_file_for_manual_verification(tmp_path, monkeypatch):
    mount = tmp_path / "YandexDisk"
    monkeypatch.setattr(yandex_webdav, "mounted_filesystem", lambda _path: (True, "mounted"))

    def direct_operation(operation, *, source, target, payload=b"", timeout_seconds=60):
        assert operation == "write"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
        return True, f"visible: {target}"

    monkeypatch.setattr(yandex_webdav, "_run_filesystem_operation", direct_operation)
    ok, detail = yandex_webdav.test_write(directory="Checks", mount_point=str(mount))
    assert ok is True
    assert "visible:" in detail
    assert list((mount / "Checks").glob("fargovpn-davfs-test-*.txt"))


def test_owned_upload_is_unmounted_after_copy(tmp_path, monkeypatch):
    archive = tmp_path / "backup.tar.gz"
    archive.write_bytes(b"archive")
    mount = tmp_path / "YandexDisk"
    events = []
    monkeypatch.setattr(
        yandex_webdav, "mount_filesystem",
        lambda **kwargs: (events.append("mount") or (True, "mounted", True)),
    )
    monkeypatch.setattr(
        yandex_webdav, "unmount_filesystem",
        lambda *args, **kwargs: (events.append("unmount") or (True, "synced")),
    )
    monkeypatch.setattr(
        yandex_webdav, "_run_filesystem_operation",
        lambda *args, **kwargs: (events.append("copy") or (True, "copied")),
    )
    ok, detail = yandex_webdav.upload_file(archive, mount_point=str(mount))
    assert ok is True
    assert events == ["mount", "copy", "unmount"]
    assert "synced" in detail


def test_failed_normal_unmount_is_lazily_detached_and_reported(monkeypatch):
    states = iter([(True, "mounted"), (True, "mounted"), (False, "missing")])
    monkeypatch.setattr(yandex_webdav, "mounted_filesystem", lambda _path: next(states))
    commands = []

    def fake_command(args, timeout):
        commands.append(args)
        return (124, "", True) if len(commands) == 1 else (0, "", False)

    monkeypatch.setattr(yandex_webdav, "_run_command", fake_command)
    ok, detail = yandex_webdav.unmount_filesystem("/media/YandexDisk", timeout_seconds=1)
    assert ok is False
    assert commands == [["umount", "/media/YandexDisk"], ["umount", "-l", "/media/YandexDisk"]]
    assert "локальный архив сохранён" in detail
