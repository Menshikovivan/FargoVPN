from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def text(name: str) -> str:
    return (ROOT / name).read_text(encoding="utf-8")


def test_referral_confirmation_contains_owner_fallback_and_menu():
    source = text("main.py")
    start = source.index("async def process_referral_code")
    end = source.index("@dp.callback_query", start)
    block = source[start:end]
    assert "Авторизация подтверждена! Добро пожаловать в FargoVPN." in block
    assert "owner_username" in block
    assert "owner_name" in block
    assert 'owner.get("display_name")' in block
    assert "ID {int(owner.get('tg_id') or 0)}" in block
    assert "reply_markup = await get_user_menu_async" in block
    assert "reply_markup=reply_markup" in block
    registration = source[source.index("def register_referral_user"):source.index("def invitation_text")]
    assert "WHERE COALESCE(users.referred_by_tg_id,0)=0" in registration
    assert "RETURNING tg_id" in registration


def test_display_name_is_added_by_backward_compatible_migration():
    migration = text("init_db.py")
    assert "username TEXT, display_name TEXT" in migration
    assert '"display_name":"TEXT"' in migration


def test_telegram_journal_is_not_in_handler_critical_path_and_slow_logs_exist():
    source = text("main.py")
    start = source.index("class EventJournalMiddleware")
    end = source.index("# Dispatcher must exist", start)
    block = source[start:end]
    assert "_schedule_event_record(" in block
    assert "await asyncio.to_thread(\n                user_events.safe_record_event" not in block
    assert "operation=telegram_handler" in block
    assert "outcome=%s" in block
    database = text("db.py")
    assert "operation=%s duration_ms=%d" in database
    assert '"db_query"' in database
    assert '"db_connect"' in database


def test_payment_attention_badge_and_mobile_card_contract():
    web = text("webapp.py")
    script = text("static/panel.js")
    css = text("static/panel.css")
    assert '@app.get("/api/panel/payments/attention")' in web
    assert "status IN ('pending','processing')" in web
    assert "data-payment-attention" in web
    assert 'data-label="Действия"' in web
    assert "initPaymentAttention" in script
    assert "/api/panel/payments/attention" in script
    assert ".payments-table tr.payment-row" in css
    assert "content:attr(data-label)" in css


def test_every_new_xui_client_has_empty_flow_but_updates_preserve_existing_flow():
    subscriptions = text("services/subscriptions.py")
    xui = text("services/xui_api.py")
    assert '"flow": "xtls-rprx-vision"' not in subscriptions
    assert subscriptions.count('"flow": ""') >= 2
    assert 'new_client["flow"] = ""' in xui
    assert '"flow": str(base.get("flow") or "") if existing_client else ""' in xui
    update_start = xui.index("def update_client_sync")
    update_end = xui.index("def extend_client_sync", update_start)
    assert 'client.update(changes)' in xui[update_start:update_end]


def test_backup_uses_short_lived_davfs_and_bounded_worker():
    transport = text("yandex_webdav.py")
    assert '/proc/self/mountinfo' in transport
    assert "pid = os.fork()" in transport
    assert "select.select([read_fd], [], [], timeout)" in transport
    assert "os.kill(pid, signal.SIGKILL)" in transport
    assert "configure_credentials" not in transport
    assert "configure_fstab" not in transport
    assert "ensure_mounted" not in transport
    assert "def mount_filesystem(" in transport
    assert "def unmount_filesystem(" in transport
    assert '["umount", "-l", target]' in transport
