#!/usr/bin/env python3
"""Yandex.Disk transport through a short-lived davfs2 mount.

Credentials remain in ``/etc/davfs2/secrets``.  FargoVPN mounts WebDAV only for
the operation that needs it and always attempts a bounded, synchronous unmount.
This keeps davfs2 out of the normal boot/shutdown lifecycle.
"""
from __future__ import annotations

import logging
import json
import fcntl
import functools
import os
import select
import signal
import shutil
import subprocess
import time
from pathlib import Path

logger = logging.getLogger("vpn-service-backup.yandex")
DEFAULT_URL = "https://webdav.yandex.ru:443"
DEFAULT_MOUNT_POINT = "/media/YandexDisk"
DEFAULT_MOUNT_TIMEOUT = 30.0
DEFAULT_UNMOUNT_TIMEOUT = 120.0
DAVFS_LOCK_PATH = "/run/vpn-service-yandex-davfs.lock"


def serialized_davfs_operation(function):
    """Prevent backup and web-panel tests from sharing one temporary mount."""
    @functools.wraps(function)
    def wrapped(*args, **kwargs):
        lock_path = Path(DAVFS_LOCK_PATH)
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        with lock_path.open("a+", encoding="utf-8") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            return function(*args, **kwargs)
    return wrapped


def clean_remote_path(path: str) -> str:
    parts = [part for part in str(path or "").replace("\\", "/").split("/") if part]
    if any(part in {".", ".."} for part in parts):
        raise ValueError("Путь Яндекс.Диска не должен содержать . или ..")
    return "/".join(parts)


def _decode_mount_path(value: str) -> str:
    return (
        str(value)
        .replace("\\040", " ")
        .replace("\\011", "\t")
        .replace("\\012", "\n")
        .replace("\\134", "\\")
    )


def mounted_filesystem(mount_point: str = DEFAULT_MOUNT_POINT) -> tuple[bool, str]:
    """Inspect mountinfo without stat'ing a potentially stale FUSE endpoint."""
    wanted = os.path.abspath(str(mount_point or DEFAULT_MOUNT_POINT))
    try:
        lines = Path("/proc/self/mountinfo").read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        return False, f"Не удалось прочитать /proc/self/mountinfo: {exc}"
    for line in lines:
        left, separator, right = line.partition(" - ")
        fields = left.split()
        if not separator or len(fields) < 6 or _decode_mount_path(fields[4]) != wanted:
            continue
        right_fields = right.split()
        fs_type = right_fields[0] if right_fields else "unknown"
        source = _decode_mount_path(right_fields[1]) if len(right_fields) > 1 else "unknown"
        return True, f"{wanted} смонтирован ({fs_type}, {source})"
    return False, f"Яндекс.Диск не смонтирован в {wanted}"


def _run_command(args: list[str], timeout_seconds: float) -> tuple[int, str, bool]:
    """Run a mount helper without allowing it to hold the backup worker forever."""
    process = subprocess.Popen(
        args,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True,
    )
    try:
        output, _ = process.communicate(timeout=max(1.0, float(timeout_seconds)))
        return int(process.returncode or 0), (output or "").strip(), False
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=2)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        try:
            output, _ = process.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            output = ""
        return 124, (output or "").strip(), True


def mount_filesystem(
    *,
    base_url: str = DEFAULT_URL,
    mount_point: str = DEFAULT_MOUNT_POINT,
    timeout_seconds: float = DEFAULT_MOUNT_TIMEOUT,
) -> tuple[bool, str, bool]:
    """Mount davfs2 on demand.  The last value says whether we own the mount."""
    mounted, detail = mounted_filesystem(mount_point)
    if mounted:
        return True, detail, False
    target = Path(os.path.abspath(str(mount_point or DEFAULT_MOUNT_POINT)))
    if not target.is_absolute():
        return False, "Точка монтирования davfs2 должна быть абсолютным путём", False
    target.mkdir(parents=True, exist_ok=True)
    source = str(base_url or DEFAULT_URL).strip()
    if not source.startswith("https://"):
        return False, "Для Яндекс.Диска разрешён только HTTPS WebDAV URL", False
    command = [
        "mount", "-t", "davfs", source, str(target),
        "-o", "rw,_netdev,nosuid,nodev,noexec",
    ]
    code, output, timed_out = _run_command(command, timeout_seconds)
    mounted, mounted_detail = mounted_filesystem(str(target))
    if code == 0 and mounted:
        return True, mounted_detail, True
    if mounted:
        # The helper may have completed just as our timeout expired.  Treat the
        # mount as ours so the caller will still remove it in finally.
        return True, mounted_detail, True
    reason = output or ("превышен timeout" if timed_out else f"код {code}")
    return False, f"Не удалось подключить Яндекс.Диск через davfs2: {reason}", False


def unmount_filesystem(
    mount_point: str = DEFAULT_MOUNT_POINT,
    *,
    timeout_seconds: float = DEFAULT_UNMOUNT_TIMEOUT,
) -> tuple[bool, str]:
    """Synchronize davfs2 and unmount, lazily detaching only after a failure."""
    mounted, _ = mounted_filesystem(mount_point)
    if not mounted:
        return True, "davfs2 уже отключён"
    target = os.path.abspath(str(mount_point or DEFAULT_MOUNT_POINT))
    code, output, timed_out = _run_command(["umount", target], timeout_seconds)
    still_mounted, _ = mounted_filesystem(target)
    if code == 0 and not still_mounted:
        return True, "Кэш davfs2 синхронизирован, Яндекс.Диск отключён"

    # A failed umount must not leave a FUSE mount in shutdown.target.  Lazy
    # detach is an emergency cleanup only; the upload remains failed and its
    # local archive stays in the retry queue.
    lazy_code, lazy_output, _ = _run_command(["umount", "-l", target], 10.0)
    still_mounted, _ = mounted_filesystem(target)
    reason = output or ("превышен timeout" if timed_out else f"код {code}")
    if lazy_code == 0 and not still_mounted:
        return False, (
            f"Штатное отключение davfs2 не завершилось ({reason}); mount аварийно отсоединён. "
            "Передача не подтверждена, локальный архив сохранён для повтора"
        )
    lazy_reason = lazy_output or f"код {lazy_code}"
    return False, (
        f"Не удалось отключить davfs2 ({reason}); аварийное отсоединение также не выполнено "
        f"({lazy_reason}). Требуется проверка администратора"
    )


def _target_path(mount_point: str, directory: str, filename: str | None = None) -> Path:
    mount = Path(os.path.abspath(str(mount_point or DEFAULT_MOUNT_POINT)))
    clean = clean_remote_path(directory)
    target = mount.joinpath(*clean.split("/")) if clean else mount
    if filename:
        target = target / Path(filename).name
    return target


def _filesystem_action(
    operation: str,
    source_name: str,
    target_name: str,
    payload: bytes,
) -> tuple[bool, str]:
    try:
        target = Path(target_name)
        if operation == "probe":
            target.mkdir(parents=True, exist_ok=True)
            target.stat()
            result = (True, f"Каталог доступен: {target}")
        elif operation == "copy":
            source = Path(source_name)
            target.parent.mkdir(parents=True, exist_ok=True)
            with source.open("rb") as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst, length=1024 * 1024)
                dst.flush()
                os.fsync(dst.fileno())
            actual = target.stat().st_size
            expected = source.stat().st_size
            if actual != expected:
                raise RuntimeError(f"Размер копии {actual} байт вместо {expected}")
            result = (True, f"Принято смонтированной файловой системой: {target} ({actual} байт)")
        elif operation == "write":
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            actual = target.stat().st_size
            if actual != len(payload):
                raise RuntimeError(f"Размер тестового файла {actual} байт вместо {len(payload)}")
            result = (True, f"Тестовый файл оставлен для проверки на Диске: {target} ({actual} байт)")
        elif operation == "matches":
            source = Path(source_name)
            expected = source.stat().st_size
            actual = target.stat().st_size if target.is_file() else -1
            result = (
                actual == expected,
                f"Размер {actual} байт" if actual >= 0 else f"Файл не найден: {target}",
            )
        else:
            raise ValueError(f"Неизвестная файловая операция: {operation}")
        return result
    except BaseException as exc:
        return False, str(exc)


def _run_filesystem_operation(
    operation: str,
    *,
    source: Path | None,
    target: Path,
    payload: bytes = b"",
    timeout_seconds: float = 60.0,
) -> tuple[bool, str]:
    timeout = max(1.0, float(timeout_seconds))
    read_fd, write_fd = os.pipe()
    pid = os.fork()
    if pid == 0:
        # Use os._exit so the isolated FUSE worker never runs application
        # cleanup/finalizers inherited from the bot or web process.
        try:
            os.close(read_fd)
            result = _filesystem_action(
                operation, str(source or ""), str(target), payload
            )
            encoded = json.dumps(result, ensure_ascii=False).encode("utf-8")
            os.write(write_fd, encoded)
        except BaseException:
            pass
        finally:
            try:
                os.close(write_fd)
            except OSError:
                pass
            os._exit(0)
    os.close(write_fd)
    ready, _, _ = select.select([read_fd], [], [], timeout)
    if not ready:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        os.close(read_fd)
        # Do not wait here: waitpid can itself block while a FUSE operation is
        # stuck in uninterruptible kernel sleep. The short-lived backup worker
        # may exit immediately and init will reap the orphaned child.
        return False, (
            f"Операция с {target} превысила timeout {timeout:g} сек. "
            "Возможен зависший davfs2 mount; Telegram-доставка продолжает работать независимо."
        )
    try:
        chunks: list[bytes] = []
        while True:
            chunk = os.read(read_fd, 65536)
            if not chunk:
                break
            chunks.append(chunk)
        try:
            os.waitpid(pid, 0)
        except ChildProcessError:
            pass
        if not chunks:
            return False, "Файловый worker завершился без результата"
        ok, detail = json.loads(b"".join(chunks).decode("utf-8"))
        return bool(ok), str(detail)
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        return False, f"Не удалось получить результат файлового worker: {exc}"
    finally:
        try:
            os.close(read_fd)
        except OSError:
            pass


@serialized_davfs_operation
def upload_file(
    path: Path,
    *,
    username: str = "",
    password: str = "",
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = "",
    fstab_file: str = "",
    retries: int = 1,
    verify_attempts: int = 1,
    verify_delay: float = 0.0,
    timeout_seconds: float = 900.0,
) -> tuple[bool, str]:
    del username, password, secrets_file, fstab_file, verify_attempts, verify_delay
    source = Path(path)
    if not source.is_file():
        return False, f"Архив не найден: {source}"
    if source.stat().st_size <= 0:
        return False, "Архив пуст"
    mounted, mount_detail, owns_mount = mount_filesystem(
        base_url=base_url,
        mount_point=mount_point,
        timeout_seconds=min(60.0, max(5.0, float(timeout_seconds))),
    )
    if not mounted:
        return False, mount_detail
    destination = _target_path(mount_point, directory, source.name)
    attempts = max(1, int(retries))
    last_detail = "неизвестная ошибка"
    copy_ok = False
    try:
        for attempt in range(1, attempts + 1):
            copy_ok, detail = _run_filesystem_operation(
                "copy", source=source, target=destination, timeout_seconds=timeout_seconds
            )
            if copy_ok:
                last_detail = detail
                logger.info(
                    "davfs2 copy accepted file=%s size=%d target=%s attempt=%d/%d",
                    source.name, source.stat().st_size, destination, attempt, attempts,
                )
                break
            last_detail = detail
            logger.warning(
                "davfs2 copy failed file=%s attempt=%d/%d: %s",
                source.name, attempt, attempts, detail,
            )
            if "timeout" in detail.lower():
                break
            if attempt < attempts:
                time.sleep(1.0)
    finally:
        if owns_mount:
            unmount_ok, unmount_detail = unmount_filesystem(mount_point)
        else:
            unmount_ok, unmount_detail = True, "Использовано уже активное монтирование; оно оставлено владельцу"
    if not copy_ok:
        suffix = f"; {unmount_detail}" if owns_mount else ""
        return False, f"Копирование через davfs2 не выполнено: {last_detail}{suffix}"
    if not unmount_ok:
        return False, f"Файл записан в кэш davfs2, но передача не подтверждена: {unmount_detail}"
    return True, f"davfs2: {last_detail}. {unmount_detail}"


@serialized_davfs_operation
def test_connection(
    username: str = "",
    password: str = "",
    *,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = "",
    fstab_file: str = "",
    timeout_seconds: float = 30.0,
) -> tuple[bool, str]:
    del username, password, secrets_file, fstab_file
    mounted, detail, owns_mount = mount_filesystem(
        base_url=base_url, mount_point=mount_point,
        timeout_seconds=min(60.0, max(5.0, float(timeout_seconds))),
    )
    if not mounted:
        return False, detail
    try:
        target = _target_path(mount_point, directory)
        ok, probe_detail = _run_filesystem_operation(
            "probe", source=None, target=target, timeout_seconds=timeout_seconds
        )
    finally:
        unmount_ok, unmount_detail = (
            unmount_filesystem(mount_point) if owns_mount
            else (True, "Использовано уже активное монтирование")
        )
    return ok and unmount_ok, f"{detail}; {probe_detail}; {unmount_detail}"


@serialized_davfs_operation
def test_write(
    username: str = "",
    password: str = "",
    *,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = "",
    fstab_file: str = "",
    timeout_seconds: float = 60.0,
) -> tuple[bool, str]:
    del username, password, secrets_file, fstab_file
    mounted, detail, owns_mount = mount_filesystem(
        base_url=base_url, mount_point=mount_point,
        timeout_seconds=min(60.0, max(5.0, float(timeout_seconds))),
    )
    if not mounted:
        return False, detail
    name = f"fargovpn-davfs-test-{time.time_ns()}.txt"
    target = _target_path(mount_point, directory, name)
    payload = f"FargoVPN davfs2 test {time.time_ns()}\n".encode("utf-8")
    try:
        ok, write_detail = _run_filesystem_operation(
            "write", source=None, target=target, payload=payload, timeout_seconds=timeout_seconds
        )
    finally:
        unmount_ok, unmount_detail = (
            unmount_filesystem(mount_point) if owns_mount
            else (True, "Использовано уже активное монтирование")
        )
    return ok and unmount_ok, f"{write_detail}; {unmount_detail}"


@serialized_davfs_operation
def remote_file_matches(
    path: Path,
    *,
    username: str = "",
    password: str = "",
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = "",
    fstab_file: str = "",
    timeout_seconds: float = 30.0,
) -> tuple[bool, str]:
    del username, password, secrets_file, fstab_file
    source = Path(path)
    if not source.is_file():
        return False, f"Локальная копия не найдена: {source}"
    mounted, detail, owns_mount = mount_filesystem(
        base_url=base_url, mount_point=mount_point,
        timeout_seconds=min(60.0, max(5.0, float(timeout_seconds))),
    )
    if not mounted:
        return False, detail
    try:
        target = _target_path(mount_point, directory, source.name)
        ok, match_detail = _run_filesystem_operation(
            "matches", source=source, target=target, timeout_seconds=timeout_seconds
        )
    finally:
        unmount_ok, unmount_detail = (
            unmount_filesystem(mount_point) if owns_mount
            else (True, "Использовано уже активное монтирование")
        )
    return ok and unmount_ok, f"{match_detail}; {unmount_detail}"
