#!/usr/bin/env bash
set -u
echo "=== FargoVPN backend diagnostics ==="
run(){ echo; echo "> $*"; "$@" 2>&1 || true; }
run systemctl status vpn-service-web.socket --no-pager -n 80
run systemctl status vpn-service-web.service --no-pager -n 80
run systemctl status vpn-service-bot.service --no-pager -n 80
run systemctl status vpn-service-backup.service --no-pager -n 80
run ss -xlpn
run ss -ltnp
if [[ -S /run/vpn-service/fargovpn.sock ]]; then
  run curl --unix-socket /run/vpn-service/fargovpn.sock -fsS http://localhost/healthz
  run curl --unix-socket /run/vpn-service/fargovpn.sock -fsS http://localhost/health
fi
run journalctl -u vpn-service-web.service --since '-45 min' --no-pager -n 500
run journalctl -u vpn-service-bot.service --since '-45 min' --no-pager -n 500
run journalctl -u vpn-service-backup.service --since '-45 min' --no-pager -n 300
