#!/usr/bin/env python3
"""Read-only FargoVPN network diagnostics; reverse proxy is external."""
from __future__ import annotations
import json, os, socket, subprocess
from pathlib import Path

def command(argv):
    try:
        r=subprocess.run(argv,text=True,capture_output=True,timeout=15,check=False)
        return {"argv":argv,"returncode":r.returncode,"output":(r.stdout or r.stderr or "").strip()[-8000:]}
    except Exception as exc:
        return {"argv":argv,"error":str(exc)}

def collect(host='127.0.0.1', port=0):
    result={"host":host,"port":port,"listeners":command(['ss','-ltnp']),"unix_listeners":command(['ss','-xlpn']),"systemd":{}}
    for unit in ('vpn-service-web.socket','vpn-service-web.service','vpn-service-bot.service','vpn-service-backup.service','x-ui.service'):
        result['systemd'][unit]=command(['systemctl','status',unit,'--no-pager','-n','40'])
    return result

def main():
    print(json.dumps(collect(),ensure_ascii=False,indent=2))

if __name__=='__main__': main()
