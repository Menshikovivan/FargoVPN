#!/usr/bin/env python3
"""Verified FargoVPN backup reassembly and restore manager.

The archive format is intentionally self-contained for FargoVPN + 3x-ui state.
The external reverse-proxy/L4 layer is managed outside this project and is
never restored here.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tarfile
import tempfile
import time
from pathlib import Path
from typing import Any


APP_DIR = Path(__file__).resolve().parent
SAFE_PART_RE = re.compile(r"^(?P<base>.+\.tar\.gz)\.part(?P<index>\d{1,4})$")
PROTECTED_CONFIG = {
    "DATABASE_URL", "DB_PATH", "BACKUP_DIR", "BACKUP_LOCK_PATH", "BACKUP_STATE_PATH",
    "BACKUP_LIVE_STATE_PATH", "BACKUP_FORCE_PATH", "XUI_DB_ENV_FILE", "XUI_DB_PATH",
    "WEB_SOCKET_PATH", "WEB_SOCKET_GROUP", "PUSH_VAPID_PRIVATE_KEY_PATH", "INSTALL_PROFILE",
    "UPDATE_DIR", "CHAT_MEDIA_CACHE_DIR", "BROADCAST_DIR", "SUBSCRIPTION_REFRESH_DIR",
}
PROTECTED_XUI_ENV = {
    "XUI_DB_DSN", "XUI_DB_TYPE", "XUI_DB_HOST", "XUI_DB_PORT", "XUI_DB_NAME", "XUI_DB_USER", "XUI_DB_PASSWORD",
}


def json_out(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def find_archive(source_dir: Path) -> Path:
    source = source_dir.expanduser().resolve()
    if not source.is_dir():
        raise RuntimeError(f"Каталог с бэкапом не найден: {source}")
    direct = sorted(p for p in source.glob("*.tar.gz") if p.is_file())
    groups: dict[str, list[tuple[int, Path]]] = {}
    for path in source.iterdir():
        if not path.is_file():
            continue
        match = SAFE_PART_RE.match(path.name)
        if match:
            groups.setdefault(match.group("base"), []).append((int(match.group("index")), path))
    candidates: list[tuple[str, Path | None, list[tuple[int, Path]]]] = []
    for path in direct:
        candidates.append((path.name, path, []))
    for base, items in groups.items():
        candidates.append((base, None, sorted(items)))
    if not candidates:
        raise RuntimeError("В каталоге не найден ни .tar.gz, ни комплект .tar.gz.part001/.part002")
    if len(candidates) > 1:
        names = ", ".join(name for name, _, _ in candidates)
        raise RuntimeError(f"Найдено несколько комплектов резервных копий: {names}. Оставьте один комплект в каталоге.")
    name, direct_path, parts = candidates[0]
    if direct_path:
        return direct_path
    indexes = [i for i, _ in parts]
    expected = list(range(1, len(parts) + 1))
    if indexes != expected:
        raise RuntimeError(f"Части {name} неполные или имеют пропуски: найдены {indexes}, ожидались {expected}")
    # The final joined archive is created by prepare_archive().
    return parts[0][1]


def reassemble_parts(source_dir: Path, output: Path) -> Path:
    source = source_dir.expanduser().resolve()
    direct = [p for p in source.glob("*.tar.gz") if p.is_file()]
    groups: dict[str, list[tuple[int, Path]]] = {}
    for path in source.iterdir():
        if not path.is_file():
            continue
        match = SAFE_PART_RE.match(path.name)
        if match:
            groups.setdefault(match.group("base"), []).append((int(match.group("index")), path))
    if direct and groups:
        raise RuntimeError("В каталоге одновременно лежат цельный архив и части другого архива; оставьте один комплект.")
    if len(direct) == 1:
        shutil.copy2(direct[0], output)
        return output
    if len(direct) > 1:
        raise RuntimeError("В каталоге найдено несколько цельных .tar.gz архивов.")
    if len(groups) != 1:
        raise RuntimeError("В каталоге не найден единственный комплект частей бэкапа.")
    base, parts = next(iter(groups.items()))
    parts = sorted(parts)
    indexes = [i for i, _ in parts]
    if indexes != list(range(1, len(parts) + 1)):
        raise RuntimeError(f"Комплект {base} неполный: найдены части {indexes}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as target:
        for _, part in parts:
            with part.open("rb") as source:
                shutil.copyfileobj(source, target, length=1024 * 1024)
    if output.stat().st_size <= 0:
        raise RuntimeError("Склеенный архив пуст")
    return output


def safe_extract(archive: Path, destination: Path) -> Path:
    destination = destination.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    with tarfile.open(archive, "r:gz") as bundle:
        members = bundle.getmembers()
        for member in members:
            name = member.name.replace("\\", "/")
            pure = Path(name)
            if not name or name.startswith("/") or ".." in pure.parts:
                raise RuntimeError(f"Небезопасный путь в архиве: {name!r}")
            if member.issym() or member.islnk() or member.isdev() or not (member.isfile() or member.isdir()):
                raise RuntimeError(f"Небезопасный тип файла в архиве: {name!r}")
            target = (destination / name).resolve()
            if target != root and root not in target.parents:
                raise RuntimeError(f"Архив выходит за каталог распаковки: {name!r}")
        bundle.extractall(destination, filter="data")
    result = destination / "vpn_service_backup"
    if not result.is_dir():
        raise RuntimeError("Каталог vpn_service_backup отсутствует в архиве")
    return result


def verify_archive(root: Path) -> dict[str, Any]:
    manifest_path = root / "manifest.json"
    if not manifest_path.is_file():
        raise RuntimeError("manifest.json отсутствует")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict):
        raise RuntimeError("manifest.json имеет неверный формат")
    if manifest.get("application_database") != "PostgreSQL":
        raise RuntimeError("Бэкап приложения не содержит PostgreSQL dump")
    app_dump = root / str(manifest.get("application_dump") or "databases/fargovpn.sql")
    if not app_dump.is_file():
        raise RuntimeError("Бэкап FargoVPN PostgreSQL не найден")
    xui_dump = root / str(manifest.get("xui_dump") or "")
    if not xui_dump.is_file():
        raise RuntimeError("Бэкап базы 3x-ui не найден")
    checksums_path = root / "checksums.json"
    if checksums_path.is_file():
        checksums = json.loads(checksums_path.read_text(encoding="utf-8"))
        if not isinstance(checksums, dict):
            raise RuntimeError("checksums.json имеет неверный формат")
        for rel, expected in checksums.items():
            file_path = root / rel
            if not file_path.is_file() or sha256(file_path) != str(expected):
                raise RuntimeError(f"Контрольная сумма не совпадает: {rel}")
    if xui_dump.suffix == ".db":
        conn = sqlite3.connect(f"file:{xui_dump}?mode=ro", uri=True)
        try:
            integrity = str(conn.execute("PRAGMA integrity_check").fetchone()[0]).strip().lower()
        finally:
            conn.close()
        if integrity != "ok":
            raise RuntimeError(f"SQLite 3x-ui integrity_check: {integrity}")
    return manifest


def prepare(source_dir: Path, work_dir: Path) -> dict[str, Any]:
    work_dir = work_dir.expanduser().resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    archive = work_dir / "backup.tar.gz"
    reassemble_parts(source_dir, archive)
    extract_root = safe_extract(archive, work_dir / "extracted")
    manifest = verify_archive(extract_root)
    return {"archive": str(archive), "root": str(extract_root), "manifest": manifest}


def dsn_password_and_cli(dsn: str) -> tuple[str, dict[str, str]]:
    from sqlalchemy.engine import make_url
    value = str(dsn or "").strip().replace("postgresql+psycopg://", "postgresql://", 1)
    parsed = make_url(value)
    env = os.environ.copy()
    if parsed.password is not None:
        env["PGPASSWORD"] = parsed.password
        value = parsed.set(password=None).render_as_string(hide_password=False)
    return value, env


def raw_dsn(dsn: str) -> str:
    return str(dsn or "").strip().replace("postgresql+psycopg://", "postgresql://", 1)


def _pg_identifier(value: str, label: str) -> str:
    value = str(value or "")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
        raise RuntimeError(f"Недопустимое имя PostgreSQL для {label}: {value!r}")
    return value


def pg_parts(dsn: str) -> tuple[str, str, str | None]:
    from sqlalchemy.engine import make_url
    parsed = make_url(raw_dsn(dsn))
    if not parsed.database:
        raise RuntimeError("DSN PostgreSQL не содержит имени базы")
    user = str(parsed.username or "")
    if not user:
        raise RuntimeError("DSN PostgreSQL не содержит пользователя")
    return _pg_identifier(str(parsed.database), "базы"), _pg_identifier(user, "пользователя"), parsed.host


def run_postgres_sql(sql_text: str, database: str = "postgres") -> None:
    if shutil.which("runuser") and shutil.which("psql"):
        completed = subprocess.run(["runuser", "-u", "postgres", "--", "psql", "-v", "ON_ERROR_STOP=1", "-d", database, "-c", sql_text], capture_output=True, text=True, timeout=120)
        if completed.returncode == 0:
            return
        detail = (completed.stderr or completed.stdout or "").strip()
        raise RuntimeError(f"PostgreSQL admin-команда завершилась ошибкой: {detail[-2500:]}")
    raise RuntimeError("Для безопасного переключения PostgreSQL нужен локальный runuser/psql (стандартная установка Ubuntu/PostgreSQL).")


def make_staging_db(target_dsn: str, suffix: str) -> tuple[str, str]:
    target_db, target_user, _host = pg_parts(target_dsn)
    staging = f"{target_db}_restore_{suffix}"[:60]
    staging = _pg_identifier(re.sub(r"[^A-Za-z0-9_]", "_", staging), "staging-базы")
    run_postgres_sql(f'CREATE DATABASE "{staging}" OWNER "{target_user}"')
    from sqlalchemy.engine import make_url
    return make_url(raw_dsn(target_dsn)).set(database=staging).render_as_string(hide_password=False), staging


def restore_dump(dump: Path, dsn: str) -> None:
    command_dsn, env = dsn_password_and_cli(dsn)
    subprocess.run(["psql", "--dbname", command_dsn, "--set", "ON_ERROR_STOP=1", "--file", str(dump)], check=True, env=env, timeout=1800, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def app_counts(dsn: str) -> dict[str, int]:
    import psycopg
    with psycopg.connect(raw_dsn(dsn)) as conn:
        result = {}
        for table in ("users", "payments", "user_events", "audit_log"):
            exists = conn.execute("SELECT to_regclass(%s)", (f"public.{table}",)).fetchone()[0]
            if exists:
                result[table] = int(conn.execute(f'SELECT count(*) FROM "{table}"').fetchone()[0])
        if "users" not in result:
            raise RuntimeError("После восстановления не найдена критическая таблица users")
        return result


def choose_backup_name(base: str) -> str:
    stamp = time.strftime("%Y%m%d_%H%M%S")
    candidate = f"{base}_pre_restore_{stamp}"
    return re.sub(r"[^A-Za-z0-9_]", "_", candidate)[:63]


def swap_pg_database(target_dsn: str, staging_name: str) -> tuple[str, str]:
    target_name, _user, _host = pg_parts(target_dsn)
    staging_name = _pg_identifier(staging_name, "staging-базы")
    rollback_name = _pg_identifier(choose_backup_name(target_name), "rollback-базы")
    # Keep the previous database so a failed post-restore health check can roll back.
    run_postgres_sql(f'SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname IN (\'{target_name}\',\'{staging_name}\') AND pid <> pg_backend_pid();')
    run_postgres_sql(f'ALTER DATABASE "{target_name}" RENAME TO "{rollback_name}"')
    try:
        run_postgres_sql(f'ALTER DATABASE "{staging_name}" RENAME TO "{target_name}"')
    except Exception:
        try:
            run_postgres_sql(f'ALTER DATABASE "{rollback_name}" RENAME TO "{target_name}"')
        finally:
            raise
    return target_name, rollback_name


def parse_literal_config(path: Path) -> dict[str, Any]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    result: dict[str, Any] = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            try:
                value = ast.literal_eval(node.value)
            except Exception:
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    result[target.id] = value
    return result


def merge_config(target: Path, source: Path) -> None:
    source_values = parse_literal_config(source)
    text = target.read_text(encoding="utf-8") if target.is_file() else "import aiohttp\n"
    for name, value in source_values.items():
        if name in PROTECTED_CONFIG or name.upper().startswith("NGINX_"):
            continue
        line = f"{name} = {value!r}"
        pattern = rf"(?m)^{re.escape(name)}\s*=.*$"
        text = re.sub(pattern, line, text) if re.search(pattern, text) else text.rstrip() + "\n" + line + "\n"
    compile(text, str(target), "exec")
    target.write_text(text.rstrip() + "\n", encoding="utf-8")
    os.chmod(target, 0o600)


def parse_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        value=value.strip()
        if len(value)>=2 and value[0]==value[-1] and value[0] in "'\"": value=value[1:-1]
        values[key.strip()] = value
    return values


def merge_xui_env(target: Path, source: Path) -> None:
    if not source.is_file():
        return
    source_values = parse_env(source)
    current = target.read_text(encoding="utf-8") if target.is_file() else ""
    for key,value in source_values.items():
        if key in PROTECTED_XUI_ENV:
            continue
        rendered = f'{key}={value!r}' if any(c in value for c in " #\t") else f"{key}={value}"
        pattern = rf"(?m)^(?:export\s+)?{re.escape(key)}\s*=.*$"
        current = re.sub(pattern, rendered, current) if re.search(pattern,current) else current.rstrip()+"\n"+rendered+"\n"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(current, encoding="utf-8")
    os.chmod(target,0o600)


def _service_exists(unit: str) -> bool:
    return subprocess.run(["systemctl", "cat", unit], capture_output=True, text=True, timeout=30).returncode == 0


def _external_units() -> list[str]:
    return [u for u in ("x-ui.service", "3x-ui.service", "xray.service") if _service_exists(u)]


def stop_services(include_xui: bool) -> None:
    units=["vpn-service-bot.service","vpn-service-web.service","vpn-service-web.socket"]
    if include_xui:
        units = _external_units() + units
    for unit in units:
        subprocess.run(["systemctl","stop",unit],check=False,capture_output=True,text=True,timeout=60)


def start_services(full: bool) -> None:
    subprocess.run(["systemctl","daemon-reload"],check=False,capture_output=True,text=True,timeout=60)
    if full:
        for unit in _external_units():
            subprocess.run(["systemctl","start",unit],check=False,capture_output=True,text=True,timeout=60)
    subprocess.run(["systemctl","start","vpn-service-bot.service"],check=False,capture_output=True,text=True,timeout=60)
    if full:
        subprocess.run(["systemctl","start","vpn-service-web.socket"],check=False,capture_output=True,text=True,timeout=60)
        subprocess.run(["systemctl","start","vpn-service-web.service"],check=False,capture_output=True,text=True,timeout=60)


def verify_live(full: bool, config_path: Path) -> None:
    values = parse_literal_config(config_path)
    if full:
        socket = str(values.get("WEB_SOCKET_PATH", "/run/vpn-service/fargovpn.sock"))
        if shutil.which("curl") and Path(socket).exists():
            completed = subprocess.run(["curl","--unix-socket",socket,"-fsS","--max-time","5","http://localhost/health"],capture_output=True,text=True,timeout=10)
            if completed.returncode != 0 or not completed.stdout.startswith("OK"):
                raise RuntimeError(f"Health-check веб-панели после восстановления не пройден: {(completed.stderr or completed.stdout).strip()}")
        check = subprocess.run(["systemctl","is-active","--quiet","vpn-service-web.service"],check=False)
        if check.returncode != 0:
            raise RuntimeError("vpn-service-web.service не active после восстановления")
        external = _external_units()
        panel_units = [u for u in ("x-ui.service", "3x-ui.service") if u in external]
        if panel_units and not any(subprocess.run(["systemctl","is-active","--quiet",u],check=False).returncode == 0 for u in panel_units):
            raise RuntimeError("Служба 3x-ui не active после восстановления")
    bot_token = str(values.get("BOT_TOKEN") or "").strip()
    if bot_token and subprocess.run(["systemctl","is-active","--quiet","vpn-service-bot.service"],check=False).returncode != 0:
        raise RuntimeError("vpn-service-bot.service не active после восстановления")


def restore_users_only(archive: Path, root: Path) -> dict[str, Any]:
    import config
    target_dsn = str(getattr(config,"DATABASE_URL","") or "").strip()
    if not target_dsn.startswith("postgresql"):
        raise RuntimeError("Текущая FargoVPN установка не использует PostgreSQL")
    expected=(verify_archive(root).get("application_row_counts") or {})
    profile = str(getattr(config, "INSTALL_PROFILE", "full") or "full").lower()
    staging_dsn, staging_name = make_staging_db(target_dsn, time.strftime("%Y%m%d_%H%M%S"))
    stopped = False
    try:
        stop_services(include_xui=False)
        stopped = True
        restore_dump(root/"databases"/"fargovpn.sql", staging_dsn)
        restored_counts=app_counts(staging_dsn)
        if expected.get("users") is not None and int(restored_counts.get("users",-1)) != int(expected["users"]):
            raise RuntimeError(f"Критическая проверка users не пройдена: в архиве {expected['users']}, восстановлено {restored_counts.get('users')}")
        target_name, rollback_name=swap_pg_database(target_dsn,staging_name)
        subprocess.run([sys.executable, str(APP_DIR/"init_db.py")], check=True, timeout=600, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        final_counts=app_counts(target_dsn)
        if expected.get("users") is not None and int(final_counts.get("users",-1)) != int(expected["users"]):
            raise RuntimeError(f"Контрольная проверка users после миграции не пройдена: ожидалось {expected['users']}, получено {final_counts.get('users')}")
        start_services(full=(profile == "full"))
        stopped = False
        verify_live(profile == "full", Path(config.__file__).resolve())
        return {"mode":"users-only","database":target_name,"rollback_database":rollback_name,"row_counts":final_counts,"status":"verified"}
    except Exception:
        try: run_postgres_sql(f'DROP DATABASE IF EXISTS "{_pg_identifier(staging_name, "staging-базы")}"')
        except Exception: pass
        raise
    finally:
        if stopped:
            try: start_services(full=(profile == "full"))
            except Exception: pass


def restore_full(archive: Path, root: Path) -> dict[str, Any]:
    import config
    app_dsn=str(getattr(config,"DATABASE_URL","") or "").strip()
    if not app_dsn.startswith("postgresql"):
        raise RuntimeError("DATABASE_URL FargoVPN не настроен на PostgreSQL")
    stop_services(include_xui=True)
    result:dict[str,Any]={"mode":"full"}
    suffix=time.strftime("%Y%m%d_%H%M%S")
    app_staging,app_stage_name=make_staging_db(app_dsn,suffix)
    try:
        restore_dump(root/"databases"/"fargovpn.sql",app_staging)
        result["application_row_counts"]=app_counts(app_staging)
        expected=(verify_archive(root).get("application_row_counts") or {})
        if expected.get("users") is not None and int(result["application_row_counts"].get("users",-1)) != int(expected["users"]):
            raise RuntimeError("Проверка количества пользователей после восстановления не прошла")
        _target,_rollback=swap_pg_database(app_dsn,app_stage_name)
        result["application_rollback_database"]=_rollback

        # Restore 3x-ui DB (PostgreSQL or SQLite according to archived artifact and current installation).
        xui_db_file=root/"databases"/"xui.db"
        xui_sql_file=root/"databases"/"xui.sql"
        env_path=Path(str(getattr(config,"XUI_DB_ENV_FILE","/etc/default/x-ui")))
        if xui_sql_file.is_file():
            from backup import xui_postgres_dsn_for_cli
            xui_dsn=xui_postgres_dsn_for_cli()
            xstage,xname=make_staging_db(xui_dsn,suffix)
            try:
                restore_dump(xui_sql_file,xstage)
                if shutil.which("psql"):
                    command_dsn, env = dsn_password_and_cli(xstage)
                    probe = subprocess.run(["psql", "--dbname", command_dsn, "--tuples-only", "--no-align", "--command", "SELECT count(*) FROM information_schema.tables WHERE table_schema='public'"], check=True, env=env, capture_output=True, text=True, timeout=120)
                    if int((probe.stdout or "0").strip() or "0") <= 0:
                        raise RuntimeError("В восстановленной базе 3x-ui PostgreSQL отсутствуют таблицы")
                result["xui_database"]="PostgreSQL"
                _xtarget,_xrollback=swap_pg_database(xui_dsn,xname)
                result["xui_rollback_database"]=_xrollback
            except Exception:
                try: run_postgres_sql(f'DROP DATABASE IF EXISTS "{xname}"')
                except Exception: pass
                raise
        elif xui_db_file.is_file():
            current_db=Path(str(getattr(config,"XUI_DB_PATH","/etc/x-ui/x-ui.db"))).expanduser()
            current_db.parent.mkdir(parents=True,exist_ok=True)
            with sqlite3.connect(f"file:{xui_db_file}?mode=ro",uri=True) as conn:
                integrity=str(conn.execute("PRAGMA integrity_check").fetchone()[0]).strip().lower()
            if integrity!="ok": raise RuntimeError(f"Архивная SQLite 3x-ui повреждена: {integrity}")
            rollback=current_db.with_name(current_db.name+f".pre_restore_{suffix}")
            if current_db.exists(): shutil.copy2(current_db,rollback)
            tmp=current_db.with_name(current_db.name+".restore_tmp")
            shutil.copy2(xui_db_file,tmp); os.chmod(tmp,current_db.stat().st_mode & 0o777 if current_db.exists() else 0o600); os.replace(tmp,current_db)
            result["xui_database"]="SQLite"; result["xui_rollback_file"]=str(rollback) if rollback.exists() else ""

        # Restore 3x-ui/xray configuration, preserving the current DB connection settings.
        for src_name,dst in (("etc-xui",Path("/etc/x-ui")),("etc-xray",Path("/etc/xray"))):
            src=root/"system"/src_name
            if src.is_dir():
                dst.mkdir(parents=True,exist_ok=True)
                shutil.copytree(src,dst,dirs_exist_ok=True)
        merge_xui_env(env_path,root/"configs"/"x-ui-default.env")

        config_source=root/"bot"/"config.py"
        target_config=Path(config.__file__).resolve()
        if config_source.is_file():
            merge_config(target_config,config_source)
        vapid=root/"runtime"/"vapid_private.pem"
        target_vapid=Path(str(getattr(config,"PUSH_VAPID_PRIVATE_KEY_PATH","/var/lib/vpn-service/vapid_private.pem"))).expanduser()
        if vapid.is_file():
            target_vapid.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(vapid,target_vapid); os.chmod(target_vapid,0o600)

        systemd=root/"systemd"
        if systemd.is_dir():
            for item in systemd.iterdir():
                if item.is_file() and (item.name.startswith("x-ui") or item.name.startswith("xray") or item.name.startswith("3x-ui")):
                    shutil.copy2(item,Path("/etc/systemd/system")/item.name)
        # A full restore keeps the current FargoVPN code/units and restores external VPN units only.
        compile(target_config.read_text(encoding="utf-8"),str(target_config),"exec")
        subprocess.run([sys.executable, str(APP_DIR/"init_db.py")], check=True, timeout=600, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        final_counts = app_counts(app_dsn)
        result["application_row_counts_after_migration"] = final_counts
        if expected.get("users") is not None and int(final_counts.get("users",-1)) != int(expected["users"]):
            raise RuntimeError(f"Контрольная проверка users после полного восстановления не пройдена: ожидалось {expected['users']}, получено {final_counts.get('users')}")
        start_services(full=True)
        verify_live(True,target_config)
        result["status"]="verified"
        return result
    except Exception:
        raise


def cli() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare-dir",type=Path,help="Каталог, где лежит цельный архив или его части")
    parser.add_argument("--work-dir",type=Path,help="Рабочий каталог для reassemble/extract")
    parser.add_argument("--users-only",type=Path,help="Уже склеенный .tar.gz")
    parser.add_argument("--full",type=Path,help="Уже склеенный .tar.gz")
    parser.add_argument("--json",action="store_true")
    args=parser.parse_args()
    if args.prepare_dir:
        if not args.work_dir: raise SystemExit("--prepare-dir требует --work-dir")
        report=prepare(args.prepare_dir,args.work_dir)
        json_out(report); return 0
    mode_path=args.users_only or args.full
    if not mode_path: raise SystemExit("Укажите --prepare-dir, --users-only или --full")
    archive=mode_path.expanduser().resolve()
    if not archive.is_file(): raise SystemExit(f"Архив не найден: {archive}")
    with tempfile.TemporaryDirectory(prefix="fargovpn_restore_") as work:
        root=safe_extract(archive,Path(work)); verify_archive(root)
        if args.users_only:
            report=restore_users_only(archive,root)
        else:
            report=restore_full(archive,root)
    json_out(report); return 0

if __name__=="__main__":
    try: raise SystemExit(cli())
    except Exception as exc:
        print(f"ОШИБКА ВОССТАНОВЛЕНИЯ: {exc}",file=sys.stderr)
        raise SystemExit(1)
