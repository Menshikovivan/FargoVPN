#!/usr/bin/env bash
set -u
echo "=== FargoVPN HTTPS / external reverse proxy diagnostic ==="
if [[ -f /root/vpn_bot/config.py ]]; then
  /root/vpn_bot/.venv/bin/python - <<'PY' || true
import config
print('WEB_DOMAIN=', getattr(config,'WEB_DOMAIN',''))
print('BOT_PANEL_URL=', getattr(config,'BOT_PANEL_URL',''))
print('WEB_PUBLIC_PREFIX=', getattr(config,'WEB_PUBLIC_PREFIX',''))
print('WEB_SOCKET_PATH=', getattr(config,'WEB_SOCKET_PATH',''))
PY
fi
echo "=== FargoVPN backend ==="
if [[ -S /run/vpn-service/fargovpn.sock ]]; then
  curl --unix-socket /run/vpn-service/fargovpn.sock -fsS --max-time 5 http://localhost/health || true
  echo
fi
systemctl is-active vpn-service-web.service 2>/dev/null || true
systemctl is-active vpn-service-web.socket 2>/dev/null || true
echo "=== TCP listeners ==="
ss -ltnp 2>/dev/null | head -n 120 || true
echo "=== Public URL (when configured) ==="
URL=$(python3 - <<'PY' 2>/dev/null || true
from pathlib import Path
import ast,re
p=Path('/root/vpn_bot/config.py')
if p.is_file():
 t=p.read_text(encoding='utf-8')
 for name in ('BOT_PANEL_URL','PUBLIC_PANEL_URL'):
  m=re.search(rf'(?m)^{name}\s*=\s*([\"\'][^\"\']*[\"\'])',t)
  if m:
   try:
    v=ast.literal_eval(m.group(1))
    if v: print(v); break
   except Exception: pass
PY
)
if [[ -n "$URL" ]]; then curl -I -k -L --max-time 10 "$URL" || true; fi
