from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[1]


def _guard_module():
    spec = importlib.util.spec_from_file_location("fargovpn_nginx_guard", ROOT / "nginx_panel_guard.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_guard_routes_fargovpn_to_unix_socket_and_keeps_3xui_path_separate():
    guard = _guard_module()
    guard.cfg = lambda name, default=None: {
        "WEB_DOMAIN": "vpn.example.com",
        "WEB_PUBLIC_PREFIX": "/fargovpn-admin-abc12345",
        "WEB_SOCKET_PATH": "/run/vpn-service/fargovpn.sock",
    }.get(name, default)
    original = """server {
    listen 443 ssl;
    server_name vpn.example.com;
    location ^~ /my-3x-panel/ { proxy_pass http://127.0.0.1:10443; }
    location / { return 200 ok; }
}
"""
    new = guard._insert_into_named_https_server(
        original,
        guard.block(guard.prefix(), "/run/vpn-service/fargovpn.sock"),
    )
    assert new is not None
    assert "location ^~ /my-3x-panel/" in new
    assert "location ^~ /fargovpn-admin-abc12345/" in new
    assert "proxy_pass http://unix:/run/vpn-service/fargovpn.sock:/;" in new
    assert "listen 443 ssl;" in new


def test_installer_does_not_install_nginx_but_requires_preexisting_router():
    text = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert "apt_install nginx" not in text
    assert "apt-get install nginx" not in text
    assert "systemctl enable nginx.service" not in text
    assert "setup_existing_nginx_route" in text
    assert "nginx.service" in text
    assert "00-stream.conf" in text


def test_guard_recognizes_external_nginx_unix_virtual_host():
    guard = _guard_module()
    guard.cfg = lambda name, default=None: {
        "WEB_DOMAIN": "vpn.example.com",
        "WEB_PUBLIC_PREFIX": "/fargovpn-admin-abc12345",
    }.get(name, default)
    nginx_server = """server {
    listen unix:/dev/shm/nginx-http.sock ssl default_server proxy_protocol;
    listen 127.0.0.1:9443 ssl default_server proxy_protocol;
    server_name vpn.example.com;
}
"""
    assert guard._file_contains_target_server(nginx_server) is True
