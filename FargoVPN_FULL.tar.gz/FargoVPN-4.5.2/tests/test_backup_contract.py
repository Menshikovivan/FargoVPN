import tempfile
import json
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_backup_contains_required_postgresql_dumps_and_telegram_delivery():
    text = (ROOT / "backup.py").read_text(encoding="utf-8")
    assert 'databases / "fargovpn.sql"' in text
    assert 'databases / "xui.sql"' in text
    assert 'def send_to_telegram_sync' in text
    assert 'def _deliver_archive' in text


def test_removed_remote_backup_runtime_is_absent():
    for relative in ["backup.py", "config.example.py", "webapp.py", "install.sh"]:
        text = (ROOT / relative).read_text(encoding="utf-8")
        assert not any(token.lower() in text.lower() for token in ("yan" + "dex", "yadi" + "sk", "web" + "dav", "dav" + "fs")), relative
    assert not (ROOT / ("yan" + "dex" + "_" + "web" + "dav" + ".py")).exists()


def test_backup_service_runs_daily_check():
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert "ExecStart=$TARGET/.venv/bin/python $TARGET/backup.py --service" in installer
    assert "OnCalendar=*-*-* 03:30:00" in installer
    assert "Persistent=true" in installer
    assert "OnUnitActiveSec=15m" not in installer
    assert "systemctl enable vpn-service-bot.service vpn-service-backup.timer" in installer


def test_manual_backup_is_available_and_uses_single_service():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    assert 'callback_data="admin:backup"' in text
    assert 'async def run_admin_backup' in text
    assert "request_backup_now" in text
    assert "launch_detached" not in text
    assert '@dp.message(Command("backup"))' in text


def test_backup_live_state_contract():
    text = (ROOT / "backup.py").read_text(encoding="utf-8")
    web = (ROOT / "webapp.py").read_text(encoding="utf-8")
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert 'BACKUP_LIVE_STATE_PATH' in text
    assert 'def _live_event' in text
    assert 'def read_live_state' in text
    assert '"phase": "start"' in text
    assert '"telegram"' in text
    assert '@app.get("/api/backup/live"' in web
    assert 'service == "backup-live"' in web
    assert 'value="backup-live"' in web
    assert 'BACKUP_LIVE_STATE_PATH' in installer


def test_users_query_is_postgres_safe():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "COLLATE NOCASE" not in text
    assert "LOWER(COALESCE(username" in text


def test_two_part_archive_reassembly_and_integrity():
    import subprocess, sys
    with tempfile.TemporaryDirectory() as temp:
        base=Path(temp)
        src=base/'payload'; src.write_bytes(b'X'*12000)
        archive=base/'vpn_service_full_backup_test.tar.gz'
        manifest={"format":"FargoVPN backup 4.5","application_database":"PostgreSQL","application_dump":"databases/fargovpn.sql","xui_dump":"databases/xui.db","application_row_counts":{"users":3}}
        (base/'stage').mkdir(); (base/'stage'/'manifest.json').write_text(json.dumps(manifest),encoding='utf-8'); (base/'stage'/'checksums.json').write_text('{}',encoding='utf-8')
        (base/'stage'/'databases').mkdir(); (base/'stage'/'databases'/'fargovpn.sql').write_text('CREATE TABLE users(id integer);',encoding='utf-8')
        import sqlite3
        db=base/'stage'/'databases'/'xui.db'; c=sqlite3.connect(db); c.execute('create table settings(k text)'); c.commit(); c.close()
        with tarfile.open(archive,'w:gz') as tar: tar.add(base/'stage',arcname='vpn_service_backup')
        data=archive.read_bytes(); split=len(data)//2
        restore_dir=base/'parts'; restore_dir.mkdir(); (restore_dir/(archive.name+'.part001')).write_bytes(data[:split]); (restore_dir/(archive.name+'.part002')).write_bytes(data[split:])
        work=base/'work'
        r=subprocess.run([sys.executable,str(ROOT/'restore_manager.py'),'--prepare-dir',str(restore_dir),'--work-dir',str(work),'--json'],capture_output=True,text=True)
        assert r.returncode==0, r.stderr
        joined=work/'backup.tar.gz'; assert joined.read_bytes()==data
        assert (work/'extracted'/'vpn_service_backup'/'manifest.json').is_file()
