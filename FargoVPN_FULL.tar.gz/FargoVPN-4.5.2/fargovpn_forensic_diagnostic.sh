#!/usr/bin/env bash
set -u
echo "=== FargoVPN forensic diagnostic ==="
echo "=== VERSION ==="
cat /root/vpn_bot/VERSION 2>/dev/null || true
echo "=== SERVICES ==="
for unit in vpn-service-bot.service vpn-service-web.service vpn-service-web.socket vpn-service-backup.service x-ui.service; do systemctl status "$unit" --no-pager -n 40 2>&1 || true; done
echo "=== SOCKET / LISTENERS ==="
ss -xlpn 2>&1 || true
ss -ltnp 2>&1 || true
echo "=== HEALTH ==="
if [[ -S /run/vpn-service/fargovpn.sock ]]; then curl --unix-socket /run/vpn-service/fargovpn.sock -fsS --max-time 5 http://localhost/health 2>&1 || true; echo; fi
echo "=== BACKUP LIVE ==="
cat /var/lib/vpn-service/backup-live.json 2>/dev/null || true
echo "=== LOGS ==="
journalctl -u vpn-service-web.service --since '-60 min' --no-pager -n 250 2>&1 || true
journalctl -u vpn-service-bot.service --since '-60 min' --no-pager -n 250 2>&1 || true
journalctl -u vpn-service-backup.service --since '-60 min' --no-pager -n 250 2>&1 || true
