"""Пример конфигурации. Установщик создаёт config.py автоматически."""
import aiohttp

INSTALL_PROFILE = "full"
SERVICE_NAME = "MyVPN"
BOT_TOKEN = "123456:telegram-bot-token"
ADMIN_IDS = [123456789]
SUBSCRIPTION_DAYS = 30
BOT_WELCOME_TEXT = ""  # optional; {service} is replaced with SERVICE_NAME
BOT_SUPPORT_PROMPT = ""
FAQ_INCY_URL = "https://apps.apple.com/ru/app/incy/id6756943388"
BOT_IDENTITY_REFRESH_SECONDS = 600
BOT_SYNC_INTERVAL_SECONDS = 3600
TELEGRAM_UPDATE_LEASE_SECONDS = 600
TELEGRAM_UPDATE_DEDUP_KEEP_DAYS = 7
DB_PATH = "/root/vpn_bot/data/vpn_bot.db"  # legacy source path; runtime uses DATABASE_URL
DATABASE_URL = "postgresql+psycopg://fargovpn:CHANGE_ME@127.0.0.1:5432/fargovpn"
DATABASE_POOL_SIZE = 4
DATABASE_MAX_OVERFLOW = 4
DATABASE_POOL_TIMEOUT = 15
BACKUP_DATABASE_TIMEOUT_SECONDS = 300
BASE_URL = "https://panel.example.com/"
MASTER_API_URL = BASE_URL
MASTER_API_TOKEN = "3x-ui-api-token"
SUB_BASE_URL = "https://panel.example.com/sub/"
PAYMENT_PRICE = 150
PAYMENT_PHONE = "+79990000000"
PAYMENT_BANK = "Банк"
PAYMENT_RECEIVER = "Получатель"

# Local receipt OCR. PAYMENT_PHONE and PAYMENT_RECEIVER are the expected
# recipient details. Automatic approval requires all checks to pass.
RECEIPT_OCR_ENABLED = True
RECEIPT_AUTO_APPROVE = True
RECEIPT_MIN_AMOUNT = 150.0  # accepted when recognized amount is >= this value
RECEIPT_MAX_AGE_HOURS = 24
RECEIPT_RECEIVER_ALIASES = ""  # e.g. "Иван И.; И. Иванов"
RECEIPT_ALLOW_MASKED_PHONE = True
RECEIPT_TIMEZONE = "Asia/Almaty"
RECEIPT_OCR_LANGUAGES = "rus+eng"
RECEIPT_OCR_TIMEOUT = 20
# Individual filters. Defaults are intentionally tolerant of mobile-bank
# screenshots: phone and date are optional because some banks do not show them.
RECEIPT_FILTER_NAME = True
RECEIPT_FILTER_PHONE = False
RECEIPT_FILTER_AMOUNT = True
RECEIPT_FILTER_DATE = False
RECEIPT_FILTER_STATUS = True
RECEIPT_FILTER_DUPLICATE = True
RECEIPT_SUBMIT_LIMIT = 5
RECEIPT_SUBMIT_WINDOW_SECONDS = 3600
SUPPORT_MESSAGE_LIMIT = 10
SUPPORT_MESSAGE_WINDOW_SECONDS = 600

API_TIMEOUT = aiohttp.ClientTimeout(total=12.0)

WEB_HOST = '127.0.0.1'
WEB_SOCKET_PATH = '/run/vpn-service/fargovpn.sock'
APP_LOG_PATH = "/var/log/vpn_bot.log"
WEB_REVERSE_PROXY = True
WEB_PUBLIC_PREFIX = "/fargovpn-admin-example"
WEB_DOMAIN = ""
WEB_TLS_SERVER_NAME = ""
WEB_USERNAME = "admin"
WEB_PASSWORD_HASH = 'pbkdf2_sha256$260000$a7a7b280d05f7079c7af6f09f6cf41d1$aa12d0b0cfe258020d16d7dc8fb57f166f27908aacddce9689de43908c249f6d'
WEB_SECRET_KEY = "replace-with-a-random-secret"
WEB_COOKIE_HTTPS_ONLY = True
WEB_SESSION_MAX_AGE_SECONDS = 28800
CABINET_LINK_TTL_SECONDS = 86400
# Включайте только на короткое время миграции: старые ссылки не имеют срока действия.
CABINET_ALLOW_LEGACY_TOKENS = False
WEB_TRUST_PROXY_HEADERS = True
# Timezone for human-facing timestamps in the administration panel.
# SQLite audit timestamps are stored in UTC and converted for display.
WEB_TIMEZONE = "Asia/Almaty"
WEB_LOGIN_MAX_ATTEMPTS = 5
WEB_LOGIN_WINDOW_SECONDS = 900
WEB_LOGIN_BLOCK_SECONDS = 900
WEB_LOGIN_MAX_BLOCK_SECONDS = 86400
WEB_LOGIN_SECURITY_RETENTION_DAYS = 30
NGINX_GUARD_INTERVAL_SECONDS = 300

XUI_DB_PATH = "/etc/x-ui/x-ui.db"  # legacy path only; 3x-ui runtime may use PostgreSQL
XUI_PANEL_URL = BASE_URL.rstrip("/")
BOT_PANEL_URL = ""
PUBLIC_PANEL_URL = ""
XUI_CACHE_SECONDS = 15
ONLINE_METRICS_CACHE_SECONDS = 20
XUI_CONTROL_CACHE_SECONDS = 45
XUI_VERIFY_TLS = True
# Новые клиенты добавляются только в эти inbound. Пусто = все активные inbound
# разрешённых протоколов; существующие привязки при обновлении сохраняются.
XUI_MANAGED_INBOUND_IDS = []
XUI_MANAGED_PROTOCOLS = ["vless"]
REMINDER_DAYS = [7, 3, 1, 0]
REMINDER_LOCK_PATH = "/run/vpn-service-reminders.lock"
METRICS_STORE_INTERVAL_SECONDS = 60
IDENTITY_IMPORT_MAX_MB = 512
USER_EVENT_KEEP_DAYS = 365
USER_EVENT_MAX_ROWS = 250000
CHAT_MEDIA_MAX_MB = 100
CHAT_MEDIA_CACHE_DIR = "/var/cache/vpn-service/chat-media"
CHAT_MEDIA_CACHE_DAYS = 30
CHAT_MEDIA_CACHE_MAX_MB = 512
BROADCAST_DIR = "/var/lib/vpn-service/broadcasts"
BROADCAST_MEDIA_MAX_MB = 45
BROADCAST_SEND_DELAY_SECONDS = 0.04
BROADCAST_STALE_SECONDS = 7200
SUBSCRIPTION_REFRESH_DIR = "/var/lib/vpn-service/subscription-refresh"
SUBSCRIPTION_REFRESH_SEND_DELAY_SECONDS = 0.04
SUBSCRIPTION_REFRESH_STALE_SECONDS = 7200
XUI_SUBSCRIPTION_SETTINGS_CACHE_SECONDS = 30

# Browser / PWA Web Push. Keys are generated on first install and kept outside source.
PUSH_ENABLED = True
PUSH_VAPID_SUBJECT = ""  # auto-derived from WEB_DOMAIN when empty
PUSH_VAPID_PRIVATE_KEY_PATH = "/var/lib/vpn-service/vapid_private.pem"
PUSH_VAPID_PUBLIC_KEY = ""
PUSH_TTL_SECONDS = 3600
PUSH_MAX_SUBSCRIPTIONS_PER_USER = 8
PUSH_TEST_ENABLED = True

BACKUP_DIR = "/var/backups/vpn-service"
BACKUP_KEEP_DAYS = 14
BACKUP_INTERVAL_DAYS = 3
BACKUP_TELEGRAM = True
BACKUP_TELEGRAM_PART_MB = 45
BACKUP_INCLUDE_VENV = False
BACKUP_LOCK_PATH = "/run/vpn-service-backup.lock"
BACKUP_STATE_PATH = "/var/lib/vpn-service/backup-state.json"
BACKUP_RETRY_INTERVAL_SECONDS = 900
BACKUP_PENDING_KEEP_DAYS = 30
# Публичный recipient из `age-keygen -y /root/fargovpn-backup.agekey`.
# Приватный ключ храните вне сервера.
BACKUP_AGE_RECIPIENT = ""
BACKUP_REQUIRE_REMOTE_ENCRYPTION = True
# Веб-восстановление в рабочие БД небезопасно; используйте restore_staged.py.
BACKUP_ALLOW_INPLACE_RESTORE = False

# Yandex.Disk via direct HTTPS WebDAV.
YANDEX_WEBDAV_ENABLED = False
YANDEX_WEBDAV_URL = "https://webdav.yandex.ru"
YANDEX_WEBDAV_USERNAME = ""
YANDEX_WEBDAV_APP_PASSWORD = ""
YANDEX_WEBDAV_PATH = "VPN-Service-Backups"
YANDEX_UPLOAD_RETRIES = 3
YANDEX_UPLOAD_VERIFY_ATTEMPTS = 8
YANDEX_UPLOAD_VERIFY_DELAY = 1.0
YANDEX_UPLOAD_TIMEOUT_SECONDS = 900
XUI_POSTGRES_DSN = ""  # optional override; normally read from /etc/default/x-ui
XUI_DB_ENV_FILE = "/etc/default/x-ui"


# GitHub Releases is the single source of platform updates.
# The publisher login is configurable and must never be hard-coded in a package.
# All panels read the latest published release from the configured repository.
UPDATE_DIR = "/var/lib/vpn-service/updates"
UPDATE_PUBLISHER_USERNAME = "admin"
UPDATE_IS_PUBLISHER = False
GITHUB_API_BASE_URL = "https://api.github.com"
GITHUB_API_TOKEN = ""
GITHUB_REPOSITORY_OWNER = ""
GITHUB_REPOSITORY_NAME = "FargoVPN"
GITHUB_TARGET_BRANCH = "main"
GITHUB_RELEASE_TAG_PREFIX = "FargoVPN-"
GITHUB_RELEASE_NAME_TEMPLATE = "FargoVPN {version}"
GITHUB_RELEASE_ASSET_NAME = "VPN_Service_Platform_{version}_FULL.tar.gz"
GITHUB_RELEASE_MAKE_LATEST = True
GITHUB_RELEASE_DRAFT = False
GITHUB_RELEASE_PRERELEASE = False
GITHUB_MAIN_SYNC_ENABLED = True
UPDATE_CHECK_INTERVAL = 60
UPDATE_VERIFY_TLS = True
UPDATE_MAX_ARCHIVE_MB = 1024
UPDATE_STALE_JOB_SECONDS = 7200

# Preferred deployment: loopback application + existing Nginx HTTPS 443 gateway.
