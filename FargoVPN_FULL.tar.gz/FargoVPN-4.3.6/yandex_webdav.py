#!/usr/bin/env python3
"""Direct Yandex.Disk WebDAV client used by FargoVPN backups.

The implementation deliberately uses only httpx (already required by FargoVPN)
and the WebDAV methods supported by Yandex.Disk. No OAuth REST API or mounted
filesystem integration is used here.
"""
from __future__ import annotations

import logging
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import quote, urlsplit

import httpx

logger = logging.getLogger("vpn-service-backup.yandex")
DEFAULT_URL = "https://webdav.yandex.ru"


def clean_remote_path(path: str) -> str:
    parts = [part for part in str(path or "").replace("\\", "/").split("/") if part]
    if any(part in {".", ".."} for part in parts):
        raise ValueError("Путь WebDAV не должен содержать . или ..")
    return "/".join(parts)


def webdav_url(base_url: str, remote_path: str = "") -> str:
    base = str(base_url or DEFAULT_URL).strip().rstrip("/")
    parts = urlsplit(base)
    if parts.scheme != "https" or parts.netloc != "webdav.yandex.ru":
        raise ValueError("YANDEX_WEBDAV_URL должен быть https://webdav.yandex.ru")
    clean = clean_remote_path(remote_path)
    if not clean:
        return base + "/"
    return base + "/" + "/".join(quote(part, safe="") for part in clean.split("/"))


def _timeout(seconds: float = 900.0) -> httpx.Timeout:
    value = max(15.0, float(seconds))
    return httpx.Timeout(value, connect=20.0, read=value, write=value, pool=20.0)


def _client(username: str, password: str, timeout_seconds: float = 900.0) -> httpx.Client:
    if not username.strip() or not password:
        raise ValueError("Логин и пароль приложения WebDAV обязательны")
    return httpx.Client(
        auth=httpx.BasicAuth(username.strip(), password),
        timeout=_timeout(timeout_seconds),
        follow_redirects=True,
        trust_env=False,
        headers={"Accept": "*/*", "Connection": "close"},
        limits=httpx.Limits(max_connections=2, max_keepalive_connections=0, keepalive_expiry=0),
    )


def _propfind(client: httpx.Client, url: str) -> dict[str, Any]:
    body = (
        '<?xml version="1.0" encoding="utf-8"?>'
        '<d:propfind xmlns:d="DAV:"><d:prop>'
        '<d:getcontentlength/><d:resourcetype/>'
        '</d:prop></d:propfind>'
    )
    response = client.request(
        "PROPFIND",
        url,
        headers={"Depth": "0", "Content-Type": "application/xml; charset=utf-8"},
        content=body.encode("utf-8"),
    )
    if response.status_code == 404:
        return {"exists": False, "is_collection": False, "size": None}
    if response.status_code not in (200, 207):
        response.raise_for_status()
    try:
        root = ET.fromstring(response.content)
    except ET.ParseError as exc:
        raise RuntimeError(f"Некорректный XML WebDAV PROPFIND: {exc}") from exc
    collection = False
    size: int | None = None
    for element in root.iter():
        tag = element.tag.rsplit("}", 1)[-1].lower()
        if tag == "collection":
            collection = True
        elif tag == "getcontentlength":
            raw = str(element.text or "").strip()
            if raw.isdigit():
                size = int(raw)
    return {"exists": True, "is_collection": collection, "size": size}


def ensure_directory(client: httpx.Client, base_url: str, directory: str) -> None:
    parts = [part for part in clean_remote_path(directory).split("/") if part]
    current: list[str] = []
    for part in parts:
        current.append(part)
        url = webdav_url(base_url, "/".join(current))
        info = _propfind(client, url)
        if info["exists"]:
            if not info["is_collection"]:
                raise RuntimeError(f"WebDAV-ресурс {url} существует, но это не каталог")
            continue
        response = client.request("MKCOL", url)
        if response.status_code in (200, 201, 204, 405):
            confirm = _propfind(client, url)
            if confirm["exists"] and confirm["is_collection"]:
                continue
        response.raise_for_status()
        raise RuntimeError(f"Не удалось создать каталог WebDAV: {url}")


def verify_remote_file(
    username: str,
    password: str,
    remote_url: str,
    expected_size: int,
    *,
    attempts: int = 8,
    delay: float = 1.0,
    timeout_seconds: float = 60.0,
) -> tuple[bool, str]:
    last = "Файл ещё не подтверждён"
    for attempt in range(1, max(1, int(attempts)) + 1):
        try:
            with _client(username, password, timeout_seconds) as client:
                info = _propfind(client, remote_url)
                if not info["exists"]:
                    last = "Файл ещё не найден"
                elif info["is_collection"]:
                    last = "Удалённый ресурс является каталогом"
                elif info["size"] == expected_size:
                    return True, f"{expected_size} байт, размер подтверждён"
                elif info["size"] is None:
                    head = client.head(remote_url)
                    if head.status_code == 200:
                        raw = str(head.headers.get("Content-Length", "")).strip()
                        if raw.isdigit() and int(raw) == expected_size:
                            return True, f"{expected_size} байт, размер подтверждён HEAD"
                    last = "WebDAV не вернул размер файла"
                else:
                    last = f"Размер {info['size']} байт вместо {expected_size}"
        except Exception as exc:  # noqa: BLE001
            last = str(exc)
        if attempt < max(1, int(attempts)) and delay > 0:
            time.sleep(delay)
    return False, last


def delete_resource(username: str, password: str, remote_url: str, timeout_seconds: float = 60.0) -> None:
    try:
        with _client(username, password, timeout_seconds) as client:
            response = client.delete(remote_url)
            if response.status_code not in (200, 202, 204, 404):
                response.raise_for_status()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Не удалось удалить WebDAV-ресурс %s: %s", remote_url, exc)


def upload_file(
    path: Path,
    *,
    username: str,
    password: str,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    retries: int = 3,
    verify_attempts: int = 8,
    verify_delay: float = 1.0,
    timeout_seconds: float = 900.0,
) -> tuple[bool, str]:
    path = Path(path)
    if not path.is_file():
        return False, f"Архив не найден: {path}"
    size = path.stat().st_size
    if size <= 0:
        return False, "Архив пуст"
    directory = clean_remote_path(directory) or "VPN-Service-Backups"
    final_remote = "/".join(part for part in (directory, path.name) if part)
    part_remote = final_remote + ".part"
    final_url = webdav_url(base_url, final_remote)
    part_url = webdav_url(base_url, part_remote)

    last_error = "неизвестная ошибка"
    for attempt in range(1, max(1, int(retries)) + 1):
        try:
            with _client(username, password, timeout_seconds) as client:
                ensure_directory(client, base_url, directory)
            logger.info(
                "WebDAV Yandex upload start file=%s size=%d remote=%s attempt=%d/%d",
                path.name, size, final_remote, attempt, retries,
            )
            with _client(username, password, timeout_seconds) as client:
                with path.open("rb") as stream:
                    response = client.put(
                        part_url,
                        headers={"Content-Type": "application/octet-stream", "Content-Length": str(size)},
                        content=stream,
                    )
                if response.status_code not in (200, 201, 202, 204):
                    body = response.text.strip().replace("\n", " ")[:500]
                    raise RuntimeError(f"WebDAV PUT HTTP {response.status_code}: {body}")
            verified, detail = verify_remote_file(
                username, password, part_url, size,
                attempts=verify_attempts, delay=verify_delay,
                timeout_seconds=min(timeout_seconds, 120.0),
            )
            if not verified:
                raise RuntimeError(f"Проверка временного файла не пройдена: {detail}")
            with _client(username, password, timeout_seconds) as client:
                response = client.request(
                    "MOVE",
                    part_url,
                    headers={"Destination": final_url, "Overwrite": "T"},
                )
                if response.status_code not in (200, 201, 204):
                    body = response.text.strip().replace("\n", " ")[:500]
                    raise RuntimeError(f"WebDAV MOVE HTTP {response.status_code}: {body}")
            verified, detail = verify_remote_file(
                username, password, final_url, size,
                attempts=verify_attempts, delay=verify_delay,
                timeout_seconds=min(timeout_seconds, 120.0),
            )
            if not verified:
                raise RuntimeError(f"Финальная проверка не пройдена: {detail}")
            logger.info(
                "WebDAV Yandex upload success file=%s size=%d remote=%s",
                path.name, size, final_remote,
            )
            return True, f"{final_remote}: {detail}"
        except Exception as exc:  # noqa: BLE001
            last_error = str(exc)
            logger.warning(
                "WebDAV Yandex upload failed file=%s attempt=%d/%d: %s",
                path.name, attempt, retries, exc,
            )
            if attempt < max(1, int(retries)):
                time.sleep(min(15.0, 2.0 ** (attempt - 1)))
    delete_resource(username, password, part_url, timeout_seconds=min(timeout_seconds, 60.0))
    return False, f"После {retries} попыток WebDAV загрузка не подтверждена: {last_error}"


def test_connection(
    username: str,
    password: str,
    *,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
) -> tuple[bool, str]:
    try:
        directory = clean_remote_path(directory) or "VPN-Service-Backups"
        with _client(username, password, 30.0) as client:
            root = _propfind(client, webdav_url(base_url))
            if not root["exists"]:
                return False, "WebDAV корень Яндекс.Диска недоступен"
            ensure_directory(client, base_url, directory)
        return True, f"Подключение успешно. Каталог «{directory}» доступен"
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code in (401, 403):
            return False, "Ошибка авторизации WebDAV: проверьте логин и пароль приложения"
        return False, f"WebDAV HTTP {exc.response.status_code}: {exc}"
    except Exception as exc:  # noqa: BLE001
        return False, f"Ошибка WebDAV: {exc}"


def test_write(
    username: str,
    password: str,
    *,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
) -> tuple[bool, str]:
    name = f".fargovpn-webdav-test-{time.time_ns()}.txt"
    content = f"FargoVPN WebDAV test {time.time_ns()}\n".encode()
    directory = clean_remote_path(directory) or "VPN-Service-Backups"
    remote = "/".join((directory, name))
    url = webdav_url(base_url, remote)
    try:
        with _client(username, password, 60.0) as client:
            ensure_directory(client, base_url, directory)
            response = client.put(
                url,
                headers={"Content-Type": "text/plain; charset=utf-8", "Content-Length": str(len(content))},
                content=content,
            )
            if response.status_code not in (200, 201, 202, 204):
                response.raise_for_status()
        ok, detail = verify_remote_file(username, password, url, len(content), attempts=3, delay=0.5, timeout_seconds=30)
        if not ok:
            return False, f"Тестовая запись не подтверждена: {detail}"
        return True, f"Тестовая загрузка успешна: {detail}"
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code in (401, 403):
            return False, "Ошибка авторизации WebDAV: проверьте логин и пароль приложения"
        return False, f"WebDAV HTTP {exc.response.status_code}: {exc}"
    except Exception as exc:  # noqa: BLE001
        return False, f"Ошибка тестовой загрузки WebDAV: {exc}"
    finally:
        delete_resource(username, password, url, timeout_seconds=30.0)


def remote_file_matches(
    archive: Path,
    *,
    username: str,
    password: str,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
) -> tuple[bool, str]:
    archive = Path(archive)
    if not archive.is_file():
        return False, "Локальный архив отсутствует"
    remote = "/".join(part for part in (clean_remote_path(directory), archive.name) if part)
    try:
        ok, detail = verify_remote_file(
            username, password, webdav_url(base_url, remote), archive.stat().st_size,
            attempts=2, delay=0.25, timeout_seconds=30,
        )
        return ok, detail
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)
