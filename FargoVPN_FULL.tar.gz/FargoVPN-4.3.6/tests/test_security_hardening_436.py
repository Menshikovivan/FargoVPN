from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def source(name: str) -> str:
    return (ROOT / name).read_text(encoding="utf-8")


def test_autoapproval_remains_enabled_and_used():
    assert "RECEIPT_AUTO_APPROVE = True" in source("config.example.py")
    assert 'getattr(config, "RECEIPT_AUTO_APPROVE", True)' in source("main.py")


def test_payment_approval_uses_atomic_claim_and_reconciliation_state():
    text = source("services/subscriptions.py")
    assert "WHERE id=? AND status='pending'" in text
    assert "RETURNING *" in text
    assert "status='processing' AND processed_by=?" in text
    assert "def reset_payment_processing_sync" in text


def test_panel_mutations_require_session_csrf_header():
    web = source("webapp.py")
    js = source("static/panel.js")
    assert 'request.headers.get("x-csrf-token")' in web
    assert 'meta name="fargovpn-csrf-token"' in web
    assert "headers.set('X-CSRF-Token', CSRF_TOKEN)" in js


def test_remote_backups_are_age_encrypted_and_live_restore_is_off():
    backup = source("backup.py")
    installer = source("install.sh")
    web = source("webapp.py")
    assert "def encrypted_delivery_copy" in backup
    assert '["age", "--recipient"' in backup
    assert "age-keygen -o" in installer
    assert 'BACKUP_ALLOW_INPLACE_RESTORE", False' in web
    assert (ROOT / "restore_staged.py").is_file()


def test_cabinet_links_are_one_time_hashes():
    text = source("cabinet_service.py")
    assert "secrets.token_urlsafe(32)" in text
    assert "hashlib.sha256(token.encode()).hexdigest()" in text
    assert "consumed_at IS NULL" in text
    assert 'CABINET_ALLOW_LEGACY_TOKENS", False' in text


def test_new_clients_use_managed_inbound_allowlist():
    text = source("services/xui_api.py")
    assert 'getattr(config, "XUI_MANAGED_INBOUND_IDS", [])' in text
    assert 'getattr(config, "XUI_MANAGED_PROTOCOLS", ["vless"])' in text
    assert "Нет разрешённых активных inbound" in text


def test_user_actions_have_database_rate_limits():
    main = source("main.py")
    schema = source("init_db.py")
    assert '"receipt"' in main and '"support"' in main
    assert "CREATE TABLE IF NOT EXISTS action_rate_limits" in schema
    assert (ROOT / "rate_limit.py").is_file()
