from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_old_yandex_runtime_is_removed():
    for name in ["backup.py", "config.example.py", "webapp.py"]:
        text = (ROOT / name).read_text(encoding="utf-8")
        forbidden = [
            "YANDEX_DISK_MODE", "YANDEX_DISK_TOKEN", "YANDEX_LOCAL_PATH",
            "YANDEX_LOCAL_REQUIRE_MOUNT", "YANDEX_DAVFS_SECRETS_PATH",
            "RCLONE_REMOTE", "RCLONE_PATH", "cloud-api.yandex.net", "mount.davfs",
        ]
        assert not any(item in text for item in forbidden), name


def test_backup_has_both_postgresql_dumps():
    text = (ROOT / "backup.py").read_text(encoding="utf-8")
    assert 'databases / "fargovpn.sql"' in text
    assert 'databases / "xui.sql"' in text


def test_yandex_settings_panel_is_webdav_only():
    text = (ROOT / "webapp.py").read_text(encoding="utf-8")
    start = text.index('@app.get("/settings/yandex"')
    end = text.index('@app.get("/api/updates/status")', start)
    block = text[start:end]
    assert "YANDEX_WEBDAV_USERNAME" in block
    assert "YANDEX_WEBDAV_APP_PASSWORD" in block
    assert "Проверить подключение" in block
    assert "Тестовая загрузка" in block
    assert "YANDEX_DISK_TOKEN" not in block
    assert "YANDEX_DISK_MODE" not in block
    assert "xui_postgres_dsn_for_cli" in (ROOT / "backup.py").read_text(encoding="utf-8")


def test_users_query_is_postgres_safe():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "COLLATE NOCASE" not in text
    assert "LOWER(COALESCE(username" in text


def test_backup_transport_and_installer_have_no_legacy_webdav_runtime():
    backup = (ROOT / "backup.py").read_text(encoding="utf-8")
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert "rclone" not in backup
    assert "davfs2" not in backup
    assert "cloud-api.yandex.net" not in backup
    assert "apt-get install" in installer
    assert " rclone" not in installer and " davfs2" not in installer
    assert not (ROOT / "configure_yandex_webdav.sh").exists()

def test_yandex_navigation_is_separate_settings_panel():
    text = (ROOT / "webapp.py").read_text(encoding="utf-8")
    assert '("yandex", "/settings/yandex", "cloud", "Яндекс.Диск")' in text
    assert 'public_path("/settings/yandex")' in text

def test_telegram_idempotency_is_registered_before_handlers():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    middleware_pos = text.index("class TelegramUpdateIdempotencyMiddleware")
    registration_pos = text.index("dp.update.outer_middleware(TelegramUpdateIdempotencyMiddleware())")
    assert middleware_pos < registration_pos
    assert "claim_telegram_update" in text
    assert "mark_telegram_update_processed" in text
    assert "release_telegram_update" in text


def test_manual_backup_is_available_in_admin_bot():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    assert 'callback_data="admin:backup"' in text
    assert 'elif action == "backup":' in text
    assert 'async def run_admin_backup' in text
    assert 'launch_detached' in text
    assert '[sys.executable, str(APP_DIR / "backup.py"), "--force"]' in text
    assert '@dp.message(Command("backup"))' in text


def test_manual_backup_does_not_block_event_loop():
    text = (ROOT / "main.py").read_text(encoding="utf-8")
    start = text.index('async def run_admin_backup')
    end = text.index('@dp.callback_query(F.data.startswith("admin:"))', start)
    block = text[start:end]
    assert 'await asyncio.to_thread(' in block
    assert 'launch_detached' in block


def test_disabled_yandex_is_not_recorded_as_success():
    # Keep this contract independent from a production config.py / PostgreSQL DSN.
    text = (ROOT / "backup.py").read_text(encoding="utf-8")
    assert "def yandex_upload_enabled()" in text
    assert "and not yandex_upload_enabled():" in text
    assert 'return False, "Отключено: WebDAV-загрузка на Яндекс.Диск выключена в настройках"' in text
