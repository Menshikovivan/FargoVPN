#!/usr/bin/env python3
"""Safely restore a FargoVPN archive into new PostgreSQL staging databases."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import tarfile
import tempfile
import time
from pathlib import Path

import psycopg
from psycopg import sql
from sqlalchemy.engine import make_url

import config


def cli_dsn(value: str) -> tuple[str, dict[str, str]]:
    value = str(value or "").strip().replace("postgresql+psycopg://", "postgresql://", 1)
    parsed = make_url(value)
    env = os.environ.copy()
    if parsed.password is not None:
        env["PGPASSWORD"] = parsed.password
        value = parsed.set(password=None).render_as_string(hide_password=False)
    return value, env


def display_dsn(dsn: str) -> str:
    return make_url(dsn).render_as_string(hide_password=True)


def create_database(source_dsn: str, name: str) -> str:
    parsed = make_url(source_dsn)
    admin_dsn = parsed.set(database="postgres").render_as_string(hide_password=False)
    with psycopg.connect(admin_dsn, autocommit=True) as connection:
        exists = connection.execute("SELECT 1 FROM pg_database WHERE datname=%s", (name,)).fetchone()
        if exists:
            raise RuntimeError(f"База {name} уже существует; удалять её автоматически запрещено")
        connection.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))
    return parsed.set(database=name).render_as_string(hide_password=False)


def safe_extract(archive: Path, destination: Path) -> Path:
    root = destination.resolve()
    with tarfile.open(archive, "r:gz") as bundle:
        for member in bundle.getmembers():
            if member.issym() or member.islnk() or member.isdev() or not (member.isfile() or member.isdir()):
                raise RuntimeError("Архив содержит ссылку или специальный файл")
            target = (destination / member.name).resolve()
            if root != target and root not in target.parents:
                raise RuntimeError("Архив содержит небезопасный путь")
        bundle.extractall(destination, filter="data")
    result = destination / "vpn_service_backup"
    if not result.is_dir():
        raise RuntimeError("Каталог vpn_service_backup в архиве не найден")
    return result


def restore_dump(dump: Path, dsn: str) -> None:
    command_dsn, env = cli_dsn(dsn)
    subprocess.run(
        ["psql", "--dbname", command_dsn, "--set", "ON_ERROR_STOP=1", "--file", str(dump)],
        check=True, env=env, timeout=1800,
    )


def verify_app(dsn: str) -> dict[str, int]:
    result: dict[str, int] = {}
    with psycopg.connect(dsn) as connection:
        for table in ("users", "payments", "user_events"):
            exists = connection.execute("SELECT to_regclass(%s)", (f"public.{table}",)).fetchone()[0]
            if not exists:
                raise RuntimeError(f"После восстановления отсутствует таблица {table}")
            result[table] = int(connection.execute(sql.SQL("SELECT count(*) FROM {}").format(sql.Identifier(table))).fetchone()[0])
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--app-dsn", default=str(getattr(config, "DATABASE_URL", "")))
    parser.add_argument("--xui-dsn", default="", help="DSN рабочей 3x-ui; если пусто, её dump не восстанавливается")
    parser.add_argument("--suffix", default=time.strftime("restore_%Y%m%d_%H%M%S"))
    args = parser.parse_args()
    if shutil.which("psql") is None:
        raise RuntimeError("psql не установлен")
    archive = args.archive.expanduser().resolve()
    if not archive.is_file():
        raise FileNotFoundError(archive)
    created: list[str] = []
    report: dict[str, object] = {"archive": str(archive), "created_databases": created}
    with tempfile.TemporaryDirectory(prefix="fargovpn_restore_stage_") as temp_name:
        root = safe_extract(archive, Path(temp_name))
        app_dump = root / "databases" / "fargovpn.sql"
        if not app_dump.is_file():
            raise RuntimeError("databases/fargovpn.sql не найден")
        app_name = f"fargovpn_{args.suffix}".replace("-", "_")
        app_staging = create_database(args.app_dsn, app_name)
        created.append(app_name)
        restore_dump(app_dump, app_staging)
        report["application"] = {"database": app_name, "dsn": display_dsn(app_staging), "counts": verify_app(app_staging)}
        xui_dump = root / "databases" / "xui.sql"
        if args.xui_dsn and xui_dump.is_file():
            xui_name = f"xui_{args.suffix}".replace("-", "_")
            xui_staging = create_database(args.xui_dsn, xui_name)
            created.append(xui_name)
            restore_dump(xui_dump, xui_staging)
            report["xui"] = {"database": xui_name, "dsn": display_dsn(xui_staging)}
    report["next_step"] = "Остановите службы, сделайте свежий бэкап, укажите staging DSN в config.py и /etc/default/x-ui, затем запустите init_db.py и службы."
    report["rollback"] = "Верните прежние DSN и перезапустите службы; staging-базы удаляйте только после проверки."
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
