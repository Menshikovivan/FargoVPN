from pathlib import Path
import re, tarfile, subprocess

ROOT = Path(__file__).resolve().parents[1]

def test_next_version_and_clean_archive_contract():
    assert (ROOT / "VERSION").read_text().strip() == "4.4.4"
    assert (ROOT / "app" / "VERSION").read_text().strip() == "4.4.4"
    assert (ROOT / "INSTALLED_CHANGELOG_VERSION").read_text().strip() == "4.4.4"


def test_direct_message_uses_native_postgresql_boolean_and_safe_json_errors():
    text = (ROOT / "webapp.py").read_text(encoding="utf-8")
    assert '(actor, tg_id, row.get("username"), event_text, bool(ok), detail)' in text
    assert '(actor, tg_id, row.get("username"), event_text, int(ok), detail)' not in text
    assert "type.includes('application/json')" in text
    assert "raw.replace(/<[^>]*>/g,' ')" in text


def test_message_log_success_schema_is_normalized_to_boolean():
    text = (ROOT / "init_db.py").read_text(encoding="utf-8")
    assert "def _normalize_message_log_success" in text
    assert "ALTER COLUMN success TYPE BOOLEAN" in text
    assert "_normalize_message_log_success(conn)" in text

def test_socket_directory_is_not_service_runtime_directory():
    text=(ROOT/"install.sh").read_text()
    assert "RuntimeDirectory=vpn-service" not in text
    assert "d /run/vpn-service 0755 root root -" in text
    assert "SocketUser=root" in text
    assert "SocketGroup=$NGINX_SOCKET_GROUP" in text
    assert "detect_nginx_socket_group" in text
    assert "SocketMode=0660" in text

def test_web_service_logs_and_uses_socket_service():
    text=(ROOT/"install.sh").read_text()
    assert "Requires=vpn-service-web.socket nginx.service" in text
    assert "ExecStart=$TARGET/web_start.sh" in text
    assert "StandardOutput=append:/var/log/vpn_bot.log" in text
    assert "StandardError=append:/var/log/vpn_bot.log" in text

def test_public_route_is_socket_and_no_8088():
    text=(ROOT/"nginx_panel_guard.py").read_text()
    assert "proxy_pass http://unix:{socket_path}:/" in text
    assert "proxy_redirect" not in text.split('def block',1)[1].split('def _strip_location_blocks',1)[0]

def test_log_api_is_fixed_path_and_protected():
    text=(ROOT/"webapp.py").read_text()
    assert '@app.get("/api/panel/app-log")' in text
    assert 'require_auth(request)' in text
    assert 'APP_LOG_DEFAULT = "/var/log/vpn_bot.log"' in text

def test_no_runtime_407_in_serving_code():
    for path in [ROOT/"webapp.py", ROOT/"service-worker.js", ROOT/"static"/"panel.js", ROOT/"static"/"panel.css"]:
        text=path.read_text(encoding="utf-8", errors="ignore")
        assert "4.0.7" not in text

def test_archive_release_builder_has_clean_name():
    text=(ROOT/"build_release.sh").read_text()
    assert 'ARCHIVE="$ROOT/../../VPN_Service_Platform_${version}_FULL.tar.gz"' in text
    assert 'PACKAGE_NAME="$(basename "$ROOT")"' in text
    assert 'find "$ROOT" -type l -print -quit' in text
    assert '--exclude="$PACKAGE_NAME/pytest-of-root"' in text
    assert '--exclude="$PACKAGE_NAME/tmp*"' in text


def test_app_log_ui_and_endpoint_contract():
    text=(ROOT/"webapp.py").read_text()
    assert 'Лог приложения' in text
    assert 'id="app-log-output"' in text
    assert 'id="app-log-refresh"' in text
    assert '/api/panel/app-log' in text
    assert 'require_auth(request)' in text

def test_messages_unread_api_and_navigation_badge_contract():
    text=(ROOT/"webapp.py").read_text()
    assert '@app.get("/api/panel/messages/unread")' in text
    assert 'data-unread-total' in text
    assert 'unread_messages_summary' in text
    assert 'message-unread-badge' in text


def test_unread_polling_is_single_flight_and_visibility_aware():
    text=(ROOT/"static"/"panel.js").read_text()
    assert 'function initUnreadMessages()' in text
    assert 'inFlight' in text
    assert "visibilitychange" in text
    assert "pagehide" in text
    assert "15000" in text


def test_latency_sensitive_telegram_paths_offload_sync_work():
    text=(ROOT/"main.py").read_text()
    assert '_schedule_event_record(' in text
    assert 'current_user = await asyncio.to_thread(db_get_user' in text
    assert 'await asyncio.to_thread(_save_pending_registration)' in text
    assert 'await asyncio.to_thread(admin_summary_text)' in text


def test_tls_verification_defaults_to_true():
    assert 'XUI_VERIFY_TLS = True' in (ROOT / "config.example.py").read_text(encoding="utf-8")
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert '"XUI_VERIFY_TLS": True' in installer
    assert 'ensure("XUI_VERIFY_TLS", True)' in installer


def test_fresh_install_skips_xui_smoke_without_api_token():
    text=(ROOT/"install.sh").read_text(encoding="utf-8")
    assert 'XUI_TOKEN_READY=$(target_python -c' in text
    assert 'if [[ "$XUI_TOKEN_READY" == "1" ]]; then' in text
    assert 'API-токен 3x-ui пока не настроен' in text
    assert "request_json_sync(method, path)" in text


def test_publisher_upload_is_release_main_sync_then_local_apply():
    text=(ROOT/"webapp.py").read_text(encoding="utf-8")
    endpoint=text[text.index('@app.post("/updates/publish")'):text.index('@app.post("/updates/upload-and-apply")')]
    assert 'update_manager.publish_update(temp_path, archive.filename or "update.tar.gz")' in endpoint
    assert 'install_info["source"] = "local"' in endpoint
    assert 'update_manager.start_update_job(actor, update_info=install_info)' in endpoint
    assert 'update_manager.update_job_busy()' in endpoint

def test_github_main_sync_contract():
    text=(ROOT/"update_manager.py").read_text(encoding="utf-8")
    cfg=(ROOT/"config.example.py").read_text(encoding="utf-8")
    assert "GITHUB_MAIN_SYNC_ENABLED = True" in cfg
    assert "def _github_main_sync(" in text
    assert "/git/blobs" in text
    assert "/git/trees" in text
    assert "/git/commits" in text
    assert "/git/ref/heads/" in text
    assert "/git/refs/heads/" in text
    assert 'github_request("PATCH", update_ref_path' in text
    assert '"FargoVPN_FULL.tar.gz"' in text
    assert '"FargoVPN_FULL.tar.gz.sha256"' in text
    assert '"github_main_synced"' in text


def test_yandex_runtime_is_davfs2_mount():
    transport = (ROOT / "yandex_webdav.py").read_text(encoding="utf-8")
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert 'DEFAULT_URL = "https://webdav.yandex.ru:443"' in transport
    assert 'DEFAULT_MOUNT_POINT = "/media/YandexDisk"' in transport
    assert '/proc/self/mountinfo' in transport
    assert 'select.select([read_fd], [], [], timeout)' in transport
    assert '["mount"' not in transport
    assert 'configure_credentials' not in transport
    assert 'apt_install' in installer and ' davfs2' in installer
