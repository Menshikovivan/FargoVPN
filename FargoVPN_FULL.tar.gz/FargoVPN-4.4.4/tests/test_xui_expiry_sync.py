import sys
import types

# The release archive normally gets config.py from the installer. Keep these
# focused unit tests runnable in a clean source checkout as well.
if "config" not in sys.modules:
    sys.modules["config"] = types.SimpleNamespace(
        BASE_URL="http://127.0.0.1:2053",
        MASTER_API_TOKEN="test-token",
        XUI_VERIFY_TLS=False,
        XUI_INTERNAL_AUTO_DETECT=False,
        XUI_INTERNAL_BASE_URL="http://127.0.0.1:2053",
        XUI_PANEL_URL="http://127.0.0.1:2053",
        XUI_DB_PATH="",
    )

from services import xui_api


def _record(email, expiry, enable=True):
    client = {"email": email, "expiryTime": expiry, "enable": enable, "uuid": "u1", "subId": "s1"}
    normalized = {"email": email, "uuid": "u1", "sub_id": "s1", "expiry_time": expiry, "enable": enable}
    return {"client": client, "normalized": normalized, "editable_client": dict(client), "inbound_ids": [], "raw": dict(client)}


def test_extend_client_updates_local_state_only_after_xui_verification(monkeypatch):
    email = "KartmanAE+134916406"
    now_ms = 1_800_000_000_000
    old_expiry = now_ms - 7 * 86_400_000
    target = now_ms + 30 * 86_400_000
    calls = {"updates": 0, "reads": 0}

    def fake_get(_email):
        calls["reads"] += 1
        if calls["reads"] == 1:
            return _record(email, old_expiry, True)
        return _record(email, target, True)

    def fake_update(_email, changes, record=None):
        calls["updates"] += 1
        assert changes["expiryTime"] == target
        assert changes["enable"] is True
        return {"success": True, "obj": {}}

    monkeypatch.setattr(xui_api.time, "time", lambda: now_ms / 1000)
    monkeypatch.setattr(xui_api.time, "sleep", lambda _seconds: None)
    monkeypatch.setattr(xui_api, "get_client_record_sync", fake_get)
    monkeypatch.setattr(xui_api, "update_client_sync", fake_update)

    result = xui_api.extend_client_sync(email, 30, tg_id=134916406)

    assert result["expiry_time"] == target
    assert result["enable"] is True
    assert calls == {"updates": 1, "reads": 2}


def test_extend_client_fails_without_actual_xui_expiry_change_and_retries_idempotently(monkeypatch):
    email = "KartmanAE+134916406"
    now_ms = 1_800_000_000_000
    old_expiry = now_ms - 7 * 86_400_000
    target = now_ms + 30 * 86_400_000
    updates = []

    def fake_get(_email):
        return _record(email, old_expiry, True)

    def fake_update(_email, changes, record=None):
        updates.append(dict(changes))
        return {"success": True, "obj": {}}

    monkeypatch.setattr(xui_api.time, "time", lambda: now_ms / 1000)
    monkeypatch.setattr(xui_api.time, "sleep", lambda _seconds: None)
    monkeypatch.setattr(xui_api, "get_client_record_sync", fake_get)
    monkeypatch.setattr(xui_api, "update_client_sync", fake_update)

    try:
        xui_api.extend_client_sync(email, 30, tg_id=134916406)
    except RuntimeError as exc:
        assert "не подтверждено 3x-ui" in str(exc)
    else:
        raise AssertionError("Expected verification failure")

    assert len(updates) == 2
    assert updates[0]["expiryTime"] == target
    assert updates[1]["expiryTime"] == target


def test_editable_client_payload_matches_3x_ui_v38_client_model():
    source = {
        "id": 42,
        "uuid": "uuid-vless-42",
        "email": "KartmanAE+134916406",
        "expiryTime": 1792238800000,
        "enable": True,
        "allowedIPs": "10.10.0.2/32, 10.10.0.3/32",
        "resetDay": 1,
        "resetMax": 2,
        "trafficReset": "monthly",
        "trafficResetDay": 15,
        "limitHwid": 3,
        "forwardedPorts": "80:127.0.0.1:8080",
        "createdAt": 1000,
        "updatedAt": 2000,
    }

    payload = xui_api._editable_client_payload(source)

    assert payload["id"] == "uuid-vless-42"
    assert payload["allowedIPs"] == ["10.10.0.2/32", "10.10.0.3/32"]
    assert payload["resetDay"] == 1
    assert payload["resetMax"] == 2
    assert payload["trafficReset"] == "monthly"
    assert payload["trafficResetDay"] == 15
    assert payload["limitHwid"] == 3
    assert payload["forwardedPorts"] == "80:127.0.0.1:8080"
    assert payload["createdAt"] == 1000
    assert payload["updatedAt"] == 2000
    assert "created_at" not in payload
    assert "updated_at" not in payload
    assert payload["id"] != "42"


def test_extend_client_retries_the_same_absolute_update_after_post_failure(monkeypatch):
    email = "KartmanAE+134916406"
    now_ms = 1_800_000_000_000
    old_expiry = now_ms + 86_400_000
    target = old_expiry + 30 * 86_400_000
    updates = []

    def fake_get(_email):
        # First read supplies the starting state; subsequent reads show the
        # successful result only after the second update attempt.
        if len(updates) < 2:
            return _record(email, old_expiry, True)
        return _record(email, target, True)

    def fake_update(_email, changes, record=None):
        updates.append(dict(changes))
        if len(updates) == 1:
            raise RuntimeError("temporary HTTP 502")
        return {"success": True}

    monkeypatch.setattr(xui_api.time, "time", lambda: now_ms / 1000)
    monkeypatch.setattr(xui_api.time, "sleep", lambda _seconds: None)
    monkeypatch.setattr(xui_api, "get_client_record_sync", fake_get)
    monkeypatch.setattr(xui_api, "update_client_sync", fake_update)

    result = xui_api.extend_client_sync(email, 30, tg_id=134916406)

    assert result["expiry_time"] == target
    assert len(updates) == 2
    assert updates[0]["expiryTime"] == target
    assert updates[1]["expiryTime"] == target


def test_editable_client_payload_converts_csv_allowed_ips_to_string_array():
    source = {"email": "x", "allowedIPs": "10.0.0.2/32, 10.0.0.3/32"}
    payload = xui_api._editable_client_payload(source)
    assert payload["allowedIPs"] == ["10.0.0.2/32", "10.0.0.3/32"]


def test_update_client_sync_sends_allowed_ips_as_array(monkeypatch):
    captured = {}

    def fake_request(method, path, payload=None, **kwargs):
        captured.update(method=method, path=path, payload=payload)
        return {"success": True, "obj": {}}

    monkeypatch.setattr(xui_api, "request_json_sync", fake_request)
    monkeypatch.setattr(xui_api, "invalidate_snapshot_cache", lambda: None)

    record = _record("KartmanAE+134916406", 1789758000000, True)
    record["client"]["allowedIPs"] = "10.0.0.2/32,10.0.0.3/32"
    record["editable_client"] = xui_api._editable_client_payload(record["client"])

    result = xui_api.update_client_sync(
        "KartmanAE+134916406",
        {"expiryTime": 1789733200000, "enable": True},
        record=record,
    )

    assert result["success"] is True
    assert captured["method"] == "POST"
    assert captured["path"].endswith("panel/api/clients/update/KartmanAE%2B134916406")
    assert captured["payload"]["allowedIPs"] == ["10.0.0.2/32", "10.0.0.3/32"]
    assert captured["payload"]["expiryTime"] == 1789733200000
    assert captured["payload"]["enable"] is True
