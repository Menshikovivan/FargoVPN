from pathlib import Path

import yandex_webdav


def test_mount_detection_reads_mountinfo_without_touching_mount(monkeypatch):
    mountinfo = (
        "59 30 0:47 / /media/YandexDisk rw,nosuid,nodev shared:295 "
        "- fuse https://webdav.yandex.ru:443 rw,user_id=0\n"
    )
    monkeypatch.setattr(Path, "read_text", lambda self, **kwargs: mountinfo)
    ok, detail = yandex_webdav.mounted_filesystem("/media/YandexDisk")
    assert ok is True
    assert "fuse" in detail
    assert "webdav.yandex.ru" in detail


def test_missing_mount_fails_without_mount_command(monkeypatch):
    source = Path(yandex_webdav.__file__).read_text(encoding="utf-8")
    monkeypatch.setattr(Path, "read_text", lambda self, **kwargs: "")
    ok, detail = yandex_webdav.mounted_filesystem("/media/YandexDisk")
    assert ok is False
    assert "не смонтирован" in detail
    assert "configure_credentials" not in source
    assert "configure_fstab" not in source
    assert "ensure_mounted" not in source
    assert '["mount"' not in source
    assert '["umount"' not in source


def test_upload_uses_mounted_filesystem_worker(tmp_path, monkeypatch):
    archive = tmp_path / "backup.tar.gz"
    archive.write_bytes(b"FargoVPN" * 1024)
    mount = tmp_path / "media"
    calls = []

    monkeypatch.setattr(
        yandex_webdav,
        "mounted_filesystem",
        lambda mount_point: (True, f"mounted {mount_point}"),
    )

    def fake_operation(operation, *, source, target, payload=b"", timeout_seconds=60):
        calls.append((operation, source, target, timeout_seconds))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())
        return True, "accepted"

    monkeypatch.setattr(yandex_webdav, "_run_filesystem_operation", fake_operation)
    ok, detail = yandex_webdav.upload_file(
        archive,
        directory="Backups",
        mount_point=str(mount),
        retries=1,
        timeout_seconds=17,
    )
    assert ok is True
    assert calls == [("copy", archive, mount / "Backups" / archive.name, 17)]
    assert "davfs2" in detail


def test_filesystem_timeout_is_reported_without_retry_storm(tmp_path, monkeypatch):
    archive = tmp_path / "backup.tar.gz"
    archive.write_bytes(b"archive")
    monkeypatch.setattr(yandex_webdav, "mounted_filesystem", lambda _path: (True, "mounted"))
    calls = []

    def timeout_operation(*args, **kwargs):
        calls.append(1)
        return False, "operation timeout"

    monkeypatch.setattr(yandex_webdav, "_run_filesystem_operation", timeout_operation)
    ok, detail = yandex_webdav.upload_file(
        archive, mount_point=str(tmp_path / "mount"), retries=3, timeout_seconds=1
    )
    assert ok is False
    assert "timeout" in detail
    assert len(calls) == 1


def test_test_write_leaves_visible_file_for_manual_verification(tmp_path, monkeypatch):
    mount = tmp_path / "YandexDisk"
    monkeypatch.setattr(yandex_webdav, "mounted_filesystem", lambda _path: (True, "mounted"))

    def direct_operation(operation, *, source, target, payload=b"", timeout_seconds=60):
        assert operation == "write"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
        return True, f"visible: {target}"

    monkeypatch.setattr(yandex_webdav, "_run_filesystem_operation", direct_operation)
    ok, detail = yandex_webdav.test_write(directory="Checks", mount_point=str(mount))
    assert ok is True
    assert "visible:" in detail
    assert list((mount / "Checks").glob("fargovpn-davfs-test-*.txt"))
