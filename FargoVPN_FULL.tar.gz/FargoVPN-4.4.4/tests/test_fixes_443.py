from __future__ import annotations

import importlib.util
import sqlite3
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_backup_module(monkeypatch):
    config = types.ModuleType("config")
    config.BACKUP_AGE_RECIPIENT = "age1configured"
    config.BACKUP_REQUIRE_REMOTE_ENCRYPTION = True
    config.BACKUP_TELEGRAM = True
    config.ADMIN_IDS = [1]
    config.BOT_TOKEN = "token"
    config.SERVICE_NAME = "FargoVPN"
    config.DB_PATH = "unused"
    config.YANDEX_WEBDAV_ENABLED = True
    config.YANDEX_WEBDAV_URL = "https://webdav.yandex.ru:443"
    config.YANDEX_DAVFS_MOUNT_POINT = "/media/YandexDisk"
    config.YANDEX_DAVFS_SECRETS_FILE = "/etc/davfs2/secrets"
    config.YANDEX_DAVFS_FSTAB_FILE = "/etc/fstab"
    config.YANDEX_WEBDAV_USERNAME = "user"
    config.YANDEX_WEBDAV_APP_PASSWORD = "pass"
    config.YANDEX_WEBDAV_PATH = "VPN-Service-Backups"
    config.YANDEX_UPLOAD_RETRIES = 3
    config.YANDEX_UPLOAD_VERIFY_ATTEMPTS = 8
    config.YANDEX_UPLOAD_VERIFY_DELAY = 1.0
    config.YANDEX_UPLOAD_TIMEOUT_SECONDS = 900
    db = types.ModuleType("db")
    yandex = types.ModuleType("yandex_webdav")
    yandex.DEFAULT_URL = "https://webdav.yandex.ru:443"
    yandex.DEFAULT_MOUNT_POINT = "/media/YandexDisk"
    yandex.DEFAULT_SECRETS_FILE = "/etc/davfs2/secrets"
    yandex.DEFAULT_FSTAB = "/etc/fstab"
    monkeypatch.setitem(sys.modules, "config", config)
    monkeypatch.setitem(sys.modules, "db", db)
    monkeypatch.setitem(sys.modules, "yandex_webdav", yandex)
    spec = importlib.util.spec_from_file_location("backup_443_under_test", ROOT / "backup.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module, config


def extract_conversation_query() -> str:
    text = (ROOT / "user_events.py").read_text(encoding="utf-8")
    start = text.index("def conversation_users(")
    end = text.index("\n\ndef ", start + 1)
    block = text[start:end]
    marker = '"""SELECT events.tg_id,\n'
    query_start = block.index(marker) + 3
    query_end = block.index('"""', query_start)
    return block[query_start:query_end]


def test_conversation_users_groups_by_tg_id_and_keeps_latest_identity():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE users(tg_id INTEGER PRIMARY KEY, username TEXT);
        CREATE TABLE user_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tg_id INTEGER NOT NULL,
            username TEXT,
            direction TEXT,
            created_at TEXT
        );
        INSERT INTO users VALUES (100, 'canonical');
        INSERT INTO user_events(tg_id,username,direction,created_at) VALUES
            (100,'old_name','in','2026-09-20T10:00:00'),
            (100,'new_name','out','2026-09-20T10:01:00'),
            (100,'new_name','in','2026-09-20T10:02:00'),
            (200,'first','in','2026-09-20T09:00:00'),
            (200,'second','in','2026-09-20T09:01:00');
        """
    )
    rows = conn.execute(extract_conversation_query(), (100,)).fetchall()
    assert [row["tg_id"] for row in rows] == [200, 100]
    assert rows[0]["username"] == "second"
    assert rows[0]["total_events"] == 2
    assert rows[1]["username"] == "canonical"
    assert rows[1]["total_events"] == 3


def test_yandex_failure_isolated_from_telegram(monkeypatch, tmp_path):
    backup, _config = load_backup_module(monkeypatch)
    archive = tmp_path / "backup.tar.gz"
    archive.write_bytes(b"archive")
    monkeypatch.setattr(backup, "_destination_enabled", lambda name: name in {"telegram", "yandex"})
    monkeypatch.setattr(backup, "encrypted_delivery_copy", lambda path: path)
    monkeypatch.setattr(backup, "_live_event", lambda *args, **kwargs: None)
    monkeypatch.setattr(backup, "send_to_telegram_sync", lambda path: (True, "sent"))

    def fail_yandex(path):
        raise RuntimeError("WebDAV 401")

    monkeypatch.setattr(backup, "upload_to_yandex", fail_yandex)
    result = backup._deliver_archive(archive)
    assert result["telegram"] == (True, "sent")
    assert result["yandex"] == (False, "WebDAV 401")


def test_empty_legacy_age_recipient_is_recovered_from_keyfile(monkeypatch, tmp_path):
    backup, config = load_backup_module(monkeypatch)
    config.BACKUP_AGE_RECIPIENT = ""
    config.BACKUP_AGE_KEY_FILE = str(tmp_path / "backup.agekey")
    config.BACKUP_REQUIRE_REMOTE_ENCRYPTION = True
    archive = tmp_path / "backup.tar.gz"
    archive.write_bytes(b"archive" * 20)
    calls = []

    monkeypatch.setattr(backup.shutil, "which", lambda name: "/usr/bin/" + name)

    class Result:
        stdout = "age1recovered\n"
        stderr = ""

    def fake_run(command, **kwargs):
        calls.append(command)
        if command[0].endswith("age-keygen") and command[1:3] == ["-o", str(Path(config.BACKUP_AGE_KEY_FILE).with_suffix(".agekey.tmp"))]:
            Path(command[-1]).write_text("# age secret key\n" + "A" * 64, encoding="utf-8")
        elif command[0].endswith("age-keygen") and command[1] == "-y":
            pass
        elif command[0].endswith("age"):
            Path(command[command.index("--output") + 1]).write_bytes(b"encrypted archive" * 4)
        return Result()

    monkeypatch.setattr(backup.subprocess, "run", fake_run)
    encrypted = backup.encrypted_delivery_copy(archive)
    assert encrypted.exists()
    assert encrypted != archive
    assert "age-keygen" in Path(calls[0][0]).name
    assert any(cmd[:2] == ["/usr/bin/age-keygen", "-y"] for cmd in calls)
    assert any(cmd[:2] == ["age", "--recipient"] for cmd in calls)
    assert Path(config.BACKUP_AGE_KEY_FILE).stat().st_mode & 0o777 == 0o600
