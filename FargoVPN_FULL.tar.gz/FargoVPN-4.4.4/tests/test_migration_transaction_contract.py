from pathlib import Path
p=Path(__file__).parents[1] / "migration_tool.py"
t=p.read_text(encoding="utf-8")
assert 'stage="commit"' in t
assert "pg.commit()" in t
assert 'stage="verify_committed"' in t
assert 'pg = database_adapter.connect()' in t
print("migration transaction contract: PASS")
