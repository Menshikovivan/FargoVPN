import sqlite3
from contextlib import contextmanager

import user_events


def _fake_store():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        CREATE TABLE telegram_update_dedup (
            update_id INTEGER PRIMARY KEY,
            chat_id INTEGER, message_id INTEGER, update_type TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'processing',
            first_seen_at TEXT DEFAULT CURRENT_TIMESTAMP,
            processed_at TEXT, lease_until INTEGER NOT NULL DEFAULT 0
        );
        CREATE UNIQUE INDEX uq_message ON telegram_update_dedup(chat_id,message_id,update_type)
            WHERE chat_id IS NOT NULL AND message_id IS NOT NULL AND update_type<>'';
    """)
    return conn


def test_duplicate_update_and_message_are_idempotent(monkeypatch):
    conn = _fake_store()

    @contextmanager
    def fake_connect(_db_path=None):
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise

    monkeypatch.setattr(user_events, "_connect", fake_connect)
    monkeypatch.setattr(user_events, "ensure_schema", lambda _db_path=None: None)

    assert user_events.claim_telegram_update(100, chat_id=1, message_id=10, update_type="message") is True
    assert user_events.claim_telegram_update(100, chat_id=1, message_id=10, update_type="message") is False

    user_events.mark_telegram_update_processed(100)
    assert user_events.claim_telegram_update(101, chat_id=1, message_id=10, update_type="message") is False

    conn.close()


def test_failed_claim_can_be_retried(monkeypatch):
    conn = _fake_store()

    @contextmanager
    def fake_connect(_db_path=None):
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise

    monkeypatch.setattr(user_events, "_connect", fake_connect)
    monkeypatch.setattr(user_events, "ensure_schema", lambda _db_path=None: None)

    assert user_events.claim_telegram_update(200, chat_id=2, message_id=20, update_type="message") is True
    user_events.release_telegram_update(200)
    assert user_events.claim_telegram_update(201, chat_id=2, message_id=20, update_type="message") is True

    conn.close()


def test_zero_update_id_is_still_deduplicated(monkeypatch):
    conn = _fake_store()

    @contextmanager
    def fake_connect(_db_path=None):
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise

    monkeypatch.setattr(user_events, "_connect", fake_connect)
    monkeypatch.setattr(user_events, "ensure_schema", lambda _db_path=None: None)

    assert user_events.claim_telegram_update(0, chat_id=3, message_id=30, update_type="message") is True
    user_events.mark_telegram_update_processed(0)
    assert user_events.claim_telegram_update(0, chat_id=3, message_id=30, update_type="message") is False
    conn.close()
