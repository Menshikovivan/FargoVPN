import pytest
from starlette.testclient import TestClient

@pytest.fixture
def client():
    import webapp
    return TestClient(webapp.app)
