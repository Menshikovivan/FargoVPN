from __future__ import annotations
import os, re, json
from pathlib import Path
import sqlite3
import pytest

ROOT = Path(__file__).resolve().parents[1]
DB = os.getenv("FARGOVPN_REFERENCE_SQLITE")

def test_postgres_schema_covers_reference_tables():
    source = Path(DB) if DB else None
    if source is None or not source.is_file():
        pytest.skip("Set FARGOVPN_REFERENCE_SQLITE to run reference-schema check")
    conn=sqlite3.connect(source)
    try:
        tables=[r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        text=(ROOT/"init_db.py").read_text()
        for table in tables:
            assert re.search(rf"CREATE TABLE IF NOT EXISTS\s+{re.escape(table)}\s*\(", text)
            cols=[r[1] for r in conn.execute(f'PRAGMA table_info("{table}")')]
            # init_db.py is source-controlled schema; exact per-table column checks
            # are performed by migration_tool.py after a real PostgreSQL migration.
            assert cols
    finally:
        conn.close()

def test_runtime_does_not_connect_to_application_sqlite():
    allowed={"migration_tool.py","identity_migration.py","verify_postgresql_migration.py"}
    for path in ROOT.rglob("*.py"):
        if "__pycache__" in path.parts or "tests" in path.parts or path.name in allowed:
            continue
        text=path.read_text(errors="ignore")
        assert "sqlite3.connect(" not in text or path.name == "xui_api.py"

def test_backup_contains_postgres_snapshot_code():
    backup=(ROOT/"backup.py").read_text()
    assert "pg_dump" in backup
    assert 'databases / "fargovpn.sql"' in backup
    assert "vpn_bot.db" not in backup[backup.find("def create_backup"):backup.find("def cleanup_old_backups")]

def test_migration_tool_has_deterministic_fingerprint():
    text=(ROOT/"migration_tool.py").read_text()
    assert "sha256" in text
    assert "ORDER BY" in text
    assert "migration_manifest" in text
    assert "migration_report" in text
