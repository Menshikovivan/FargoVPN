#!/usr/bin/env python3
"""Yandex.Disk transport through an already mounted davfs2 filesystem.

System configuration is deliberately outside the application: an administrator
installs davfs2, stores credentials in /etc/davfs2/secrets and mounts Yandex.Disk.
FargoVPN only verifies the mount and performs bounded filesystem operations.
"""
from __future__ import annotations

import logging
import json
import os
import select
import signal
import shutil
import time
from pathlib import Path

logger = logging.getLogger("vpn-service-backup.yandex")
DEFAULT_URL = "https://webdav.yandex.ru:443"
DEFAULT_MOUNT_POINT = "/media/YandexDisk"


def clean_remote_path(path: str) -> str:
    parts = [part for part in str(path or "").replace("\\", "/").split("/") if part]
    if any(part in {".", ".."} for part in parts):
        raise ValueError("Путь Яндекс.Диска не должен содержать . или ..")
    return "/".join(parts)


def _decode_mount_path(value: str) -> str:
    return (
        str(value)
        .replace("\\040", " ")
        .replace("\\011", "\t")
        .replace("\\012", "\n")
        .replace("\\134", "\\")
    )


def mounted_filesystem(mount_point: str = DEFAULT_MOUNT_POINT) -> tuple[bool, str]:
    """Inspect mountinfo without stat'ing a potentially stale FUSE endpoint."""
    wanted = os.path.abspath(str(mount_point or DEFAULT_MOUNT_POINT))
    try:
        lines = Path("/proc/self/mountinfo").read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        return False, f"Не удалось прочитать /proc/self/mountinfo: {exc}"
    for line in lines:
        left, separator, right = line.partition(" - ")
        fields = left.split()
        if not separator or len(fields) < 6 or _decode_mount_path(fields[4]) != wanted:
            continue
        right_fields = right.split()
        fs_type = right_fields[0] if right_fields else "unknown"
        source = _decode_mount_path(right_fields[1]) if len(right_fields) > 1 else "unknown"
        return True, f"{wanted} смонтирован ({fs_type}, {source})"
    return False, (
        f"Яндекс.Диск не смонтирован в {wanted}. "
        "Смонтируйте его на хосте через davfs2; приложение mount не выполняет."
    )


def _target_path(mount_point: str, directory: str, filename: str | None = None) -> Path:
    mount = Path(os.path.abspath(str(mount_point or DEFAULT_MOUNT_POINT)))
    clean = clean_remote_path(directory)
    target = mount.joinpath(*clean.split("/")) if clean else mount
    if filename:
        target = target / Path(filename).name
    return target


def _filesystem_action(
    operation: str,
    source_name: str,
    target_name: str,
    payload: bytes,
) -> tuple[bool, str]:
    try:
        target = Path(target_name)
        if operation == "probe":
            target.mkdir(parents=True, exist_ok=True)
            target.stat()
            result = (True, f"Каталог доступен: {target}")
        elif operation == "copy":
            source = Path(source_name)
            target.parent.mkdir(parents=True, exist_ok=True)
            with source.open("rb") as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst, length=1024 * 1024)
                dst.flush()
                os.fsync(dst.fileno())
            actual = target.stat().st_size
            expected = source.stat().st_size
            if actual != expected:
                raise RuntimeError(f"Размер копии {actual} байт вместо {expected}")
            result = (True, f"Принято смонтированной файловой системой: {target} ({actual} байт)")
        elif operation == "write":
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            actual = target.stat().st_size
            if actual != len(payload):
                raise RuntimeError(f"Размер тестового файла {actual} байт вместо {len(payload)}")
            result = (True, f"Тестовый файл оставлен для проверки на Диске: {target} ({actual} байт)")
        elif operation == "matches":
            source = Path(source_name)
            expected = source.stat().st_size
            actual = target.stat().st_size if target.is_file() else -1
            result = (
                actual == expected,
                f"Размер {actual} байт" if actual >= 0 else f"Файл не найден: {target}",
            )
        else:
            raise ValueError(f"Неизвестная файловая операция: {operation}")
        return result
    except BaseException as exc:
        return False, str(exc)


def _run_filesystem_operation(
    operation: str,
    *,
    source: Path | None,
    target: Path,
    payload: bytes = b"",
    timeout_seconds: float = 60.0,
) -> tuple[bool, str]:
    timeout = max(1.0, float(timeout_seconds))
    read_fd, write_fd = os.pipe()
    pid = os.fork()
    if pid == 0:
        # Use os._exit so the isolated FUSE worker never runs application
        # cleanup/finalizers inherited from the bot or web process.
        try:
            os.close(read_fd)
            result = _filesystem_action(
                operation, str(source or ""), str(target), payload
            )
            encoded = json.dumps(result, ensure_ascii=False).encode("utf-8")
            os.write(write_fd, encoded)
        except BaseException:
            pass
        finally:
            try:
                os.close(write_fd)
            except OSError:
                pass
            os._exit(0)
    os.close(write_fd)
    ready, _, _ = select.select([read_fd], [], [], timeout)
    if not ready:
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        os.close(read_fd)
        # Do not wait here: waitpid can itself block while a FUSE operation is
        # stuck in uninterruptible kernel sleep. The short-lived backup worker
        # may exit immediately and init will reap the orphaned child.
        return False, (
            f"Операция с {target} превысила timeout {timeout:g} сек. "
            "Возможен зависший davfs2 mount; Telegram-доставка продолжает работать независимо."
        )
    try:
        chunks: list[bytes] = []
        while True:
            chunk = os.read(read_fd, 65536)
            if not chunk:
                break
            chunks.append(chunk)
        try:
            os.waitpid(pid, 0)
        except ChildProcessError:
            pass
        if not chunks:
            return False, "Файловый worker завершился без результата"
        ok, detail = json.loads(b"".join(chunks).decode("utf-8"))
        return bool(ok), str(detail)
    except (OSError, UnicodeError, ValueError, TypeError) as exc:
        return False, f"Не удалось получить результат файлового worker: {exc}"
    finally:
        try:
            os.close(read_fd)
        except OSError:
            pass


def upload_file(
    path: Path,
    *,
    username: str = "",
    password: str = "",
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = "",
    fstab_file: str = "",
    retries: int = 1,
    verify_attempts: int = 1,
    verify_delay: float = 0.0,
    timeout_seconds: float = 900.0,
) -> tuple[bool, str]:
    del username, password, base_url, secrets_file, fstab_file, verify_attempts, verify_delay
    source = Path(path)
    if not source.is_file():
        return False, f"Архив не найден: {source}"
    if source.stat().st_size <= 0:
        return False, "Архив пуст"
    mounted, mount_detail = mounted_filesystem(mount_point)
    if not mounted:
        return False, mount_detail
    destination = _target_path(mount_point, directory, source.name)
    attempts = max(1, int(retries))
    last_detail = "неизвестная ошибка"
    for attempt in range(1, attempts + 1):
        ok, detail = _run_filesystem_operation(
            "copy", source=source, target=destination, timeout_seconds=timeout_seconds
        )
        if ok:
            logger.info(
                "davfs2 copy accepted file=%s size=%d target=%s attempt=%d/%d",
                source.name, source.stat().st_size, destination, attempt, attempts,
            )
            return True, f"{detail}. Передачу на сервер завершает davfs2"
        last_detail = detail
        logger.warning(
            "davfs2 copy failed file=%s attempt=%d/%d: %s",
            source.name, attempt, attempts, detail,
        )
        if "timeout" in detail.lower():
            break
        if attempt < attempts:
            time.sleep(1.0)
    return False, f"Копирование через davfs2 не выполнено: {last_detail}"


def test_connection(
    username: str = "",
    password: str = "",
    *,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = "",
    fstab_file: str = "",
    timeout_seconds: float = 30.0,
) -> tuple[bool, str]:
    del username, password, base_url, secrets_file, fstab_file
    mounted, detail = mounted_filesystem(mount_point)
    if not mounted:
        return False, detail
    target = _target_path(mount_point, directory)
    ok, probe_detail = _run_filesystem_operation(
        "probe", source=None, target=target, timeout_seconds=timeout_seconds
    )
    return ok, f"{detail}; {probe_detail}"


def test_write(
    username: str = "",
    password: str = "",
    *,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = "",
    fstab_file: str = "",
    timeout_seconds: float = 60.0,
) -> tuple[bool, str]:
    del username, password, base_url, secrets_file, fstab_file
    mounted, detail = mounted_filesystem(mount_point)
    if not mounted:
        return False, detail
    name = f"fargovpn-davfs-test-{time.time_ns()}.txt"
    target = _target_path(mount_point, directory, name)
    payload = f"FargoVPN davfs2 test {time.time_ns()}\n".encode("utf-8")
    return _run_filesystem_operation(
        "write", source=None, target=target, payload=payload, timeout_seconds=timeout_seconds
    )


def remote_file_matches(
    path: Path,
    *,
    username: str = "",
    password: str = "",
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = "",
    fstab_file: str = "",
    timeout_seconds: float = 30.0,
) -> tuple[bool, str]:
    del username, password, base_url, secrets_file, fstab_file
    source = Path(path)
    if not source.is_file():
        return False, f"Локальная копия не найдена: {source}"
    mounted, detail = mounted_filesystem(mount_point)
    if not mounted:
        return False, detail
    target = _target_path(mount_point, directory, source.name)
    return _run_filesystem_operation(
        "matches", source=source, target=target, timeout_seconds=timeout_seconds
    )
