# FargoVPN 4.4.0 — обновление

Обновление рассчитано на существующую установку FargoVPN. Установщик сохраняет пользовательский `config.py`, выполняет существующие миграции и обновляет systemd-службы. Схема 3x-ui не изменяется.

```bash
cd /путь/к/FargoVPN-4.4.0
sudo bash ./install.sh --update-existing /root/vpn_bot
```

После обновления проверьте:

```bash
systemctl is-active vpn-service-bot.service
systemctl is-active vpn-service-web.service
systemctl is-enabled vpn-service-backup.timer
systemctl list-timers vpn-service-backup.timer --no-pager
```

Для ручной проверки бэкапа используйте кнопку `💾 Бэкап` в Telegram-админке. Она запускает `backup.py --force`; результат доставки записывается в журнал `backup_runs` и сохраняется в состоянии очереди повторной доставки при временной ошибке.

Перед обновлением сохраните внешний age-ключ резервных копий `/root/.config/fargovpn/backup.agekey` вне сервера.
