# FargoVPN 4.3.6 hardened: обновление и проверка

Автоодобрение OCR сохранено намеренно. Его параметры и текущая логика фильтров не менялись.

## 1. Резервная копия перед обновлением

```bash
sudo systemctl stop vpn-service-bot vpn-service-web
sudo -u postgres pg_dump -Fc fargovpn > /root/fargovpn-before-436.dump
sudo cp -a /root/vpn_bot /root/vpn_bot.before-436
sudo systemctl start vpn-service-web vpn-service-bot
```

Если имя базы отличается, возьмите его из `DATABASE_URL`. Отдельно сохраните базу 3x-ui по её `XUI_DB_DSN`.

## 2. Установка

Проверьте SHA-256 полученного архива, распакуйте его и запустите:

```bash
cd /путь/к/FargoVPN-4.3.6
sudo bash ./install.sh --update-existing /root/vpn_bot
```

Если Nginx Mask уже установлен, installer его не скачивает. Для первой установки Mask требуется заранее проверенный SHA-256 внешнего installer:

```bash
sudo env MASK_INSTALLER_SHA256='<64 hex>' bash ./install.sh --profile full
```

## 3. Ключ резервных копий

Installer создаёт `/root/.config/fargovpn/backup.agekey`, а публичный recipient добавляет в `config.py`. Немедленно скопируйте приватный ключ в офлайн-хранилище:

```bash
sudo age-keygen -y /root/.config/fargovpn/backup.agekey
sudo install -m 0600 /root/.config/fargovpn/backup.agekey /подключённый-защищённый-носитель/fargovpn-backup.agekey
```

Для расшифровки внешнего файла:

```bash
age --decrypt -i fargovpn-backup.agekey -o backup.tar.gz backup.tar.gz.age
```

## 4. Миграция и проверка

```bash
sudo /root/vpn_bot/.venv/bin/python /root/vpn_bot/init_db.py
sudo systemctl daemon-reload
sudo systemctl restart vpn-service-bot vpn-service-web vpn-service-nginx-guard
sudo systemctl --no-pager --full status vpn-service-bot vpn-service-web
curl --unix-socket /run/vpn-service/fargovpn.sock http://localhost/health
sudo journalctl -u vpn-service-bot -u vpn-service-web -n 100 --no-pager
```

Проверьте вручную: вход в панель, отправку сообщения одному пользователю, тестовую рассылку, повторное нажатие подтверждения одного платежа, открытие кабинета и создание encrypted backup.

Новые клиенты по умолчанию добавляются только в активные VLESS inbound. Для точного выбора задайте в `config.py`:

```python
XUI_MANAGED_INBOUND_IDS = [1, 3]
XUI_MANAGED_PROTOCOLS = ["vless"]
```

## 5. Безопасное восстановление

Веб-восстановление поверх рабочих баз отключено. Создайте новые staging-базы:

```bash
sudo /root/vpn_bot/.venv/bin/python /root/vpn_bot/restore_staged.py \
  /var/backups/vpn-service/vpn_service_full_backup_YYYYMMDD_HHMMSS.tar.gz \
  --app-dsn 'postgresql+psycopg://USER:PASSWORD@127.0.0.1:5432/fargovpn' \
  --xui-dsn 'postgresql://USER:PASSWORD@127.0.0.1:5432/xui'
```

Скрипт не переключает production автоматически. Сначала сравните счётчики и пользователей, затем остановите службы, замените DSN и запустите `init_db.py`. Откат — вернуть прежние DSN и перезапустить службы; staging-базы до завершения проверки не удалять.

## 6. Откат приложения

```bash
sudo systemctl stop vpn-service-bot vpn-service-web
sudo mv /root/vpn_bot /root/vpn_bot.failed-436
sudo mv /root/vpn_bot.before-436 /root/vpn_bot
sudo systemctl daemon-reload
sudo systemctl start vpn-service-web vpn-service-bot
```

Если миграция только добавила таблицы/индексы, старый код продолжит работать с прежней БД. Если данные уже восстанавливались в staging, для отката достаточно вернуть прежние DSN.
