# FargoVPN 4.4.1 — исправление бэкапов

После обновления проверьте без вывода секретов:

```bash
systemctl daemon-reload
systemctl restart vpn-service-bot.service vpn-service-web.service
systemctl restart vpn-service-backup.timer
systemctl status vpn-service-backup.timer --no-pager
```

Проверьте настройки `config.py`:

- `DATABASE_URL` — действующая PostgreSQL база FargoVPN;
- для 3x-ui PostgreSQL: `XUI_DB_TYPE=postgres` и `XUI_DB_DSN` в `/etc/default/x-ui`;
- для legacy 3x-ui SQLite: существует `XUI_DB_PATH` (обычно `/etc/x-ui/x-ui.db`);
- `BACKUP_TELEGRAM=True`, корректный `ADMIN_IDS`;
- `BACKUP_AGE_RECIPIENT` настроен, если `BACKUP_REQUIRE_REMOTE_ENCRYPTION=True`;
- `YANDEX_WEBDAV_ENABLED=True`, `YANDEX_WEBDAV_URL=https://webdav.yandex.ru`, логин и пароль приложения заданы.

Ручная проверка:

```bash
cd /root/vpn_bot
.venv/bin/python backup.py --force
```

Результат смотрите в:

```bash
journalctl -u vpn-service-backup.service -n 100 --no-pager
```

В веб-панели откройте «Бэкапы». В Telegram нажмите `💾 Бэкап`. Оба запуска используют `backup.py --force`.

Не выводите содержимое `config.py`, токены, пароли и age private key в чат или журналы.
