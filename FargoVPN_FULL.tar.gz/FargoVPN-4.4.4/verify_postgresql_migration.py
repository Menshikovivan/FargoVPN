#!/usr/bin/env python3
"""Verify existing FargoVPN PostgreSQL data against a SQLite snapshot, read-only."""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os, sqlite3
import db as adapter

def norm(v):
    if isinstance(v,(dt.datetime,dt.date,dt.time)): return v.isoformat()
    if isinstance(v,memoryview): return "B64:"+bytes(v).hex()
    if isinstance(v,(bytes,bytearray)): return "B64:"+bytes(v).hex()
    if isinstance(v,bool): return "BOOL:"+("1" if v else "0")
    if isinstance(v,float): return f"FLOAT:{v:.17g}"
    return "NULL" if v is None else "VAL:"+str(v)

def digest(row):
    return hashlib.sha256(("\x1f".join(norm(v) for v in row)+"\n").encode()).hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--sqlite", required=True)
    ap.add_argument("--dsn", default="")
    args=ap.parse_args()
    dsn=args.dsn or os.environ.get("DATABASE_URL","")
    if not dsn:
        raise SystemExit("DATABASE_URL or --dsn is required")
    s=sqlite3.connect(args.sqlite)
    s.row_factory=sqlite3.Row
    pg=None
    try:
        os.environ["FARGOVPN_DATABASE_URL"]=dsn
        adapter.dispose()
        pg=adapter.connect()
        tables=[r[0] for r in s.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )]
        result={"status":"PASS","tables":{}}
        for t in tables:
            cols=[r[1] for r in s.execute(
                f'PRAGMA table_info("{t.replace(chr(34),chr(34)*2)}")'
            )]
            qcols=", ".join('"'+c.replace('"','""')+'"' for c in cols)
            sq=s.execute(f'SELECT {qcols} FROM "{t.replace(chr(34),chr(34)*2)}"').fetchall()
            pq=pg.execute(f'SELECT {qcols} FROM "{t.replace(chr(34),chr(34)*2)}"').fetchall()
            sh=sorted(digest(tuple(r)) for r in sq)
            ph=sorted(digest(tuple(r)) for r in pq)
            ok=len(sq)==len(pq) and sh==ph
            result["tables"][t]={
                "sqlite_rows":len(sq),
                "postgresql_rows":len(pq),
                "status":"PASS" if ok else "FAIL"
            }
            if not ok:
                result["status"]="FAIL"
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["status"]=="PASS" else 2
    finally:
        if pg: pg.close()
        s.close()

if __name__=="__main__":
    raise SystemExit(main())
