param(
    [string]$BaseUrl = $env:FARGOVPN_BASE_URL,
    [string]$Username = $env:FARGOVPN_USERNAME,
    [string]$Password = $env:FARGOVPN_PASSWORD,
    [string]$PanelPrefix = $env:FARGOVPN_PANEL_PREFIX,
    [switch]$Headed
)
$ErrorActionPreference = 'Stop'
if (-not $BaseUrl) { $BaseUrl = 'https://example.invalid/fargovpn-admin/' }
if (-not $Username) { $Username = Read-Host 'FargoVPN login' }
if (-not $Password) { $Password = Read-Host 'FargoVPN password' -AsSecureString; $Password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($Password)) }
$env:FARGOVPN_BASE_URL = $BaseUrl
$env:FARGOVPN_USERNAME = $Username
$env:FARGOVPN_PASSWORD = $Password
$args = @('tools/fargovpn_button_autotest.py', '--base-url', $BaseUrl)
if ($PanelPrefix) { $args += @('--panel-prefix', $PanelPrefix) }
if ($Headed) { $args += '--headed' }
python @args
exit $LASTEXITCODE
