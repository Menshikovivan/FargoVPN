#!/usr/bin/env python3
"""Real browser regression test for FargoVPN admin Push UI.
Requires Playwright: python -m pip install playwright && python -m playwright install chromium
Credentials are supplied only through env vars or CLI; nothing is hard-coded.
"""
from __future__ import annotations
import argparse
import csv
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
import shutil
from typing import Any

from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError


BUTTONS = [
    ("Проверить", "panel-push-check"),
    ("Обновить журнал", "panel-push-log-refresh"),
    ("Включить", "panel-push-enable"),
    ("Тест", "panel-push-test"),
    ("Выключить", "panel-push-disable"),
]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--base-url", default=os.getenv("FARGOVPN_BASE_URL", "https://example.invalid/fargovpn-admin/"))
    p.add_argument("--username", default=os.getenv("FARGOVPN_USERNAME", ""))
    p.add_argument("--password", default=os.getenv("FARGOVPN_PASSWORD", ""))
    p.add_argument("--out", default=os.getenv("FARGOVPN_AUTOTEST_OUT", str(Path.home() / "FargoVPN-Autotest")))
    p.add_argument("--headed", action="store_true")
    p.add_argument("--dry-run", action="store_true", help="Resolve the panel URL/prefix and exit without starting Playwright")
    p.add_argument("--panel-prefix", default=os.getenv("FARGOVPN_PANEL_PREFIX", ""), help="Optional public panel prefix, e.g. /fargovpn-admin-...")
    p.add_argument("--config", default=os.getenv("FARGOVPN_CONFIG", "/root/vpn_bot/config.py"), help="Optional FargoVPN config.py used for local auto-detection of WEB_PUBLIC_PREFIX")
    return p.parse_args()


def resolve_panel_target(base: str, explicit: str, config_file: str) -> tuple[str, str, str, bool]:
    parsed_base = re.match(r"^(https?://[^/]+)(/.*)?$", base)
    if not parsed_base:
        raise RuntimeError(f"Некорректный --base-url: {base}")
    origin = parsed_base.group(1)
    base_path = (parsed_base.group(2) or "/").split("?", 1)[0].split("#", 1)[0].rstrip("/") or "/"

    def config_prefix() -> str:
        cfg = Path(config_file).expanduser()
        if not cfg.is_file():
            return ""
        try:
            text = cfg.read_text(encoding="utf-8", errors="replace")
            m = re.search(r"^\s*WEB_PUBLIC_PREFIX\s*=\s*['\"]([^'\"]*)['\"]", text, re.MULTILINE)
            value = (m.group(1) if m else "").strip()
            return ("/" + value.strip("/")) if value else ""
        except Exception:
            return ""

    if explicit:
        prefix = "/" + explicit.strip("/")
    elif base_path not in ("", "/"):
        prefix = re.sub(r"/login/?$", "", base_path).rstrip("/")
    else:
        prefix = config_prefix()
    app_root = origin + (prefix + "/" if prefix else "/")
    return origin, prefix, app_root, base_path not in ("", "/")


def main() -> int:
    args = parse_args()
    if not args.dry_run and (not args.username or not args.password):
        print("ERROR: set FARGOVPN_USERNAME and FARGOVPN_PASSWORD or pass --username/--password", file=sys.stderr)
        return 2
    base = args.base_url.rstrip("/") + "/"
    out = Path(args.out).expanduser()
    out.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    csv_path = out / f"fargovpn_button_autotest_{stamp}.csv"
    txt_path = out / f"fargovpn_button_autotest_{stamp}.log"
    rows: list[dict[str, Any]] = []
    console_errors: list[str] = []
    network_events: list[dict[str, Any]] = []

    def record(name: str, success: bool, status: str, detail: str, elapsed_ms: float = 0.0) -> None:
        row = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "check": name,
            "success": success,
            "status": status,
            "elapsed_ms": round(elapsed_ms, 1),
            "detail": detail,
        }
        rows.append(row)
        line = f"[{row['timestamp']}] {name} | {'PASS' if success else 'FAIL'} | {status} | {elapsed_ms:.1f} ms | {detail}"
        txt_path.write_text((txt_path.read_text(encoding='utf-8') if txt_path.exists() else '') + line + "\n", encoding="utf-8")
        print(line)

    # Resolve the target before starting a browser. This makes --dry-run useful
    # on headless/server environments where outbound browser navigation may be restricted.
    pre_origin, pre_prefix, pre_app_root, pre_has_path = resolve_panel_target(base, (args.panel_prefix or "").strip(), args.config)
    if args.dry_run:
        if not pre_prefix:
            print("ERROR: public prefix не найден. Укажите --panel-prefix или проверьте WEB_PUBLIC_PREFIX в config.py.", file=sys.stderr)
            return 2
        print(f"base-url={base}")
        print(f"config={args.config}")
        print(f"panel-prefix={pre_prefix}")
        print(f"panel-root={pre_app_root}")
        return 0

    with sync_playwright() as pw:
        executable = shutil.which('chromium') or pw.chromium.executable_path
        browser = pw.chromium.launch(headless=not args.headed, executable_path=executable)
        context = browser.new_context(ignore_https_errors=False, viewport={"width": 390, "height": 844}, service_workers="allow")
        try:
            context.grant_permissions(["notifications"], origin=re.match(r"https?://[^/]+", base).group(0))
        except Exception:
            pass
        page = context.new_page()
        page.on("console", lambda msg: console_errors.append(f"{msg.type}: {msg.text}") if msg.type == "error" else None)
        page.on("requestfinished", lambda req: network_events.append({"method": req.method, "url": req.url, "status": req.response().status if req.response() else None}))
        page.on("requestfailed", lambda req: network_events.append({"method": req.method, "url": req.url, "status": "FAILED", "failure": req.failure}))

        # 1. Open the supplied URL and establish the real public panel root.
        origin, prefix, app_root, base_has_path = resolve_panel_target(base, (args.panel_prefix or "").strip(), args.config)
        page.goto(base, wait_until="domcontentloaded", timeout=30000)

        def meta_prefix() -> str:
            for selector in (
                'meta[name="fargovpn-canonical-path"]',
                'meta[name="fargovpn-sw-scope"]',
            ):
                node = page.locator(selector).first
                if node.count():
                    value = (node.get_attribute("content") or "").strip()
                    if value.startswith("/") and value != "/":
                        return value.rstrip("/")
            return ""

        prefix = prefix or meta_prefix()
        looks_like_panel = bool(page.locator('input[name="username"]').count() and page.locator('input[name="password"]').count())

        if not prefix and not looks_like_panel:
            raise RuntimeError(
                "Не удалось определить public prefix панели. "
                "Запущенный на сервере тест автоматически проверил локальный config.py, но WEB_PUBLIC_PREFIX там не найден. "
                "Укажите --panel-prefix /fargovpn-admin-... или передайте --base-url полным URL панели."
            )

        app_root = origin + (prefix + "/" if prefix else "/")

        # Navigate to the canonical panel login unless the supplied URL is
        # already the actual panel page.
        if not looks_like_panel and page.url.rstrip("/") != app_root.rstrip("/"):
            page.goto(app_root + "login", wait_until="domcontentloaded", timeout=30000)

        # Re-read prefix from FargoVPN's own metadata after landing on the panel.
        prefix = prefix or meta_prefix()
        app_root = origin + (prefix + "/" if prefix else "/")
        if not page.locator('input[name="username"]').count():
            raise RuntimeError(f"Не найдена форма входа FargoVPN: {page.url}. Проверьте --panel-prefix={prefix or '<missing>'}.")

        page.fill('input[name="username"]', args.username)
        page.fill('input[name="password"]', args.password)
        page.click("#login-submit")
        page.wait_for_timeout(1500)
        try:
            page.wait_for_load_state("domcontentloaded", timeout=5000)
        except PlaywrightTimeoutError:
            pass

        # Login succeeds only when the browser leaves /login and the protected
        # root can be opened again with the same browser session.
        page.goto(app_root, wait_until="networkidle", timeout=30000)
        login_ok = "/login" not in page.url and bool(page.locator("#panel-push-status, nav, .sidebar").count())
        record("login", login_ok, "BROWSER", f"url={page.url}; app_root={app_root}")
        if not login_ok:
            raise RuntimeError(f"Login did not establish an authenticated panel session: final URL {page.url}")

        # 2. Settings/Notifications page.
        settings_url = app_root.rstrip("/") + "/settings#notifications"
        page.goto(settings_url, wait_until="networkidle", timeout=30000)
        page.wait_for_selector("#panel-push-status", state="attached", timeout=15000)
        body_text = page.locator("body").inner_text()
        raw_js_markers = (
            "const ps=document.getElementById('panel-push-status')",
            "window.__fargovpnPushBooted",
            "const renderLogs=async()",
            "const panelPush",
        )
        raw_js_leak = any(marker in body_text for marker in raw_js_markers)
        record("raw-js-leak", not raw_js_leak, "DOM", "raw Push JS visible in body text" if raw_js_leak else "no raw Push JS in visible DOM text")

        sw = page.evaluate("""async () => ({
          secure: window.isSecureContext,
          notifications: ('Notification' in window ? Notification.permission : 'unsupported'),
          registrations: ('serviceWorker' in navigator) ? (await navigator.serviceWorker.getRegistrations()).map(r => ({scope:r.scope, active:r.active?.scriptURL || null})) : [],
          manifest: document.querySelector('link[rel=manifest]')?.href || null,
          canonical: document.querySelector('meta[name=fargovpn-canonical-path]')?.content || null,
          pushStatusExists: !!document.getElementById('panel-push-status')
        })""")
        record("browser-service-worker", bool(sw.get("registrations")), "BROWSER", str(sw), 0)
        record("secure-context", bool(sw.get("secure")), "BROWSER", f"secure={sw.get('secure')}; notification={sw.get('notifications')}")

        # 3. Exercise every Push control and capture DOM + network + console changes.
        for label, element_id in BUTTONS:
            before_state = page.locator("#panel-push-status").inner_text()
            before_log = page.locator("#panel-push-log").inner_text()
            started = time.perf_counter()
            before_count = len(network_events)
            console_before = len(console_errors)
            try:
                page.click(f"#{element_id}")
                page.wait_for_timeout(1500)
                after_state = page.locator("#panel-push-status").inner_text()
                after_log = page.locator("#panel-push-log").inner_text()
                elapsed = (time.perf_counter() - started) * 1000
                events = network_events[before_count:]
                relevant = [e for e in events if "/api/panel/push/" in e.get("url", "")]
                request_summary = "; ".join(
                    f"{e['method']} {e['url'].split('?')[0]} -> {e['status']}" for e in relevant[-8:]
                ) or "no push API request observed"
                changed = (after_state != before_state) or (after_log != before_log)
                new_console = console_errors[console_before:]
                # A test with zero registered subscriptions may legitimately return
                # an application-level error; it still must produce a request and no JS crash.
                expected_clean_failure = label == "Тест" and after_state == "Ошибка" and bool(relevant) and not new_console
                success = bool(relevant) and changed and not new_console or expected_clean_failure
                detail = (
                    f"state={before_state!r}->{after_state!r}; "
                    f"log_changed={after_log != before_log}; {request_summary}; "
                    f"console_errors={len(new_console)}"
                )
                record(f"button:{label}", success, "UI", detail, elapsed)
            except Exception as exc:
                try:
                    page.screenshot(path=str(out / f"failure_{element_id}_{stamp}.png"), full_page=True)
                    (out / f"failure_{element_id}_{stamp}.html").write_text(page.content(), encoding="utf-8")
                except Exception:
                    pass
                record(f"button:{label}", False, "EXCEPTION", repr(exc), (time.perf_counter() - started) * 1000)

        # Reopen PWA start URL and verify session persists in same browser profile.
        page.goto(app_root, wait_until="networkidle", timeout=30000)
        record("session-reload", "/login" not in page.url, "BROWSER", f"url={page.url}; app_root={app_root}")
        context.close()
        browser.close()

    with csv_path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=["timestamp", "check", "success", "status", "elapsed_ms", "detail"])
        writer.writeheader(); writer.writerows(rows)
    (out / f"fargovpn_button_autotest_{stamp}_network.json").write_text(__import__('json').dumps(network_events, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / f"fargovpn_button_autotest_{stamp}_console.txt").write_text("\n".join(console_errors), encoding="utf-8")
    failed = [r for r in rows if not r["success"]]
    print(f"SUMMARY PASS={len(rows)-len(failed)} FAIL={len(failed)} CSV={csv_path}")
    return 1 if failed else 0

if __name__ == "__main__":
    raise SystemExit(main())
