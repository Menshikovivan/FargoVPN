<#
FargoVPN client-side diagnostic for Windows PowerShell 5.1 / 7+.
This script performs HTTP/TLS/API timing checks without installing a browser engine.
True browser Service Worker/Push registration cannot be proven by pure HTTP; the
script therefore reports HTTP availability and clearly marks browser-only checks.
#>
[CmdletBinding()]
param(
    [string]$BaseUrl = "https://example.invalid/fargovpn-admin/",
    [string]$OutputDir = "$env:USERPROFILE\FargoVPN-Diagnostics"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$csvPath = Join-Path $OutputDir "fargovpn_diagnostic_$stamp.csv"
$txtPath = Join-Path $OutputDir "fargovpn_diagnostic_$stamp.txt"

$BaseUrl = $BaseUrl.TrimEnd('/') + '/'
$uri = [Uri]$BaseUrl
$prefix = $uri.AbsolutePath.TrimEnd('/')

$results = New-Object System.Collections.Generic.List[object]

function Add-Result {
    param([string]$Name,[bool]$Success,[string]$Status,[double]$Ms,[string]$Details)
    $row = [pscustomobject]@{
        Timestamp = (Get-Date).ToString('o')
        Check = $Name
        Success = $Success
        Status = $Status
        ResponseMs = [math]::Round($Ms,2)
        Details = $Details
    }
    $results.Add($row)
    "[{0}] {1} | {2} | {3} ms | {4}" -f $row.Timestamp,$Name,$Status,$row.ResponseMs,$Details | Tee-Object -FilePath $txtPath -Append
}

function Invoke-TimedRequest {
    param([string]$Name,[string]$Url,[string]$Method='GET')
    $sw = [Diagnostics.Stopwatch]::StartNew()
    try {
        $request = [Net.HttpWebRequest]::Create($Url)
        $request.Method = $Method
        $request.AllowAutoRedirect = $false
        $request.Timeout = 15000
        $request.ReadWriteTimeout = 15000
        $request.UserAgent = 'FargoVPN-Diagnostic/1.0'
        $response = [Net.HttpWebResponse]$request.GetResponse()
        $sw.Stop()
        $status = [int]$response.StatusCode
        $location = [string]$response.Headers['Location']
        $response.Close()
        Add-Result $Name ($status -ge 200 -and $status -lt 400) "$status" $sw.Elapsed.TotalMilliseconds (if($location){"Location=$location"}else{'OK'})
        return $status
    } catch [Net.WebException] {
        $sw.Stop()
        $resp = $_.Exception.Response
        if ($resp -is [Net.HttpWebResponse]) {
            $status = [int]$resp.StatusCode
            $resp.Close()
            Add-Result $Name ($status -ge 200 -and $status -lt 500) "$status" $sw.Elapsed.TotalMilliseconds 'HTTP response received; application may require authentication.'
            return $status
        }
        Add-Result $Name $false 'ERROR' $sw.Elapsed.TotalMilliseconds $_.Exception.Message
        return -1
    } catch {
        $sw.Stop()
        Add-Result $Name $false 'ERROR' $sw.Elapsed.TotalMilliseconds $_.Exception.Message
        return -1
    }
}

"FargoVPN client diagnostic" | Set-Content $txtPath
"Base URL: $BaseUrl" | Add-Content $txtPath
"Prefix: $prefix" | Add-Content $txtPath

Invoke-TimedRequest 'Panel HTTPS' $BaseUrl | Out-Null
Invoke-TimedRequest 'Health' ($BaseUrl + 'health') | Out-Null
Invoke-TimedRequest 'Service Worker' ($BaseUrl + 'service-worker.js') | Out-Null
Invoke-TimedRequest 'Manifest' ($BaseUrl + 'manifest.webmanifest') | Out-Null
Invoke-TimedRequest 'Updates releases API' ($BaseUrl + 'api/updates/releases') | Out-Null
Invoke-TimedRequest 'Messages page' ($BaseUrl + 'messages') | Out-Null
Invoke-TimedRequest 'Push status API' ($BaseUrl + 'api/panel/push/status') | Out-Null
Invoke-TimedRequest 'Push logs API' ($BaseUrl + 'api/panel/push/logs?limit=10') | Out-Null

try {
    $tcp = Test-NetConnection -ComputerName $uri.DnsSafeHost -Port $uri.Port -WarningAction SilentlyContinue
    Add-Result 'TCP 443' ([bool]$tcp.TcpTestSucceeded) ($(if($tcp.TcpTestSucceeded){'OPEN'}else{'FAILED'})) 0 'TCP connectivity'
} catch {
    Add-Result 'TCP 443' $false 'ERROR' 0 $_.Exception.Message
}

try {
    $tcpClient = New-Object Net.Sockets.TcpClient
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $tcpClient.Connect($uri.DnsSafeHost,$uri.Port)
    $sw.Stop()
    $ssl = New-Object Net.Security.SslStream($tcpClient.GetStream(),$false,{param($s,$cert,$chain,$errors) return $true})
    $ssl.AuthenticateAsClient($uri.DnsSafeHost)
    $cert = New-Object Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)
    $validNow = (Get-Date) -ge $cert.NotBefore -and (Get-Date) -le $cert.NotAfter
    Add-Result 'TLS certificate' $validNow 'CERT' $sw.Elapsed.TotalMilliseconds ("Subject={0}; NotAfter={1:O}; Issuer={2}" -f $cert.Subject,$cert.NotAfter,$cert.Issuer)
    $ssl.Dispose(); $tcpClient.Dispose()
} catch {
    Add-Result 'TLS certificate' $false 'ERROR' 0 $_.Exception.Message
}

# Pure HTTP cannot test browser Service Worker registration or PushManager.
Add-Result 'Browser Service Worker registration' $true 'MANUAL' 0 'HTTP file check completed. Verify navigator.serviceWorker registration in a real browser/PWA.'
Add-Result 'Browser Push subscription' $true 'MANUAL' 0 'HTTP endpoint check completed. Verify Notification.permission and PushManager subscription in a real browser/PWA.'

$results | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvPath

$failed = @($results | Where-Object { -not $_.Success -and $_.Status -ne 'MANUAL' }).Count
$manual = @($results | Where-Object { $_.Status -eq 'MANUAL' }).Count
$passed = @($results | Where-Object { $_.Success -and $_.Status -ne 'MANUAL' }).Count

$summary = "FargoVPN: PASS=$passed FAIL=$failed MANUAL=$manual. Лог: $txtPath"
Write-Host ""; Write-Host $summary

# Native Windows 10/11 toast, using only built-in Windows Runtime APIs.
try {
    $null = [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime]
    $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
    $safe = [System.Security.SecurityElement]::Escape($summary)
    $xml.LoadXml("<toast><visual><binding template='ToastGeneric'><text>FargoVPN диагностика</text><text>$safe</text></binding></visual></toast>")
    $toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
    $notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('FargoVPN Diagnostic')
    $notifier.Show($toast)
} catch {
    Write-Warning "Windows Toast недоступен в текущей сессии: $($_.Exception.Message)"
}

if ($failed -gt 0) { exit 1 }
exit 0
