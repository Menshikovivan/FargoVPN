from pathlib import Path
import re, tarfile, subprocess

ROOT = Path(__file__).resolve().parents[1]



def test_installer_config_mutator_heredoc_is_valid_python():
    text = (ROOT / "install.sh").read_text(encoding="utf-8")
    lines = text.splitlines()
    opener = next(i for i in range(len(lines) - 2) if lines[i].strip().startswith('\"$TARGET/.venv/bin/python\" <<') and lines[i + 1].strip() == 'from pathlib import Path' and 'import ast, hashlib' in lines[i + 2])
    end = next(i for i in range(opener + 1, len(lines)) if lines[i] == "PY")
    source = "\n".join(lines[opener + 1:end]) + "\n"
    compile(source, "install.sh:config-mutator-heredoc", "exec")
    assert 'if os.environ.get("FARGOVPN_SKIP_LEGACY_SQLITE_MIGRATION") == "1":\n        print(' in source
    assert 'else:\n        if snapshot_db.is_file():' in source

def test_next_version_and_clean_archive_contract():
    assert (ROOT / "VERSION").read_text().strip() == "4.6.8"
    assert (ROOT / "app" / "VERSION").read_text().strip() == "4.6.8"
    assert (ROOT / "INSTALLED_CHANGELOG_VERSION").read_text().strip() == "4.6.8"


def test_direct_message_uses_native_postgresql_boolean_and_safe_json_errors():
    text = (ROOT / "webapp.py").read_text(encoding="utf-8")
    assert '(actor, tg_id, row.get("username"), event_text, bool(ok), detail)' in text
    assert '(actor, tg_id, row.get("username"), event_text, int(ok), detail)' not in text
    assert "type.includes('application/json')" in text
    assert "raw.replace(/<[^>]*>/g,' ')" in text


def test_message_log_success_schema_is_normalized_to_boolean():
    text = (ROOT / "init_db.py").read_text(encoding="utf-8")
    assert "def _normalize_message_log_success" in text
    assert "ALTER COLUMN success TYPE BOOLEAN" in text
    assert "_normalize_message_log_success(conn)" in text

def test_socket_directory_is_not_service_runtime_directory():
    text=(ROOT/"install.sh").read_text()
    assert "RuntimeDirectory=vpn-service" not in text
    assert "d /run/vpn-service 0755 root root -" in text
    assert "SocketUser=root" in text
    assert "SocketGroup=$SOCKET_GROUP" in text
    assert "SocketMode=0660" in text
    assert "apt_install nginx" not in text.lower()
    assert "apt-get install nginx" not in text.lower()
    assert "systemctl enable nginx.service" not in text.lower()

def test_web_service_logs_and_uses_socket_service():
    text=(ROOT/"install.sh").read_text()
    assert "ExecStart=$TARGET/web_start.sh" in text
    assert "StandardOutput=append:/var/log/vpn_bot.log" in text
    assert "StandardError=append:/var/log/vpn_bot.log" in text
    assert "vpn-service-backup.service" in text
    assert "backup.py --service" in text

def test_fargovpn_ships_external_nginx_compatibility_bridge_only():
    assert (ROOT/"nginx_panel_guard.py").exists()
    assert (ROOT/"vpn-service-nginx-guard.service").exists()
    installer=(ROOT/"install.sh").read_text().lower()
    assert "apt_install nginx" not in installer
    assert "apt-get install nginx" not in installer
    assert "systemctl enable nginx.service" not in installer
    assert "setup_existing_nginx_route" in installer

def test_log_api_is_fixed_path_and_protected():
    text=(ROOT/"webapp.py").read_text()
    assert '@app.get("/api/panel/app-log")' in text
    assert 'require_auth(request)' in text
    assert 'APP_LOG_DEFAULT = "/var/log/vpn_bot.log"' in text

def test_no_runtime_407_in_serving_code():
    for path in [ROOT/"webapp.py", ROOT/"service-worker.js", ROOT/"static"/"panel.js", ROOT/"static"/"panel.css"]:
        text=path.read_text(encoding="utf-8", errors="ignore")
        assert "4.0.7" not in text

def test_archive_release_builder_has_clean_name():
    text=(ROOT/"build_release.sh").read_text()
    assert 'ARCHIVE="$ROOT/../VPN_Service_Platform_${version}_FULL.tar.gz"' in text
    assert 'PACKAGE_NAME="$(basename "$ROOT")"' in text
    assert 'find "$ROOT" -type l -print -quit' in text
    assert '--exclude="$PACKAGE_NAME/pytest-of-root"' in text
    assert '--exclude="$PACKAGE_NAME/tmp*"' in text


def test_app_log_ui_and_endpoint_contract():
    text=(ROOT/"webapp.py").read_text()
    assert 'Лог приложения' in text
    assert 'id="app-log-output"' in text
    assert 'id="app-log-refresh"' in text
    assert '/api/panel/app-log' in text
    assert 'require_auth(request)' in text

def test_messages_unread_api_and_navigation_badge_contract():
    text=(ROOT/"webapp.py").read_text()
    assert '@app.get("/api/panel/messages/unread")' in text
    assert 'data-unread-total' in text
    assert 'unread_messages_summary' in text
    assert 'message-unread-badge' in text


def test_unread_polling_is_single_flight_and_visibility_aware():
    text=(ROOT/"static"/"panel.js").read_text()
    assert 'function initUnreadMessages()' in text
    assert 'inFlight' in text
    assert "visibilitychange" in text
    assert "pagehide" in text
    assert "15000" in text


def test_latency_sensitive_telegram_paths_offload_sync_work():
    text=(ROOT/"main.py").read_text()
    assert '_schedule_event_record(' in text
    assert 'current_user = await asyncio.to_thread(db_get_user' in text
    assert 'await asyncio.to_thread(_save_pending_registration)' in text
    assert 'await asyncio.to_thread(admin_summary_text)' in text


def test_tls_verification_defaults_to_true():
    assert 'XUI_VERIFY_TLS = True' in (ROOT / "config.example.py").read_text(encoding="utf-8")
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert '"XUI_VERIFY_TLS": True' in installer
    assert 'ensure("XUI_VERIFY_TLS", True)' in installer


def test_fresh_install_skips_xui_smoke_without_api_token():
    text=(ROOT/"install.sh").read_text(encoding="utf-8")
    assert 'XUI_TOKEN_READY=$(target_python -c' in text
    assert 'if [[ "$XUI_TOKEN_READY" == "1" ]]; then' in text
    assert 'API-токен 3x-ui пока не настроен' in text
    assert "request_json_sync(method, path)" in text


def test_publisher_upload_and_install_are_separate():
    text=(ROOT/"webapp.py").read_text(encoding="utf-8")
    endpoint=text[text.index('@app.post("/updates/publish")'):text.index('@app.post("/updates/upload-and-apply")')]
    assert 'update_manager.publish_update(temp_path, archive.filename or "update.tar.gz")' in endpoint
    assert 'audit(actor, "publish_update"' in endpoint
    assert 'installed": False' in endpoint
    assert 'update_manager.start_update_job(actor, update_info=install_info)' not in endpoint
    page=text[text.index('@app.get("/updates", response_class=HTMLResponse)'):text.index('@app.post("/updates/check")')]
    assert 'Загрузить обновление в GitHub' in page
    assert 'Установка теперь выполняется отдельно' in page
    assert 'published_install_ready' in page

def test_github_main_sync_contract():
    text=(ROOT/"update_manager.py").read_text(encoding="utf-8")
    cfg=(ROOT/"config.example.py").read_text(encoding="utf-8")
    assert "GITHUB_MAIN_SYNC_ENABLED = True" in cfg
    assert "def _github_main_sync(" in text
    assert "/git/blobs" in text
    assert "/git/trees" in text
    assert "/git/commits" in text
    assert "/git/ref/heads/" in text
    assert "/git/refs/heads/" in text
    assert 'github_request("PATCH", update_ref_path' in text
    assert '"FargoVPN_FULL.tar.gz"' in text
    assert '"FargoVPN_FULL.tar.gz.sha256"' in text
    assert '"github_main_synced"' in text



def test_web_updater_invokes_existing_install_without_mask_flags():
    text=(ROOT/"update_manager.py").read_text(encoding="utf-8")
    start=text.index("def installer_command(")
    end=text.index("def launch_update(", start)
    block=text[start:end]
    assert "--update-existing" in block
    assert "--profile" in block
    assert "--mask" not in block

def test_web_panel_version_source_is_installed_version_file():
    updater = (ROOT / "update_manager.py").read_text(encoding="utf-8")
    web = (ROOT / "webapp.py").read_text(encoding="utf-8")
    assert 'APP_DIR / "VERSION"' in updater
    assert 'def current_version()' in updater
    assert 'update_manager.current_version()' in web
    assert 'APP_DIR / "VERSION"' not in web


def test_staged_update_copy_simulation_preserves_runtime_files(tmp_path):
    src = tmp_path / "staging"
    target = tmp_path / "target"
    src.mkdir(); target.mkdir()
    (src / "VERSION").write_text("4.5.5\n", encoding="utf-8")
    (src / "main.py").write_text("NEW_CODE = True\n", encoding="utf-8")
    (src / "config.py").write_text("OLD_CONFIG = True\n", encoding="utf-8")
    (src / "data").mkdir(); (src / "data" / "vpn_bot.db").write_text("KEEP_DB", encoding="utf-8")
    (src / ".venv").mkdir(); (src / ".venv" / "KEEP").write_text("KEEP_VENV", encoding="utf-8")
    (target / "VERSION").write_text("4.5.3\n", encoding="utf-8")
    (target / "config.py").write_text("OLD_INSTALLED_CONFIG\n", encoding="utf-8")
    (target / "data").mkdir(); (target / "data" / "vpn_bot.db").write_text("CURRENT_DB", encoding="utf-8")
    (target / ".venv").mkdir(); (target / ".venv" / "KEEP").write_text("CURRENT_VENV", encoding="utf-8")
    subprocess.run([
        "rsync", "-a",
        "--exclude=config.py", "--exclude=.venv/", "--exclude=data/",
        "--exclude=backups/", "--exclude=backup/",
        str(src) + "/", str(target) + "/",
    ], check=True)
    (target / "VERSION").write_text((src / "VERSION").read_text(encoding="utf-8"), encoding="utf-8")
    assert (target / "main.py").read_text(encoding="utf-8") == "NEW_CODE = True\n"
    assert (target / "VERSION").read_text(encoding="utf-8").strip() == "4.5.5"
    assert (target / "config.py").read_text(encoding="utf-8") == "OLD_INSTALLED_CONFIG\n"
    assert (target / "data" / "vpn_bot.db").read_text(encoding="utf-8") == "CURRENT_DB"
    assert (target / ".venv" / "KEEP").read_text(encoding="utf-8") == "CURRENT_VENV"


def test_staged_update_syncs_code_and_version_into_installed_target():
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    updater = (ROOT / "update_manager.py").read_text(encoding="utf-8")
    worker = (ROOT / "update_worker.py").read_text(encoding="utf-8")
    assert 'return (APP_DIR / "VERSION").read_text' in updater
    assert 'package_root / "install.sh"' in updater
    assert '"--update-existing", str(APP_DIR)' in updater
    assert 'rsync -a \\\n' in installer
    assert '--exclude=\'config.py\'' in installer
    assert '--exclude=\'.venv/\'' in installer
    assert '--exclude=\'data/\'' in installer
    assert 'install -m 0644 "$SRC/VERSION" "$TARGET/VERSION"' in installer
    assert 'VPN_UPDATE_TARGET_VERSION' in updater and 'VPN_UPDATE_TARGET_VERSION' not in worker


def test_update_failure_has_structured_reason_without_raw_journal_dump():
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert 'summary_fail' in installer
    assert 'print_update_summary' in installer
    assert 'abort_install' in installer
    assert 'systemctl show "$unit" -p ActiveState' in installer
    assert 'journalctl' not in installer
    assert 'systemctl status' not in installer


def test_venv_reuse_requires_requirements_and_pip_check():
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert 'definitely_not_a_real_marker' not in installer
    assert 'pip_requirements_ok' in installer
    assert '-m pip check' in installer
    assert 'metadata.version(requirement.name)' in installer


def test_bot_restart_observation_exists_after_update():
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert 'NRestarts' in installer
    assert 'бот начал автоматические перезапуски сразу после обновления' in installer


def test_final_summary_reports_external_nginx_postgresql_and_xui():
    installer = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert 'summary_nginx_service' in installer
    assert 'summary_unit postgresql.service' in installer
    assert 'summary_xui_service' in installer
    assert '443 / внешний Nginx' in installer
    assert 'Веб-панель FargoVPN: $PANEL_PUBLIC_URL' in installer


def test_bot_is_explicitly_restarted_when_token_is_configured():
    text = (ROOT / "install.sh").read_text(encoding="utf-8")
    anchor = 'systemctl enable vpn-service-bot.service vpn-service-backup.timer vpn-service-reminders.timer'
    start = text.index(anchor)
    block = text[start:text.index('if [[ $PROFILE == full ]]; then', start)]
    assert 'BOT_READY_FOR_RESTART=$(target_python -c' in block
    assert 'systemctl restart vpn-service-bot.service' in block
    assert 'enable vpn-service-bot.service' in block


def test_web_start_failure_emits_structured_systemd_details_not_journal_dump():
    text = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert 'service_failure_details() {' in text
    assert 'ExecMainCode' in text
    assert 'ExecMainStatus' in text
    assert 'tail -n 12 "$log_file"' in text
    assert 'journalctl' not in text
