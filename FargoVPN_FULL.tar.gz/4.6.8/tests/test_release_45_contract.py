from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]


def _text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8", errors="ignore")


def test_release_version_markers_are_468():
    for path in ("VERSION", "app/VERSION", "INSTALLED_CHANGELOG_VERSION"):
        assert _text(path).strip() == "4.6.8"


def test_remote_backup_runtime_is_absent():
    forbidden = ("yad" + "ex", "web" + "dav", "dav" + "fs", "r" + "clone")
    assert not (ROOT / "scripts/cleanup_legacy_remote_backup.sh").exists()
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.is_symlink() or "__pycache__" in path.parts or ".pytest_cache" in path.parts or path.parts[-2:-1] == ("tests",):
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        assert not any(term in text.lower() for term in forbidden), path

def test_backup_is_single_telegram_service():
    installer=_text("install.sh")
    backup=_text("backup.py")
    web=_text("webapp.py")
    main=_text("main.py")
    assert "ExecStart=$TARGET/.venv/bin/python $TARGET/backup.py --service" in installer
    assert "request_backup_now" in backup and "vpn-service-backup.service" in backup
    assert 'destinations = destinations or {"telegram"}' in backup
    assert "launch_detached" not in web
    assert "launch_detached" not in main
    assert ".age" not in backup

def test_restore_manager_verifies_users_and_two_part_reassembly():
    text=_text("restore_manager.py")
    assert "users-only" in text
    assert "part001" in _text("RELEASE_NOTES_4.5.5.md") or "part" in text
    assert "application_row_counts" in text
    assert "users" in text


def test_inbound_selection_contract():
    xui = _text("services/xui_api.py")
    web = _text("webapp.py")
    cfg = _text("config.example.py")
    assert "def fetch_inbounds_sync" in xui
    assert "def inbound_selection_status_sync" in xui
    assert "def inbound_ids_sync" in xui
    assert "XUI_MANAGED_INBOUND_IDS = []" in cfg
    assert '"XUI_MANAGED_INBOUND_IDS": inbound_ids if inbound_selection_present else current_inbound_config' in web
    assert '"inboundIds": inbound_ids' in xui
    assert "ensure_client_inbounds_sync" in xui
    assert "Существующие клиенты не перебиндиваются" in web


def test_xui_stability_contract():
    xui = _text("services/xui_api.py")
    cfg = _text("config.example.py")
    assert "XUI_REQUEST_GATE" in xui
    assert "BoundedSemaphore(4)" in xui
    assert "Retry-After" in xui
    assert "retry_attempts = 3 if method in retry_methods else 1" in xui
    assert "XUI_REQUEST_TIMEOUT_SECONDS = 12" in cfg
    assert "XUI_MIN_REQUEST_INTERVAL_MS = 100" in cfg
    assert "XUI_INBOUND_CACHE_SECONDS = 60" in cfg


def test_healthcheck_contract():
    web = _text("webapp.py")
    script = _text("scripts/healthcheck.sh")
    assert '@app.get("/healthz"' in web
    assert 'fetch_snapshot_sync' not in web[web.index('@app.get("/healthz"'):]
    assert '--unix-socket' in script
    assert '/healthz' in script
    assert os.access(ROOT / "scripts/healthcheck.sh", os.X_OK)


def test_backup_schedule_and_no_remote_dependency():
    installer = _text("install.sh")
    assert "OnCalendar=*-*-* 03:30:00" in installer
    assert "dav" + "fs2" not in installer.lower()
    assert 'backup.py --service' in installer
    backup = _text("backup.py")
    assert "upload_to_" + "yan" + "dex" not in backup
    assert 'destinations = destinations or {"telegram"}' in backup


def test_overview_routes_present():
    webapp = (ROOT / "webapp.py").read_text(encoding="utf-8")
    assert '@app.get("/", response_class=HTMLResponse)' in webapp
    assert '@app.get("/api/panel/update-status")' in webapp
    assert 'def dashboard(request: Request):' in webapp
    assert 'def panel_update_status(request: Request):' in webapp
