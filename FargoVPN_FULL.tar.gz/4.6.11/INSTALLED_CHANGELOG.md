# FargoVPN 4.6.11

Установленная production-версия.

Основные изменения: Firefox Push через пользовательский жест, устойчивое открытие личного кабинета через Telegram access token, `no-store` для cabinet response и очищенная production-сборка.
