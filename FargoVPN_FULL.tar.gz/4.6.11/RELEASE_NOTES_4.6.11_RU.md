# FargoVPN 4.6.11

Production-релиз.

### Push
- Firefox получает подписку непосредственно из пользовательского клика после предварительной подготовки.
- Для Firefox используется `Uint8Array` для VAPID `applicationServerKey`.
- Добавлена диагностика Mozilla Push Service.
- Chrome/Chromium-поток сохранён.

### Кабинет
- Исправлена гонка при открытии «Кабинета на сайте» из Telegram.
- Access token повторно используется в течение TTL и больше не инвалидируется после первого перехода.
- Cabinet HTML и redirect помечены `no-store`.

### Архив
- Удалены исторические audit/diff/test/release артефакты.
- Включены только актуальные production-файлы 4.6.11.
