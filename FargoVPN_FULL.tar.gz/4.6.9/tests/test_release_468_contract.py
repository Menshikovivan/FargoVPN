from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def text(name):
    return (ROOT / name).read_text(encoding='utf-8', errors='ignore')


def test_468_version_and_fixed_publisher_boundary():
    assert (ROOT / 'VERSION').read_text().strip() == '4.6.9'
    assert (ROOT / 'app/VERSION').read_text().strip() == '4.6.9'
    assert (ROOT / 'INSTALLED_CHANGELOG_VERSION').read_text().strip() == '4.6.9'
    assert 'PUBLISHER_USERNAME = "menshikovivan"' in text('update_manager.py')
    assert 'UPDATE_PUBLISHER_USERNAME = "menshikovivan"' in text('config.example.py')
    assert 'UPDATE_PUBLISHER_USERNAME": "menshikovivan"' in text('install.sh')


def test_update_mutation_routes_have_backend_publisher_guards():
    source = text('webapp.py')
    guarded = [
        '/updates/github/test', '/updates/github/config', '/updates/publish',
        '/updates/upload-and-apply', '/updates/force-version', '/updates/rollback',
        '/api/updates/log', '/api/updates/releases', '/updates/config', '/updates/token',
    ]
    for path in guarded:
        route_idx = max(source.rfind('@app.get("', 0, source.find(path)), source.rfind('@app.post("', 0, source.find(path)))
        assert route_idx >= 0, path
        block = source[route_idx:source.find('\n@app.', route_idx + 5) if source.find('\n@app.', route_idx + 5) >= 0 else len(source)]
        assert 'require_auth(request)' in block, path
        assert 'can_publish_update(request)' in block, path


def test_non_publisher_update_page_has_only_regular_check_install_controls():
    source = text('webapp.py')
    assert 'Для этой учётной записи доступны только проверка и установка обновлений.' in source
    assert "rollback_block = ''" in source
    assert 'if publisher and rollback_candidate' in source
    assert 'manual_block = ""' in source


def test_telegram_terminal_chat_errors_do_not_abort_normal_workflow():
    source = text('main.py')
    assert 'class JournalBot(Bot):' in source
    assert 'TelegramForbiddenError' in source
    assert 'chat not found' in source
    assert 'bot was blocked by the user' in source
    assert 'return None' in source[source.index('class JournalBot'):source.index('def refresh_telegram_identity')]


def test_restore_rekey_includes_all_user_linked_records():
    source = text('services/xui_api.py')
    block = source[source.index('def _rekey_related_rows'):source.index('def sync_snapshot_to_db')]
    for table in ('payments', 'message_log', 'user_events', 'push_subscriptions', 'pending_registrations', 'cabinet_access_tokens', 'referral_rewards', 'telegram_link_requests'):
        assert table in block
    assert 'referred_by_tg_id' in block


def test_subscription_renewals_are_serialized_per_identity():
    source = text('services/subscriptions.py')
    assert 'def _subscription_identity_lock_sync' in source
    assert 'pg_advisory_lock(hashtextextended(?, 0))' in source
    assert 'with _subscription_identity_lock_sync(tg_id, db_path):' in source


def test_payment_claim_remains_compare_and_set():
    source = text('services/subscriptions.py')
    start = source.index('def approve_payment_sync')
    end = source.index('def decline_payment_sync', start)
    block = source[start:end]
    assert "SET status='processing'" in block
    assert "WHERE id=? AND status='pending'" in block
    assert 'RETURNING *' in block
    assert "WHERE id=? AND status='processing' AND processed_by=?" in block


def test_push_diagnostics_distinguish_browser_retrieval_error_and_vapid_pair_health():
    service = text('push_service.py')
    web = text('webapp.py')
    assert 'def _vapid_keypair_health' in service
    assert '_repair_config_public(expected_public)' in service
    assert 'public key restored from private key' in service or 'public key synchronized from private key' in service
    assert 'getSubscription() error name=' in web
    assert 'retrieving push subscription' in web.lower()
    assert 'PushSubscription создан' in web


def test_update_callback_producers_are_prefix_covered_and_show_instruction_is_orphaned():
    source = text('main.py')
    producers = re.findall(r'callback_data\s*=\s*[f]?"([^"\n]+)', source)
    assert any(x.startswith('menu:') for x in producers)
    assert any(x.startswith('admin:') for x in producers)
    assert any(x.startswith('faq:') for x in producers)
    assert any(x.startswith('approve_') for x in producers)
    assert any(x.startswith('decline_') for x in producers)
    assert any(x.startswith('crmv_') for x in producers)
    assert any(x.startswith('crmmod_') for x in producers)
    assert any(x.startswith('crmdel_') for x in producers)
    assert 'F.data == "show_instruction"' in source
    assert 'callback_data="show_instruction"' not in source


def test_payment_lookup_index_covers_identity_and_status():
    source = text('init_db.py')
    assert 'idx_payments_tg_status_created' in source
    assert 'CREATE INDEX IF NOT EXISTS idx_users_referred_by' in source
