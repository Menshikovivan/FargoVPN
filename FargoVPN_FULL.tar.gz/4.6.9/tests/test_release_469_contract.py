from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def text(name):
    return (ROOT / name).read_text(encoding="utf-8", errors="ignore")


def test_469_version_files_are_bumped():
    for name in ("VERSION", "app/VERSION", "INSTALLED_CHANGELOG_VERSION"):
        assert (ROOT / name).read_text().strip() == "4.6.9"
    assert (ROOT / "RELEASE_NOTES_4.6.9.md").exists()


def test_vapid_private_key_is_source_of_truth_for_public_key():
    service = text("push_service.py")
    assert "expected=b64u(_pub(key))" in service or "expected_public = b64u(_pub(key))" in service
    assert "_repair_config_public(expected" in service
    assert "public_key()" in service


def test_vapid_subject_is_rejected_for_localhost_and_requires_real_url_or_mailto():
    service = text("push_service.py")
    assert "VAPID subject не настроен" in service
    assert "localhost/local/invalid host" in service
    assert "mailto:" in service


def test_push_subscription_records_vapid_public_key_and_migrates_old_schema():
    service = text("push_service.py")
    db = text("init_db.py")
    assert "vapid_public_key" in service
    assert "vapid_public_key" in db
    assert '_ensure_columns(conn,"panel_push_subscriptions"' in db


def test_provider_reason_is_parsed_and_safari_bad_jwt_gets_specific_diagnostic():
    service = text("push_service.py")
    assert 'decoded.get("reason")' in service
    assert 'reason=BadJwtToken' in service
    assert 'PUSH_VAPID_SUBJECT' in service


def test_vapid_key_mismatch_is_not_silently_used():
    service = text("push_service.py")
    assert 'stored_public and stored_public != current_public' in service
    assert 'VAPID public key изменился; требуется повторно включить Push' in service


def test_browser_abort_recovery_resets_registration_and_retries_once():
    web = text("webapp.py")
    assert 'const resetPushRegistration=' in web
    assert 'unregister()' in web
    assert 'caches.delete' in web
    assert "попытка '+attempt+'/2" in web
    assert 'applicationServerKey:keyBuffer' in web
    assert 'oldKey=sub.options.applicationServerKey' in web


def test_push_subscribe_returns_503_for_invalid_vapid_configuration():
    web = text("webapp.py")
    route = web[web.index('@app.post("/api/panel/push/subscribe")'):web.index('@app.post("/api/panel/push/unsubscribe")')]
    assert 'except ValueError as exc' in route
    assert 'HTTPException(503' in route
