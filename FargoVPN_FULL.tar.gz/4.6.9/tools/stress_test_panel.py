#!/usr/bin/env python3
"""Simple external concurrency smoke test for the public panel health endpoint."""
from __future__ import annotations

import argparse
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.request import Request, urlopen


def one(url: str, timeout: float) -> tuple[bool, float, int, str]:
    started = time.perf_counter()
    try:
        req = Request(url, headers={"User-Agent": "FargoVPN-stress-test/4.6.9"})
        with urlopen(req, timeout=timeout) as response:
            body = response.read(128)
            elapsed = time.perf_counter() - started
            ok = 200 <= int(response.status) < 300 and b"ok" in body.lower()
            return ok, elapsed, int(response.status), body.decode(errors="replace")[:128]
    except Exception as exc:
        return False, time.perf_counter() - started, 0, str(exc)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("url", help="Unauthenticated health endpoint, e.g. https://panel.example.com/health")
    p.add_argument("--requests", type=int, default=500)
    p.add_argument("--concurrency", type=int, default=50)
    p.add_argument("--timeout", type=float, default=10.0)
    args = p.parse_args()
    if args.requests < 1 or args.concurrency < 1:
        p.error("requests and concurrency must be positive")
    started = time.perf_counter()
    results=[]
    with ThreadPoolExecutor(max_workers=min(args.concurrency, args.requests)) as pool:
        futures=[pool.submit(one,args.url,args.timeout) for _ in range(args.requests)]
        for fut in as_completed(futures):
            results.append(fut.result())
    total=time.perf_counter()-started
    latencies=[r[1] for r in results]
    ok=sum(1 for r in results if r[0])
    latencies.sort()
    def pct(q):
        if not latencies: return 0.0
        idx=min(len(latencies)-1,max(0,int(round(q*(len(latencies)-1)))))
        return latencies[idx]*1000
    print(f"requests={len(results)} ok={ok} failed={len(results)-ok} concurrency={args.concurrency} total_s={total:.3f}")
    print(f"rps={len(results)/total:.1f} mean_ms={statistics.fmean(latencies)*1000:.1f} p50_ms={pct(.50):.1f} p95_ms={pct(.95):.1f} p99_ms={pct(.99):.1f} max_ms={max(latencies,default=0)*1000:.1f}")
    for sample in [r for r in results if not r[0]][:10]:
        print("FAIL", sample[2], sample[3])
    return 0 if ok == len(results) else 2

if __name__ == "__main__":
    raise SystemExit(main())
