#!/usr/bin/env python3
"""Read-only diagnostics for Telegram identity damage after backup restore.

The report deliberately does not rewrite users, payments or 3x-ui records.
Use the existing identity migration tools after reviewing the report.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

TERMINAL_PATTERNS = (
    "chat not found",
    "bot was blocked by the user",
    "user is deactivated",
    "user not found",
    "chat_id is empty",
    "have no access to the chat",
)


def _db_rows(sql: str, params=()):
    import db
    import config

    with db.connect(getattr(config, "DB_PATH", None), timeout=30) as c:
        return [dict(row._row._mapping) if hasattr(row, "_row") and hasattr(row._row, "_mapping") else dict(row) for row in c.execute(sql, params).fetchall()]


def _count(sql: str, params=()) -> int:
    rows = _db_rows(sql, params)
    return int(next(iter(rows[0].values()), 0) if rows else 0)


def _normalise_detail(value: Any) -> str:
    return str(value or "").casefold()


def collect_report(include_xui: bool = False) -> dict[str, Any]:
    import config

    report: dict[str, Any] = {"database": {}, "telegram_delivery": {}, "identity": {}, "3x_ui": {}}
    report["database"] = {
        "users_total": _count("SELECT COUNT(*) AS n FROM users"),
        "users_positive_tg_id": _count("SELECT COUNT(*) AS n FROM users WHERE tg_id > 0"),
        "users_negative_local_id": _count("SELECT COUNT(*) AS n FROM users WHERE tg_id < 0"),
        "users_zero_tg_id": _count("SELECT COUNT(*) AS n FROM users WHERE tg_id = 0"),
        "payments_missing_user": _count("SELECT COUNT(*) AS n FROM payments p LEFT JOIN users u ON u.tg_id=p.tg_id WHERE u.tg_id IS NULL"),
        "events_missing_user": _count("SELECT COUNT(*) AS n FROM user_events e LEFT JOIN users u ON u.tg_id=e.tg_id WHERE u.tg_id IS NULL"),
    }

    failed = _db_rows(
        """
        SELECT tg_id, COUNT(*) AS failures, MAX(created_at) AS last_failure
        FROM user_events
        WHERE direction='out' AND success=0
          AND LOWER(COALESCE(metadata,'' ) || ' ' || COALESCE(text,'')) LIKE ANY (ARRAY[
              '%chat not found%', '%bot was blocked by the user%', '%user is deactivated%',
              '%user not found%', '%chat_id is empty%', '%have no access to the chat%'
          ])
        GROUP BY tg_id ORDER BY tg_id
        """
    )
    failed_ids = [int(r["tg_id"]) for r in failed if int(r.get("tg_id") or 0) != 0]
    mismatches = _db_rows(
        """
        SELECT tg_id, telegram_chat_id, COUNT(*) AS events, MAX(created_at) AS last_event
        FROM user_events
        WHERE telegram_chat_id IS NOT NULL AND telegram_chat_id <> tg_id
        GROUP BY tg_id, telegram_chat_id ORDER BY tg_id
        """
    )
    report["telegram_delivery"] = {
        "terminal_failure_users": len(failed_ids),
        "terminal_failure_user_ids": failed_ids,
        "terminal_failure_events": int(sum(int(r.get("failures") or 0) for r in failed)),
        "chat_id_mismatch_pairs": mismatches,
        "chat_id_mismatch_users": len({int(r["tg_id"]) for r in mismatches}),
    }

    suspicious_identity = _db_rows(
        """
        SELECT u.tg_id, u.username, u.email, u.identity_source, u.identity_updated_at,
               u.uuid, u.enable, u.expiry_time
        FROM users u
        WHERE u.tg_id > 0
          AND (COALESCE(u.email,'') = '' OR COALESCE(u.identity_source,'') ILIKE '%restore%')
        ORDER BY u.tg_id
        """
    )
    report["identity"] = {
        "suspicious_positive_rows": len(suspicious_identity),
        "suspicious_positive_sample": suspicious_identity[:100],
    }

    if include_xui:
        try:
            from services.xui_api import fetch_snapshot_sync
            snapshot = fetch_snapshot_sync(force=True)
            clients = [dict(item) for item in snapshot.get("clients", []) if isinstance(item, dict)]
            xui_by_tg: dict[int, int] = {}
            conflicts = []
            duplicates: dict[int, list[str]] = {}
            for client in clients:
                tg = int(client.get("tg_id") or 0)
                email = str(client.get("email") or "")
                if tg <= 0:
                    continue
                duplicates.setdefault(tg, []).append(email)
                xui_by_tg[tg] = xui_by_tg.get(tg, 0) + 1
            local_rows = _db_rows("SELECT tg_id,username,email,uuid FROM users WHERE tg_id>0 ORDER BY tg_id")
            for row in local_rows:
                tg = int(row["tg_id"])
                matches = [c for c in clients if int(c.get("tg_id") or 0) == tg]
                if len(matches) > 1:
                    conflicts.append({"tg_id": tg, "type": "duplicate_xui_tgId", "emails": [str(c.get("email") or "") for c in matches]})
                elif not matches and str(row.get("email") or "").strip():
                    by_email = [c for c in clients if str(c.get("email") or "").casefold() == str(row.get("email") or "").casefold()]
                    if by_email and int(by_email[0].get("tg_id") or 0) not in (0, tg):
                        conflicts.append({"tg_id": tg, "type": "email_points_to_other_xui_tgId", "email": row.get("email"), "xui_tg_id": by_email[0].get("tg_id")})
            report["3x_ui"] = {"clients": len(clients), "identity_conflicts": conflicts, "identity_conflict_count": len(conflicts)}
        except Exception as exc:
            report["3x_ui"] = {"error": str(exc)}

    report["affected_users"] = len(set(failed_ids) | {int(r["tg_id"]) for r in mismatches})
    report["note"] = (
        "A positive Telegram ID is authoritative in 4.6.9. A terminal Telegram delivery error means the chat is unreachable/blocked; "
        "it is not evidence by itself that the ID is wrong. A mismatch between local tg_id and telegram_chat_id, or an xUI tgId conflict, "
        "is the signal to run identity migration/rebind."
    )
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--xui", action="store_true", help="Also compare local identities with a live 3x-ui snapshot")
    parser.add_argument("--json", action="store_true", help="Print JSON only")
    args = parser.parse_args()
    report = collect_report(include_xui=args.xui)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2, default=str))
        return 0
    print("FargoVPN restore identity diagnostics (read-only)")
    print(f"Users: {report['database']['users_total']} total / {report['database']['users_positive_tg_id']} positive / {report['database']['users_negative_local_id']} local")
    print(f"Missing user references: payments={report['database']['payments_missing_user']}, events={report['database']['events_missing_user']}")
    print(f"Terminal Telegram delivery failures: {report['telegram_delivery']['terminal_failure_users']} users, {report['telegram_delivery']['terminal_failure_events']} events")
    print(f"telegram_chat_id != tg_id: {report['telegram_delivery']['chat_id_mismatch_users']} users")
    print(f"Union of affected candidates: {report['affected_users']} users")
    if args.xui:
        print(f"3x-ui identity conflicts: {report.get('3x_ui', {}).get('identity_conflict_count', 'n/a')}")
    print("JSON:")
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
