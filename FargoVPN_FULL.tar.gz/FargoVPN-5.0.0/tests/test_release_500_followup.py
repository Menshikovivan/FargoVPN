from pathlib import Path
import ast
import re

ROOT = Path(__file__).resolve().parents[1]


def _function_source(path: Path, name: str) -> str:
    tree = ast.parse(path.read_text(encoding='utf-8'))
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(path.read_text(encoding='utf-8'), node)


def _load_xui_helpers():
    import json, re as _re, threading, time
    ns = {'Any': object, 'dict': dict, 'list': list, 'str': str, 'int': int,
          'threading': threading, 'time': time, 'json': json, 're': _re, '_SERVER_TRAFFIC_SAMPLE': {'ts': 0.0, 'up': 0, 'down': 0}, '_SERVER_TRAFFIC_SAMPLE_LOCK': threading.Lock()}
    code = '\n\n'.join(_function_source(ROOT / 'services' / 'xui_api.py', n) for n in (
        '_int', '_bool', '_client_credential_id', 'normalize_timestamp_ms',
        'normalize_client', '_traffic_counter', '_sample_network_rate',
        'summarize_server_traffic', 'summarize_inbound_traffic'))
    exec(code, ns)
    return ns


def test_3xui_current_client_and_inbound_shapes_preserve_traffic():
    ns = _load_xui_helpers()
    client = ns['normalize_client']({
        'email': 'alice', 'uuid': 'u1', 'totalGB': 10,
        'expiryTime': 1735689600000,
        'traffic': {'up': 1234, 'down': 5678, 'enable': True},
    })
    assert client['up'] == 1234
    assert client['down'] == 5678
    inbound = ns['summarize_inbound_traffic']([{
        'id': 1, 'up': 0, 'down': 0, 'enable': True,
        'clientStats': [{'email': 'alice', 'up': 1234, 'down': 5678}],
    }])
    assert inbound['up'] == 1234
    assert inbound['down'] == 5678


def test_3xui_server_status_supports_current_and_legacy_network_keys():
    ns = _load_xui_helpers()
    result = ns['summarize_server_traffic']({'netIO': {'up': 1000, 'down': 2000}})
    assert result['up'] == 1000 and result['down'] == 2000
    result2 = ns['summarize_server_traffic']({'netTraffic': {'sent': 3000, 'recv': 4000}})
    assert result2['up'] == 3000 and result2['down'] == 4000


def test_notifications_buttons_are_not_left_disabled_after_preflight_failure():
    text = (ROOT / 'webapp.py').read_text(encoding='utf-8')
    assert '<button type="button" id="panel-push-enable">' in text
    boot = re.search(r'const boot=\(\)=>.*?window\.addEventListener\(\'pagehide\'', text, re.S).group(0)
    assert 'const eb=document.getElementById(\'panel-push-enable\');if(eb)eb.disabled=false;' in boot
    assert 'return null;' in boot
    assert 'Подготовка Push не завершилась' in boot
    assert 'Повторная подготовка Push по пользовательскому клику' in text


def test_github_publish_syncs_full_safe_project_tree():
    text = (ROOT / 'update_manager.py').read_text(encoding='utf-8')
    start = text.index('def _github_main_public_files(')
    end = text.index('\n\ndef _github_main_sync(', start)
    source = text[start:end]
    assert 'archive_root.rglob("*")' in source
    assert 'forbidden_names' in source
    assert 'forbidden_dirs' in source
    assert 'forbidden_suffixes' in source
    assert 'config.py' in source and '.env' in source
    assert 'files["FargoVPN_FULL.tar.gz"]' in source
    assert 'files["install.sh"] = _github_main_bootstrap()' in source


def test_5_0_0_version_is_not_renamed():
    for name in ('VERSION', 'app/VERSION', 'static/VERSION'):
        assert (ROOT / name).read_text(encoding='utf-8').strip() == '5.0.0'


def test_install_accepts_legacy_profile_argument():
    src = (ROOT / "install.sh").read_text(encoding="utf-8")
    assert "--profile)" in src
    assert "--profile=*)" in src
    assert "LEGACY_PROFILE" in src
    assert "в 5.0 используется полный профиль" in src

