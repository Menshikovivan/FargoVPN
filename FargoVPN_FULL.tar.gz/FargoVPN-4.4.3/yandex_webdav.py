#!/usr/bin/env python3
"""Yandex.Disk transport via the system davfs2 WebDAV mount.

FargoVPN intentionally uses the same davfs2 flow as the documented Yandex.Disk
WebDAV setup: credentials in /etc/davfs2/secrets, mount at /media/YandexDisk,
and ordinary filesystem I/O through that mount.
"""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
import time
from pathlib import Path

logger = logging.getLogger("vpn-service-backup.yandex")
DEFAULT_URL = "https://webdav.yandex.ru:443"
DEFAULT_MOUNT_POINT = "/media/YandexDisk"
DEFAULT_SECRETS_FILE = "/etc/davfs2/secrets"
DEFAULT_FSTAB = "/etc/fstab"


def clean_remote_path(path: str) -> str:
    parts = [part for part in str(path or "").replace("\\", "/").split("/") if part]
    if any(part in {".", ".."} for part in parts):
        raise ValueError("Путь Яндекс.Диска не должен содержать . или ..")
    return "/".join(parts)


def _normalise_url(base_url: str | None = None) -> str:
    url = str(base_url or DEFAULT_URL).strip().rstrip("/")
    if url not in {"https://webdav.yandex.ru", DEFAULT_URL}:
        raise ValueError("YANDEX_WEBDAV_URL должен быть https://webdav.yandex.ru:443")
    return url if url.endswith(":443") else DEFAULT_URL


def _mount_path(mount_point: str | None = None) -> Path:
    return Path(mount_point or DEFAULT_MOUNT_POINT)


def _secrets_path(secrets_file: str | None = None) -> Path:
    return Path(secrets_file or DEFAULT_SECRETS_FILE)


def _fstab_path(fstab_file: str | None = None) -> Path:
    return Path(fstab_file or DEFAULT_FSTAB)


def _run(command: list[str], *, timeout: float = 60.0, check: bool = False) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, capture_output=True, text=True, timeout=max(5.0, float(timeout)), check=check)


def _is_mounted(mount_point: Path) -> bool:
    result = _run(["mountpoint", "-q", str(mount_point)], timeout=15)
    return result.returncode == 0


def configure_credentials(username: str, password: str, *, base_url: str = DEFAULT_URL, secrets_file: str = DEFAULT_SECRETS_FILE) -> bool:
    username = str(username or "").strip()
    password = str(password or "")
    url = _normalise_url(base_url)
    secrets = _secrets_path(secrets_file)
    if not username or not password:
        raise ValueError("Логин и пароль приложения Яндекс обязательны")
    if any(char in password for char in "\r\n") or any(char.isspace() for char in username):
        raise ValueError("Логин и пароль приложения не должны содержать переносов строк; логин также не должен содержать пробелы")
    secrets.parent.mkdir(parents=True, exist_ok=True)
    existing = secrets.read_text(encoding="utf-8") if secrets.exists() else ""
    desired = f"{DEFAULT_URL} {username} {password}"
    existing_yandex = next((line.strip() for line in existing.splitlines() if line.strip() and not line.lstrip().startswith("#") and line.split(None, 1)[0] in {url, DEFAULT_URL, "https://webdav.yandex.ru"}), "")
    changed = existing_yandex != desired
    lines: list[str] = []
    for line in existing.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            lines.append(line)
            continue
        first = stripped.split(None, 1)[0]
        if first in {url, DEFAULT_URL, "https://webdav.yandex.ru"}:
            continue
        lines.append(line)
    lines.append(desired)
    temporary = secrets.with_name(secrets.name + f".{os.getpid()}.tmp")
    temporary.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    os.chmod(temporary, 0o600)
    os.replace(temporary, secrets)
    os.chmod(secrets, 0o600)
    return changed


def configure_fstab(*, base_url: str = DEFAULT_URL, mount_point: str = DEFAULT_MOUNT_POINT, fstab_file: str = DEFAULT_FSTAB) -> None:
    url = _normalise_url(base_url)
    mount = _mount_path(mount_point)
    fstab = _fstab_path(fstab_file)
    mount.mkdir(parents=True, exist_ok=True)
    existing = fstab.read_text(encoding="utf-8") if fstab.exists() else ""
    entries: list[str] = []
    found = False
    for line in existing.splitlines():
        stripped = line.strip()
        fields = stripped.split()
        if fields and not stripped.startswith("#") and len(fields) >= 3 and fields[1] == str(mount):
            if fields[2] == "davfs":
                if not found:
                    entries.append(f"{url} {mount} davfs _netdev,nosuid,nodev,noexec 0 0")
                    found = True
                continue
        entries.append(line)
    if not found:
        if entries and entries[-1] != "":
            entries.append("")
        entries.append(f"{url} {mount} davfs _netdev,nosuid,nodev,noexec 0 0")
    temporary = fstab.with_name(fstab.name + f".{os.getpid()}.tmp")
    temporary.write_text("\n".join(entries).rstrip() + "\n", encoding="utf-8")
    os.chmod(temporary, 0o644)
    os.replace(temporary, fstab)
    os.chmod(fstab, 0o644)


def ensure_mounted(
    username: str,
    password: str,
    *,
    base_url: str = DEFAULT_URL,
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = DEFAULT_SECRETS_FILE,
    fstab_file: str = DEFAULT_FSTAB,
    timeout_seconds: float = 120.0,
) -> Path:
    url = _normalise_url(base_url)
    mount = _mount_path(mount_point)
    credentials_changed = configure_credentials(username, password, base_url=url, secrets_file=secrets_file)
    configure_fstab(base_url=url, mount_point=str(mount), fstab_file=fstab_file)
    mount.mkdir(parents=True, exist_ok=True)
    if _is_mounted(mount):
        if not credentials_changed:
            return mount
        result = _run(["umount", str(mount)], timeout=min(float(timeout_seconds), 60.0))
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "неизвестная ошибка").strip().replace("\n", " ")
            raise RuntimeError(f"Не удалось перемонтировать Яндекс.Диск после изменения credentials: {detail[:700]}")
    result = _run(["mount", "-t", "davfs", url, str(mount)], timeout=timeout_seconds)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "неизвестная ошибка").strip().replace("\n", " ")
        raise RuntimeError(f"Не удалось смонтировать Яндекс.Диск через davfs2: {detail[:700]}")
    if not _is_mounted(mount):
        raise RuntimeError(f"Команда mount завершилась успешно, но {mount} не является смонтированной файловой системой")
    return mount


def _remote_path(mount: Path, directory: str, filename: str | None = None) -> Path:
    clean = clean_remote_path(directory)
    target = mount / clean if clean else mount
    if filename:
        target = target / Path(filename).name
    return target


def _sync() -> None:
    result = _run(["sync"], timeout=120)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "неизвестная ошибка").strip()
        raise RuntimeError(f"sync после записи Яндекс.Диска завершился ошибкой: {detail[:500]}")


def _copy_atomic(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.part")
    temporary.unlink(missing_ok=True)
    try:
        with source.open("rb") as src, temporary.open("wb") as dst:
            shutil.copyfileobj(src, dst, length=1024 * 1024)
            dst.flush()
            os.fsync(dst.fileno())
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def upload_file(
    path: Path,
    *,
    username: str,
    password: str,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = DEFAULT_SECRETS_FILE,
    fstab_file: str = DEFAULT_FSTAB,
    retries: int = 3,
    verify_attempts: int = 8,
    verify_delay: float = 1.0,
    timeout_seconds: float = 900.0,
) -> tuple[bool, str]:
    source = Path(path)
    if not source.is_file():
        return False, f"Архив не найден: {source}"
    size = source.stat().st_size
    if size <= 0:
        return False, "Архив пуст"
    last_error = "неизвестная ошибка"
    for attempt in range(1, max(1, int(retries)) + 1):
        try:
            mount = ensure_mounted(
                username, password, base_url=base_url, mount_point=mount_point,
                secrets_file=secrets_file, fstab_file=fstab_file,
                timeout_seconds=min(float(timeout_seconds), 300.0),
            )
            destination = _remote_path(mount, directory, source.name)
            _copy_atomic(source, destination)
            _sync()
            verified, detail = verify_remote_file(
                username, password, str(destination), size,
                base_url=base_url, mount_point=mount_point, secrets_file=secrets_file,
                fstab_file=fstab_file, attempts=verify_attempts, delay=verify_delay,
                timeout_seconds=min(float(timeout_seconds), 120.0),
            )
            if not verified:
                raise RuntimeError(f"Файл через davfs2 не подтверждён: {detail}")
            logger.info("davfs2 Yandex upload success file=%s size=%d remote=%s attempt=%d/%d", source.name, size, destination, attempt, retries)
            return True, f"{destination}: {detail}"
        except Exception as exc:  # noqa: BLE001
            last_error = str(exc)
            logger.warning("davfs2 Yandex upload failed file=%s attempt=%d/%d: %s", source.name, attempt, retries, exc)
            if attempt < max(1, int(retries)):
                time.sleep(min(10.0, max(0.0, float(verify_delay))))
    return False, f"После {max(1, int(retries))} попыток загрузка через davfs2 не подтверждена: {last_error}"


def verify_remote_file(
    username: str,
    password: str,
    remote_path: str,
    expected_size: int,
    *,
    base_url: str = DEFAULT_URL,
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = DEFAULT_SECRETS_FILE,
    fstab_file: str = DEFAULT_FSTAB,
    attempts: int = 8,
    delay: float = 1.0,
    timeout_seconds: float = 60.0,
) -> tuple[bool, str]:
    try:
        mount = ensure_mounted(
            username, password, base_url=base_url, mount_point=mount_point,
            secrets_file=secrets_file, fstab_file=fstab_file,
            timeout_seconds=min(float(timeout_seconds), 120.0),
        )
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)
    target = Path(remote_path)
    if not target.is_absolute():
        target = mount / target
    for attempt in range(1, max(1, int(attempts)) + 1):
        try:
            if target.is_file():
                actual = target.stat().st_size
                if actual == int(expected_size):
                    return True, f"{expected_size} байт, размер подтверждён через davfs2"
                return False, f"Размер {actual} байт вместо {expected_size}"
            last = "Файл ещё не виден через смонтированный Яндекс.Диск"
        except OSError as exc:
            last = str(exc)
        if attempt < max(1, int(attempts)) and delay > 0:
            time.sleep(delay)
    return False, last


def delete_resource(username: str, password: str, remote_path: str, *, base_url: str = DEFAULT_URL, mount_point: str = DEFAULT_MOUNT_POINT, secrets_file: str = DEFAULT_SECRETS_FILE, fstab_file: str = DEFAULT_FSTAB) -> None:
    mount = ensure_mounted(username, password, base_url=base_url, mount_point=mount_point, secrets_file=secrets_file, fstab_file=fstab_file)
    target = Path(remote_path)
    if not target.is_absolute():
        target = mount / clean_remote_path(remote_path)
    try:
        target.unlink(missing_ok=True)
        _sync()
    except OSError as exc:
        logger.warning("Не удалось удалить файл Яндекс.Диска %s: %s", target, exc)


def test_connection(
    username: str,
    password: str,
    *,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = DEFAULT_SECRETS_FILE,
    fstab_file: str = DEFAULT_FSTAB,
) -> tuple[bool, str]:
    try:
        mount = ensure_mounted(username, password, base_url=base_url, mount_point=mount_point, secrets_file=secrets_file, fstab_file=fstab_file)
        target = _remote_path(mount, directory)
        target.mkdir(parents=True, exist_ok=True)
        _sync()
        return True, f"davfs2 смонтирован: {mount}; каталог доступен: {target}"
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


def test_write(
    username: str,
    password: str,
    *,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = DEFAULT_SECRETS_FILE,
    fstab_file: str = DEFAULT_FSTAB,
) -> tuple[bool, str]:
    name = f".fargovpn-davfs-test-{time.time_ns()}.txt"
    content = f"FargoVPN davfs2 test {time.time_ns()}\n".encode("utf-8")
    try:
        mount = ensure_mounted(username, password, base_url=base_url, mount_point=mount_point, secrets_file=secrets_file, fstab_file=fstab_file)
        target = _remote_path(mount, directory, name)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        with target.open("r+b") as handle:
            os.fsync(handle.fileno())
        _sync()
        actual = target.stat().st_size
        if actual != len(content):
            return False, f"Тестовая запись создана, но размер {actual} байт вместо {len(content)}"
        try:
            target.unlink(missing_ok=True)
            _sync()
        except OSError as exc:
            logger.warning("Не удалось удалить тестовый файл %s: %s", target, exc)
        return True, f"Тестовая запись через davfs2 успешна: {target} ({actual} байт)"
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


def remote_file_matches(
    path: Path,
    *,
    username: str,
    password: str,
    base_url: str = DEFAULT_URL,
    directory: str = "VPN-Service-Backups",
    mount_point: str = DEFAULT_MOUNT_POINT,
    secrets_file: str = DEFAULT_SECRETS_FILE,
    fstab_file: str = DEFAULT_FSTAB,
) -> tuple[bool, str]:
    source = Path(path)
    if not source.is_file():
        return False, f"Локальная копия не найдена: {source}"
    try:
        mount = ensure_mounted(username, password, base_url=base_url, mount_point=mount_point, secrets_file=secrets_file, fstab_file=fstab_file)
        target = _remote_path(mount, directory, source.name)
        _sync()
        return verify_remote_file(username, password, str(target), source.stat().st_size, base_url=base_url, mount_point=mount_point, secrets_file=secrets_file, fstab_file=fstab_file, attempts=3, delay=1.0)
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)
