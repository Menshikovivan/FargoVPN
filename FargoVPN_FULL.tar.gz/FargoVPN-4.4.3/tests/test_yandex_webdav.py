from pathlib import Path

import yandex_webdav


def test_configure_credentials_replaces_existing_yandex_entries(tmp_path):
    secrets = tmp_path / "secrets"
    secrets.write_text(
        "# keep me\nhttps://webdav.yandex.ru:443 old oldpass\nhttps://example.invalid foo bar\n",
        encoding="utf-8",
    )
    changed = yandex_webdav.configure_credentials("newuser", "newpass", secrets_file=str(secrets))
    assert changed is True
    lines = secrets.read_text(encoding="utf-8").splitlines()
    assert lines.count("https://webdav.yandex.ru:443 newuser newpass") == 1
    assert all("oldpass" not in line for line in lines)
    assert "https://example.invalid foo bar" in lines
    assert oct(secrets.stat().st_mode & 0o777) == "0o600"


def test_configure_fstab_replaces_existing_mount_entry(tmp_path):
    fstab = tmp_path / "fstab"
    mount = tmp_path / "YandexDisk"
    mount.mkdir()
    fstab.write_text(
        "UUID=x / ext4 defaults 0 1\nhttps://webdav.yandex.ru:443 {0} davfs old 0 0\n".format(mount),
        encoding="utf-8",
    )
    yandex_webdav.configure_fstab(fstab_file=str(fstab), mount_point=str(mount))
    lines = [line for line in fstab.read_text(encoding="utf-8").splitlines() if line.strip()]
    davfs = [line for line in lines if f" {mount} davfs " in line]
    assert davfs == [f"https://webdav.yandex.ru:443 {mount} davfs _netdev,nosuid,nodev,noexec 0 0"]


def test_upload_uses_mounted_filesystem_and_sync(tmp_path, monkeypatch):
    archive = tmp_path / "backup.tar.gz"
    archive.write_bytes(b"FargoVPN" * 1024)
    mount = tmp_path / "media"
    (mount / "Backups").mkdir(parents=True)
    calls = []

    monkeypatch.setattr(yandex_webdav, "ensure_mounted", lambda *a, **kw: mount)
    monkeypatch.setattr(yandex_webdav, "_sync", lambda: calls.append("sync"))
    monkeypatch.setattr(yandex_webdav, "verify_remote_file", lambda *a, **kw: (True, "ok"))

    ok, detail = yandex_webdav.upload_file(
        archive,
        username="user",
        password="pass",
        directory="Backups",
        mount_point=str(mount),
        retries=1,
        verify_attempts=1,
        verify_delay=0,
    )
    assert ok is True
    assert (mount / "Backups" / archive.name).read_bytes() == archive.read_bytes()
    assert "sync" in calls
    assert "ok" in detail


def test_mount_command_is_exact_documented_davfs2_flow(tmp_path, monkeypatch):
    mount = tmp_path / "YandexDisk"
    secrets = tmp_path / "secrets"
    fstab = tmp_path / "fstab"
    commands = []

    monkeypatch.setattr(yandex_webdav, "configure_credentials", lambda *a, **kw: None)
    monkeypatch.setattr(yandex_webdav, "configure_fstab", lambda *a, **kw: None)
    state = {"mounted": False}

    def fake_is_mounted(_mount):
        return state["mounted"]

    def fake_run(command, **kwargs):
        commands.append(command)
        if command[:2] == ["mountpoint", "-q"]:
            return type("R", (), {"returncode": 0 if state["mounted"] else 1, "stdout": "", "stderr": ""})()
        if command[:3] == ["mount", "-t", "davfs"]:
            state["mounted"] = True
            return type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})()
        return type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})()

    monkeypatch.setattr(yandex_webdav, "_is_mounted", fake_is_mounted)
    monkeypatch.setattr(yandex_webdav, "_run", fake_run)
    result = yandex_webdav.ensure_mounted(
        "login", "app-password", mount_point=str(mount), secrets_file=str(secrets), fstab_file=str(fstab)
    )
    assert result == mount
    assert ["mount", "-t", "davfs", "https://webdav.yandex.ru:443", str(mount)] in commands


def test_configure_credentials_uses_exact_yandex_webdav_endpoint(tmp_path):
    secrets = tmp_path / "secrets"
    changed = yandex_webdav.configure_credentials("login", "app-password", base_url="https://webdav.yandex.ru", secrets_file=str(secrets))
    assert changed is True
    assert secrets.read_text(encoding="utf-8").strip() == "https://webdav.yandex.ru:443 login app-password"
    assert yandex_webdav.configure_credentials("login", "app-password", base_url="https://webdav.yandex.ru", secrets_file=str(secrets)) is False
